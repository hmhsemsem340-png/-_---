import React, { useState, useEffect } from 'react';
import { RecordItem, ThemeType, AppSettings, AuditLogEntry } from './types';
import { INITIAL_RECORDS } from './data/initialData';
import { Header } from './components/Header';
import { DataTable } from './components/DataTable';
import { DataForm } from './components/DataForm';
import { ImportModal } from './components/ImportModal';
import { BulkEntryModal } from './components/BulkEntryModal';
import { PrintReportModal } from './components/PrintReportModal';
import { SettingsPage } from './components/SettingsPage';
import { ExportModal } from './components/ExportModal';
import { DuplicateRecordModal, DuplicateConflictData } from './components/DuplicateRecordModal';
import { SmartShortcutsBar } from './components/SmartShortcutsBar';
import { Sidebar } from './components/Sidebar';
import { KeyboardHelpModal } from './components/KeyboardHelpModal';
import { BackupRestoreModal } from './components/BackupRestoreModal';
import { GoogleMapsImportModal } from './components/GoogleMapsImportModal';
import { AuditLogModal } from './components/AuditLogModal';
import { SimilarRecordsModal } from './components/SimilarRecordsModal';
import { UnderReviewPage } from './components/UnderReviewPage';
import { CollationEngine } from './utils/collationEngine';
import { DuplicateEngine } from './utils/duplicateEngine';
import { SimilarityEngine } from './utils/similarityEngine';
import { StorageEngine } from './utils/storageEngine';
import { MojibakeEngine } from './utils/mojibakeEngine';
import { recordItemToStreetRecord, streetRecordToRecordItem } from './utils/recordAdapter';
import { MojibakeModal } from './components/MojibakeModal';
import { cleanArabicString, normalizeArabicText } from './utils/arabicEncoding';
import { ArabicUtils } from './utils/arabicUtils';
import { analyzeAllStreetSimilarities, embedSimilarityNoteIntoMetadata, extractStreetRootName } from './utils/streetSimilarity';
import { DEFAULT_DYNAMIC_THEME } from './utils/themeConfig';
import { getAuditUserName, createAuditLogEntry, formatAuditDate } from './utils/auditLogger';
import { parseStreetPrefixAndName } from './utils/streetSplitter';
import * as XLSX from 'xlsx';
import { CheckCircle2 } from 'lucide-react';

export const DEFAULT_STREET_CATEGORIES = [
  'شارع',
  'رئيسي',
  'فرعي',
  'حارة',
  'عطفة',
  'ميدان',
  'طريق',
  'زقاق',
  'درب',
  'سكة',
  'حي'
];

export const DEFAULT_UNOFFICIAL_SUBTYPES = [
  'مأذونية محددة / دفاتر مأذون',
  'محضرين / إعلانات قضائية',
  'شهر عقاري / توثيق / سجل عيني',
  'خرائط مساحية وهيئة المساحة',
  'ضرائب عقارية / عوائد',
  'محاكم وقضايا',
  'داتا خاصة',
  'داتا عقود زواج',
  'داتا بطاقة رقم قومي',
  'مأذونية مقترحة',
  'أخرى (مخصص)'
];

export const OFFICIAL_SEVEN_NOTARIZATIONS = [
  'شبرا بحري',
  'سكنيدة',
  'طاموس',
  'شبرا قبلي',
  'قرطسا بحري',
  'نقرها',
  'قرطسا قبلي'
];

export const DEFAULT_SETTINGS: AppSettings = {
  fontFamily: 'Tahoma, Arial, sans-serif',
  fontSize: 'base',
  printFontSize: '11pt',
  tableDensity: 'normal',
  enableZebra: true,
  cellBorders: true,
  viewMode: 'normal',
  readingModeFontSize: 'xl',
  readingModeHighContrast: true,
  mouseEditQuickTouch: true,
  enableProductivitySuite: true,
  enableSmartAutoCorrect: true,
  enableKeyboardShortcuts: true,
  showDataHealthBar: true,
  showSmartShortcutsBar: true,
  showQuickDistrictTags: true,
  showSidebar: false,
  cleanWorkspaceMode: false,
  conditionalFormatting: true,
  conditionalFormattingAlerts: true,
  conditionalFormattingReviews: true,
  mouseDoubleClickAction: 'edit',
  mouseMiddleClickAction: 'select',
  mouseRightClickMenu: true,
  mouseHoverHighlight: true,
  mouseShowHoverToolbar: true,
  auditAutoSave: true,
  auditAutoSaveDelay: 600,
  auditShowAlphabetRibbon: true,
  auditShowSerialInTable: true,
  auditArrowKeyNavigation: true,
  auditPrefixDrawerMode: true,
  canUnlockRecords: false,
  autoPrecautionUnderReview: false,
  customStreetCategories: DEFAULT_STREET_CATEGORIES,
  customUnofficialSubTypes: DEFAULT_UNOFFICIAL_SUBTYPES,
  suggestedOfficialNotarizations: OFFICIAL_SEVEN_NOTARIZATIONS,
  dynamicTheme: DEFAULT_DYNAMIC_THEME
};

const sanitizeImportedRecords = (raw: unknown): RecordItem[] => {
  if (!Array.isArray(raw)) return [];
  const valid: RecordItem[] = [];
  raw.forEach((item, idx) => {
    if (!item || typeof item !== 'object') return;
    const rec = item as Partial<RecordItem>;
    const name = typeof rec.name === 'string' ? rec.name.trim() : '';
    if (!name) return;
    valid.push({
      id: typeof rec.id === 'string' && rec.id ? rec.id : `json_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`,
      name,
      permission: typeof rec.permission === 'string' ? rec.permission : '',
      metadata: typeof rec.metadata === 'string' ? rec.metadata : '',
      category: typeof rec.category === 'string' && rec.category ? rec.category : 'شارع',
      auditLogs: Array.isArray(rec.auditLogs) ? rec.auditLogs : undefined,
      lastModifiedAt: typeof rec.lastModifiedAt === 'string' ? rec.lastModifiedAt : undefined,
      lastModifiedBy: typeof rec.lastModifiedBy === 'string' ? rec.lastModifiedBy : undefined
    });
  });
  return valid;
};

export default function App() {
  const [records, setRecords] = useState<RecordItem[]>(() => {
    const saved = localStorage.getItem('street_data_records_v2');
    if (saved !== null) {
      try {
        const parsed: RecordItem[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse saved records:', e);
      }
    }
    return INITIAL_RECORDS;
  });

  const [undoHistory, setUndoHistory] = useState<RecordItem[][]>([]);

  const [theme, setTheme] = useState<ThemeType>(() => {
    return (localStorage.getItem('street_data_theme') as ThemeType) || 'excel';
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('street_data_app_settings');
    if (saved) {
      try {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      } catch (e) {
        console.error(e);
      }
    }
    return { ...DEFAULT_SETTINGS };
  });

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isBulkOpen, setIsBulkOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isPrintOpen, setIsPrintOpen] = useState(false);
  const [showSettingsPage, setShowSettingsPage] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'stats' | 'appearance' | 'productivity' | 'data'>('stats');
  const [isAdvancedExportOpen, setIsAdvancedExportOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<RecordItem | null>(null);
  const [lastEditedId, setLastEditedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [duplicateConflict, setDuplicateConflict] = useState<DuplicateConflictData | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isBackupRestoreOpen, setIsBackupRestoreOpen] = useState(false);
  const [isGoogleMapsModalOpen, setIsGoogleMapsModalOpen] = useState(false);
  const [sidebarDistrictFilter, setSidebarDistrictFilter] = useState('');
  const [auditLogRecord, setAuditLogRecord] = useState<RecordItem | null>(null);
  const [isMojibakeOpen, setIsMojibakeOpen] = useState(false);
  const [isSimilarModalOpen, setIsSimilarModalOpen] = useState(false);
  const [similarModalRootFilter, setSimilarModalRootFilter] = useState('');
  const [showUnderReviewPage, setShowUnderReviewPage] = useState(false);

  // Global Keyboard Shortcuts (F1 for Help, Alt+S for Sidebar)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // F1: Open Keyboard Help Modal
      if (e.key === 'F1') {
        e.preventDefault();
        setIsHelpModalOpen(prev => !prev);
        return;
      }

      // Alt+S: Toggle Sidebar
      if (e.altKey && (e.key === 's' || e.key === 'S' || e.key === 'س')) {
        e.preventDefault();
        setIsSidebarOpen(prev => !prev);
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const sortAlphabetically = (items: RecordItem[]) => {
    return CollationEngine.sortRecords(items, 'name', 'asc');
  };

  const handleRepairFromMojibakeModal = (repairedStreetRecords: any[]) => {
    pushUndoSnapshot(records);
    const converted = repairedStreetRecords.map(streetRecordToRecordItem);
    const sorted = sortAlphabetically(converted);
    setRecords(sorted);
    setIsMojibakeOpen(false);
    showToast('✓ تم بنجاح ترميم وتصحيح نصوص الـ Mojibake التالفة وتحديث السجلات');
  };

  const normalizeStreetName = (str: string) => normalizeArabicText(str);

  const pushUndoSnapshot = (prevRecords: RecordItem[]) => {
    setUndoHistory(history => [...history.slice(-14), prevRecords]);
  };

  const handleUndo = () => {
    if (undoHistory.length === 0) {
      showToast('لا توجد عمليات سابقة للتراجع عنها');
      return;
    }
    const previousState = undoHistory[undoHistory.length - 1];
    setUndoHistory(prev => prev.slice(0, -1));
    setRecords(previousState);
    showToast('✓ تم التراجع عن آخر عملية واستعادة السجلات السابقة بنجاح');
  };

  useEffect(() => {
    localStorage.setItem('street_data_records_v2', JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem('street_data_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('street_data_app_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    const autoBackupInterval = setInterval(() => {
      const snapshot = {
        timestamp: new Date().toISOString(),
        records,
        settings
      };
      localStorage.setItem('street_data_json_autosave', JSON.stringify(snapshot));
    }, 60000);

    const handleBeforeUnload = () => {
      const snapshot = {
        timestamp: new Date().toISOString(),
        records,
        settings
      };
      localStorage.setItem('street_data_json_autosave', JSON.stringify(snapshot));
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      clearInterval(autoBackupInterval);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [records, settings]);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  const executeSaveRecord = (item: Omit<RecordItem, 'id'>, editId?: string) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);

    if (editId) {
      const existingRecord = records.find(r => r.id === editId);
      const auditEntry = createAuditLogEntry(existingRecord, item, currentUserName, 'update');
      
      const updatedItem: RecordItem = {
        ...(existingRecord || {}),
        ...item,
        id: editId,
        auditLogs: auditEntry
          ? [auditEntry, ...(existingRecord?.auditLogs || [])]
          : (existingRecord?.auditLogs || []),
        lastModifiedAt: auditEntry?.formattedDate || existingRecord?.lastModifiedAt || formatAuditDate(),
        lastModifiedBy: auditEntry?.userName || existingRecord?.lastModifiedBy || currentUserName
      };

      setRecords(prev => {
        const next = prev.map(r => (r.id === editId ? updatedItem : r));
        return sortAlphabetically(next);
      });
      setEditingRecord(updatedItem);
      setLastEditedId(editId);
      showToast(`✓ تم تحديث وتوثيق (${updatedItem.name}) في سجل المراجعة بنجاح`);
    } else {
      const auditEntry = createAuditLogEntry(null, item, currentUserName, 'create');
      const newItem: RecordItem = {
        ...item,
        id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
        auditLogs: auditEntry ? [auditEntry] : [],
        lastModifiedAt: auditEntry?.formattedDate || formatAuditDate(),
        lastModifiedBy: auditEntry?.userName || currentUserName
      };
      setRecords(prev => {
        const next = [newItem, ...prev];
        return sortAlphabetically(next);
      });
      setLastEditedId(newItem.id);
      showToast(`✓ تم إضافة (${newItem.name}) بنجاح وتوثيق قيد السجل`);
    }
  };

  const findBestSimilarOrDuplicateRecord = (
    item: Omit<RecordItem, 'id'>,
    allRecords: RecordItem[],
    editId?: string
  ): { 
    record: RecordItem; 
    score: number; 
    reason: string; 
    isExact: boolean; 
    isMetadataEqual: boolean;
  } | null => {
    const rawName = item.name.trim();
    if (!rawName || rawName.length < 2) return null;

    const normIncoming = normalizeStreetName(rawName);
    const searchIncoming = ArabicUtils.normalizeForSearch(rawName);
    const rootIncoming = extractStreetRootName(rawName);

    // 1. Direct normalized match
    const exactMatch = allRecords.find(
      r => (!editId || r.id !== editId) && normalizeStreetName(r.name) === normIncoming
    );
    if (exactMatch) {
      const isMetaEqual = ArabicUtils.areMetadataEqual(item.metadata, exactMatch.metadata);
      return {
        record: exactMatch,
        score: 1.0,
        reason: isMetaEqual
          ? 'تطابق كامل وتام في اسم الشارع مع تساوي كامل في البيانات الوصفية (سجل متطابق كلياً)'
          : 'تطابق كامل وتام في اسم الشارع مع سجل موجود مسبقاً',
        isExact: true,
        isMetadataEqual: isMetaEqual
      };
    }

    // 2. Normalized search match (ignoring al-ta'rif, hamzas, etc.)
    const searchMatch = allRecords.find(
      r => (!editId || r.id !== editId) && ArabicUtils.normalizeForSearch(r.name) === searchIncoming
    );
    if (searchMatch) {
      const isMetaEqual = ArabicUtils.areMetadataEqual(item.metadata, searchMatch.metadata);
      return {
        record: searchMatch,
        score: isMetaEqual ? 1.0 : 0.98,
        reason: isMetaEqual
          ? `تطابق تام في الاسم وتساوي في البيانات الوصفية مع اختلاف طفيف في الهمزات أو أل التعريف («${searchMatch.name}»)`
          : `تطابق تام مع اختلاف طفيف في الهمزات أو أل التعريف («${searchMatch.name}»)`,
        isExact: isMetaEqual,
        isMetadataEqual: isMetaEqual
      };
    }

    // 3. Root name match (without prefixes like شارع / حارة / عطفة / درب)
    if (rootIncoming && rootIncoming.length >= 3) {
      const rootMatch = allRecords.find(r => {
        if (editId && r.id === editId) return false;
        const rRoot = extractStreetRootName(r.name);
        return rRoot && rRoot.length >= 3 && rRoot === rootIncoming;
      });
      if (rootMatch) {
        const isMetaEqual = ArabicUtils.areMetadataEqual(item.metadata, rootMatch.metadata);
        return {
          record: rootMatch,
          score: isMetaEqual ? 0.96 : 0.92,
          reason: isMetaEqual
            ? `تشابه وثيق في جذر الاسم («${rootIncoming}») مع تساوي تام في البيانات الوصفية («${rootMatch.name}»)`
            : `تشابه وثيق في جذر الاسم («${rootIncoming}») مع اختلاف البادئة والتصنيف («${rootMatch.name}»)`,
          isExact: isMetaEqual,
          isMetadataEqual: isMetaEqual
        };
      }
    }

    // 4. Phonetic & string similarity score >= 0.78
    let bestCandidate: RecordItem | null = null;
    let bestScore = 0;

    for (const r of allRecords) {
      if (editId && r.id === editId) continue;
      const score = SimilarityEngine.calculateSimilarity(rawName, r.name);
      if (score > bestScore) {
        bestScore = score;
        bestCandidate = r;
      }
    }

    if (bestCandidate && bestScore >= 0.78) {
      const isMetaEqual = ArabicUtils.areMetadataEqual(item.metadata, bestCandidate.metadata);
      const adjustedScore = isMetaEqual ? Math.min(1.0, bestScore + 0.15) : bestScore;
      return {
        record: bestCandidate,
        score: adjustedScore,
        reason: isMetaEqual
          ? `تشابه كتابي بنسبة (${Math.round(adjustedScore * 100)}%) مع تساوي تام في البيانات الوصفية («${bestCandidate.name}»)`
          : `تشابه كتابي ولغوي عالي بنسبة (${Math.round(bestScore * 100)}%) مع الشارع المسجل («${bestCandidate.name}»)`,
        isExact: adjustedScore >= 0.95 || (bestScore >= 0.88 && isMetaEqual),
        isMetadataEqual: isMetaEqual
      };
    }

    return null;
  };

  const handleSaveRecord = (item: Omit<RecordItem, 'id'>, editId?: string, isAutoSave: boolean = false) => {
    // 1. Silent Background Auto-Save: Always execute directly without interrupting user with duplicate modal
    if (isAutoSave && editId) {
      executeSaveRecord(item, editId);
      return;
    }

    // 2. Editing an existing record:
    if (editId) {
      const match = findBestSimilarOrDuplicateRecord(item, records, editId);
      // Trigger duplicate conflict only if the edited data collides with a DIFFERENT record (exact match, or high similarity with matching metadata)
      if (match && match.record.id !== editId && (match.isExact || (match.score >= 0.88 && match.isMetadataEqual))) {
        const isSamePermission = normalizeStreetName(match.record.permission) === normalizeStreetName(item.permission);
        setIsAddOpen(false);
        setIsBulkOpen(false);
        setDuplicateConflict({
          item,
          editId,
          existingRecord: match.record,
          isSamePermission,
          isMetadataEqual: match.isMetadataEqual,
          similarityScore: match.score,
          matchReason: match.reason
        });
        return;
      }
      // If no conflict with other records, save the modified name, metadata, permission, and category directly
      executeSaveRecord(item, editId);
      return;
    }

    // 3. New Record Entry: Check for exact or highly similar records to offer merge/view
    const match = findBestSimilarOrDuplicateRecord(item, records, undefined);
    if (match) {
      const isSamePermission = normalizeStreetName(match.record.permission) === normalizeStreetName(item.permission);
      setIsAddOpen(false);
      setIsBulkOpen(false);
      setDuplicateConflict({
        item,
        editId: undefined,
        existingRecord: match.record,
        isSamePermission,
        isMetadataEqual: match.isMetadataEqual,
        similarityScore: match.score,
        matchReason: match.reason
      });
      return;
    }

    executeSaveRecord(item, undefined);
  };

  const handleViewExistingFromDuplicate = (existingRecord: RecordItem) => {
    setDuplicateConflict(null);
    setEditingRecord(existingRecord);
    setIsAddOpen(true);
    showToast(`👁️ تم فتح السجل الحالي المسجل بالنظام: "${existingRecord.name}"`);
  };

  const handleOpenSimilarModal = (rootName?: string) => {
    setSimilarModalRootFilter(rootName || '');
    setIsSimilarModalOpen(true);
  };

  const handleUpdateRecordFromSimilar = (updated: RecordItem) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);
    const oldRec = records.find(r => r.id === updated.id);
    const isNowTruth = updated.status === 'تام' || updated.isTruthRecord;
    const wasTruth = oldRec?.status === 'تام' || oldRec?.isTruthRecord;

    let changeReason = 'تحديث وتصنيف من مركز فحص المتشابهات';
    if (isNowTruth && !wasTruth) {
      changeReason = 'اعتماد كـ «عنوان الحقيقة 🔒» (بيان تام مغلق)';
    } else if (!isNowTruth && wasTruth) {
      changeReason = 'فك قفل البيان التام للاستثناء والمراجعة';
    }

    const auditEntry = createAuditLogEntry(oldRec, updated, currentUserName, 'status_change', changeReason);
    const itemWithAudit: RecordItem = {
      ...updated,
      lastModifiedAt: auditEntry?.formattedDate || formatAuditDate(),
      lastModifiedBy: auditEntry?.userName || currentUserName,
      auditLogs: auditEntry ? [auditEntry, ...(oldRec?.auditLogs || [])] : (oldRec?.auditLogs || [])
    };

    setRecords(prev => prev.map(r => (r.id === updated.id ? itemWithAudit : r)));
    setLastEditedId(updated.id);
    showToast(`✓ تم تحديث (${updated.name}) ${isNowTruth ? 'واعتماده كعنوان حقيقة مغلق 🔒' : 'بنجاح'}`);
  };

  const handleBatchUpdateRecordsFromSimilar = (updatedList: RecordItem[]) => {
    pushUndoSnapshot(records);
    const updateMap = new Map(updatedList.map(u => [u.id, u]));
    setRecords(prev => prev.map(r => updateMap.get(r.id) || r));
    showToast(`✓ تم تحديث (${updatedList.length}) سجل من مركز فحص وتصنيف المتشابهات`);
  };

  const handleMergeDuplicateNotes = (
    existingId: string, 
    incomingItemOrMetadata: string | Omit<RecordItem, 'id'>, 
    incomingCategory?: string
  ) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);

    const isFullItem = typeof incomingItemOrMetadata === 'object' && incomingItemOrMetadata !== null;
    // CRITICAL: Always fall back to duplicateConflict.item to guarantee street name and metadata are never lost
    const incomingItem = isFullItem 
      ? (incomingItemOrMetadata as Omit<RecordItem, 'id'>) 
      : (duplicateConflict?.item || null);

    const incomingMetadata = isFullItem 
      ? incomingItem!.metadata 
      : (typeof incomingItemOrMetadata === 'string' ? incomingItemOrMetadata : duplicateConflict?.item?.metadata || '');

    const resolvedCategory = incomingItem?.category || incomingCategory || duplicateConflict?.item?.category;
    const conflictEditId = duplicateConflict?.editId;

    let targetUpdatedRecord: RecordItem | null = null;

    setRecords(prev => {
      // If the duplicate conflict originated from editing an existing separate record, remove that old record
      const baseList = (conflictEditId && conflictEditId !== existingId)
        ? prev.filter(r => r.id !== conflictEditId)
        : prev;

      const target = baseList.find(r => r.id === existingId);
      if (!target) return baseList;

      const currentMeta = target.metadata?.trim() || '';
      const newMeta = (incomingMetadata || '').trim();

      // Smart merge notes using semantic deduplication engine
      let merged = ArabicUtils.smartMergeNotes(currentMeta, newMeta);

      // Intelligent street name and landmark handling:
      // Landmark prefix patterns e.g. "بجوار كلية الشريعه والقانون شارع الرحاب"
      const landmarkPattern = /^(بجوار|خلف|أمام|بجانب|قرب|ناحية|تقاطع|متفرع من|عمارة|برج|مسجد|كنيسة|مستشفى|مدرسة|كلية|صيدلية|ميدان|محطة|سوق|دائر|عطفة)\s+(.+)$/i;
      const incomingRawName = incomingItem?.name?.trim() || '';
      let finalName = target.name;

      if (incomingRawName && incomingRawName !== target.name) {
        const incomingHasLandmark = landmarkPattern.test(incomingRawName);
        const targetHasLandmark = landmarkPattern.test(target.name);

        if (incomingHasLandmark && !targetHasLandmark) {
          // If incoming has descriptive landmark prefix and target has a clean canonical street name:
          // Keep target's clean name and append the descriptive landmark text into metadata notes
          finalName = target.name;
          merged = ArabicUtils.smartMergeNotes(merged, incomingRawName);
        } else if (!incomingHasLandmark && targetHasLandmark) {
          // If incoming is clean and target has landmark, adopt clean name and preserve target's old landmark in metadata
          finalName = incomingRawName;
          merged = ArabicUtils.smartMergeNotes(merged, target.name);
        } else {
          finalName = incomingRawName;
        }
      }

      // Preserve or upgrade permission and add cross-reference if shared
      let finalPermission = target.permission;
      const incomingPerm = incomingItem?.permission?.trim() || '';
      if (incomingPerm) {
        if (!target.permission || target.permission === 'غير محدد' || target.permission === 'عام') {
          finalPermission = incomingPerm;
        } else if (target.permission !== incomingPerm) {
          // If permissions differ, preserve main permission and note shared permission in metadata
          const crossRefTag = `[مشترك مع مأذونية: ${incomingPerm}]`;
          if (!merged.includes(incomingPerm)) {
            merged = ArabicUtils.smartMergeNotes(merged, '', crossRefTag);
          }
        }
      }

      const finalCategory = resolvedCategory?.trim() ? resolvedCategory.trim() : (target.category || 'شارع');
      const finalStatus = incomingItem?.status || target.status;
      const finalIsLocked = incomingItem?.isLocked ?? target.isLocked ?? false;
      const finalIsTruth = incomingItem?.isTruthRecord ?? target.isTruthRecord ?? false;

      const updatedPayload: Omit<RecordItem, 'id'> = {
        name: finalName,
        permission: finalPermission,
        category: finalCategory,
        metadata: merged,
        status: finalStatus,
        isLocked: finalIsLocked,
        isTruthRecord: finalIsTruth
      };

      const auditEntry = createAuditLogEntry(
        target, 
        updatedPayload, 
        currentUserName, 
        'update', 
        `دمج وتحديث بيانات السجل تلقائياً (اعتماد الاسم: «${finalName}» والملاحظات) لتفادي التكرار وحفظ البيانات الوصفية`
      );

      const finalItem: RecordItem = {
        ...target,
        ...updatedPayload,
        lastModifiedAt: auditEntry?.formattedDate || formatAuditDate(),
        lastModifiedBy: auditEntry?.userName || currentUserName,
        auditLogs: auditEntry ? [auditEntry, ...(target.auditLogs || [])] : target.auditLogs
      };

      targetUpdatedRecord = finalItem;

      const updatedList = baseList.map(r => r.id === existingId ? finalItem : r);
      return sortAlphabetically(updatedList);
    });

    if (targetUpdatedRecord) {
      setEditingRecord(targetUpdatedRecord);
    }
    setLastEditedId(existingId);
    showToast(`✓ تم بنجاح دمج وتحديث بيانات الشارع والملاحظات الوصفية باسم («${targetUpdatedRecord?.name || incomingItem?.name || 'المعتمد'}») دون تكرار`);
    setDuplicateConflict(null);
  };

  const handleReplaceDuplicateRecord = (existingId: string, newItem: Omit<RecordItem, 'id'>) => {
    pushUndoSnapshot(records);
    const existingRecord = records.find(r => r.id === existingId);
    const currentUserName = getAuditUserName(settings.reviewerName);
    const auditEntry = createAuditLogEntry(existingRecord, newItem, currentUserName, 'update', 'استبدال بيانات السجل الأصلي بعد مراجعة التكرار');
    const conflictEditId = duplicateConflict?.editId;
    
    const updated: RecordItem = {
      ...newItem,
      id: existingId,
      lastModifiedAt: auditEntry?.formattedDate || existingRecord?.lastModifiedAt,
      lastModifiedBy: auditEntry?.userName || existingRecord?.lastModifiedBy,
      auditLogs: auditEntry ? [auditEntry, ...(existingRecord?.auditLogs || [])] : existingRecord?.auditLogs
    };

    setRecords(prev => {
      const baseList = (conflictEditId && conflictEditId !== existingId)
        ? prev.filter(r => r.id !== conflictEditId)
        : prev;
      const next = baseList.map(r => (r.id === existingId ? updated : r));
      return sortAlphabetically(next);
    });
    setEditingRecord(updated);
    setLastEditedId(existingId);
    showToast(`✓ تم تحديث وتوثيق استبدال بيانات (${updated.name}) بنجاح`);
    setDuplicateConflict(null);
  };

  const handleSaveAsSeparateDuplicate = (newItem: Omit<RecordItem, 'id'>) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);
    const auditEntry = createAuditLogEntry(null, newItem, currentUserName, 'create', 'حفظ كإدخال مكرر منفصل');
    const formattedItem: RecordItem = {
      ...newItem,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      lastModifiedAt: auditEntry?.formattedDate || formatAuditDate(),
      lastModifiedBy: auditEntry?.userName || currentUserName,
      auditLogs: auditEntry ? [auditEntry] : []
    };
    setRecords(prev => sortAlphabetically([formattedItem, ...prev]));
    setLastEditedId(formattedItem.id);
    showToast(`✓ تم حفظ الشارع وتوثيقه كإدخال منفصل بنجاح`);
    setDuplicateConflict(null);
  };

  const handleCancelDuplicate = () => {
    setDuplicateConflict(null);
    showToast('تم إلغاء إضافة الشارع المكرر بناءً على رغبتك');
  };

  const handleDeleteRecord = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا السجل؟')) {
      pushUndoSnapshot(records);
      setRecords(prev => prev.filter(r => r.id !== id));
      showToast('تم حذف السجل بنجاح (يمكنك التراجع عبر زر التراجع)');
    }
  };

  const handleImportData = (
    imported: Omit<RecordItem, 'id'>[],
    mode: 'append' | 'replace',
    decisions: Record<number, 'merge' | 'replace' | 'separate' | 'skip'> = {}
  ) => {
    if (mode === 'replace') {
      const confirmed = window.confirm(
        `تحذير: سيتم حذف جميع السجلات الحالية (${records.length.toLocaleString('ar-EG')}) واستبدالها بالبيانات المستوردة. هل أنت متأكد من المتابعة؟`
      );
      if (!confirmed) {
        showToast('تم إلغاء الاستيراد، لم يتم حذف أي سجل');
        return;
      }
    }

    pushUndoSnapshot(records);

    if (mode === 'replace') {
      const newItems: RecordItem[] = imported.map((item, idx) => ({
        ...item,
        id: `imp_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`
      }));
      setRecords(sortAlphabetically(newItems));
      showToast(`✓ تم استبدال السجلات بنجاح بإجمالي (${newItems.length}) شارع`);
      return;
    }

    // Append mode with duplicate decision handling
    const existingMap = new Map<string, RecordItem>();
    records.forEach(r => {
      existingMap.set(normalizeStreetName(r.name), { ...r });
    });

    const newAdditions: RecordItem[] = [];
    let mergedCount = 0;
    let replacedCount = 0;
    let skippedCount = 0;

    imported.forEach((item, idx) => {
      const normName = normalizeStreetName(item.name);
      const match = existingMap.get(normName);
      const decision = decisions[idx] || (match ? 'skip' : 'separate');

      if (!match || decision === 'separate') {
        newAdditions.push({
          ...item,
          id: `imp_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`
        });
      } else if (decision === 'merge') {
        mergedCount++;
        const currentMeta = match.metadata?.trim() || '';
        const incomingMeta = item.metadata?.trim() || '';
        const mergedMeta = ArabicUtils.smartMergeNotes(currentMeta, incomingMeta);

        existingMap.set(normName, {
          ...match,
          metadata: mergedMeta,
          category: match.category || item.category || 'شارع'
        });
      } else if (decision === 'replace') {
        replacedCount++;
        existingMap.set(normName, {
          ...item,
          id: match.id
        });
      } else if (decision === 'skip') {
        skippedCount++;
      }
    });

    const combined = [...Array.from(existingMap.values()), ...newAdditions];
    setRecords(sortAlphabetically(combined));

    const parts: string[] = [];
    if (newAdditions.length > 0) parts.push(`إضافة ${newAdditions.length} جديد`);
    if (mergedCount > 0) parts.push(`دمج ${mergedCount}`);
    if (replacedCount > 0) parts.push(`تحديث ${replacedCount}`);
    if (skippedCount > 0) parts.push(`تخطي ${skippedCount} مكرر`);

    showToast(`✓ اكتمل الاستيراد: ${parts.join('، ') || 'لم يطرأ تغيير'}`);
  };

  const handleBulkAddRecords = (
    newItems: Omit<RecordItem, 'id'>[],
    strategy: 'merge' | 'skip' | 'separate' = 'merge'
  ) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);

    if (strategy === 'separate') {
      const addedItems: RecordItem[] = newItems.map((item, idx) => ({
        ...item,
        id: `bulk_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`,
        lastModifiedAt: formatAuditDate(),
        lastModifiedBy: currentUserName,
        auditLogs: [
          {
            id: `audit_${Date.now()}_${idx}`,
            timestamp: new Date().toISOString(),
            formattedDate: formatAuditDate(),
            userName: currentUserName,
            action: 'create',
            changes: [],
            note: 'إدراج عبر إدخال القوائم المجمعة للمأذونية'
          }
        ]
      }));

      setRecords(prev => sortAlphabetically([...addedItems, ...prev]));
      showToast(`✓ تم بنجاح إدراج (${addedItems.length}) شارع جديد وتنظيمها أبجدياً`);
      return;
    }

    const existingMap = new Map<string, RecordItem>();
    records.forEach(r => {
      existingMap.set(normalizeStreetName(r.name), { ...r });
    });

    const newAdditions: RecordItem[] = [];
    let mergedCount = 0;
    let skippedCount = 0;

    newItems.forEach((item, idx) => {
      const norm = normalizeStreetName(item.name);
      const matched = existingMap.get(norm);

      if (!matched) {
        newAdditions.push({
          ...item,
          id: `bulk_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 4)}`,
          lastModifiedAt: formatAuditDate(),
          lastModifiedBy: currentUserName,
          auditLogs: [
            {
              id: `audit_${Date.now()}_${idx}`,
              timestamp: new Date().toISOString(),
              formattedDate: formatAuditDate(),
              userName: currentUserName,
              action: 'create',
              changes: [],
              note: 'إدراج عبر إدخال القوائم المجمعة للمأذونية'
            }
          ]
        });
      } else if (strategy === 'merge') {
        mergedCount++;
        const currentMeta = matched.metadata?.trim() || '';
        const incomingMeta = item.metadata?.trim() || '';
        const merged = ArabicUtils.smartMergeNotes(currentMeta, incomingMeta);

        const auditEntry: AuditLogEntry = {
          id: `audit_merge_${Date.now()}_${idx}`,
          timestamp: new Date().toISOString(),
          formattedDate: formatAuditDate(),
          userName: currentUserName,
          action: 'note_update',
          changes: [
            {
              field: 'metadata',
              fieldLabel: 'البيان الوصفي والتوثيقي',
              oldValue: currentMeta,
              newValue: merged
            }
          ],
          note: 'دمج وتحديث بيانات وملاحظات الشارع من إدخال القوائم'
        };

        existingMap.set(norm, {
          ...matched,
          metadata: merged,
          category: matched.category || item.category || 'شارع',
          status: item.status || matched.status || 'نشط',
          lastModifiedAt: formatAuditDate(),
          lastModifiedBy: currentUserName,
          auditLogs: [auditEntry, ...(matched.auditLogs || [])]
        });
      } else if (strategy === 'skip') {
        skippedCount++;
      }
    });

    const combined = [...Array.from(existingMap.values()), ...newAdditions];
    setRecords(sortAlphabetically(combined));

    const parts: string[] = [];
    if (newAdditions.length > 0) parts.push(`إضافة ${newAdditions.length} شارع جديد`);
    if (mergedCount > 0) parts.push(`دمج وتحديث ${mergedCount} سجل موجود مسبقاً`);
    if (skippedCount > 0) parts.push(`تخطي ${skippedCount} مكرر`);

    showToast(`✓ اكتملت المعالجة والإدراج: ${parts.join('، ') || 'تم التحقق من القائمة'}`);
  };

  const handleRepairMojibake = () => {
    pushUndoSnapshot(records);
    let repairedCount = 0;
    const repaired = records.map(r => {
      const fixedName = cleanArabicString(r.name);
      const fixedPerm = cleanArabicString(r.permission);
      const fixedMeta = cleanArabicString(r.metadata);
      const fixedCat = cleanArabicString(r.category);

      if (
        fixedName !== r.name ||
        fixedPerm !== r.permission ||
        fixedMeta !== r.metadata ||
        fixedCat !== r.category
      ) {
        repairedCount++;
      }

      return {
        ...r,
        name: fixedName,
        permission: fixedPerm,
        metadata: fixedMeta,
        category: fixedCat
      };
    });

    setRecords(sortAlphabetically(repaired));
    showToast(
      repairedCount > 0
        ? `✓ تم فحص وتصحيح ترميز (${repairedCount}) سجلاً بنجاح دون أي فقدان للبيانات`
        : '✓ تم فحص قاعدة البيانات بالكامل: جميع النصوص والحروف العربية سليمة 100%'
    );
  };

  const handleExportJSON = () => {
    const dataStr = JSON.stringify({
      appName: 'منظومة الشوارع و المأذونيات بدمنهور',
      exportDate: new Date().toISOString(),
      totalRecords: records.length,
      records: records,
      settings: settings
    }, null, 2);

    const blob = new Blob([dataStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `damanhur_streets_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('✓ تم تنزيل النسخة الاحتياطية JSON بنجاح');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        let items: RecordItem[] = [];

        if (Array.isArray(parsed)) {
          items = sanitizeImportedRecords(parsed);
        } else if (parsed && typeof parsed === 'object' && Array.isArray(parsed.records)) {
          items = sanitizeImportedRecords(parsed.records);
          if (parsed.settings && typeof parsed.settings === 'object') {
            setSettings(prev => ({ ...prev, ...parsed.settings }));
          }
        }

        if (items.length === 0) {
          showToast('الملف لا يحتوي على سجلات شوارع صالحة');
          return;
        }

        pushUndoSnapshot(records);
        setRecords(sortAlphabetically(items));
        showToast(`✓ تم بنجاح استعادة (${items.length}) شارع من النسخة الاحتياطية`);
      } catch (err) {
        console.error(err);
        showToast('فشل قراءة ملف JSON، يرجى التأكد من سلامة صيغة الملف');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleResetData = () => {
    pushUndoSnapshot(records);
    setRecords(INITIAL_RECORDS);
    showToast('تم استعادة السجلات النموذجية المعتمدة بنجاح');
  };

  const handleExportExcel = () => {
    const dataToExport = records.map((r, index) => {
      const parsed = parseStreetPrefixAndName(r.name, r.category);
      return {
        'م': index + 1,
        'اسم الشارع': parsed.cleanName,
        'المأذونية / جهة الاختصاص': r.permission,
        'النوع': parsed.detectedType,
        'البيان الوصفي / الملاحظات': r.metadata
      };
    });

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    ws['!dir'] = 'rtl';
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'شوارع دمنهور');

    XLSX.writeFile(wb, `شوارع_ومأذونيات_دمنهور_${new Date().toISOString().slice(0, 10)}.xlsx`);
    showToast('✓ تم تصدير ملف Excel بنجاح');
  };

  const handleExportCSV = () => {
    const similarityMap = analyzeAllStreetSimilarities(records);
    const rows = records.map((r, idx) => {
      const simInfo = similarityMap.get(r.id);
      const metaWithSim = (simInfo?.suggestedNote && (!r.metadata || !r.metadata.includes(simInfo.suggestedNote)))
        ? embedSimilarityNoteIntoMetadata(r.metadata, simInfo.suggestedNote)
        : (r.metadata || '');
      const parsed = parseStreetPrefixAndName(r.name, r.category);
      return [
        idx + 1,
        parsed.cleanName,
        r.permission || '',
        parsed.detectedType,
        metaWithSim
      ];
    });

    const headers = ['م', 'اسم الشارع', 'المأذونية / جهة الاختصاص', 'النوع', 'البيان الوصفي / الملاحظات'];
    const csvContent = [headers, ...rows]
      .map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
      .join('\r\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `شوارع_ومأذونيات_دمنهور_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('✓ تم تصدير ملف CSV العربي المتوافق مع الجداول بنجاح');
  };

  const handleEmbedSimilarityNote = (recordId: string, noteToEmbed: string) => {
    pushUndoSnapshot(records);
    setRecords(prev => {
      return prev.map(r => {
        if (r.id === recordId) {
          return {
            ...r,
            metadata: embedSimilarityNoteIntoMetadata(r.metadata, noteToEmbed)
          };
        }
        return r;
      });
    });
    showToast(`✓ تم تضمين ملاحظة (${noteToEmbed}) في السجل بنجاح`);
  };

  const handleEmbedAllSimilarities = () => {
    const similarityMap = analyzeAllStreetSimilarities(records);
    let updatedCount = 0;
    pushUndoSnapshot(records);
    setRecords(prev => {
      return prev.map(r => {
        const info = similarityMap.get(r.id);
        if (info?.hasSimilarity && info.suggestedNote) {
          const newMeta = embedSimilarityNoteIntoMetadata(r.metadata, info.suggestedNote);
          if (newMeta !== r.metadata) {
            updatedCount++;
            return {
              ...r,
              metadata: newMeta
            };
          }
        }
        return r;
      });
    });
    showToast(`✓ تم تحديث وتضمين ملاحظات الاشتراك تلقائياً لـ (${updatedCount}) سجل`);
  };

  const handleQuickUpdateNote = (id: string, newMetadata: string) => {
    pushUndoSnapshot(records);
    const currentUserName = getAuditUserName(settings.reviewerName);
    setRecords(prev => prev.map(r => {
      if (r.id !== id) return r;
      const oldMeta = (r.metadata || '').trim();
      const nextMeta = (newMetadata || '').trim();
      if (oldMeta === nextMeta) return r;
      const log = createAuditLogEntry(r, {
        name: r.name,
        permission: r.permission,
        category: r.category,
        metadata: nextMeta
      }, currentUserName, 'note_update', 'تعديل سريع للملاحظات والحدود');
      return {
        ...r,
        metadata: nextMeta,
        lastModifiedAt: log?.formattedDate || r.lastModifiedAt,
        lastModifiedBy: log?.userName || r.lastModifiedBy,
        auditLogs: log ? [log, ...(r.auditLogs || [])] : r.auditLogs
      };
    }));
    setLastEditedId(id);
    showToast('✓ تم تحديث وحفظ ملاحظات الشارع وتوثيق التعديل في سجل المراجعة');
  };

  const handleBatchDelete = (ids: string[]) => {
    if (ids.length === 0) return;
    pushUndoSnapshot(records);
    const idSet = new Set(ids);
    setRecords(prev => prev.filter(r => !idSet.has(r.id)));
    showToast(`✓ تم بنجاح حذف (${ids.length}) سجل محدد`);
  };

  const handleBatchChangePermission = (ids: string[], newPermission: string) => {
    if (ids.length === 0 || !newPermission) return;
    pushUndoSnapshot(records);
    const idSet = new Set(ids);
    const currentUserName = getAuditUserName(settings.reviewerName);
    setRecords(prev => prev.map(r => {
      if (!idSet.has(r.id)) return r;
      if (r.permission === newPermission) return r;
      const log = createAuditLogEntry(r, {
        name: r.name,
        permission: newPermission,
        category: r.category,
        metadata: r.metadata
      }, currentUserName, 'permission_update', `تعديل مأذونية جماعي إلى «${newPermission}»`);
      return {
        ...r,
        permission: newPermission,
        lastModifiedAt: log?.formattedDate || r.lastModifiedAt,
        lastModifiedBy: log?.userName || r.lastModifiedBy,
        auditLogs: log ? [log, ...(r.auditLogs || [])] : r.auditLogs
      };
    }));
    showToast(`✓ تم تحديث وتوثيق مأذونية (${ids.length}) سجل إلى «${newPermission}»`);
  };

  const handleQuickBatchFill = (params: {
    fillType: 'permission' | 'metadata' | 'both' | 'autoInferPermission';
    targetPermission?: string;
    targetMetadata?: string;
    onlyEmpty: boolean;
    selectedIds?: string[];
  }) => {
    pushUndoSnapshot(records);
    let updatedCount = 0;

    const nameToPermMap = new Map<string, string>();
    if (params.fillType === 'autoInferPermission') {
      records.forEach(r => {
        if (r.permission && r.permission.trim() && r.permission !== 'غير محدد') {
          const norm = normalizeArabicText(r.name);
          if (norm && !nameToPermMap.has(norm)) {
            nameToPermMap.set(norm, r.permission);
          }
        }
      });
    }

    setRecords(prev => {
      return prev.map(r => {
        if (params.selectedIds && params.selectedIds.length > 0 && !params.selectedIds.includes(r.id)) {
          return r;
        }

        let modified = false;
        let newPerm = r.permission;
        let newMeta = r.metadata;

        if (params.fillType === 'autoInferPermission') {
          if (!r.permission || !r.permission.trim() || r.permission === 'غير محدد') {
            const norm = normalizeArabicText(r.name);
            if (norm && nameToPermMap.has(norm)) {
              newPerm = nameToPermMap.get(norm)!;
              modified = true;
            }
          }
        }

        if (params.fillType === 'permission' || params.fillType === 'both') {
          const isPermEmpty = !r.permission || !r.permission.trim() || r.permission === 'غير محدد';
          if ((params.onlyEmpty ? isPermEmpty : true) && params.targetPermission) {
            newPerm = params.targetPermission;
            modified = true;
          }
        }

        if (params.fillType === 'metadata' || params.fillType === 'both') {
          const isMetaEmpty = !r.metadata || !r.metadata.trim();
          if ((params.onlyEmpty ? isMetaEmpty : true) && params.targetMetadata !== undefined) {
            newMeta = params.targetMetadata;
            modified = true;
          }
        }

        if (modified) {
          updatedCount++;
          return {
            ...r,
            permission: newPerm,
            metadata: newMeta
          };
        }
        return r;
      });
    });

    showToast(`✓ تم بنجاح تعبئة وضبط (${updatedCount}) سجل`);
  };

  const handleRestoreData = (newRecords: RecordItem[], restoredSettings?: Partial<AppSettings>, isMerge?: boolean) => {
    pushUndoSnapshot(records);
    if (isMerge) {
      const existingNames = new Set(records.map(r => normalizeArabicText(r.name)));
      const uniqueNew = newRecords.filter(r => !existingNames.has(normalizeArabicText(r.name)));
      setRecords(prev => sortAlphabetically([...prev, ...uniqueNew]));
      showToast(`✓ تم دمج (${uniqueNew.length}) سجل جديد مع الحفاظ على السجلات الحالية`);
    } else {
      setRecords(sortAlphabetically(newRecords));
      showToast(`✓ تم استعادة قاعدة البيانات بنجاح (${newRecords.length} سجل)`);
    }

    if (restoredSettings) {
      setSettings(prev => ({
        ...prev,
        ...restoredSettings
      }));
    }
  };

  const handleGoogleMapsImport = (importedStreets: RecordItem[]) => {
    pushUndoSnapshot(records);
    
    // Merge logic: Update existing matching names with rich metadata/district or append new streets
    const existingMap = new Map<string, RecordItem>();
    records.forEach(r => {
      existingMap.set(normalizeArabicText(r.name), r);
    });

    let addedCount = 0;
    let updatedCount = 0;
    const updatedRecords = [...records];

    importedStreets.forEach(item => {
      const norm = normalizeArabicText(item.name);
      if (existingMap.has(norm)) {
        // Update existing record if it had empty permission or metadata
        const existingRec = existingMap.get(norm)!;
        const targetIdx = updatedRecords.findIndex(r => r.id === existingRec.id);
        if (targetIdx !== -1) {
          const current = updatedRecords[targetIdx];
          const needsPermUpdate = !current.permission || current.permission === 'غير محدد';
          const needsMetaUpdate = !current.metadata || !current.metadata.trim();
          if (needsPermUpdate || needsMetaUpdate) {
            updatedRecords[targetIdx] = {
              ...current,
              permission: needsPermUpdate ? item.permission : current.permission,
              metadata: current.metadata ? `${current.metadata} | ${item.metadata}` : item.metadata,
              category: current.category === 'غير محدد' ? item.category : current.category
            };
            updatedCount++;
          }
        }
      } else {
        // New record to add
        updatedRecords.push(item);
        existingMap.set(norm, item);
        addedCount++;
      }
    });

    const sorted = sortAlphabetically(updatedRecords);
    setRecords(sorted);
    showToast(`✓ تم استيراد وتحديث شوارع الكتلة العمرانية لدمنهور (إضافة ${addedCount} جديد، وتحديث ${updatedCount} سجل)`);
  };

  const handleMarkAllAsUnderReview = (preserveLocked = false, customReason?: string) => {
    pushUndoSnapshot(records);
    let updatedCount = 0;
    const currentUserName = getAuditUserName(settings.reviewerName);
    const now = new Date();
    const formattedDate = formatAuditDate(now);
    const decisionNote = customReason?.trim() || 'تم وضع السجل في حالة «قيد المراجعة» كإجراء احترازي بقرار إداري حفاظاً على جودة البيانات ودقتها';

    const updated = records.map(r => {
      if (preserveLocked && (r.status === 'تام' || r.isLocked)) {
        return r;
      }
      updatedCount++;
      const auditLog: AuditLogEntry = {
        id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        timestamp: now.toISOString(),
        formattedDate,
        userName: currentUserName,
        action: 'status_change',
        changes: [
          {
            field: 'status',
            fieldLabel: 'حالة السجل والاعتماد',
            oldValue: r.status || 'نشط',
            newValue: 'قيد المراجعة'
          }
        ],
        note: decisionNote
      };

      return {
        ...r,
        status: 'قيد المراجعة' as const,
        isLocked: false,
        isTruthRecord: false,
        lastModifiedAt: formattedDate,
        lastModifiedBy: currentUserName,
        auditLogs: [auditLog, ...(r.auditLogs || [])]
      };
    });

    setRecords(sortAlphabetically(updated));
    showToast(`✓ تم تحويل (${updatedCount}) سجل بنجاح إلى «قيد المراجعة 🔍» وتوثيق القرار الإداري في سجل التدقيق`);
  };

  return (
    <div 
      className={`min-h-screen flex flex-col bg-gray-100/70 text-gray-900 ${
        settings.fontFamily === 'cairo' 
          ? 'font-cairo' 
          : settings.fontFamily === 'tajawal' 
            ? 'font-tajawal' 
            : settings.fontFamily === 'almarai'
              ? 'font-almarai'
              : 'font-sans'
      }`}
      dir="rtl"
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-gray-700 animate-in fade-in slide-in-from-top-4 duration-200 max-w-md text-center">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs sm:text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Main App Header */}
      <Header
        theme={theme}
        setTheme={setTheme}
        settings={settings}
        totalCount={records.length}
        underReviewCount={records.filter(r => r.status === 'قيد المراجعة').length}
        onOpenAdd={() => {
          setEditingRecord(null);
          setIsAddOpen(true);
          setShowSettingsPage(false);
          setShowUnderReviewPage(false);
        }}
        onOpenAudit={() => {
          setEditingRecord(records.length > 0 ? records[0] : null);
          setIsAddOpen(true);
          setShowSettingsPage(false);
          setShowUnderReviewPage(false);
        }}
        onOpenBulk={() => setIsBulkOpen(true)}
        onOpenImport={() => setIsImportOpen(true)}
        onOpenGoogleMapsImport={() => setIsGoogleMapsModalOpen(true)}
        onOpenSimilarModal={handleOpenSimilarModal}
        onOpenUnderReviewPage={() => {
          setShowUnderReviewPage(true);
          setShowSettingsPage(false);
          setIsAddOpen(false);
        }}
        onOpenPrint={() => setIsPrintOpen(true)}
        onOpenSettings={(tab = 'stats') => {
          setSettingsTab(tab);
          setShowSettingsPage(true);
          setShowUnderReviewPage(false);
        }}
        onExportExcel={handleExportExcel}
        onExportCSV={handleExportCSV}
        onOpenAdvancedExport={() => setIsAdvancedExportOpen(true)}
        onResetData={handleResetData}
        onExportJSON={handleExportJSON}
        onImportJSON={handleImportJSON}
        onOpenBackupRestore={() => setIsBackupRestoreOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
        onOpenHelp={() => setIsHelpModalOpen(true)}
        onOpenMojibakeScanner={() => setIsMojibakeOpen(true)}
        onUpdateSettings={setSettings}
      />

      <main className="flex-1 max-w-[1560px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-5">
        {showSettingsPage ? (
          <SettingsPage
            onBack={() => setShowSettingsPage(false)}
            settings={settings}
            onUpdateSettings={setSettings}
            theme={theme}
            setTheme={setTheme}
            records={records}
            onExportJSON={handleExportJSON}
            onImportJSON={handleImportJSON}
            onResetData={handleResetData}
            onRepairMojibake={handleRepairMojibake}
            onOpenImport={() => setIsImportOpen(true)}
            onOpenAdvancedExport={() => setIsAdvancedExportOpen(true)}
            onOpenBackupRestore={() => setIsBackupRestoreOpen(true)}
            onMarkAllUnderReview={handleMarkAllAsUnderReview}
            initialTab={settingsTab}
          />
        ) : showUnderReviewPage ? (
          <UnderReviewPage
            onBack={() => setShowUnderReviewPage(false)}
            records={records}
            onUpdateRecord={handleSaveRecord}
            onBatchUpdateRecords={(updatedList) => {
              pushUndoSnapshot(records);
              const map = new Map(updatedList.map(u => [u.id, u]));
              setRecords(prev => sortAlphabetically(prev.map(r => map.get(r.id) || r)));
              showToast(`✓ تم تحديث واعتماد (${updatedList.length}) سجل بنجاح`);
            }}
            onDeleteRecord={handleDeleteRecord}
            onToast={showToast}
            theme={theme}
            settings={settings}
            onOpenSimilarModal={handleOpenSimilarModal}
            onMarkAllUnderReview={handleMarkAllAsUnderReview}
          />
        ) : isAddOpen ? (
          <DataForm
            onClose={() => {
              setIsAddOpen(false);
              setEditingRecord(null);
            }}
            onSave={handleSaveRecord}
            onSaveBulk={handleBulkAddRecords}
            existingRecords={records}
            editRecord={editingRecord}
            theme={theme}
            settings={settings}
            onUpdateSettings={setSettings}
            onOpenSimilarModal={handleOpenSimilarModal}
            onOpenUnderReviewPage={() => {
              setShowUnderReviewPage(true);
              setIsAddOpen(false);
            }}
          />
        ) : (
          <DataTable
            records={records}
            onEdit={(record) => {
              setEditingRecord(record);
              setIsAddOpen(true);
            }}
            onViewAuditLog={(record) => {
              setAuditLogRecord(record);
            }}
            onOpenAudit={(record) => {
              setAuditLogRecord(record || (records.length > 0 ? records[0] : null));
            }}
            onDelete={handleDeleteRecord}
            onBatchDelete={handleBatchDelete}
            onBatchChangePermission={handleBatchChangePermission}
            onToast={showToast}
            theme={theme}
            settings={settings}
            lastEditedId={lastEditedId}
            onQuickUpdateNote={handleQuickUpdateNote}
            onQuickBatchFill={handleQuickBatchFill}
            onEmbedSimilarityNote={handleEmbedSimilarityNote}
            onEmbedAllSimilarities={handleEmbedAllSimilarities}
            onUpdateSettings={setSettings}
            onOpenSimilarModal={handleOpenSimilarModal}
            onOpenUnderReviewPage={() => {
              setShowUnderReviewPage(true);
              setShowSettingsPage(false);
              setIsAddOpen(false);
            }}
            onBatchUpdateRecords={(updatedList) => {
              pushUndoSnapshot(records);
              const map = new Map(updatedList.map(u => [u.id, u]));
              setRecords(prev => sortAlphabetically(prev.map(r => map.get(r.id) || r)));
            }}
            activeDistrictFilter={sidebarDistrictFilter}
            onClearDistrictFilter={() => setSidebarDistrictFilter('')}
          />
        )}
      </main>

      <footer className="bg-white border-t border-gray-200 py-4 text-center text-xs text-gray-500">
        <p>منظومة الشوارع و المأذونيات بدمنهور © 2026 • مالك البرنامج: الأستاذ/ حسام الدين الخولي</p>
      </footer>

      {/* Floating Smart Productivity & Shortcuts Bar */}
      {settings.showSmartShortcutsBar !== false && (
        <SmartShortcutsBar
          onOpenAdd={() => {
            setEditingRecord(null);
            setIsAddOpen(true);
            setShowSettingsPage(false);
          }}
          onFocusSearch={() => {
            setShowSettingsPage(false);
            setIsAddOpen(false);
            setTimeout(() => {
              document.getElementById('main-search-input')?.focus();
            }, 50);
          }}
          onUndo={handleUndo}
          canUndo={undoHistory.length > 0}
          undoCount={undoHistory.length}
          settings={settings}
          onUpdateSettings={setSettings}
          theme={theme}
          onOpenHelp={() => setIsHelpModalOpen(true)}
          onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
        />
      )}

      {/* Lateral Sidebar Drawer */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        records={records}
        theme={theme}
        settings={settings}
        activeDistrictFilter={sidebarDistrictFilter}
        onSelectDistrictFilter={(district) => {
          setSidebarDistrictFilter(district);
          setIsSidebarOpen(false);
          setShowSettingsPage(false);
          setIsAddOpen(false);
        }}
        onOpenAdd={() => {
          setEditingRecord(null);
          setIsAddOpen(true);
          setShowSettingsPage(false);
          setIsSidebarOpen(false);
        }}
        onOpenBulk={() => {
          setIsBulkOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenImport={() => {
          setIsImportOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenGoogleMapsImport={() => {
          setIsGoogleMapsModalOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenUnderReviewPage={() => {
          setShowUnderReviewPage(true);
          setShowSettingsPage(false);
          setIsAddOpen(false);
          setIsSidebarOpen(false);
        }}
        onOpenPrint={() => {
          setIsPrintOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenAdvancedExport={() => {
          setIsAdvancedExportOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenBackupRestore={() => {
          setIsBackupRestoreOpen(true);
          setIsSidebarOpen(false);
        }}
        onOpenSettings={(tab = 'stats') => {
          setSettingsTab(tab);
          setShowSettingsPage(true);
          setIsSidebarOpen(false);
        }}
        onOpenHelp={() => {
          setIsSidebarOpen(false);
          setIsHelpModalOpen(true);
        }}
        onRepairMojibake={handleRepairMojibake}
        onQuickFill={() => handleQuickBatchFill({ fillType: 'autoInferPermission', onlyEmpty: true })}
      />

      {/* Comprehensive Keyboard Help Modal */}
      <KeyboardHelpModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
        theme={theme}
        settings={settings}
      />

      {/* Local Cloud Restoration & Encrypted Backup Modal */}
      <BackupRestoreModal
        isOpen={isBackupRestoreOpen}
        onClose={() => setIsBackupRestoreOpen(false)}
        records={records}
        settings={settings}
        theme={theme}
        onRestoreData={handleRestoreData}
        onToast={showToast}
      />

      {/* Modals */}
      <GoogleMapsImportModal
        isOpen={isGoogleMapsModalOpen}
        onClose={() => setIsGoogleMapsModalOpen(false)}
        existingRecords={records}
        onImportAndUpdate={handleGoogleMapsImport}
      />

      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportData={handleImportData}
        existingRecords={records}
        theme={theme}
      />

      <BulkEntryModal
        isOpen={isBulkOpen}
        onClose={() => setIsBulkOpen(false)}
        onAddBulk={handleBulkAddRecords}
        existingRecords={records}
        theme={theme}
      />

      <PrintReportModal
        isOpen={isPrintOpen}
        onClose={() => setIsPrintOpen(false)}
        records={records}
        theme={theme}
        settings={settings}
      />

      <ExportModal
        isOpen={isAdvancedExportOpen}
        onClose={() => setIsAdvancedExportOpen(false)}
        records={records}
        theme={theme}
        settings={settings}
        onToast={showToast}
      />

      {duplicateConflict && (
        <DuplicateRecordModal
          isOpen={Boolean(duplicateConflict)}
          conflict={duplicateConflict}
          onClose={handleCancelDuplicate}
          onMergeNotes={handleMergeDuplicateNotes}
          onReplaceExisting={handleReplaceDuplicateRecord}
          onSaveAsDuplicate={handleSaveAsSeparateDuplicate}
          onViewExisting={handleViewExistingFromDuplicate}
          theme={theme}
        />
      )}

      {/* Audit Log Modal (سجل التعديلات والتوثيق القانوني) */}
      {auditLogRecord && (
        <AuditLogModal
          record={auditLogRecord}
          onClose={() => setAuditLogRecord(null)}
          onEditRecord={(rec) => {
            setEditingRecord(rec);
            setIsAddOpen(true);
          }}
        />
      )}

      {/* Mojibake Text Reconstruction Center (مركز ترميم النصوص المشوهة) */}
      <MojibakeModal
        isOpen={isMojibakeOpen}
        onClose={() => setIsMojibakeOpen(false)}
        records={records.map(recordItemToStreetRecord)}
        onRepairAll={handleRepairFromMojibakeModal}
      />

      {/* Similar Records Hub & Ground Truth Management (مركز فحص وتصنيف المتشابهات وعناوين الحقيقة) */}
      <SimilarRecordsModal
        isOpen={isSimilarModalOpen}
        onClose={() => {
          setIsSimilarModalOpen(false);
          setSimilarModalRootFilter('');
        }}
        records={records}
        onUpdateRecord={handleUpdateRecordFromSimilar}
        onBatchUpdateRecords={handleBatchUpdateRecordsFromSimilar}
        onSelectForEdit={(record) => {
          setEditingRecord(record);
          setIsAddOpen(true);
          setIsSimilarModalOpen(false);
        }}
        initialFilterName={similarModalRootFilter}
      />

    </div>
  );
}
