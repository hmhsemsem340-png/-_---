import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Shield,
  ShieldCheck,
  Lock,
  Unlock,
  Download,
  Upload,
  Calendar,
  Clock,
  UserCheck,
  FileCheck,
  RefreshCw,
  Copy,
  Check,
  AlertTriangle,
  Database,
  Layers,
  Sparkles,
  Info,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { RecordItem, ThemeType, AppSettings } from '../types';
import { getFormattedDatabaseTimestamps, FormattedDatabaseTime, getExportFileTimestamp } from '../utils/dateTimeUtils';
import { 
  createEncryptedBackup, 
  decryptBackup, 
  BackupPayload, 
  BackupEnvelope 
} from '../utils/encryptionUtils';
import { OFFICIAL_DISTRICTS } from '../utils/districtColors';

interface BackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: RecordItem[];
  settings: AppSettings;
  theme: ThemeType;
  onRestoreData: (newRecords: RecordItem[], restoredSettings?: Partial<AppSettings>, isMerge?: boolean) => void;
  onToast: (msg: string) => void;
}

export function BackupRestoreModal({
  isOpen,
  onClose,
  records,
  settings,
  theme,
  onRestoreData,
  onToast
}: BackupRestoreModalProps) {
  const [activeTab, setActiveTab] = useState<'backup' | 'restore'>('backup');

  // Backup State
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordHint, setPasswordHint] = useState('');
  const [useEncryption, setUseEncryption] = useState(true);
  const [reviewerName, setReviewerName] = useState(settings.reviewerName || 'مراجع السجلات المعتمد');
  const [backupScope, setBackupScope] = useState<'all' | 'district'>('all');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [includeSettings, setIncludeSettings] = useState(true);
  const [customNote, setCustomNote] = useState('');
  const [isGeneratingBackup, setIsGeneratingBackup] = useState(false);
  const [copied, setCopied] = useState(false);

  // Restore State
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoreRawText, setRestoreRawText] = useState('');
  const [restorePassword, setRestorePassword] = useState('');
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [decryptedPreview, setDecryptedPreview] = useState<BackupPayload | null>(null);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [restoreMode, setRestoreMode] = useState<'replace' | 'merge'>('replace');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Live Database Timestamps
  const [currentTimestamps, setCurrentTimestamps] = useState<FormattedDatabaseTime>(() => getFormattedDatabaseTimestamps());

  useEffect(() => {
    if (isOpen) {
      setCurrentTimestamps(getFormattedDatabaseTimestamps());
      setReviewerName(settings.reviewerName || 'مراجع السجلات المعتمد');
      setRestoreError(null);
      setDecryptedPreview(null);
      setRestoreFile(null);
      setRestoreRawText('');
      setRestorePassword('');
    }
  }, [isOpen, settings.reviewerName]);

  if (!isOpen) return null;

  // Filtered records for backup
  const recordsToBackup = backupScope === 'district' && selectedDistrict
    ? records.filter(r => r.permission === selectedDistrict)
    : records;

  const handleExportBackup = async (andCopyText = false) => {
    if (useEncryption) {
      if (!password || password.length < 4) {
        onToast('⚠️ يرجى إدخال كلمة مرور من 4 أحرف أو أرقام على الأقل لحماية النسخة');
        return;
      }
      if (password !== confirmPassword) {
        onToast('⚠️ كلمتا المرور غير متطابقتين، يرجى التأكد وإعادة الإدخال');
        return;
      }
    }

    try {
      setIsGeneratingBackup(true);
      const timestamps = getFormattedDatabaseTimestamps();
      
      const payload: BackupPayload = {
        version: '2.0',
        app: 'damanhour-streets-system',
        createdAt: new Date().toISOString(),
        timestamps,
        reviewerName: reviewerName.trim() || undefined,
        recordCount: recordsToBackup.length,
        records: recordsToBackup,
        settings: includeSettings ? settings : undefined,
        customNotes: customNote.trim() || undefined
      };

      const envelope = await createEncryptedBackup(
        payload,
        useEncryption ? password : undefined,
        passwordHint
      );

      const jsonStr = JSON.stringify(envelope, null, 2);

      if (andCopyText) {
        await navigator.clipboard.writeText(jsonStr);
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
        onToast('✓ تم نسخ حزمة النسخة الاحتياطية المشفرة إلى الحافظة بنجاح');
      } else {
        const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
        const filename = `damanhour_backup_${getExportFileTimestamp()}_${useEncryption ? 'encrypted' : 'plain'}.damanhour-backup`;
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);

        onToast(`✓ تم إنشاء وتنزيل ملف النسخة الاحتياطية (${recordsToBackup.length} سجل) بنجاح`);
      }
    } catch (err: any) {
      onToast(`فشل إنشاء النسخة الاحتياطية: ${err?.message || 'خطأ غير متوقع'}`);
    } finally {
      setIsGeneratingBackup(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setRestoreFile(file);
    setRestoreError(null);
    setDecryptedPreview(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      setRestoreRawText(content);
      attemptQuickParse(content);
    };
    reader.readAsText(file, 'utf-8');
  };

  const attemptQuickParse = async (contentStr: string, manualPassword?: string) => {
    setRestoreError(null);
    try {
      const parsed = JSON.parse(contentStr);
      const pwd = manualPassword !== undefined ? manualPassword : restorePassword;
      
      // If it's encrypted and no password provided yet
      if (parsed.format === 'damanhour-encrypted-backup' || parsed.isEncrypted === true) {
        if (!pwd) {
          setRestoreError('هذا الملف مشفر ومحمي بكلمة مرور. يرجى إدخال كلمة المرور بالأسفل للمعاينة والاستعادة.');
          return;
        }
      }

      setIsDecrypting(true);
      const decrypted = await decryptBackup(parsed, pwd);
      setDecryptedPreview(decrypted);
      setRestoreError(null);
      onToast('✓ تم فك تشفير والتحقق من سلامة النسخة الاحتياطية بنجاح');
    } catch (err: any) {
      setDecryptedPreview(null);
      setRestoreError(err?.message || 'تعذر قراءة أو فك تشفير الملف، تأكد من كلمة المرور وصحة الملف');
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleExecuteRestore = () => {
    if (!decryptedPreview || !decryptedPreview.records) {
      onToast('⚠️ لا توجد بيانات صالحة للاستعادة');
      return;
    }

    const isMerge = restoreMode === 'merge';
    onRestoreData(decryptedPreview.records, decryptedPreview.settings, isMerge);
    onToast(
      isMerge 
        ? `✓ تم دمج ${decryptedPreview.records.length} سجل بنجاح مع السجلات الحالية`
        : `✓ تم استعادة قاعدة البيانات بالكامل (${decryptedPreview.records.length} سجل) بنجاح`
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
      <div className="bg-white rounded-3xl shadow-2xl border border-gray-200 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-l from-gray-900 via-gray-800 to-emerald-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">الاستعادة والنسخ الاحتياطي المشفر</h2>
              <p className="text-xs text-gray-300 font-medium">حماية ونقل قاعدة بيانات شوارع دمنهور بين الأجهزة بأمان تام</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white rounded-xl hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Database Timestamp & Status Bar */}
        <div className="px-5 py-2.5 bg-emerald-50/80 border-b border-emerald-100 flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-900">
          <div className="flex items-center gap-2 font-bold">
            <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>ميلادي: {currentTimestamps.gregorianDate}</span>
            <span className="text-emerald-400">•</span>
            <span>هجري: {currentTimestamps.hijriDate}</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <Clock className="w-3.5 h-3.5" />
            <span>الساعة: {currentTimestamps.gregorianTime}</span>
            <span className="text-emerald-400">•</span>
            <span>{records.length} سجل حالي</span>
          </div>
        </div>

        {/* Tabs Bar */}
        <div className="px-5 pt-3 bg-gray-50 border-b border-gray-200 flex gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`pb-3 px-4 font-black text-sm border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'backup'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>إنشاء نسخة احتياطية مشفرة</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('restore')}
            className={`pb-3 px-4 font-black text-sm border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'restore'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-800'
            }`}
          >
            <Unlock className="w-4 h-4" />
            <span>فك التشفير والاستعادة</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1 text-gray-800">
          
          {activeTab === 'backup' ? (
            <div className="space-y-4">
              
              {/* Reviewer & Timestamps Info Card */}
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 space-y-3">
                <h4 className="text-xs font-black text-gray-900 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span>بيانات التوثيق والتدقيق المعتمدة</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">اسم المراجع / مدقق القاعدة:</label>
                    <input
                      type="text"
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="مثال: مراجع السجلات المعتمد / أ. حسام"
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">نطاق التصدير والحفظ:</label>
                    <select
                      value={backupScope}
                      onChange={(e: any) => setBackupScope(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                    >
                      <option value="all">كافة سجلات القاعدة ({records.length} سجل)</option>
                      <option value="district">مأذونية / منطقة مخصصة فقط</option>
                    </select>
                  </div>
                </div>

                {backupScope === 'district' && (
                  <div className="pt-1">
                    <label className="block text-xs font-bold text-gray-700 mb-1">اختر المأذونية المطلوب حفظها:</label>
                    <select
                      value={selectedDistrict}
                      onChange={(e) => setSelectedDistrict(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                    >
                      <option value="">-- اختر المأذونية --</option>
                      {OFFICIAL_DISTRICTS.map(d => (
                        <option key={d.name} value={d.name}>{d.name} ({records.filter(r => r.permission === d.name).length} سجل)</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Encryption Settings */}
              <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-emerald-700" />
                    <span className="text-xs font-black text-emerald-950">تشفير وحماية بكلمة مرور (AES-256)</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={useEncryption}
                      onChange={(e) => setUseEncryption(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-gray-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                {useEncryption ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">كلمة المرور:</label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="أدخل كلمة مرور قوية"
                        className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">تأكيد كلمة المرور:</label>
                      <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="أعد إدخال كلمة المرور"
                        className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-700 mb-1">تلميح كلمة المرور (اختياري):</label>
                      <input
                        type="text"
                        value={passwordHint}
                        onChange={(e) => setPasswordHint(e.target.value)}
                        placeholder="مثال: رقم هاتف العمل أو تاريخ تأسيس المكتب"
                        className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      />
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-amber-800 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                    ⚠️ سيتم حفظ النسخة كملف بيانات قياسي مفتوح دون تشفير، مناسب للاستخدام السريع الداخلي.
                  </p>
                )}
              </div>

              {/* Advanced Options */}
              <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200 space-y-2 text-xs">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={includeSettings}
                    onChange={(e) => setIncludeSettings(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>تضمين إعدادات الخطوط والسمة الديناميكية المخصصة مع النسخة</span>
                </label>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">ملاحظات توثيقية إضافية للنسخة (اختياري):</label>
                  <input
                    type="text"
                    value={customNote}
                    onChange={(e) => setCustomNote(e.target.value)}
                    placeholder="مثال: نسخة معتمدة بعد مراجعة مأذونية قبلي ونقرها بالكامل"
                    className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => handleExportBackup(false)}
                  disabled={isGeneratingBackup}
                  className="flex-1 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل ملف النسخة الاحتياطية (.damanhour-backup)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleExportBackup(true)}
                  disabled={isGeneratingBackup}
                  className="py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'تم النسخ' : 'نسخ الحزمة المشفرة'}</span>
                </button>
              </div>

            </div>
          ) : (
            <div className="space-y-4">
              
              {/* File Upload Box */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-6 border-2 border-dashed border-gray-300 hover:border-emerald-500 bg-gray-50 hover:bg-emerald-50/40 rounded-3xl transition cursor-pointer text-center space-y-2"
              >
                <Upload className="w-8 h-8 text-emerald-600 mx-auto" />
                <div className="text-xs sm:text-sm font-black text-gray-800">
                  {restoreFile ? restoreFile.name : 'انقر لاختيار ملف النسخة الاحتياطية أو اسحبه هنا'}
                </div>
                <p className="text-[11px] text-gray-500">
                  يدعم ملفات النسخ الاحتياطي المشفرة (.damanhour-backup) أو ملفات JSON السحابية
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".damanhour-backup,.json,.enc.json"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>

              {/* Password Input for Encrypted Files */}
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 space-y-2">
                <label className="block text-xs font-bold text-gray-800">
                  كلمة المرور لفك التشفير (إذا كان الملف محمياً):
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={restorePassword}
                    onChange={(e) => setRestorePassword(e.target.value)}
                    placeholder="أدخل كلمة مرور الملف..."
                    className="flex-1 px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => attemptQuickParse(restoreRawText, restorePassword)}
                    disabled={!restoreRawText || isDecrypting}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                  >
                    {isDecrypting ? 'جاري الفك...' : 'تحقق وفك'}
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {restoreError && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-2.5 text-xs text-amber-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{restoreError}</span>
                </div>
              )}

              {/* Decrypted Inspection Preview */}
              {decryptedPreview && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                    <div className="flex items-center gap-2 text-xs font-black text-emerald-950">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>بيانات النسخة جاهزة للاستعادة</span>
                    </div>
                    <span className="px-2.5 py-0.5 bg-emerald-200 text-emerald-900 rounded-lg text-[11px] font-bold">
                      {decryptedPreview.records?.length || 0} سجل موثق
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-700">
                    <div>
                      <span className="font-bold text-gray-500">تاريخ الإنشاء ميلادي:</span>{' '}
                      <span className="font-bold text-gray-900">{decryptedPreview.timestamps?.gregorianFull || decryptedPreview.createdAt}</span>
                    </div>
                    <div>
                      <span className="font-bold text-gray-500">تاريخ الإنشاء هجري:</span>{' '}
                      <span className="font-bold text-gray-900">{decryptedPreview.timestamps?.hijriFull || '-'}</span>
                    </div>
                    <div>
                      <span className="font-bold text-gray-500">المراجع المعتمد:</span>{' '}
                      <span className="font-bold text-emerald-800">{decryptedPreview.reviewerName || 'غير محدد'}</span>
                    </div>
                    <div>
                      <span className="font-bold text-gray-500">ملاحظات النسخة:</span>{' '}
                      <span className="font-medium text-gray-800">{decryptedPreview.customNotes || 'لا توجد'}</span>
                    </div>
                  </div>

                  {/* Restore Mode Selection */}
                  <div className="pt-2 border-t border-emerald-200">
                    <label className="block text-xs font-bold text-emerald-950 mb-1.5">طريقة الاستعادة والتطبيق:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setRestoreMode('replace')}
                        className={`p-2.5 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                          restoreMode === 'replace'
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        استبدال كامل للقاعدة
                      </button>
                      <button
                        type="button"
                        onClick={() => setRestoreMode('merge')}
                        className={`p-2.5 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                          restoreMode === 'merge'
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        دمج ذكي مع السجلات الحالية
                      </button>
                    </div>
                  </div>

                  {/* Execute Button */}
                  <button
                    type="button"
                    onClick={handleExecuteRestore}
                    className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-black text-xs sm:text-sm transition shadow-md cursor-pointer mt-2"
                  >
                    تأكيد وتطبيق الاستعادة على قاعدة البيانات الآن
                  </button>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500 shrink-0">
          <div className="flex items-center gap-1.5">
            <Info className="w-4 h-4 text-emerald-600" />
            <span>يتم التشفير بالكامل محلياً على جهازك دون إرسال أي بيانات لخوادم خارجية</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-xl font-bold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
}
