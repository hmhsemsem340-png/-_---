import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  FileSpreadsheet,
  FileDown,
  FileText,
  FileCode2,
  Printer,
  ExternalLink,
  Layers,
  ListOrdered,
  Building2,
  Type,
  Palette,
  Download,
  Loader2,
  CheckCircle2,
  Share2,
  FileCheck
} from 'lucide-react';
import ExcelJS from 'exceljs';
import * as XLSX from 'xlsx';
import { RecordItem, ThemeType, AppSettings } from '../types';
import { getThemeColors, ThemeColors } from '../utils/themeConfig';
import { getDistrictColor, OFFICIAL_DISTRICTS } from '../utils/districtColors';
import { normalizeArabicText } from '../utils/arabicEncoding';
import { generateReportHtml, exportToProtectedPdf } from '../utils/exportHelpers';
import { getLibreOfficeStatus, openInLibreOffice, LibreOfficeStatus } from '../utils/libreoffice';
import { analyzeAllStreetSimilarities, embedSimilarityNoteIntoMetadata } from '../utils/streetSimilarity';
import { getFormattedDatabaseTimestamps, FormattedDatabaseTime } from '../utils/dateTimeUtils';
import { downloadSystemFeaturesMarkdown } from '../utils/downloadMarkdown';
import { parseStreetPrefixAndName } from '../utils/streetSplitter';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: RecordItem[];
  theme: ThemeType;
  settings?: AppSettings;
  onToast: (msg: string) => void;
}

type ExportMode = 'all' | 'permission' | 'district' | 'sequence' | 'alphabet';
type ExportFormat = 'xlsx' | 'ods' | 'csv' | 'html' | 'pdf';

const ARABIC_ALPHABET = ['ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'];

const MODE_LABELS: Record<ExportMode, string> = {
  all: 'كل السجلات',
  permission: 'حسب المأذونية',
  district: 'حسب المنطقة الرسمية',
  sequence: 'بنفس الترتيب الحالي',
  alphabet: 'حسب الحرف الأبجدي'
};

const FORMAT_LABELS: Record<ExportFormat, string> = {
  xlsx: 'Excel منسّق (.xlsx)',
  ods: 'OpenDocument (.ods)',
  csv: 'CSV عربي متوافق (.csv)',
  html: 'HTML منسّق',
  pdf: 'PDF للطباعة'
};

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function toArgb(hex: string): string {
  return hex.replace('#', 'FF');
}

/**
 * Builds export data array with automatic indexing and optional embedded similarity notes
 */
function buildExportRows(
  records: RecordItem[],
  similarityMap?: Map<string, any>,
  includeSimilarityNotes: boolean = false
): Record<string, string | number>[] {
  return records.map((r, index) => {
    let finalMeta = r.metadata || '-';
    if (includeSimilarityNotes && similarityMap) {
      const sim = similarityMap.get(r.id);
      if (sim?.suggestedNote) {
        finalMeta = embedSimilarityNoteIntoMetadata(r.metadata || '', sim.suggestedNote);
      }
    }

    const parsed = parseStreetPrefixAndName(r.name, r.category);

    return {
      'م': index + 1,
      'اسم الشارع': parsed.cleanName,
      'المأذونية': r.permission || 'غير محدد',
      'النوع': parsed.detectedType,
      'البيانات الوصفية والملاحظات': finalMeta
    };
  });
}

/**
 * Generates custom CSV string with proper escaping and custom delimiter
 */
function generateCustomCsv(
  rows: Record<string, string | number>[],
  delimiter: ',' | ';' = ','
): string {
  if (rows.length === 0) return '';
  const headers = Object.keys(rows[0]);
  
  const escapeCell = (val: string | number | undefined | null) => {
    if (val === undefined || val === null) return '""';
    const str = String(val);
    if (str.includes(delimiter) || str.includes('"') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return `"${str}"`;
  };

  const lines: string[] = [];
  // Header line
  lines.push(headers.map(escapeCell).join(delimiter));

  // Data rows
  rows.forEach(row => {
    const line = headers.map(h => escapeCell(row[h])).join(delimiter);
    lines.push(line);
  });

  return lines.join('\r\n');
}

async function buildFormattedWorkbook(
  records: RecordItem[],
  colors: ThemeColors,
  zebra: boolean,
  districtColors: boolean,
  similarityMap?: Map<string, any>,
  includeSimilarityNotes: boolean = false,
  reviewerName?: string,
  includeTimestamps: boolean = true,
  columns?: AppSettings['dynamicTheme']['columns']
): Promise<ExcelJS.Workbook> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'منظومة الشوارع و المأذونيات بدمنهور';
  workbook.created = new Date();
  const ws = workbook.addWorksheet('البيانات', { views: [{ rightToLeft: true }] });

  const timestamps = getFormattedDatabaseTimestamps();

  const colAlignments: ('center' | 'right' | 'left')[] = [
    (columns?.index?.align as any) || 'center',
    (columns?.name?.align as any) || 'right',
    (columns?.permission?.align as any) || 'right',
    (columns?.category?.align as any) || 'center',
    (columns?.metadata?.align as any) || 'right',
  ];

  const isBoldCol: boolean[] = [
    columns?.index?.fontWeight === 'bold' || columns?.index?.fontWeight === 'black',
    columns?.name?.fontWeight === 'bold' || columns?.name?.fontWeight === 'black' || true,
    columns?.permission?.fontWeight === 'bold' || columns?.permission?.fontWeight === 'black' || true,
    columns?.category?.fontWeight === 'bold' || columns?.category?.fontWeight === 'black',
    columns?.metadata?.fontWeight === 'bold' || columns?.metadata?.fontWeight === 'black',
  ];

  // Column widths definition
  ws.columns = [
    { key: 'col1', width: 8 },
    { key: 'col2', width: 45 },
    { key: 'col3', width: 24 },
    { key: 'col4', width: 15 },
    { key: 'col5', width: 55 }
  ];

  let headerRowIndex = 1;

  if (includeTimestamps) {
    // Row 1: Title Banner
    const titleRow = ws.addRow(['منظومة الشوارع والمأذونيات بدمنهور - كشف معتمد وموثق']);
    titleRow.height = 28;
    ws.mergeCells('A1:E1');
    const titleCell = ws.getCell('A1');
    titleCell.font = { name: 'Amiri', size: 14, bold: true, color: { argb: 'FFFFFFFF' } };
    titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: toArgb(colors.hexHeader) } };
    titleCell.alignment = { vertical: 'middle', horizontal: 'center' };

    // Row 2: Gregorian & Hijri Timestamps & Reviewer Banner
    const metaText = `التاريخ الميلادي: ${timestamps.gregorianDate} • التاريخ الهجري: ${timestamps.hijriDate} (الساعة: ${timestamps.gregorianTime}) • المراجع: ${reviewerName || 'مراجع السجلات المعتمد'}`;
    const metaRow = ws.addRow([metaText]);
    metaRow.height = 22;
    ws.mergeCells('A2:E2');
    const metaCell = ws.getCell('A2');
    metaCell.font = { name: 'Amiri', size: 10, bold: true, color: { argb: 'FF1F2937' } };
    metaCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: toArgb(colors.hexZebra) } };
    metaCell.alignment = { vertical: 'middle', horizontal: 'center' };

    headerRowIndex = 3;
  }

  // Header Row
  const tableHeaders = ['م', 'اسم الشارع', 'المأذونية', 'النوع', 'البيانات الوصفية والملاحظات'];
  const headerRow = ws.addRow(tableHeaders);
  headerRow.height = 26;
  headerRow.eachCell((cell, colNumber) => {
    cell.font = { name: 'Amiri', size: 12, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: toArgb(colors.hexHeader) } };
    cell.alignment = { vertical: 'middle', horizontal: colAlignments[colNumber - 1] || 'center' };
    cell.border = {
      top: { style: 'thin', color: { argb: toArgb(colors.hexHeader) } },
      bottom: { style: 'thin', color: { argb: toArgb(colors.hexHeader) } },
      left: { style: 'thin', color: { argb: 'FFD1D5DB' } },
      right: { style: 'thin', color: { argb: 'FFD1D5DB' } }
    };
  });

  records.forEach((r, index) => {
    let finalMeta = r.metadata || '-';
    if (includeSimilarityNotes && similarityMap) {
      const sim = similarityMap.get(r.id);
      if (sim?.suggestedNote) {
        finalMeta = embedSimilarityNoteIntoMetadata(r.metadata || '', sim.suggestedNote);
      }
    }

    const parsed = parseStreetPrefixAndName(r.name, r.category);
    const row = ws.addRow([index + 1, parsed.cleanName, r.permission || 'غير محدد', parsed.detectedType, finalMeta]);
    const bg = zebra && index % 2 === 1 ? colors.hexZebra : colors.hexZebraAlt;
    const district = districtColors ? getDistrictColor(r.permission, r.metadata, r.name) : null;

    row.eachCell((cell, colNumber) => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: toArgb(bg) } };
      cell.font = { 
        name: 'Amiri', 
        size: 11, 
        bold: isBoldCol[colNumber - 1] || false,
        color: { argb: 'FF111827' } 
      };
      cell.alignment = {
        vertical: 'middle',
        horizontal: colAlignments[colNumber - 1] || (colNumber === 1 ? 'center' : 'right')
      };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        bottom: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        left: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        right: { style: 'thin', color: { argb: 'FFD1D5DB' } }
      };
    });

    if (district) {
      const permCell = row.getCell(3);
      permCell.font = { name: 'Amiri', size: 11, bold: true, color: { argb: toArgb(district.hex) } };
    }
  });

  ws.autoFilter = { from: `A${headerRowIndex}`, to: `E${headerRowIndex + records.length}` };
  ws.views = [{ rightToLeft: true, state: 'frozen', ySplit: headerRowIndex }];
  return workbook;
}

export function ExportModal({
  isOpen,
  onClose,
  records,
  theme,
  settings,
  onToast
}: ExportModalProps) {
  const [exportMode, setExportMode] = useState<ExportMode>('all');
  const [selectedPermission, setSelectedPermission] = useState<string>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedLetter, setSelectedLetter] = useState<string>('ا');
  const [exportFormat, setExportFormat] = useState<ExportFormat>('xlsx');
  const [csvDelimiter, setCsvDelimiter] = useState<',' | ';'>(',');
  const [includeZebra, setIncludeZebra] = useState(true);
  const [includeDistrictColors, setIncludeDistrictColors] = useState(true);
  const [includeSimilarityNotes, setIncludeSimilarityNotes] = useState(true);
  const [includeTimestamps, setIncludeTimestamps] = useState(true);
  const [reviewerName, setReviewerName] = useState(settings?.reviewerName || 'مراجع السجلات المعتمد');
  const [exporting, setExporting] = useState(false);
  const [loStatus, setLoStatus] = useState<LibreOfficeStatus | null>(null);

  // Live database timestamps
  const timestamps = useMemo(() => getFormattedDatabaseTimestamps(), [isOpen]);

  useEffect(() => {
    if (settings?.reviewerName) {
      setReviewerName(settings.reviewerName);
    }
  }, [settings?.reviewerName]);

  useEffect(() => {
    let cancelled = false;
    getLibreOfficeStatus().then(status => {
      if (!cancelled) setLoStatus(status);
    });
    return () => { cancelled = true; };
  }, []);

  const colors = useMemo(() => getThemeColors(theme), [theme]);

  // Compute similarity and cross-reference map for all records
  const similarityMap = useMemo(() => {
    return analyzeAllStreetSimilarities(records);
  }, [records]);

  // Count records with similarities in current database
  const similarityCount = useMemo(() => {
    let count = 0;
    similarityMap.forEach(info => {
      if (info.hasSimilarity) count++;
    });
    return count;
  }, [similarityMap]);

  const permissions = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      const p = (r.permission || '').trim();
      if (p) set.add(p);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'ar'));
  }, [records]);

  const filteredRecords = useMemo(() => {
    switch (exportMode) {
      case 'permission':
        return records.filter(r => (r.permission || '').trim() === selectedPermission);
      case 'district':
        return records.filter(r => {
          const d = getDistrictColor(r.permission, r.metadata, r.name);
          return d !== null && d.key === selectedDistrict;
        });
      case 'alphabet':
        return records.filter(r => {
          const first = normalizeArabicText(r.name).charAt(0);
          return first === selectedLetter;
        });
      case 'sequence':
        return [...records];
      case 'all':
      default:
        return [...records].sort((a, b) => a.name.localeCompare(b.name, 'ar'));
    }
  }, [exportMode, records, selectedPermission, selectedDistrict, selectedLetter]);

  if (!isOpen) return null;

  const getThemeBg = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-700 text-white';
      case 'libreoffice': return 'bg-cyan-900 text-white';
      case 'modern': return 'bg-indigo-900 text-white';
      case 'hybrid':
      default: return 'bg-gradient-to-l from-emerald-700 via-cyan-800 to-indigo-900 text-white';
    }
  };

  const getAccentButton = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-700 hover:bg-emerald-800';
      case 'libreoffice': return 'bg-cyan-700 hover:bg-cyan-800';
      case 'modern': return 'bg-indigo-700 hover:bg-indigo-800';
      case 'hybrid':
      default: return 'bg-gradient-to-l from-emerald-700 via-cyan-700 to-indigo-700 hover:opacity-90';
    }
  };

  const getActiveChip = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-100 text-emerald-900 border-emerald-500 ring-2 ring-emerald-400';
      case 'libreoffice': return 'bg-cyan-100 text-cyan-900 border-cyan-500 ring-2 ring-cyan-400';
      case 'modern': return 'bg-indigo-100 text-indigo-900 border-indigo-500 ring-2 ring-indigo-400';
      case 'hybrid':
      default: return 'bg-gradient-to-l from-emerald-100 via-cyan-100 to-indigo-100 text-gray-900 border-emerald-500 ring-2 ring-emerald-400';
    }
  };

  const dateStamp = new Date().toISOString().slice(0, 10);
  const baseName = `البيانات_والمأذونيات_${dateStamp}`;

  const handleExport = async () => {
    if (filteredRecords.length === 0) {
      onToast('لا توجد سجلات مطابقة للتصدير');
      return;
    }
    setExporting(true);
    try {
      if (exportFormat === 'xlsx') {
        const workbook = await buildFormattedWorkbook(
          filteredRecords,
          colors,
          includeZebra,
          includeDistrictColors,
          similarityMap,
          includeSimilarityNotes,
          reviewerName,
          includeTimestamps,
          settings?.dynamicTheme?.columns
        );
        const buffer = await workbook.xlsx.writeBuffer();
        downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `${baseName}.xlsx`);
        onToast(`تم تصدير ${filteredRecords.length} سجل كملف Excel منسّق بنجاح`);
      } else if (exportFormat === 'ods') {
        const exportData = buildExportRows(filteredRecords, similarityMap, includeSimilarityNotes);
        const worksheet = XLSX.utils.json_to_sheet(exportData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'البيانات');
        if (!workbook.Workbook) workbook.Workbook = {};
        if (!workbook.Workbook.Views) workbook.Workbook.Views = [];
        workbook.Workbook.Views[0] = { RTL: true };
        XLSX.writeFile(workbook, `${baseName}.ods`, { bookType: 'ods' });
        onToast(`تم تصدير ${filteredRecords.length} سجل كملف ODS بنجاح`);
      } else if (exportFormat === 'csv') {
        const exportData = buildExportRows(filteredRecords, similarityMap, includeSimilarityNotes);
        const csvContent = generateCustomCsv(exportData, csvDelimiter);
        // Add header comment with timestamps & reviewer if requested
        let finalCsv = csvContent;
        if (includeTimestamps) {
          const commentHeader = `# منظومة الشوارع والمأذونيات بدمنهور - تاريخ التصدير: ${timestamps.gregorianDate} الموافق ${timestamps.hijriDate} (${timestamps.gregorianTime}) - المراجع: ${reviewerName}\r\n`;
          finalCsv = commentHeader + csvContent;
        }
        // Prepend UTF-8 BOM (\uFEFF) to ensure Microsoft Excel and other spreadsheet apps open Arabic properly
        const blob = new Blob(['\uFEFF' + finalCsv], { type: 'text/csv;charset=utf-8;' });
        downloadBlob(blob, `${baseName}.csv`);
        onToast(`تم تصدير ${filteredRecords.length} سجل كملف CSV عربي متوافق بنجاح`);
      } else if (exportFormat === 'html') {
        const processedRecords = includeSimilarityNotes
          ? filteredRecords.map(r => {
              const sim = similarityMap.get(r.id);
              return sim?.suggestedNote
                ? { ...r, metadata: embedSimilarityNoteIntoMetadata(r.metadata || '', sim.suggestedNote) }
                : r;
            })
          : filteredRecords;

        const html = generateReportHtml({
          records: processedRecords,
          title: 'تقرير الشوارع والمأذونيات الرسمية',
          subtitle: `كشف البيانات والمواقع المعتمدة • ${filteredRecords.length} سجل`,
          footer: 'تم الاعتماد والإصدار الآلي عبر منظومة الشوارع و المأذونيات بدمنهور',
          orientation: 'landscape',
          margin: '10mm',
          theme,
          zebra: includeZebra,
          printFontSize: '11pt',
          reviewerName,
          includeTimestamps,
          columns: settings?.dynamicTheme?.columns
        });
        const blob = new Blob(['\uFEFF' + html], { type: 'text/html;charset=utf-8;' });
        downloadBlob(blob, `${baseName}.html`);
        onToast(`تم تصدير ${filteredRecords.length} سجل كملف HTML منسّق بنجاح`);
      } else if (exportFormat === 'pdf') {
        const processedRecords = includeSimilarityNotes
          ? filteredRecords.map(r => {
              const sim = similarityMap.get(r.id);
              return sim?.suggestedNote
                ? { ...r, metadata: embedSimilarityNoteIntoMetadata(r.metadata || '', sim.suggestedNote) }
                : r;
            })
          : filteredRecords;

        exportToProtectedPdf({
          records: processedRecords,
          title: 'تقرير الشوارع والمأذونيات الرسمية',
          subtitle: `كشف البيانات والمواقع المعتمدة • ${filteredRecords.length} سجل`,
          footer: 'تم الاعتماد والإصدار الآلي عبر منظومة الشوارع و المأذونيات بدمنهور',
          orientation: 'landscape',
          margin: '10mm',
          theme,
          zebra: includeZebra,
          printFontSize: '11pt',
          reviewerName,
          includeTimestamps,
          columns: settings?.dynamicTheme?.columns
        });
        onToast(`تم فتح نافذة الطباعة لتصدير ${filteredRecords.length} سجل PDF`);
      }
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء التصدير، يرجى المحاولة مرة أخرى');
    } finally {
      setExporting(false);
    }
  };

  const handleOpenInLibreOffice = async () => {
    if (filteredRecords.length === 0) return;
    setExporting(true);
    try {
      const workbook = await buildFormattedWorkbook(
        filteredRecords,
        colors,
        includeZebra,
        includeDistrictColors,
        similarityMap,
        includeSimilarityNotes,
        reviewerName,
        includeTimestamps
      );
      const buffer = await workbook.xlsx.writeBuffer();
      const file = new File([buffer], `${baseName}.xlsx`, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const ok = await openInLibreOffice(file);
      if (ok) {
        onToast('تم فتح الملف المنسّق في برنامج LibreOffice بنجاح');
      } else {
        onToast('تعذر فتح LibreOffice، تأكد من تشغيل الخادم المساعد (npm run server)');
      }
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء فتح الملف في LibreOffice');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden border border-gray-100 flex flex-col max-h-[95vh]">

        <div className={`px-6 py-4 flex items-center justify-between shrink-0 ${getThemeBg()}`}>
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-white" />
            <div>
              <h3 className="text-lg font-bold">نافذة التصدير المتقدم والتصنيفي</h3>
              <p className="text-xs text-white/85">تصدير منسّق مطابق لثيم البرنامج • Excel / ODS / CSV / HTML / PDF</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/20 transition text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1">

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span>نطاق التصدير (اختر السجلات المطلوبة)</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(Object.keys(MODE_LABELS) as ExportMode[]).map(mode => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setExportMode(mode)}
                  className={`px-3 py-2 rounded-xl border text-xs font-bold transition cursor-pointer text-right ${
                    exportMode === mode ? getActiveChip() : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  {MODE_LABELS[mode]}
                </button>
              ))}
            </div>
          </div>

          {exportMode === 'permission' && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span>اختر المأذونية:</span>
              </label>
              <select
                value={selectedPermission}
                onChange={(e) => setSelectedPermission(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl bg-white text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="">— اختر مأذونية —</option>
                {permissions.map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          )}

          {exportMode === 'district' && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span>اختر المنطقة الرسمية:</span>
              </label>
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl bg-white text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="">— اختر منطقة —</option>
                {OFFICIAL_DISTRICTS.map(d => (
                  <option key={d.key} value={d.key}>{d.name}</option>
                ))}
              </select>
            </div>
          )}

          {exportMode === 'alphabet' && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
                <Type className="w-4 h-4 text-purple-600" />
                <span>اختر الحرف الأبجدي الأول:</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {ARABIC_ALPHABET.map(letter => (
                  <button
                    key={letter}
                    type="button"
                    onClick={() => setSelectedLetter(letter)}
                    className={`w-9 h-9 rounded-lg border text-sm font-bold transition cursor-pointer ${
                      selectedLetter === letter
                        ? getActiveChip()
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    {letter}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
              <FileDown className="w-4 h-4 text-indigo-600" />
              <span>صيغة الملف الناتج</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(Object.keys(FORMAT_LABELS) as ExportFormat[]).map(format => (
                <button
                  key={format}
                  type="button"
                  onClick={() => setExportFormat(format)}
                  className={`px-3 py-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-right flex items-center gap-2 ${
                    exportFormat === format ? getActiveChip() : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  {format === 'xlsx' && <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />}
                  {format === 'ods' && <FileSpreadsheet className="w-4 h-4 text-cyan-600 shrink-0" />}
                  {format === 'csv' && <FileText className="w-4 h-4 text-gray-500 shrink-0" />}
                  {format === 'html' && <FileCode2 className="w-4 h-4 text-orange-500 shrink-0" />}
                  {format === 'pdf' && <Printer className="w-4 h-4 text-amber-600 shrink-0" />}
                  <span>{FORMAT_LABELS[format]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Reviewer & Documentation Stamps Section */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-emerald-950">
                <FileCheck className="w-4 h-4 text-emerald-700" />
                <span>توثيق المستند وتضمين التاريخ والمراجع</span>
              </div>
              <label className="flex items-center gap-2 text-xs font-bold text-emerald-900 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeTimestamps}
                  onChange={(e) => setIncludeTimestamps(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 rounded"
                />
                <span>تضمين في المستند</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">اسم المراجع / القائم بالتدقيق:</label>
                <input
                  type="text"
                  value={reviewerName}
                  onChange={(e) => setReviewerName(e.target.value)}
                  placeholder="مثال: أ. حسام / مراجع السجلات المعتمد"
                  className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                />
              </div>
              <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-100 flex flex-col justify-center text-[11px] text-emerald-900">
                <span className="font-bold">التاريخ الميلادي: {timestamps.gregorianDate} ({timestamps.gregorianTime})</span>
                <span className="font-bold text-emerald-700">التاريخ الهجري: {timestamps.hijriDate}</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
              <Palette className="w-4 h-4 text-purple-600" />
              <span>خيارات التنسيق والفهرسة والترميز الذكي</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeZebra}
                  onChange={(e) => setIncludeZebra(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600"
                />
                <span className="text-xs font-semibold text-gray-800">الشرائط المخططة (Zebra Striping)</span>
              </label>
              <label className="flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeDistrictColors}
                  onChange={(e) => setIncludeDistrictColors(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600"
                />
                <span className="text-xs font-semibold text-gray-800">ألوان المأذونيات حسب المناطق الرسمية</span>
              </label>
              <label className="flex items-center gap-3 px-4 py-3 rounded-xl border border-blue-200 bg-blue-50/60 sm:col-span-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeSimilarityNotes}
                  onChange={(e) => setIncludeSimilarityNotes(e.target.checked)}
                  className="w-4 h-4 accent-blue-600"
                />
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5 text-blue-600" />
                    تضمين إشارات الاشتراك والتشابه آلياً في الملاحظات ([مشترك مع مأذونية أخرى...])
                  </span>
                  <span className="text-[11px] text-blue-700">
                    يكتشف تلقائياً الشوارع المشتركة بين مأذونيتين ويدرج بياناً صريحاً بها ({similarityCount.toLocaleString('ar-EG')} سجل)
                  </span>
                </div>
              </label>
            </div>

            {exportFormat === 'csv' && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 mt-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-emerald-600" />
                    ترميز CSV العربي وضبط الفاصلة:
                  </span>
                  <span className="text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md font-mono font-bold">
                    UTF-8 مع BOM (\uFEFF)
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-emerald-900">
                  <span className="font-medium">فاصلة الأعمدة:</span>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer font-bold">
                    <input
                      type="radio"
                      name="csv_delimiter"
                      checked={csvDelimiter === ','}
                      onChange={() => setCsvDelimiter(',')}
                      className="accent-emerald-600"
                    />
                    فاصلة قياسية ( , )
                  </label>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer font-bold">
                    <input
                      type="radio"
                      name="csv_delimiter"
                      checked={csvDelimiter === ';'}
                      onChange={() => setCsvDelimiter(';')}
                      className="accent-emerald-600"
                    />
                    فاصلة منقوطة ( ; ) - متوافقة مع Excel العربي
                  </label>
                </div>
              </div>
            )}

            <p className="text-[11px] text-gray-500">
              الثيم الحالي: <span className="font-bold text-gray-700">{colors.name}</span> — الفهرسة الرقمية (العمود م) تتم تلقائياً بتسلسل سليم.
            </p>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-700">
              <ListOrdered className="w-4 h-4 text-emerald-600" />
              <span>عدد السجلات المحددة للتصدير:</span>
              <span className="text-emerald-700 text-sm font-black">{filteredRecords.length.toLocaleString('ar-EG')}</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-gray-500">
              {loStatus?.installed ? (
                <span className="flex items-center gap-1 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  LibreOffice متاح
                </span>
              ) : (
                <span className="text-gray-400">LibreOffice غير متصل</span>
              )}
            </div>
          </div>

        </div>

        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenInLibreOffice}
              disabled={exporting || !loStatus?.installed}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-300 bg-white text-gray-700 text-xs font-bold transition hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              title="فتح الملف المنسّق مباشرة في LibreOffice"
            >
              <ExternalLink className="w-4 h-4 text-cyan-600" />
              <span>فتح في LibreOffice</span>
            </button>
            <button
              type="button"
              onClick={downloadSystemFeaturesMarkdown}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition cursor-pointer shadow-2xs"
              title="تحميل الملف المرفق لكافة مميزات وإمكانيات المنظومة بصيغة Markdown (.md)"
            >
              <FileText className="w-4 h-4 text-emerald-600" />
              <span>دليل المميزات (Markdown .md)</span>
              <Download className="w-3.5 h-3.5 text-emerald-700" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-gray-300 bg-white text-gray-700 text-xs font-bold transition hover:bg-gray-100 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleExport}
              disabled={exporting || filteredRecords.length === 0}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-xs font-black transition shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer ${getAccentButton()}`}
            >
              {exporting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>{exporting ? 'جارٍ التصدير...' : `تصدير ${FORMAT_LABELS[exportFormat]}`}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}