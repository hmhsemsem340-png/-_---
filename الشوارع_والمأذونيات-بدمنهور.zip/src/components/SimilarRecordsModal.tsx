// ===================================================================
// 🏛️ مركز فحص ومراجعة وتصنيف البيانات المتشابهة وعناوين الحقيقة
// Similar & Duplicate Records Hub & Ground Truth Management
// Supports:
// 1. Standalone Page Mode & Modal Mode (صفحة مستقلة بكامل الإعدادات السابقة)
// 2. Side-by-Side Comparison (المقارنة المتجاورة في عمودين متجاورين)
// 3. Field-by-Field Accuracy Picker (تحديد البيانات الأدق لكل حقل بضغطة زر)
// 4. Pre-Save Staging & Verification (أمان الحفظ والمراجعة والاستيثاق قبل الحفظ)
// ===================================================================

import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  Search, 
  AlertTriangle, 
  Share2, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles, 
  Tag, 
  FileText, 
  ExternalLink, 
  Layers, 
  Filter, 
  GitMerge, 
  Info, 
  Trash2,
  Edit3,
  HelpCircle,
  Building2,
  Check,
  Columns,
  List,
  ArrowRight,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Save,
  RotateCcw,
  Maximize2,
  Minimize2,
  FileCheck,
  Eye,
  Sliders,
  Copy
} from 'lucide-react';
import { RecordItem, ThemeType, RecordStatus } from '../types';
import { groupSimilarRecords, SimilarityGroup } from '../utils/streetSimilarity';
import { getDistrictColor } from '../utils/districtColors';
import { normalizeArabicText } from '../utils/arabicEncoding';
import { ArabicUtils } from '../utils/arabicUtils';
import { parseStreetPrefixAndName } from '../utils/streetSplitter';
import { OFFICIAL_NOTARIZATIONS } from '../types';

interface SimilarRecordsModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: RecordItem[];
  theme?: ThemeType;
  onUpdateRecord: (updatedRecord: RecordItem) => void;
  onBatchUpdateRecords?: (updatedRecords: RecordItem[]) => void;
  onSelectForEdit?: (record: RecordItem) => void;
  onOpenAuditRecord?: (record: RecordItem) => void;
  onDeleteRecord?: (recordId: string) => void;
  onToast?: (msg: string) => void;
  initialFilterName?: string;
  initialRootFilter?: string;
  isStandalonePage?: boolean;
}

export const SimilarRecordsModal: React.FC<SimilarRecordsModalProps> = ({
  isOpen,
  onClose,
  records,
  theme,
  onUpdateRecord,
  onBatchUpdateRecords,
  onSelectForEdit,
  onOpenAuditRecord,
  onDeleteRecord,
  onToast,
  initialFilterName,
  initialRootFilter,
  isStandalonePage = false
}) => {
  const [searchQuery, setSearchQuery] = useState(initialFilterName || initialRootFilter || '');
  const [filterType, setFilterType] = useState<
    'all' | 'duplicate_same' | 'shared' | 'prefix_variant' | 'has_truth' | 'no_truth'
  >('all');
  
  // View mode: 'side_by_side' (مقارنة متجاورة) vs 'list' (عرض البطاقات)
  const [viewMode, setViewMode] = useState<'side_by_side' | 'list'>('side_by_side');

  // Toggle full-screen page mode when inside modal
  const [isFullScreen, setIsFullScreen] = useState(isStandalonePage);

  // Active selected cluster group
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);

  // Two adjacent records for Side-by-Side Comparison
  const [primaryRecordId, setPrimaryRecordId] = useState<string | null>(null); // Side A
  const [candidateRecordId, setCandidateRecordId] = useState<string | null>(null); // Side B

  // Field-by-Field Precision Accuracy Picker state
  const [pickedName, setPickedName] = useState<string>('');
  const [pickedNameSource, setPickedNameSource] = useState<'a' | 'b' | 'custom'>('a');

  const [pickedPermission, setPickedPermission] = useState<string>('');
  const [pickedPermissionSource, setPickedPermissionSource] = useState<'a' | 'b' | 'custom'>('a');

  const [pickedCategory, setPickedCategory] = useState<string>('');
  const [pickedCategorySource, setPickedCategorySource] = useState<'a' | 'b' | 'custom'>('a');

  const [pickedMetadata, setPickedMetadata] = useState<string>('');
  const [pickedMetadataSource, setPickedMetadataSource] = useState<'a' | 'b' | 'merged' | 'custom'>('merged');

  const [pickedStatus, setPickedStatus] = useState<RecordStatus>('تام');
  const [pickedIsLocked, setPickedIsLocked] = useState<boolean>(true);

  // Safety Verification Modal before committing merges/overwrites
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [verifyActionType, setVerifyActionType] = useState<'adopt_truth' | 'update_both' | 'merge_into_one'>('adopt_truth');

  // Group similar records
  const allGroups = useMemo(() => {
    return groupSimilarRecords(records);
  }, [records]);

  // Statistics
  const stats = useMemo(() => {
    let samePermDups = 0;
    let sharedPerms = 0;
    let withTruth = 0;
    let withoutTruth = 0;

    for (const g of allGroups) {
      if (g.groupType === 'duplicate_same_permission' || g.groupType === 'mixed') samePermDups++;
      if (g.groupType === 'shared_permissions' || g.groupType === 'mixed') sharedPerms++;
      if (g.truthRecord) withTruth++;
      else withoutTruth++;
    }

    return { samePermDups, sharedPerms, withTruth, withoutTruth };
  }, [allGroups]);

  // Filter groups
  const filteredGroups = useMemo(() => {
    let list = allGroups;

    if (filterType === 'duplicate_same') {
      list = list.filter(g => g.groupType === 'duplicate_same_permission' || g.groupType === 'mixed');
    } else if (filterType === 'shared') {
      list = list.filter(g => g.groupType === 'shared_permissions' || g.groupType === 'mixed');
    } else if (filterType === 'prefix_variant') {
      list = list.filter(g => g.groupType === 'prefix_variant');
    } else if (filterType === 'has_truth') {
      list = list.filter(g => Boolean(g.truthRecord));
    } else if (filterType === 'no_truth') {
      list = list.filter(g => !g.truthRecord);
    }

    if (searchQuery.trim()) {
      const q = normalizeArabicText(searchQuery.trim().toLowerCase());
      list = list.filter(g => {
        const rootMatch = normalizeArabicText(g.rootName.toLowerCase()).includes(q);
        if (rootMatch) return true;
        return g.records.some(r => 
          normalizeArabicText(r.name.toLowerCase()).includes(q) ||
          normalizeArabicText(r.permission || '').includes(q) ||
          normalizeArabicText(r.metadata || '').includes(q)
        );
      });
    }

    return list;
  }, [allGroups, filterType, searchQuery]);

  // Keep selected group in sync
  useEffect(() => {
    if (filteredGroups.length > 0) {
      if (!selectedGroupId || !filteredGroups.some(g => g.id === selectedGroupId)) {
        setSelectedGroupId(filteredGroups[0].id);
      }
    } else {
      setSelectedGroupId(null);
    }
  }, [filteredGroups, selectedGroupId]);

  // Active selected group
  const activeGroup = useMemo(() => {
    if (!selectedGroupId) return filteredGroups[0] || null;
    return allGroups.find(g => g.id === selectedGroupId) || filteredGroups[0] || null;
  }, [allGroups, filteredGroups, selectedGroupId]);

  // Setup Side A and Side B whenever active group changes
  useEffect(() => {
    if (!activeGroup || activeGroup.records.length === 0) {
      setPrimaryRecordId(null);
      setCandidateRecordId(null);
      return;
    }

    const truthRec = activeGroup.truthRecord || activeGroup.records[0];
    setPrimaryRecordId(truthRec.id);

    const otherRec = activeGroup.records.find(r => r.id !== truthRec.id) || activeGroup.records[1] || activeGroup.records[0];
    setCandidateRecordId(otherRec.id);
  }, [activeGroup]);

  const primaryRecord = useMemo(() => {
    if (!activeGroup) return null;
    return activeGroup.records.find(r => r.id === primaryRecordId) || activeGroup.truthRecord || activeGroup.records[0] || null;
  }, [activeGroup, primaryRecordId]);

  const candidateRecord = useMemo(() => {
    if (!activeGroup) return null;
    return activeGroup.records.find(r => r.id === candidateRecordId) || activeGroup.records.find(r => r.id !== primaryRecordId) || null;
  }, [activeGroup, candidateRecordId, primaryRecordId]);

  // Helper to merge notes cleanly
  const mergeNotesCleanly = (noteA: string, noteB: string, recA: RecordItem, recB: RecordItem): string => {
    let crossTag: string | undefined = undefined;
    if (recA.permission && recB.permission && recA.permission !== recB.permission) {
      crossTag = `[مشترك بين مأذونيتي: ${recA.permission} و ${recB.permission}]`;
    }
    return ArabicUtils.smartMergeNotes(noteA, noteB, crossTag);
  };

  // Populate Field-by-Field Accuracy Picker when primary or candidate records change
  useEffect(() => {
    if (primaryRecord && candidateRecord) {
      // Name: Default to primary or truth record
      setPickedName(primaryRecord.name);
      setPickedNameSource('a');

      // Permission: Default to primary
      setPickedPermission(primaryRecord.permission);
      setPickedPermissionSource('a');

      // Category: Default to primary
      setPickedCategory(primaryRecord.category || candidateRecord.category || 'شارع');
      setPickedCategorySource('a');

      // Metadata: Clean merge by default
      const mergedMeta = mergeNotesCleanly(
        primaryRecord.metadata || '',
        candidateRecord.metadata || '',
        primaryRecord,
        candidateRecord
      );
      setPickedMetadata(mergedMeta);
      setPickedMetadataSource('merged');

      // Status
      setPickedStatus('تام');
      setPickedIsLocked(true);
    }
  }, [primaryRecord?.id, candidateRecord?.id]);

  const notify = (msg: string) => {
    if (onToast) onToast(msg);
  };

  if (!isOpen) return null;

  // Handle setting Side A as Ground Truth
  const handleSetAsTruthRecord = (record: RecordItem) => {
    const updatedRecord: RecordItem = {
      ...record,
      status: 'تام',
      isLocked: true,
      isTruthRecord: true,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      metadata: record.metadata
        ? record.metadata.includes('عنوان الحقيقة')
          ? record.metadata
          : `${record.metadata}\n[معتمد نهائي - عنوان الحقيقة المرجعي 🔒]`
        : '[معتمد نهائي - عنوان الحقيقة المرجعي 🔒]'
    };
    onUpdateRecord(updatedRecord);
    notify(`✓ تم اعتماد (${record.name}) كـ «عنوان الحقيقة 🔒» (بيان تام مغلق)`);
  };

  // Save Executions after Safety Verification
  const executeVerifiedCommit = () => {
    if (!primaryRecord || !candidateRecord) return;

    if (verifyActionType === 'adopt_truth') {
      // Commit primary record as Ground Truth with all picked fields
      const updatedPrimary: RecordItem = {
        ...primaryRecord,
        name: pickedName.trim(),
        permission: pickedPermission.trim(),
        category: pickedCategory.trim(),
        metadata: pickedMetadata.trim(),
        status: 'تام',
        isLocked: true,
        isTruthRecord: true,
        lastModifiedAt: new Date().toLocaleString('ar-EG'),
        lastModifiedBy: 'مركز المتشابهات',
        auditLogs: [
          ...(primaryRecord.auditLogs || []),
          {
            id: `audit-${Date.now()}`,
            timestamp: new Date().toISOString(),
            operation: 'update',
            details: `تم اعتماد السجل كـ «بيان تام 🔒» بعد المقارنة المتجاورة واختيار الحقول الأدق مع (${candidateRecord.name})`,
            user: 'مركز المتشابهات'
          }
        ]
      };

      // Also update candidate record with classification link
      const updatedCandidate: RecordItem = {
        ...candidateRecord,
        similarityClassification: 'مشترك مع عنوان الحقيقة',
        truthRecordId: primaryRecord.id,
        lastModifiedAt: new Date().toLocaleString('ar-EG'),
        metadata: candidateRecord.metadata
          ? candidateRecord.metadata.includes('عنوان الحقيقة')
            ? candidateRecord.metadata
            : `${candidateRecord.metadata}\n[مرتبط بعنوان الحقيقة المعتمد: ${pickedName}]`
          : `[مرتبط بعنوان الحقيقة المعتمد: ${pickedName}]`
      };

      if (onBatchUpdateRecords) {
        onBatchUpdateRecords([updatedPrimary, updatedCandidate]);
      } else {
        onUpdateRecord(updatedPrimary);
        onUpdateRecord(updatedCandidate);
      }

      notify(`✓ تم اعتماد (${pickedName}) كـ «بيان تام 🔒» وتوثيق السجل المقابل بنجاح`);
    } else if (verifyActionType === 'update_both') {
      // Update both records with their respective field improvements
      const updatedPrimary: RecordItem = {
        ...primaryRecord,
        name: pickedNameSource === 'a' ? pickedName.trim() : primaryRecord.name,
        permission: pickedPermissionSource === 'a' ? pickedPermission.trim() : primaryRecord.permission,
        category: pickedCategorySource === 'a' ? pickedCategory.trim() : primaryRecord.category,
        metadata: pickedMetadata.trim(),
        status: pickedStatus,
        isLocked: pickedIsLocked,
        lastModifiedAt: new Date().toLocaleString('ar-EG'),
        lastModifiedBy: 'مركز المتشابهات'
      };

      const updatedCandidate: RecordItem = {
        ...candidateRecord,
        name: pickedNameSource === 'b' ? pickedName.trim() : candidateRecord.name,
        permission: pickedPermissionSource === 'b' ? pickedPermission.trim() : candidateRecord.permission,
        category: pickedCategorySource === 'b' ? pickedCategory.trim() : candidateRecord.category,
        metadata: pickedMetadata.trim(),
        lastModifiedAt: new Date().toLocaleString('ar-EG'),
        lastModifiedBy: 'مركز المتشابهات'
      };

      if (onBatchUpdateRecords) {
        onBatchUpdateRecords([updatedPrimary, updatedCandidate]);
      } else {
        onUpdateRecord(updatedPrimary);
        onUpdateRecord(updatedCandidate);
      }

      notify(`✓ تم حفظ وتحديث السجلين المتجاورين بأمان`);
    } else if (verifyActionType === 'merge_into_one') {
      // Merge into primary record and delete/archive candidate
      const mergedRecord: RecordItem = {
        ...primaryRecord,
        name: pickedName.trim(),
        permission: pickedPermission.trim(),
        category: pickedCategory.trim(),
        metadata: pickedMetadata.trim(),
        status: 'تام',
        isLocked: true,
        isTruthRecord: true,
        lastModifiedAt: new Date().toLocaleString('ar-EG'),
        lastModifiedBy: 'مركز المتشابهات',
        auditLogs: [
          ...(primaryRecord.auditLogs || []),
          {
            id: `audit-${Date.now()}`,
            timestamp: new Date().toISOString(),
            operation: 'update',
            details: `تم دمج السجل (${candidateRecord.name}) في هذا السجل بعد مقارنة الحقول المتجاورة`,
            user: 'مركز المتشابهات'
          }
        ]
      };

      onUpdateRecord(mergedRecord);
      if (onDeleteRecord && candidateRecord.id !== primaryRecord.id) {
        onDeleteRecord(candidateRecord.id);
      }
      notify(`✓ تم دمج السجلين بنجاح في سجل موحد معتمد كـ «بيان تام 🔒»`);
    }

    setShowVerifyModal(false);
  };

  // Container classes based on standalone vs modal vs full-screen
  const containerClass = isStandalonePage
    ? 'w-full min-h-[calc(100vh-140px)] bg-slate-50 rounded-3xl shadow-sm border border-slate-200 flex flex-col overflow-hidden animate-in fade-in duration-150'
    : isFullScreen
      ? 'fixed inset-0 z-50 bg-slate-100 flex flex-col overflow-hidden animate-in fade-in duration-200'
      : 'fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150';

  const modalBoxClass = isStandalonePage || isFullScreen
    ? 'w-full h-full flex flex-col overflow-hidden bg-white'
    : 'bg-white rounded-3xl shadow-2xl w-full max-w-7xl max-h-[92vh] flex flex-col overflow-hidden border border-gray-200';

  return (
    <div className={containerClass} dir="rtl">
      <div className={modalBoxClass}>
        
        {/* ================= HEADER BAR ================= */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 text-white shrink-0 shadow-md border-b border-indigo-700/50">
          <div className="flex items-center gap-3">
            {isStandalonePage ? (
              <button
                type="button"
                onClick={onClose}
                className="p-2.5 bg-white/10 hover:bg-white/20 rounded-2xl transition cursor-pointer text-white flex items-center gap-1.5 text-xs font-bold"
                title="العودة لجدول السجلات الرئيسي"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة للجدول الرئيسي</span>
              </button>
            ) : (
              <div className="p-2.5 bg-indigo-500/20 rounded-2xl border border-indigo-400/30">
                <Layers className="w-6 h-6 text-amber-300" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  مركز فحص ومقارنة المتشابهات وعناوين الحقيقة
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-400 text-slate-950">
                  {allGroups.length} مجموعة متشابهة
                </span>
              </div>
              <p className="text-xs text-indigo-200 mt-0.5">
                مقارنة متجاورة (Side-by-Side) واختيار أدق الحقول بضغطة زر مع أمان الحفظ والاستيثاق قبل الاعتماد
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-black/30 p-1 rounded-xl border border-white/10 text-xs font-bold">
              <button
                type="button"
                onClick={() => setViewMode('side_by_side')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  viewMode === 'side_by_side'
                    ? 'bg-indigo-600 text-white shadow-xs font-black'
                    : 'text-indigo-200 hover:text-white'
                }`}
                title="المقارنة المتجاورة واختيار الحقول الأدق في عمودين"
              >
                <Columns className="w-3.5 h-3.5" />
                <span>المقارنة المتجاورة (Side-by-Side)</span>
              </button>

              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-indigo-600 text-white shadow-xs font-black'
                    : 'text-indigo-200 hover:text-white'
                }`}
                title="عرض جميع البطاقات في قائمة مجمعة"
              >
                <List className="w-3.5 h-3.5" />
                <span>عرض القائمة</span>
              </button>
            </div>

            {/* Toggle Full Screen / Page Mode (when in modal mode) */}
            {!isStandalonePage && (
              <button
                type="button"
                onClick={() => setIsFullScreen(prev => !prev)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition cursor-pointer text-white"
                title={isFullScreen ? 'تصغير النافذة' : 'عرض كصفحة كاملة مستقلة'}
              >
                {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
            )}

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 bg-white/10 hover:bg-red-500/80 rounded-xl transition cursor-pointer text-white"
              title="إغلاق النافذة (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ================= SEARCH & STATS FILTER BAR ================= */}
        <div className="p-3.5 bg-slate-50 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="relative flex-1 min-w-[260px] max-w-md">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في أسماء الشوارع المتشابهة، المأذونية، أو الملاحظات..."
              className="w-full pr-9 pl-8 py-2 bg-white border border-gray-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                filterType === 'all'
                  ? 'bg-gray-900 text-white shadow-xs'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              الكل ({allGroups.length})
            </button>

            <button
              type="button"
              onClick={() => setFilterType('duplicate_same')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                filterType === 'duplicate_same'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>تكرار بنفس المأذونية ({stats.samePermDups})</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterType('shared')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                filterType === 'shared'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-blue-50 text-blue-900 border border-blue-200 hover:bg-blue-100'
              }`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشترك بين مأذونيات ({stats.sharedPerms})</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterType('no_truth')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                filterType === 'no_truth'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-rose-50 text-rose-900 border border-rose-200 hover:bg-rose-100'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>تحتاج عنوان حقيقة ({stats.withoutTruth})</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterType('has_truth')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1 ${
                filterType === 'has_truth'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>معتمد كعنوان حقيقة ({stats.withTruth})</span>
            </button>
          </div>
        </div>

        {/* ================= MAIN CONTENT BODY ================= */}
        {filteredGroups.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-gray-200 space-y-3 m-6">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold text-gray-900">لا توجد سجلات متشابهة مطابقة لمعايير البحث</h4>
            <p className="text-xs text-gray-500 max-w-md mx-auto">
              جميع الشوارع إما فريدة تماماً أو تم تدقيقها وتصنيفها.
            </p>
          </div>
        ) : viewMode === 'side_by_side' ? (
          /* ================= SIDE-BY-SIDE MODE (المقارنة المتجاورة) ================= */
          <div className="flex-1 flex overflow-hidden bg-slate-100/70">
            
            {/* RIGHT PANE: Cluster Groups List */}
            <div className="w-72 sm:w-80 border-l border-gray-200 bg-white flex flex-col shrink-0 overflow-hidden">
              <div className="p-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between text-xs font-bold text-gray-700">
                <span className="flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  <span>المجموعات ({filteredGroups.length})</span>
                </span>
                <span className="text-[11px] text-gray-500">اختر للمقارنة</span>
              </div>

              <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
                {filteredGroups.map(group => {
                  const isSelected = group.id === selectedGroupId;
                  const hasTruth = Boolean(group.truthRecord);
                  return (
                    <button
                      key={group.id}
                      type="button"
                      onClick={() => setSelectedGroupId(group.id)}
                      className={`w-full text-right p-3.5 transition cursor-pointer flex flex-col gap-1.5 ${
                        isSelected 
                          ? 'bg-indigo-50 border-r-4 border-indigo-600 font-bold text-indigo-950'
                          : 'hover:bg-gray-50 text-gray-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black truncate max-w-[170px]">{group.rootName}</span>
                        <div className="flex items-center gap-1">
                          {hasTruth && (
                            <span title="له عنوان حقيقة معتمد 🔒">
                              <Lock className="w-3.5 h-3.5 text-emerald-600" />
                            </span>
                          )}
                          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-black bg-gray-200 text-gray-800">
                            {group.records.length}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-[11px] text-gray-500">
                        <span>{(group.permissions || []).join(' • ')}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* LEFT PANE: Side-by-Side Comparison & Field-by-Field Picker Board */}
            {activeGroup && primaryRecord && candidateRecord && (
              <div className="flex-1 flex flex-col overflow-y-auto p-4 sm:p-5 space-y-5 bg-slate-100/60">
                
                {/* Active Group Header & Record Switcher */}
                <div className="bg-white p-4 rounded-3xl border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-3 shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-2xl">
                      <Columns className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm sm:text-base font-black text-gray-900 flex items-center gap-2">
                        <span>مجموعة: «{activeGroup.rootName}»</span>
                        <span className="px-2.5 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-900 font-black">
                          {activeGroup.records.length} سجلات للمقارنة
                        </span>
                      </h4>
                      <p className="text-xs text-gray-500">
                        قارن بدقة بين السجلين المتجاورين وحدد الحقل الأدق بضغطة زر
                      </p>
                    </div>
                  </div>

                  {/* Switch Candidate Record if group has > 2 records */}
                  {activeGroup.records.length > 2 && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-bold text-gray-600">قارن مع:</span>
                      {activeGroup.records.filter(r => r.id !== primaryRecord.id).map(r => (
                        <button
                          key={r.id}
                          type="button"
                          onClick={() => setCandidateRecordId(r.id)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                            r.id === candidateRecord.id
                              ? 'bg-indigo-600 text-white shadow-xs'
                              : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                          }`}
                        >
                          {r.name} ({r.permission})
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* THE TWO ADJACENT COLUMNS (Side A vs Side B) */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  
                  {/* ================= COLUMN A: Record 1 (سجل الطرف أ) ================= */}
                  <div className="bg-white rounded-3xl border-2 border-emerald-300 shadow-md flex flex-col overflow-hidden">
                    <div className="p-3.5 bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 text-white flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-amber-300" />
                        <span className="text-xs font-black">السجل (أ) — المرجعي / الأول</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-400 text-emerald-950">
                        {primaryRecord.status === 'تام' ? '🔒 بيان تام معتمد' : 'سجل نشط'}
                      </span>
                    </div>

                    <div className="p-4 space-y-4">
                      {/* Field: Street Name */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedNameSource === 'a' 
                          ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">اسم الشارع في (أ):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedName(primaryRecord.name);
                              setPickedNameSource('a');
                              notify(`✓ تم اعتماد اسم الشارع من السجل (أ)`);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-1 ${
                              pickedNameSource === 'a'
                                ? 'bg-emerald-700 text-white shadow-xs'
                                : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                            }`}
                          >
                            {pickedNameSource === 'a' ? <Check className="w-3.5 h-3.5" /> : null}
                            <span>{pickedNameSource === 'a' ? '✓ هو الأدق المعتمد' : 'اعتماد هذا الاسم كالأدق'}</span>
                          </button>
                        </div>
                        <div className="text-sm font-black text-gray-950">
                          {primaryRecord.name}
                        </div>
                      </div>

                      {/* Field: Permission */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedPermissionSource === 'a' 
                          ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">المأذونية في (أ):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedPermission(primaryRecord.permission);
                              setPickedPermissionSource('a');
                              notify(`✓ تم اعتماد مأذونية السجل (أ)`);
                            }}
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                              pickedPermissionSource === 'a'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                            }`}
                          >
                            {pickedPermissionSource === 'a' ? <Check className="w-3 h-3" /> : null}
                            <span>{pickedPermissionSource === 'a' ? '✓ المعتمد' : 'اعتماد مأذونية (أ)'}</span>
                          </button>
                        </div>
                        <div className="text-xs font-bold text-gray-900">
                          {primaryRecord.permission}
                        </div>
                      </div>

                      {/* Field: Category */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedCategorySource === 'a' 
                          ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">التصنيف في (أ):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedCategory(primaryRecord.category || 'شارع');
                              setPickedCategorySource('a');
                            }}
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                              pickedCategorySource === 'a'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                            }`}
                          >
                            {pickedCategorySource === 'a' ? <Check className="w-3 h-3" /> : null}
                            <span>{pickedCategorySource === 'a' ? '✓ المعتمد' : 'اعتماد تصنيف (أ)'}</span>
                          </button>
                        </div>
                        <div className="text-xs font-bold text-gray-900">
                          {primaryRecord.category || 'شارع'}
                        </div>
                      </div>

                      {/* Field: Metadata / Notes */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedMetadataSource === 'a' 
                          ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">الملاحظات في (أ):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedMetadata(primaryRecord.metadata || '');
                              setPickedMetadataSource('a');
                              notify(`✓ تم اختيار ملاحظات السجل (أ)`);
                            }}
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                              pickedMetadataSource === 'a'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                            }`}
                          >
                            {pickedMetadataSource === 'a' ? <Check className="w-3 h-3" /> : null}
                            <span>{pickedMetadataSource === 'a' ? '✓ المعتمد' : 'اعتماد ملاحظات (أ)'}</span>
                          </button>
                        </div>
                        <p className="text-xs text-gray-700 whitespace-pre-line min-h-[45px]">
                          {primaryRecord.metadata || 'لا توجد ملاحظات.'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* ================= COLUMN B: Record 2 (سجل الطرف ب) ================= */}
                  <div className="bg-white rounded-3xl border-2 border-indigo-300 shadow-md flex flex-col overflow-hidden">
                    <div className="p-3.5 bg-gradient-to-r from-indigo-900 via-purple-900 to-indigo-950 text-white flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Share2 className="w-4 h-4 text-purple-300" />
                        <span className="text-xs font-black">السجل (ب) — السجل المقارن / المقابل</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-400 text-indigo-950">
                        {candidateRecord.status === 'تام' ? '🔒 بيان تام معتمد' : 'سجل قيد المقارنة'}
                      </span>
                    </div>

                    <div className="p-4 space-y-4">
                      {/* Field: Street Name */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedNameSource === 'b' 
                          ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">اسم الشارع في (ب):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedName(candidateRecord.name);
                              setPickedNameSource('b');
                              notify(`✓ تم اعتماد اسم الشارع من السجل (ب)`);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-1 ${
                              pickedNameSource === 'b'
                                ? 'bg-indigo-700 text-white shadow-xs'
                                : 'bg-white hover:bg-indigo-100 text-indigo-900 border border-indigo-300'
                            }`}
                          >
                            {pickedNameSource === 'b' ? <Check className="w-3.5 h-3.5" /> : null}
                            <span>{pickedNameSource === 'b' ? '✓ هو الأدق المعتمد' : 'اعتماد هذا الاسم كالأدق'}</span>
                          </button>
                        </div>
                        <div className="text-sm font-black text-gray-950">
                          {candidateRecord.name}
                        </div>
                      </div>

                      {/* Field: Permission */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedPermissionSource === 'b' 
                          ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">المأذونية في (ب):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedPermission(candidateRecord.permission);
                              setPickedPermissionSource('b');
                              notify(`✓ تم اعتماد مأذونية السجل (ب)`);
                            }}
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                              pickedPermissionSource === 'b'
                                ? 'bg-indigo-700 text-white font-black'
                                : 'bg-white hover:bg-indigo-100 text-indigo-900 border border-indigo-300'
                            }`}
                          >
                            {pickedPermissionSource === 'b' ? <Check className="w-3 h-3" /> : null}
                            <span>{pickedPermissionSource === 'b' ? '✓ المعتمد' : 'اعتماد مأذونية (ب)'}</span>
                          </button>
                        </div>
                        <div className="text-xs font-bold text-gray-900">
                          {candidateRecord.permission}
                        </div>
                      </div>

                      {/* Field: Category */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedCategorySource === 'b' 
                          ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">التصنيف في (ب):</span>
                          <button
                            type="button"
                            onClick={() => {
                              setPickedCategory(candidateRecord.category || 'شارع');
                              setPickedCategorySource('b');
                            }}
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                              pickedCategorySource === 'b'
                                ? 'bg-indigo-700 text-white font-black'
                                : 'bg-white hover:bg-indigo-100 text-indigo-900 border border-indigo-300'
                            }`}
                          >
                            {pickedCategorySource === 'b' ? <Check className="w-3 h-3" /> : null}
                            <span>{pickedCategorySource === 'b' ? '✓ المعتمد' : 'اعتماد تصنيف (ب)'}</span>
                          </button>
                        </div>
                        <div className="text-xs font-bold text-gray-900">
                          {candidateRecord.category || 'شارع'}
                        </div>
                      </div>

                      {/* Field: Metadata / Notes */}
                      <div className={`p-3 rounded-2xl border transition ${
                        pickedMetadataSource === 'b' 
                          ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-gray-600">الملاحظات في (ب):</span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                setPickedMetadata(candidateRecord.metadata || '');
                                setPickedMetadataSource('b');
                                notify(`✓ تم اختيار ملاحظات السجل (ب)`);
                              }}
                              className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                                pickedMetadataSource === 'b'
                                  ? 'bg-indigo-700 text-white font-black'
                                  : 'bg-white hover:bg-indigo-100 text-indigo-900 border border-indigo-300'
                              }`}
                            >
                              {pickedMetadataSource === 'b' ? <Check className="w-3 h-3" /> : null}
                              <span>{pickedMetadataSource === 'b' ? '✓ المعتمد' : 'ملاحظات (ب)'}</span>
                            </button>

                            {/* Clean Merge Option */}
                            <button
                              type="button"
                              onClick={() => {
                                const merged = mergeNotesCleanly(
                                  primaryRecord.metadata || '',
                                  candidateRecord.metadata || '',
                                  primaryRecord,
                                  candidateRecord
                                );
                                setPickedMetadata(merged);
                                setPickedMetadataSource('merged');
                                notify(`✓ تم دمج ملاحظات الطرفين معاً`);
                              }}
                              className={`px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                                pickedMetadataSource === 'merged'
                                  ? 'bg-purple-700 text-white font-black'
                                  : 'bg-purple-50 text-purple-900 border border-purple-300'
                              }`}
                              title="دمج ملاحظات الطرفين معاً دون تكرار"
                            >
                              <GitMerge className="w-3 h-3" />
                              <span>{pickedMetadataSource === 'merged' ? '✓ دمج الطرفين' : 'دمج الطرفين ⇋'}</span>
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-gray-700 whitespace-pre-line min-h-[45px]">
                          {candidateRecord.metadata || 'لا توجد ملاحظات.'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ================= PRE-SAVE VERIFICATION & STAGING PREVIEW ================= */}
                <div className="bg-white rounded-3xl border-2 border-amber-300 shadow-xl p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-200 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                        <FileCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-gray-950">
                          معاينة السجل النهائي الموثق واستيثاق الحفظ (Pre-Save Verification Staging)
                        </h4>
                        <p className="text-xs text-gray-500">
                          يتم تجميع الحقول الأدق المختارة هنا للمراجعة الدقيقة مع إمكانية التعديل قبل الحفظ النهائي
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-gray-700">حالة السجل المعتمد:</span>
                      <select
                        value={pickedStatus}
                        onChange={(e) => {
                          const s = e.target.value as RecordStatus;
                          setPickedStatus(s);
                          setPickedIsLocked(s === 'تام');
                        }}
                        className="px-3 py-1.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-bold text-gray-900"
                      >
                        <option value="تام">🔒 بيان تام (عنوان الحقيقة المغلق)</option>
                        <option value="نشط">نشط</option>
                        <option value="قيد المراجعة">قيد المراجعة</option>
                      </select>
                    </div>
                  </div>

                  {/* Editable Staging Form */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Final Name */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-700 flex items-center justify-between">
                        <span>اسم الشارع المعتمد:</span>
                        <span className="text-[10px] text-gray-500 font-normal">
                          (المصدر: {pickedNameSource === 'a' ? 'السجل أ' : pickedNameSource === 'b' ? 'السجل ب' : 'مخصص'})
                        </span>
                      </label>
                      <input
                        type="text"
                        value={pickedName}
                        onChange={(e) => {
                          setPickedName(e.target.value);
                          setPickedNameSource('custom');
                        }}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-300 rounded-xl text-xs font-black text-gray-950 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    {/* Final Permission */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-700 flex items-center justify-between">
                        <span>المأذونية المعتمدة:</span>
                        <span className="text-[10px] text-gray-500 font-normal">
                          (المصدر: {pickedPermissionSource === 'a' ? 'السجل أ' : pickedPermissionSource === 'b' ? 'السجل ب' : 'مخصص'})
                        </span>
                      </label>
                      <select
                        value={pickedPermission}
                        onChange={(e) => {
                          setPickedPermission(e.target.value);
                          setPickedPermissionSource('custom');
                        }}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-amber-500 cursor-pointer"
                      >
                        {OFFICIAL_NOTARIZATIONS.map(notar => (
                          <option key={notar} value={notar}>{notar}</option>
                        ))}
                        {!OFFICIAL_NOTARIZATIONS.includes(pickedPermission as any) && pickedPermission && (
                          <option value={pickedPermission}>{pickedPermission}</option>
                        )}
                      </select>
                    </div>

                    {/* Final Category */}
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-700 flex items-center justify-between">
                        <span>التصنيف الإداري:</span>
                        <span className="text-[10px] text-gray-500 font-normal">
                          (المصدر: {pickedCategorySource === 'a' ? 'السجل أ' : 'السجل ب'})
                        </span>
                      </label>
                      <input
                        type="text"
                        value={pickedCategory}
                        onChange={(e) => {
                          setPickedCategory(e.target.value);
                          setPickedCategorySource('custom');
                        }}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>

                    {/* Final Metadata & Notes */}
                    <div className="md:col-span-3 space-y-1">
                      <label className="text-xs font-bold text-gray-700 flex items-center justify-between">
                        <span>الملاحظات والبيانات الوصفية النهائية:</span>
                        <span className="text-[10px] text-gray-500 font-normal">
                          (المصدر: {pickedMetadataSource === 'merged' ? 'دمج الطرفين' : pickedMetadataSource === 'a' ? 'السجل أ' : 'السجل ب'})
                        </span>
                      </label>
                      <textarea
                        rows={2}
                        value={pickedMetadata}
                        onChange={(e) => {
                          setPickedMetadata(e.target.value);
                          setPickedMetadataSource('custom');
                        }}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-300 rounded-xl text-xs font-medium text-gray-900 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  {/* Safety Pre-Verification Actions */}
                  <div className="pt-3 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3 text-xs text-gray-600">
                      <span className="flex items-center gap-1 font-bold text-emerald-700">
                        <Check className="w-3.5 h-3.5" />
                        تم تدقيق الاسم والمأذونية
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-bold text-emerald-700">
                        <Check className="w-3.5 h-3.5" />
                        البيان محمي وموثق
                      </span>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Action 1: Adopt Truth and link candidate */}
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyActionType('adopt_truth');
                          setShowVerifyModal(true);
                        }}
                        className="flex items-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                        title="اعتماد وحفظ السجل المختار كـ «بيان تام 🔒» وتوثيق السجل المقابل برابط تصنيفي"
                      >
                        <Lock className="w-4 h-4 text-amber-300" />
                        <span>اعتماد كـ «بيان تام 🔒» وربط السجل المقابل</span>
                      </button>

                      {/* Action 2: Update both safely */}
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyActionType('update_both');
                          setShowVerifyModal(true);
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition"
                        title="تحديث كلا السجلين بالبيانات الأدقة المختارة بأمان"
                      >
                        <Save className="w-4 h-4" />
                        <span>حفظ وتحديث السجلين بأمان</span>
                      </button>

                      {/* Action 3: Merge into one and archive candidate */}
                      <button
                        type="button"
                        onClick={() => {
                          setVerifyActionType('merge_into_one');
                          setShowVerifyModal(true);
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-2.5 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition"
                        title="دمج السجلين في سجل موثق واحد وأرشفة السجل المكرر"
                      >
                        <GitMerge className="w-4 h-4" />
                        <span>دمج السجلين في سجل واحد</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* ================= LIST VIEW (عرض القائمة التقليدية) ================= */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50">
            {filteredGroups.map(group => (
              <div 
                key={group.id}
                className="bg-white p-4 rounded-3xl border border-gray-200 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                  <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
                    <span>{group.rootName}</span>
                    <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-900">
                      {group.records.length} سجلات
                    </span>
                  </h4>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedGroupId(group.id);
                      setViewMode('side_by_side');
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    <Columns className="w-3.5 h-3.5" />
                    <span>فتح المقارنة المتجاورة ⚡</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {group.records.map(rec => (
                    <div 
                      key={rec.id}
                      className="p-3 bg-gray-50 rounded-2xl border border-gray-200 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-900">{rec.name}</span>
                        {rec.status === 'تام' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded-md">
                            <Lock className="w-3 h-3" />
                            <span>تام 🔒</span>
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-gray-600">
                        {rec.permission} • {rec.category}
                      </div>
                      {rec.metadata && (
                        <p className="text-[10px] text-gray-500 truncate">{rec.metadata}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ================= FINAL SAFETY CONFIRMATION DIALOG ================= */}
        {showVerifyModal && primaryRecord && candidateRecord && (
          <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 space-y-4 text-right">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-base font-black text-gray-950">استيثاق وتأكيد أمان الحفظ</h4>
                  <p className="text-xs text-gray-500">يرجى مراجعة ملخص الإجراء قبل التطبيق النهائي على قاعدة البيانات</p>
                </div>
              </div>

              {/* Summary of What Will Happen */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs space-y-2">
                <div className="font-bold text-slate-800">تفاصيل السجل المعتمد الناتج:</div>
                <div className="grid grid-cols-2 gap-2 text-slate-700">
                  <div><strong>اسم الشارع:</strong> {pickedName}</div>
                  <div><strong>المأذونية:</strong> {pickedPermission}</div>
                  <div><strong>التصنيف:</strong> {pickedCategory}</div>
                  <div><strong>الحالة:</strong> {pickedStatus === 'تام' ? '🔒 بيان تام مغلق' : pickedStatus}</div>
                </div>
                {pickedMetadata && (
                  <div className="pt-2 border-t border-slate-200">
                    <span className="font-bold">الملاحظات:</span>
                    <p className="text-[11px] text-slate-600 whitespace-pre-line mt-0.5">{pickedMetadata}</p>
                  </div>
                )}
              </div>

              <div className="text-xs text-gray-600 bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                ✓ سيتم تسجيل عملية التدقيق والمقارنة في سجل التوثيق القانوني (Audit Log) متضمناً تاريخ ووقت المراجعة.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowVerifyModal(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  إلغاء وتعديل
                </button>

                <button
                  type="button"
                  onClick={executeVerifiedCommit}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-black shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>تأكيد الحفظ النهائي والاعتماد</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
