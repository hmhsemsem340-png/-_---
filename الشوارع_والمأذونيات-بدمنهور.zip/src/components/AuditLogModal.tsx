import React, { useState } from 'react';
import {
  X,
  History,
  User,
  Clock,
  ArrowLeft,
  Copy,
  Check,
  Printer,
  ShieldCheck,
  Edit3,
  FileSpreadsheet
} from 'lucide-react';
import { RecordItem, AuditLogEntry } from '../types';
import { getAuditUserName, setAuditUserName, formatAuditDate } from '../utils/auditLogger';

interface AuditLogModalProps {
  record: RecordItem | null;
  onClose: () => void;
  onEditRecord?: (record: RecordItem) => void;
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({
  record,
  onClose,
  onEditRecord
}) => {
  const [currentAuditor, setCurrentAuditor] = useState<string>(getAuditUserName());
  const [isEditingAuditor, setIsEditingAuditor] = useState<boolean>(false);
  const [tempAuditor, setTempAuditor] = useState<string>(currentAuditor);
  const [copied, setCopied] = useState<boolean>(false);

  if (!record) return null;

  const logs: AuditLogEntry[] = record.auditLogs || [];
  const lastModified = record.lastModifiedAt || (logs[0]?.formattedDate) || 'سجل أصلي معتمد';
  const lastUser = record.lastModifiedBy || (logs[0]?.userName) || currentAuditor;

  const handleSaveAuditor = () => {
    if (tempAuditor.trim()) {
      setAuditUserName(tempAuditor.trim());
      setCurrentAuditor(tempAuditor.trim());
      setIsEditingAuditor(false);
    }
  };

  const handleCopyReport = () => {
    let report = `=== تقرير التوثيق وسجل التعديلات القانوني ===\n`;
    report += `اسم الشارع: ${record.name}\n`;
    report += `المأذونية المختصة: ${record.permission}\n`;
    report += `التصنيف: ${record.category || 'غير محدد'}\n`;
    report += `الملاحظات الحالية: ${record.metadata || 'لا توجد'}\n`;
    report += `تاريخ آخر تعديل: ${lastModified}\n`;
    report += `الموثق الأخير: ${lastUser}\n`;
    report += `-------------------------------------------\n`;
    report += `سجل العمليات والتعديلات (${logs.length} عملية):\n`;

    if (logs.length === 0) {
      report += `• لم يتم تسجيل أي تعديلات يدوية على هذا السجل حتى الآن.\n`;
    } else {
      logs.forEach((log, index) => {
        report += `[${index + 1}] التاريخ: ${log.formattedDate} | المستخدم: ${log.userName}\n`;
        if (log.note) report += `    بيان العملية: ${log.note}\n`;
        log.changes.forEach(change => {
          report += `    - ${change.fieldLabel}:\n`;
          report += `      * القيمة السابقة: ${change.oldValue}\n`;
          report += `      * القيمة الحالية: ${change.newValue}\n`;
        });
        report += `\n`;
      });
    }

    report += `تاريخ استخراج التقرير: ${formatAuditDate()}\n`;
    report += `المستخرج: ${currentAuditor}\n`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handlePrintAudit = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const htmlContent = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
        <head>
          <meta charset="utf-8">
          <title>شهادة وسجل تعديلات - ${record.name}</title>
          <style>
            body {
              font-family: system-ui, -apple-system, sans-serif;
              padding: 24px;
              color: #1e293b;
              line-height: 1.6;
            }
            .header {
              text-align: center;
              border-bottom: 2px solid #0f172a;
              padding-bottom: 16px;
              margin-bottom: 20px;
            }
            .title { font-size: 20px; font-weight: bold; margin: 0; color: #0f172a; }
            .subtitle { font-size: 13px; color: #64748b; margin-top: 4px; }
            .info-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 12px;
              background: #f8fafc;
              padding: 16px;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
              margin-bottom: 24px;
              font-size: 14px;
            }
            .info-item strong { color: #0f172a; }
            .section-title {
              font-size: 16px;
              font-weight: bold;
              border-bottom: 1px solid #cbd5e1;
              padding-bottom: 6px;
              margin-bottom: 14px;
            }
            .log-card {
              border: 1px solid #cbd5e1;
              border-radius: 6px;
              padding: 12px;
              margin-bottom: 12px;
              page-break-inside: avoid;
            }
            .log-header {
              display: flex;
              justify-content: space-between;
              font-weight: bold;
              background: #f1f5f9;
              padding: 6px 10px;
              border-radius: 4px;
              font-size: 13px;
              margin-bottom: 8px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: 13px;
              margin-top: 8px;
            }
            th, td {
              border: 1px solid #cbd5e1;
              padding: 6px 10px;
              text-align: right;
            }
            th { background: #f8fafc; font-weight: bold; }
            .old-val { color: #991b1b; text-decoration: line-through; background: #fff1f2; }
            .new-val { color: #166534; font-weight: bold; background: #f0fdf4; }
            .footer {
              margin-top: 30px;
              padding-top: 16px;
              border-top: 1px solid #cbd5e1;
              display: flex;
              justify-content: space-between;
              font-size: 12px;
              color: #64748b;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">جمهورية مصر العربية - محافظة البحيرة</h1>
            <p class="title" style="font-size: 16px; margin-top: 6px;">منظومة الشوارع والمأذونيات بدمنهور</p>
            <p class="subtitle">سجل التعديلات والتوثيق القانوني للشارع (Audit Trail Certificate)</p>
          </div>

          <div class="info-grid">
            <div class="info-item"><strong>اسم الشارع:</strong> ${record.name}</div>
            <div class="info-item"><strong>المأذونية المختصة:</strong> ${record.permission}</div>
            <div class="info-item"><strong>التصنيف:</strong> ${record.category || 'غير محدد'}</div>
            <div class="info-item"><strong>الملاحظات الحالية:</strong> ${record.metadata || 'لا توجد'}</div>
            <div class="info-item"><strong>تاريخ آخر تعديل:</strong> ${lastModified}</div>
            <div class="info-item"><strong>الموثق المسؤول:</strong> ${lastUser}</div>
          </div>

          <div class="section-title">تفاصيل سجل التعديلات والتغييرات السابقة (${logs.length} عملية):</div>

          ${logs.length === 0 ? `
            <div style="text-align: center; padding: 24px; color: #64748b; border: 1px dashed #cbd5e1; border-radius: 6px;">
              لم تُسجل أي تغييرات سابقة على هذا الشارع. السجل يحتفظ ببياناته الأصلية المعتمدة.
            </div>
          ` : logs.map((log, i) => `
            <div class="log-card">
              <div class="log-header">
                <span>عملية رقم [${logs.length - i}]: ${log.formattedDate}</span>
                <span>المستخدم القائم بالإجراء: ${log.userName}</span>
              </div>
              ${log.note ? `<div style="font-size: 12px; color: #475569; margin-bottom: 6px;"><strong>البيان:</strong> ${log.note}</div>` : ''}
              <table>
                <thead>
                  <tr>
                    <th style="width: 25%;">البيان المعدل</th>
                    <th style="width: 37%;">القيمة السابقة</th>
                    <th style="width: 38%;">القيمة المحدثة (الحالية)</th>
                  </tr>
                </thead>
                <tbody>
                  ${log.changes.map(c => `
                    <tr>
                      <td><strong>${c.fieldLabel}</strong></td>
                      <td class="old-val">${c.oldValue}</td>
                      <td class="new-val">${c.newValue}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `).join('')}

          <div class="footer">
            <span>تاريخ استخراج الشهادة: ${formatAuditDate()}</span>
            <span>الموثق / المراجع: ${currentAuditor}</span>
            <span>توقيع الموثق: ............................</span>
          </div>

          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const getActionBadge = (action: AuditLogEntry['action']) => {
    switch (action) {
      case 'create':
        return <span className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300">إنشاء السجل</span>;
      case 'permission_update':
        return <span className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-purple-100 text-purple-800 border border-purple-300">تعديل المأذونية</span>;
      case 'note_update':
        return <span className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-amber-100 text-amber-800 border border-amber-300">تعديل الملاحظات</span>;
      default:
        return <span className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-blue-100 text-blue-800 border border-blue-300">تحديث بيانات</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl border border-white/20">
              <History className="w-5 h-5 text-indigo-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">سجل التعديلات والتوثيق القانوني</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  Audit Trail
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                تتبع كامل لكافة التغييرات والقيم السابقة والحالية وتواريخ التوثيق
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Street Summary & Auditor Banner */}
        <div className="p-4 bg-slate-50 border-b border-gray-200 shrink-0 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-semibold text-gray-500">الشارع الحالي:</span>
              <span className="text-sm font-black text-gray-900 bg-white px-2.5 py-1 rounded-lg border border-gray-200 shadow-2xs">
                {record.name}
              </span>
              <span className="text-xs font-semibold text-gray-500">المأذونية:</span>
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                {record.permission}
              </span>
            </div>

            {onEditRecord && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onEditRecord(record);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-gray-100 text-gray-700 text-xs font-bold rounded-lg border border-gray-300 shadow-2xs transition cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                <span>تعديل بيانات الشارع الآن</span>
              </button>
            )}
          </div>

          {/* Auditor / User configuration row (LocalStorage) */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-white rounded-xl border border-gray-200 text-xs">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="text-gray-600 font-medium">المستخدم القائم بالتوثيق (محفوظ محلياً):</span>
              
              {isEditingAuditor ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={tempAuditor}
                    onChange={(e) => setTempAuditor(e.target.value)}
                    className="px-2.5 py-1 text-xs border border-emerald-400 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-bold text-gray-900 bg-emerald-50/40"
                    placeholder="اكتب اسم الموثق..."
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={handleSaveAuditor}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer shadow-2xs"
                  >
                    حفظ
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTempAuditor(currentAuditor);
                      setIsEditingAuditor(false);
                    }}
                    className="px-2 py-1 bg-gray-200 text-gray-700 rounded-lg text-xs cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="font-bold text-gray-900 bg-emerald-50 text-emerald-900 px-2 py-0.5 rounded border border-emerald-200">
                    {currentAuditor}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setTempAuditor(currentAuditor);
                      setIsEditingAuditor(true);
                    }}
                    className="text-xs text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                  >
                    (تغيير المستخدم)
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-1.5 text-gray-500 text-[11px]">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>آخر توثيق: <strong className="text-gray-800">{lastModified}</strong></span>
            </div>
          </div>
        </div>

        {/* Audit Log Entries List */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4 bg-gray-50/50">
          {logs.length === 0 ? (
            <div className="text-center py-12 px-4 bg-white rounded-2xl border border-dashed border-gray-300">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3 border border-indigo-100">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-black text-gray-900 mb-1">لا توجد تعديلات سابقة مسجلة على هذا الشارع</h3>
              <p className="text-xs text-gray-500 max-w-md mx-auto leading-relaxed">
                هذا السجل يحتفظ ببياناته الأصلية المعتمدة. عند قيامك بأي تعديل مستقبلي (على الاسم، المأذونية، الملاحظات، أو التصنيف)، سيقوم النظام آلياً بتسجيل:
              </p>
              <div className="inline-flex items-center gap-3 mt-3 text-[11px] font-bold text-gray-600 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200">
                <span>✓ تاريخ ووقت التعديل</span>
                <span>✓ اسم المستخدم ({currentAuditor})</span>
                <span>✓ القيمة السابقة والحالية</span>
              </div>
            </div>
          ) : (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between text-xs text-gray-500 px-1">
                <span className="font-bold">التسلسل الزمني للعمليات والتعديلات ({logs.length} عملية مسجلة):</span>
                <span>مرتبة من الأحدث إلى الأقدم</span>
              </div>

              {logs.map((log, index) => (
                <div
                  key={log.id || index}
                  className="bg-white rounded-xl border border-gray-200 shadow-2xs overflow-hidden transition hover:border-indigo-200 hover:shadow-xs"
                >
                  {/* Card Header */}
                  <div className="p-3 bg-gray-50/80 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-black flex items-center justify-center border border-indigo-200">
                        {logs.length - index}
                      </span>
                      {getActionBadge(log.action)}
                      {log.note && (
                        <span className="text-xs text-gray-600 font-medium mr-1">
                          • {log.note}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <div className="flex items-center gap-1 font-bold text-gray-700">
                        <User className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{log.userName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[11px]">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{log.formattedDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Changes Table */}
                  <div className="p-3">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-right border-collapse">
                        <thead>
                          <tr className="border-b border-gray-200 text-[11px] text-gray-500 font-semibold bg-gray-50/50">
                            <th className="py-1.5 px-3 w-1/4">البيان</th>
                            <th className="py-1.5 px-3 w-3/8 text-rose-700">القيمة السابقة</th>
                            <th className="py-1.5 px-3 w-3/8 text-emerald-700">القيمة المحدثة (الجديدة)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {log.changes.map((change, cIdx) => (
                            <tr key={cIdx} className="hover:bg-gray-50/50">
                              <td className="py-2 px-3 font-bold text-gray-800 flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                                <span>{change.fieldLabel}</span>
                              </td>
                              <td className="py-2 px-3">
                                <div className="p-1.5 rounded-lg bg-rose-50 border border-rose-200/70 text-rose-900 line-through text-[11px] leading-relaxed break-words font-medium">
                                  {change.oldValue || '—'}
                                </div>
                              </td>
                              <td className="py-2 px-3">
                                <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 font-bold text-[11px] leading-relaxed break-words">
                                  {change.newValue || '—'}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 sm:p-4 bg-white border-t border-gray-200 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyReport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer"
              title="نسخ تقرير التوثيق القانوني للحافظة"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">تم النسخ بنجاح!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-600" />
                  <span>نسخ التقرير</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handlePrintAudit}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer"
              title="طباعة شهادة وسجل التعديلات القانوني للشارع"
            >
              <Printer className="w-4 h-4 text-indigo-600" />
              <span>طباعة الشهادة الرسمية</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
