import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  X, 
  Upload, 
  FileSpreadsheet, 
  CheckCircle, 
  AlertCircle, 
  AlertTriangle,
  Languages,
  RefreshCw,
  Sparkles,
  Columns,
  Info,
  Search,
  ShieldAlert
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { RecordItem, ThemeType } from '../types';
import {
  decodeTextBuffer,
  cleanArabicString,
  normalizeArabicText,
  scoreStreetNameColumn,
  scorePermissionColumn,
  scoreMetadataColumn,
  scoreCategoryColumn,
  ARABIC_CHAR_REGEX,
  SupportedEncoding
} from '../utils/arabicEncoding';
import { embedSimilarityNoteIntoMetadata } from '../utils/streetSimilarity';
import {
  getLibreOfficeStatus,
  convertWithLibreOffice,
  LibreOfficeStatus
} from '../utils/libreoffice';

export type ImportDuplicateDecision = 'merge' | 'replace' | 'separate' | 'skip';

interface DuplicateMatch {
  parsedIndex: number;
  parsed: Omit<RecordItem, 'id'>;
  existing: RecordItem;
  isSamePermission: boolean;
  notesSimilarity: 'identical' | 'different' | 'existing-only' | 'incoming-only' | 'none';
}

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportData: (
    imported: Omit<RecordItem, 'id'>[],
    mode: 'append' | 'replace',
    decisions?: Record<number, ImportDuplicateDecision>
  ) => void;
  existingRecords: RecordItem[];
  theme: ThemeType;
}

export function ImportModal({
  isOpen,
  onClose,
  onImportData,
  existingRecords,
  theme
}: ImportModalProps) {
  const [rawBuffer, setRawBuffer] = useState<ArrayBuffer | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileExt, setFileExt] = useState<string>('');
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [encoding, setEncoding] = useState<SupportedEncoding>('auto');
  const [usedEncodingLabel, setUsedEncodingLabel] = useState<string>('UTF-8');
  const [autoFixMojibake, setAutoFixMojibake] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Raw rows extracted from Excel/CSV (2D matrix of strings)
  const [rawSheetRows, setRawSheetRows] = useState<string[][]>([]);
  
  // Mapping configuration
  const [headerRowIndex, setHeaderRowIndex] = useState<number>(0);
  const [nameColIndex, setNameColIndex] = useState<number>(0);
  const [permColIndex, setPermColIndex] = useState<number>(-1);
  const [metaColIndex, setMetaColIndex] = useState<number>(-1);
  const [catColIndex, setCatColIndex] = useState<number>(-1);
  
  // Fallback single permission if not present in sheet
  const [fallbackPermission, setFallbackPermission] = useState<string>('شبرا بحري');

  // Per-duplicate import decisions (keyed by parsed record index)
  const [duplicateDecisions, setDuplicateDecisions] = useState<Record<number, ImportDuplicateDecision>>({});

  // Option to automatically embed similarity notes into metadata
  const [autoEmbedSimilarityNotes, setAutoEmbedSimilarityNotes] = useState<boolean>(true);

  // LibreOffice bridge state
  const [loStatus, setLoStatus] = useState<LibreOfficeStatus | null>(null);
  const [loConverting, setLoConverting] = useState<boolean>(false);

  // Check LibreOffice availability on mount
  useEffect(() => {
    let cancelled = false;
    getLibreOfficeStatus().then(status => {
      if (!cancelled) setLoStatus(status);
    });
    return () => { cancelled = true; };
  }, []);

  // Official districts list for easy fallback assignment
  const officialDistricts = [
    'شبرا بحري',
    'شبرا قبلي',
    'إفلاقة وتوابعها',
    'قرطسا وتوابعها',
    'نقرها أول وتوابعها',
    'نقرها ثان وتوابعها',
    'أبو الريش وتوابعها',
    'مأذونية عامة / دمنهور'
  ];

  // Parse raw buffer whenever buffer, encoding, or file changes
  const parseBuffer = useCallback((buffer: ArrayBuffer, ext: string, enc: SupportedEncoding) => {
    try {
      setErrorMsg(null);
      let rows: string[][] = [];
      let detectedLabel = 'UTF-8';

      const isCsvOrTxt = ext === 'csv' || ext === 'tsv' || ext === 'txt';

      if (isCsvOrTxt) {
        // Handle CSV / TSV with specialized Arabic decoding (UTF-8 vs Windows-1256 / ANSI)
        const { text, usedEncoding } = decodeTextBuffer(buffer, enc);
        detectedLabel = usedEncoding;
        
        // Read text via XLSX to accurately handle quotes, delimiters, and commas
        const wb = XLSX.read(text, { type: 'string', raw: true });
        const wsName = wb.SheetNames[0];
        if (wsName && wb.Sheets[wsName]) {
          rows = XLSX.utils.sheet_to_json(wb.Sheets[wsName], { header: 1, defval: '' }) as string[][];
        } else {
          // Fallback line split
          rows = text.split(/\r?\n/).map(line => {
            return line.includes('\t') 
              ? line.split('\t') 
              : line.includes(';') 
                ? line.split(';') 
                : line.split(',');
          });
        }
      } else {
        // Excel / LibreOffice files (.xlsx, .xls, .ods)
        const wb = XLSX.read(buffer, { type: 'array', codepage: 65001 });
        const wsName = wb.SheetNames[0];
        if (!wsName || !wb.Sheets[wsName]) {
          setErrorMsg('الملف لا يحتوي على أوراق عمل صالحة.');
          return;
        }
        rows = XLSX.utils.sheet_to_json(wb.Sheets[wsName], { header: 1, defval: '' }) as string[][];
        detectedLabel = ext === 'ods' ? 'LibreOffice ODS (OpenDocument)' : 'Excel Binary (UTF-8)';
      }

      setUsedEncodingLabel(detectedLabel);

      // Clean every cell with Arabic normalization
      const cleanedRows = rows
        .map(row => (Array.isArray(row) ? row.map(cell => cleanArabicString(cell)) : []))
        .filter(row => row.some(cell => cell.length > 0));

      if (cleanedRows.length === 0) {
        setErrorMsg('الملف فارغ أو لا يحتوي على صفوف بيانات مقروءة.');
        setRawSheetRows([]);
        return;
      }

      setRawSheetRows(cleanedRows);

      // 1. Detect best Header Row in first 10 rows
      let bestHeaderIdx = 0;
      let maxHeaderScore = -1;

      for (let r = 0; r < Math.min(10, cleanedRows.length); r++) {
        const row = cleanedRows[r];
        let rowScore = 0;
        row.forEach(cell => {
          const c = cell.toLowerCase();
          if (c.includes('شارع') || c.includes('حارة') || c.includes('اسم') || c.includes('مأذونية') || c.includes('بيان') || c.includes('ملاحظات')) {
            rowScore += 10;
          }
        });
        if (rowScore > maxHeaderScore) {
          maxHeaderScore = rowScore;
          bestHeaderIdx = r;
        }
      }

      setHeaderRowIndex(bestHeaderIdx);

      // 2. Identify candidate columns based on header row and subsequent data
      const headerRow = cleanedRows[bestHeaderIdx] || [];
      const colCount = Math.max(...cleanedRows.slice(0, 10).map(r => r.length));

      let bestNameCol = 0;
      let bestNameScore = -999;
      let bestPermCol = -1;
      let bestPermScore = 0;
      let bestMetaCol = -1;
      let bestMetaScore = 0;
      let bestCatCol = -1;
      let bestCatScore = 0;

      for (let c = 0; c < colCount; c++) {
        const headerText = headerRow[c] || `العمود ${c + 1}`;
        const sampleValues = cleanedRows.slice(bestHeaderIdx + 1, bestHeaderIdx + 15).map(r => r[c] || '');

        const nameScore = scoreStreetNameColumn(headerText, sampleValues);
        if (nameScore > bestNameScore) {
          bestNameScore = nameScore;
          bestNameCol = c;
        }

        const permScore = scorePermissionColumn(headerText, sampleValues);
        if (permScore > bestPermScore) {
          bestPermScore = permScore;
          bestPermCol = c;
        }

        const metaScore = scoreMetadataColumn(headerText, sampleValues);
        if (metaScore > bestMetaScore) {
          bestMetaScore = metaScore;
          bestMetaCol = c;
        }

        const catScore = scoreCategoryColumn(headerText, sampleValues);
        if (catScore > bestCatScore) {
          bestCatScore = catScore;
          bestCatCol = c;
        }
      }

      // Special intelligent handling for 2-column files (e.g. Street + Permission OR Street + Notes)
      if (colCount === 2) {
        const otherCol = bestNameCol === 0 ? 1 : 0;
        const otherHeader = headerRow[otherCol] || '';
        const otherSamples = cleanedRows.slice(bestHeaderIdx + 1, bestHeaderIdx + 15).map(r => r[otherCol] || '');
        
        const pScore = scorePermissionColumn(otherHeader, otherSamples);
        const mScore = scoreMetadataColumn(otherHeader, otherSamples);

        if (pScore > mScore && pScore > 0) {
          bestPermCol = otherCol;
          bestMetaCol = -1;
        } else if (mScore > pScore && mScore > 0) {
          bestMetaCol = otherCol;
          bestPermCol = -1;
        } else {
          // Check if values in other column match official district names
          const hasDistrictMatch = otherSamples.some(val => 
            /(شبرا|إفلاقة|قرطسا|نقرها|الريش|سكنيدة|طاموس|سيدي عمر|القلعة|أبو الريش|الأبعادية|الروضة)/.test(val)
          );
          if (hasDistrictMatch) {
            bestPermCol = otherCol;
            bestMetaCol = -1;
          } else {
            bestMetaCol = otherCol;
            bestPermCol = -1;
          }
        }
      }

      // Avoid mapping the same column to multiple fields if other candidates exist
      if (bestPermCol === bestNameCol) bestPermCol = -1;
      if (bestMetaCol === bestNameCol) bestMetaCol = -1;
      if (bestCatCol === bestNameCol) bestCatCol = -1;

      setNameColIndex(bestNameCol);
      setPermColIndex(bestPermCol);
      setMetaColIndex(bestMetaCol);
      setCatColIndex(bestCatCol);

    } catch (err) {
      console.error(err);
      setErrorMsg('تعذر تحليل الملف. تأكد من أن الملف بصيغة إكسيل أو CSV سليمة.');
    }
  }, []);

  // Handle file input
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const name = file.name;
    const ext = name.split('.').pop()?.toLowerCase() || '';
    setFileName(name);
    setFileExt(ext);
    setErrorMsg(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const buffer = evt.target?.result as ArrayBuffer;
      if (buffer) {
        setRawBuffer(buffer);
        parseBuffer(buffer, ext, encoding);
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  // Re-run parsing if encoding is changed by the user
  const handleEncodingChange = (newEnc: SupportedEncoding) => {
    setEncoding(newEnc);
    if (rawBuffer && fileExt) {
      parseBuffer(rawBuffer, fileExt, newEnc);
    }
  };

  // Convert the currently loaded file via LibreOffice (soffice --headless) then re-parse
  const handleLibreOfficeConvert = async () => {
    if (!rawBuffer || !fileName) return;
    setLoConverting(true);
    try {
      const file = new File([rawBuffer], fileName);
      const blob = await convertWithLibreOffice(file, 'xlsx');
      if (!blob) {
        setErrorMsg('تعذر التحويل عبر ليبرأوفيس. تأكد من تشغيل الخادم (npm run server).');
        return;
      }
      const buffer = await blob.arrayBuffer();
      setRawBuffer(buffer);
      setFileName(fileName.replace(/\.[^.]+$/, '') + '.xlsx');
      setFileExt('xlsx');
      parseBuffer(buffer, 'xlsx', encoding);
    } finally {
      setLoConverting(false);
    }
  };

  // Compute parsed records from rawSheetRows and active column mappings
  const parsedRecords = useMemo(() => {
    if (rawSheetRows.length === 0) return [];

    const startRow = headerRowIndex + 1;
    const records: Omit<RecordItem, 'id'>[] = [];

    for (let i = startRow; i < rawSheetRows.length; i++) {
      const row = rawSheetRows[i];
      if (!row || row.length === 0) continue;

      let rawName = cleanArabicString(row[nameColIndex] || '');
      if (!rawName) continue;

      // Filter out pure numbers if they leaked through
      if (/^\d+$/.test(rawName.trim()) && row.length > 1) {
        // Check if there's another column with actual text
        const altCol = row.find(val => ARABIC_CHAR_REGEX.test(val));
        if (altCol) rawName = cleanArabicString(altCol);
      }

      // Permission
      let permission = permColIndex >= 0 && row[permColIndex] 
        ? cleanArabicString(row[permColIndex]) 
        : fallbackPermission;
      if (!permission) permission = fallbackPermission;

      // Metadata / description
      const metadata = metaColIndex >= 0 && row[metaColIndex]
        ? cleanArabicString(row[metaColIndex])
        : '';

      // Category
      let category = catColIndex >= 0 && row[catColIndex]
        ? cleanArabicString(row[catColIndex])
        : '';
      
      // Auto-infer category if empty
      if (!category) {
        if (rawName.startsWith('شارع')) category = 'شارع';
        else if (rawName.startsWith('حارة')) category = 'حارة';
        else if (rawName.startsWith('زقاق')) category = 'زقاق';
        else if (rawName.startsWith('ميدان')) category = 'ميدان';
        else if (rawName.startsWith('درب')) category = 'درب';
        else if (rawName.startsWith('طريق')) category = 'طريق';
        else category = 'شارع';
      }

      records.push({
        name: rawName,
        permission,
        category,
        metadata
      });
    }

    return records;
  }, [rawSheetRows, headerRowIndex, nameColIndex, permColIndex, metaColIndex, catColIndex, fallbackPermission]);

  // Statistics on Arabic detection
  const arabicStats = useMemo(() => {
    if (parsedRecords.length === 0) return { arabicCount: 0, percent: 0 };
    const arabicCount = parsedRecords.filter(r => ARABIC_CHAR_REGEX.test(r.name)).length;
    const percent = Math.round((arabicCount / parsedRecords.length) * 100);
    return { arabicCount, percent };
  }, [parsedRecords]);

  // Detect duplicates between parsed records and existing records (normalized name match)
  const duplicateMatches = useMemo<DuplicateMatch[]>(() => {
    if (parsedRecords.length === 0 || existingRecords.length === 0) return [];
    const matches: DuplicateMatch[] = [];
    parsedRecords.forEach((parsed, idx) => {
      const normName = normalizeArabicText(parsed.name);
      if (!normName) return;
      const existing = existingRecords.find(r => normalizeArabicText(r.name) === normName);
      if (!existing) return;

      const isSamePermission = normalizeArabicText(existing.permission) === normalizeArabicText(parsed.permission);
      const existingNotes = existing.metadata?.trim() || '';
      const incomingNotes = parsed.metadata?.trim() || '';

      let notesSimilarity: DuplicateMatch['notesSimilarity'];
      if (!existingNotes && !incomingNotes) notesSimilarity = 'none';
      else if (existingNotes === incomingNotes) notesSimilarity = 'identical';
      else if (existingNotes && incomingNotes) notesSimilarity = 'different';
      else if (existingNotes) notesSimilarity = 'existing-only';
      else notesSimilarity = 'incoming-only';

      matches.push({ parsedIndex: idx, parsed, existing, isSamePermission, notesSimilarity });
    });
    return matches;
  }, [parsedRecords, existingRecords]);

  // Reset per-duplicate decisions whenever the parsed data changes
  useEffect(() => {
    setDuplicateDecisions({});
  }, [rawSheetRows, headerRowIndex, nameColIndex, permColIndex, metaColIndex, catColIndex]);

  // Summary of chosen actions for the review section
  const decisionSummary = useMemo(() => {
    const summary = { merge: 0, replace: 0, separate: 0, skip: 0 };
    duplicateMatches.forEach(m => {
      const d = duplicateDecisions[m.parsedIndex] ?? 'merge';
      summary[d]++;
    });
    return summary;
  }, [duplicateMatches, duplicateDecisions]);

  // Set of parsed indices that have an existing match (for preview badges)
  const matchedIndices = useMemo(
    () => new Set(duplicateMatches.map(m => m.parsedIndex)),
    [duplicateMatches]
  );

  const handleConfirmImport = () => {
    if (parsedRecords.length === 0) return;

    let finalRecords = [...parsedRecords];

    if (autoEmbedSimilarityNotes && duplicateMatches.length > 0) {
      const matchMap = new Map<number, DuplicateMatch>();
      duplicateMatches.forEach(m => matchMap.set(m.parsedIndex, m));

      finalRecords = finalRecords.map((rec, idx) => {
        const match = matchMap.get(idx);
        if (!match) return rec;

        const note = match.isSamePermission
          ? '[تكرر في نفس المأذونية]'
          : `[مشترك مع مأذونية: ${match.existing.permission}]`;

        return {
          ...rec,
          metadata: embedSimilarityNoteIntoMetadata(rec.metadata, note)
        };
      });
    }

    onImportData(finalRecords, importMode, duplicateDecisions);
    handleResetModal();
    onClose();
  };

  const handleResetModal = () => {
    setRawBuffer(null);
    setFileName('');
    setFileExt('');
    setRawSheetRows([]);
    setErrorMsg(null);
    setEncoding('auto');
  };

  const getThemeBg = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-700 text-white';
      case 'libreoffice': return 'bg-cyan-900 text-white';
      case 'hybrid': return 'bg-gradient-to-l from-emerald-700 via-cyan-800 to-indigo-900 text-white';
      case 'modern':
      default: return 'bg-indigo-900 text-white';
    }
  };

  if (!isOpen) return null;

  // Available column options from header row
  const headerRow = rawSheetRows[headerRowIndex] || [];
  const columnCount = Math.max(...rawSheetRows.slice(0, 10).map(r => r.length), 0);
  const columnOptions = Array.from({ length: columnCount }, (_, i) => {
    const title = headerRow[i] ? headerRow[i].trim() : `العمود ${i + 1}`;
    const sample = rawSheetRows[headerRowIndex + 1]?.[i] ? `(عينة: ${rawSheetRows[headerRowIndex + 1][i]})` : '';
    return {
      index: i,
      label: `${title} ${sample}`
    };
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-gray-100 flex flex-col max-h-[94vh]">
        
        {/* Modal Header */}
        <div className={`px-6 py-4 flex items-center justify-between shrink-0 ${getThemeBg()}`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <FileSpreadsheet className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold flex items-center gap-2">
                <span>استيراد وتغذية البيانات باللغة العربية والرموز الكاملة</span>
                <span className="px-2 py-0.5 bg-white/20 text-white rounded-full text-xs font-medium">
                  Excel / CSV
                </span>
              </h3>
              <p className="text-xs text-white/80">
                دعم ترميز ويندوز العربي Windows-1256 و UTF-8 • كشف ذكي لأسماء الشوارع • إصلاح فوري للنصوص المشوهة
              </p>
            </div>
          </div>
          <button 
            onClick={() => { handleResetModal(); onClose(); }} 
            className="p-1.5 rounded-lg hover:bg-white/20 transition text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-right">
          
          {/* 1. File Upload Dropzone */}
          <div className="border-2 border-dashed border-gray-300 rounded-2xl p-6 text-center hover:border-emerald-500 transition bg-gray-50/60 relative group">
            <input
              type="file"
              accept=".xlsx, .xls, .ods, .csv, .tsv, .txt"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
            />
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-2xl group-hover:scale-105 transition">
                <Upload className="w-8 h-8" />
              </div>
              <p className="font-bold text-gray-800 text-base">اسحب ملف الإكسيل أو CSV هنا، أو انقر لاختيار الملف من جهازك</p>
              <p className="text-xs text-gray-500">
                يدعم ملفات الإكسيل (.xlsx, .xls) وليبرأوفيس (.ods) وملفات الجداول (.csv, .tsv, .txt) بأي ترميز عربي
              </p>
              {fileName && (
                <div className="mt-2 inline-flex items-center gap-2 px-3.5 py-1.5 bg-emerald-50 text-emerald-900 text-xs font-bold rounded-xl border border-emerald-300 shadow-xs">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>الملف المختار: {fileName}</span>
                </div>
              )}
            </div>
          </div>

          {errorMsg && (
            <div className="p-4 bg-red-50 text-red-800 text-xs sm:text-sm rounded-xl border border-red-200 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span className="font-medium">{errorMsg}</span>
            </div>
          )}

          {/* 2. Encoding & Arabic Integrity Bar (تحديد الترميز ودعم الحروف العربية) */}
          {rawBuffer && (
            <div className="p-4 bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 border border-emerald-200 rounded-2xl space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Languages className="w-5 h-5 text-emerald-700" />
                  <span className="text-sm font-bold text-gray-900">
                    دعم اللغة العربية والرموز (ترميز الحروف):
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold text-gray-600">ترميز الملف:</span>
                  <select
                    value={encoding}
                    onChange={(e) => handleEncodingChange(e.target.value as SupportedEncoding)}
                    className="px-3 py-1.5 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-emerald-950 shadow-xs focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value="auto">⚡ كشف تلقائي ذكي (مستحسن)</option>
                    <option value="utf-8">🌐 UTF-8 (ترميز عالمي موحد)</option>
                    <option value="windows-1256">🏢 Windows-1256 (إكسيل ويندوز عربي الافتراضي)</option>
                    <option value="iso-8859-6">📜 ISO-8859-6 (عربي قياسي)</option>
                  </select>
                </div>
              </div>

              {/* Status indicator */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-emerald-200/60 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">الترميز النشط الآن:</span>
                  <span className="px-2 py-0.5 bg-white font-mono font-bold text-emerald-900 rounded-md border border-emerald-200">
                    {usedEncodingLabel}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-gray-600">نسبة النصوص العربية الصريحة:</span>
                  <span className={`px-2 py-0.5 rounded-md font-bold text-xs ${
                    arabicStats.percent > 80 
                      ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    {arabicStats.percent}% ({arabicStats.arabicCount.toLocaleString('ar-EG')} شارع عربي سليم)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 2.5 LibreOffice Integration (التكامل مع ليبرأوفيس في بيئة لينكس) */}
          <div className="p-4 bg-cyan-50/70 border border-cyan-200 rounded-2xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-cyan-700" />
                <span className="text-sm font-bold text-gray-900">
                  التكامل مع ليبرأوفيس (بيئة لينكس):
                </span>
              </div>
              {loStatus === null ? (
                <span className="px-2.5 py-1 bg-gray-100 text-gray-600 border border-gray-300 rounded-xl text-xs font-bold">
                  الخادم غير متصل (شغّل npm run server)
                </span>
              ) : loStatus.installed ? (
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold">
                  ✓ ليبرأوفيس مثبت: {loStatus.version}
                </span>
              ) : (
                <span className="px-2.5 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold">
                  ليبرأوفيس غير مثبت على النظام
                </span>
              )}
            </div>

            {rawBuffer && loStatus?.installed && (
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-cyan-200/60">
                <span className="text-xs text-gray-600">
                  تحويل الملف الحالي عبر ليبرأوفيس (soffice --headless) لضمان قراءة صحيحة للصيغ المعقدة:
                </span>
                <button
                  type="button"
                  onClick={handleLibreOfficeConvert}
                  disabled={loConverting}
                  className="flex items-center gap-2 px-4 py-2 bg-cyan-700 hover:bg-cyan-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${loConverting ? 'animate-spin' : ''}`} />
                  <span>{loConverting ? 'جارٍ التحويل...' : 'تحويل الملف عبر ليبرأوفيس'}</span>
                </button>
              </div>
            )}
          </div>

          {/* 3. Smart Column Mapping (تحديد ومطابقة الأعمدة بدقة) */}
          {rawSheetRows.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2">
                  <Columns className="w-5 h-5 text-emerald-600" />
                  <h4 className="text-sm font-bold text-gray-900">
                    مطابقة وتحديد أعمدة الشارع والبيانات
                  </h4>
                </div>
                <span className="text-xs text-gray-500 font-medium">
                  قام النظام باكتشاف الأعمدة تلقائياً ويمكنك تخصيصها إذا لزم الأمر
                </span>
              </div>

              {/* 2-Column Smart Mode Notice */}
              {columnOptions.length === 2 && (
                <div className="p-3.5 bg-blue-50/80 border border-blue-200 rounded-2xl flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 text-blue-950 font-bold">
                    <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>
                      تم التعرف الذكي على ملف ثنائي الأعمدة: 
                      {permColIndex !== -1 ? (
                        <span className="text-emerald-700 mx-1">«اسم الشارع + المأذونية»</span>
                      ) : metaColIndex !== -1 ? (
                        <span className="text-purple-700 mx-1">«اسم الشارع + البيان الوصفي / الملاحظات»</span>
                      ) : (
                        <span className="text-blue-700 mx-1">«اسم الشارع + بيانات إضافية»</span>
                      )}
                    </span>
                  </div>
                  <span className="text-[11px] text-blue-800 font-medium">
                    {permColIndex === -1 
                      ? 'سيتم تعيين المأذونية الافتراضية المحددة أدناه لجميع الشوارع'
                      : 'سيتم استنتاج التصنيف وتوليد الملاحظات آلياً'}
                  </span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
                
                {/* Header Row Selector */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <span>صف الترويسة / العناوين:</span>
                  </label>
                  <select
                    value={headerRowIndex}
                    onChange={(e) => setHeaderRowIndex(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:bg-white focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    {rawSheetRows.slice(0, 10).map((r, idx) => (
                      <option key={idx} value={idx}>
                        الصف رقم {idx + 1} {r[0] ? `(${r.slice(0, 2).join(' | ')})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Street Name Column */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-emerald-900 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>عمود اسم الشارع *:</span>
                  </label>
                  <select
                    value={nameColIndex}
                    onChange={(e) => setNameColIndex(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-emerald-50/70 border border-emerald-400 rounded-xl text-xs font-bold text-emerald-950 focus:bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    {columnOptions.map(col => (
                      <option key={col.index} value={col.index}>
                        {col.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Permission Column */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">عمود المأذونية:</label>
                  <select
                    value={permColIndex}
                    onChange={(e) => setPermColIndex(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:bg-white focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value={-1}>-- بدون عمود (تطبيق المأذونية أدناه) --</option>
                    {columnOptions.map(col => (
                      <option key={col.index} value={col.index}>
                        {col.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Metadata Column */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">عمود الملاحظات / الوصف:</label>
                  <select
                    value={metaColIndex}
                    onChange={(e) => setMetaColIndex(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:bg-white focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value={-1}>-- بدون عمود ملاحظات --</option>
                    {columnOptions.map(col => (
                      <option key={col.index} value={col.index}>
                        {col.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Category Column */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">عمود التصنيف:</label>
                  <select
                    value={catColIndex}
                    onChange={(e) => setCatColIndex(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:bg-white focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value={-1}>-- استنتاج تلقائي (شارع/حارة/...) --</option>
                    {columnOptions.map(col => (
                      <option key={col.index} value={col.index}>
                        {col.label}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Default Permission if no column in file */}
              {permColIndex === -1 && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="font-bold text-amber-900">
                    تطبيق مأذونية موحدة على كافة الشوارع المستوردة:
                  </span>
                  <select
                    value={fallbackPermission}
                    onChange={(e) => setFallbackPermission(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-amber-300 rounded-xl font-bold text-amber-950 focus:ring-2 focus:ring-amber-500 cursor-pointer"
                  >
                    {officialDistricts.map(dist => (
                      <option key={dist} value={dist}>{dist}</option>
                    ))}
                  </select>
                </div>
              )}

            </div>
          )}

          {/* 4. Import Mode & Live Arabic Preview Table */}
          {parsedRecords.length > 0 && (
            <div className="space-y-4">
              
              <div className="flex flex-wrap items-center justify-between bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200 text-emerald-950 text-xs sm:text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                  <span>
                    تم التعرف على <strong>{parsedRecords.length.toLocaleString('ar-EG')}</strong> شارع صالح للاستيراد باللغة العربية
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <label className="text-xs font-bold text-gray-700">طريقة الاستيراد:</label>
                  <select
                    value={importMode}
                    onChange={(e) => setImportMode(e.target.value as any)}
                    className="bg-white border border-emerald-400 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-950 cursor-pointer"
                  >
                    <option value="append">إضافة للسجلات الحالية (Append)</option>
                    <option value="replace">استبدال كامل السجلات الحالية (Replace)</option>
                  </select>
                </div>
              </div>

              {importMode === 'replace' && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-800 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>
                    تحذير: سيتم حذف جميع السجلات الحالية ({existingRecords.length.toLocaleString('ar-EG')}) واستبدالها بالملف المستورد بعد موافقتك على إجراءات التطابقات أدناه.
                  </span>
                </div>
              )}

              {/* Preview Table */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>معاينة حية للأسماء باللغة العربية والرموز (عينة من أول 6 شوارع):</span>
                  </h4>
                  <span className="text-[11px] text-gray-500 font-mono">
                    ظهور الكلمات واضحة يؤكد سلامة الترميز
                  </span>
                </div>

                <div className="border border-gray-200 rounded-2xl overflow-hidden text-xs shadow-xs">
                  <table className="w-full text-right border-collapse">
                    <thead className="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
                      <tr>
                        <th className="p-3 w-12 text-center">م</th>
                        <th className="p-3">اسم الشارع باللغة العربية</th>
                        <th className="p-3">المأذونية التابع لها</th>
                        <th className="p-3">التصنيف</th>
                        <th className="p-3">ملاحظات وبيانات وصفية</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 bg-white">
                      {parsedRecords.slice(0, 6).map((row, idx) => (
                        <tr key={idx} className="hover:bg-emerald-50/50 transition">
                          <td className="p-3 text-center font-mono font-bold text-gray-500">{idx + 1}</td>
                          <td className="p-3 font-bold text-gray-950 flex items-center gap-2">
                            <span>{row.name}</span>
                            {ARABIC_CHAR_REGEX.test(row.name) ? (
                              <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px] font-bold">عربي</span>
                            ) : (
                              <span className="px-1.5 py-0.5 bg-amber-100 text-amber-800 rounded text-[10px] font-bold">لاتيني</span>
                            )}
                            {matchedIndices.has(idx) && (
                              <span className="px-1.5 py-0.5 bg-amber-100 text-amber-800 border border-amber-300 rounded text-[10px] font-bold">
                                تطابق موجود
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-gray-700 font-medium">{row.permission}</td>
                          <td className="p-3 text-gray-600">
                            <span className="px-2 py-0.5 bg-gray-100 rounded-md font-semibold text-gray-800">
                              {row.category}
                            </span>
                          </td>
                          <td className="p-3 text-gray-500 truncate max-w-xs">{row.metadata || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 5. Duplicate Detection & Review Section */}
              {duplicateMatches.length > 0 && (
                <div className="bg-white border border-amber-300 rounded-2xl p-5 space-y-4 shadow-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-100 pb-3">
                    <div className="flex items-center gap-2">
                      <Search className="w-5 h-5 text-amber-600" />
                      <h4 className="text-sm font-bold text-gray-900">
                        اكتشاف التطابقات والتشابهات ({duplicateMatches.length.toLocaleString('ar-EG')})
                      </h4>
                    </div>
                    
                    <label className="flex items-center gap-2 text-xs font-bold text-emerald-900 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-300 cursor-pointer hover:bg-emerald-100/80 transition">
                      <input
                        type="checkbox"
                        checked={autoEmbedSimilarityNotes}
                        onChange={(e) => setAutoEmbedSimilarityNotes(e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded border-emerald-300 focus:ring-emerald-500 cursor-pointer"
                      />
                      <span>تضمين ملاحظة [مشترك مع مأذونية: ...] آلياً في خانة الملاحظات</span>
                    </label>
                  </div>

                  <div className="space-y-3">
                    {duplicateMatches.map(match => {
                      const decision = duplicateDecisions[match.parsedIndex] ?? 'merge';
                      return (
                        <div key={match.parsedIndex} className="border border-gray-200 rounded-2xl p-4 space-y-3 bg-gray-50/50">
                          {/* Header: incoming name + match type badge */}
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-gray-500">الشارع المستورد:</span>
                              <span className="font-black text-gray-950">{match.parsed.name}</span>
                            </div>
                            {match.isSamePermission ? (
                              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-[11px] font-bold">
                                <ShieldAlert className="w-3.5 h-3.5 inline-block ml-1" />
                                تطابق كامل (نفس المأذونية)
                              </span>
                            ) : (
                              <span className="px-2.5 py-1 bg-blue-100 text-blue-900 border border-blue-300 rounded-xl text-[11px] font-bold">
                                <Info className="w-3.5 h-3.5 inline-block ml-1" />
                                تطابق الاسم فقط (مأذونية مختلفة)
                              </span>
                            )}
                          </div>

                          {/* Existing record summary */}
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                            <span className="text-gray-500">السجل الحالي:</span>
                            <span className="font-bold text-gray-900">{match.existing.name}</span>
                            <span className="text-gray-400">•</span>
                            <span className="text-gray-600">المأذونية: <strong>{match.existing.permission}</strong></span>
                            <span className="text-gray-400">•</span>
                            <span className="text-gray-600">التصنيف: <strong>{match.existing.category || 'شارع'}</strong></span>
                          </div>

                          {/* Notes comparison side-by-side */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200">
                              <span className="text-[11px] font-bold text-emerald-900 block mb-1">الملاحظات الحالية:</span>
                              <p className="text-xs text-gray-800 bg-white p-2 rounded-lg border border-emerald-100 max-h-20 overflow-y-auto whitespace-pre-line leading-relaxed">
                                {match.existing.metadata?.trim() || <span className="text-gray-400 italic">لا توجد ملاحظات</span>}
                              </p>
                            </div>
                            <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200">
                              <span className="text-[11px] font-bold text-amber-900 block mb-1">الملاحظات المستوردة:</span>
                              <p className="text-xs text-gray-800 bg-white p-2 rounded-lg border border-amber-100 max-h-20 overflow-y-auto whitespace-pre-line leading-relaxed">
                                {match.parsed.metadata?.trim() || <span className="text-gray-400 italic">لا توجد ملاحظات</span>}
                              </p>
                            </div>
                          </div>

                          {/* Notes similarity indicator */}
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <span className="text-gray-500 font-bold">التشابه في الملاحظات:</span>
                            {match.notesSimilarity === 'identical' && (
                              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-lg font-bold">متطابقة تماماً</span>
                            )}
                            {match.notesSimilarity === 'different' && (
                              <span className="px-2 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 rounded-lg font-bold">مختلفة (توجد ملاحظات في الطرفين)</span>
                            )}
                            {match.notesSimilarity === 'existing-only' && (
                              <span className="px-2 py-0.5 bg-blue-100 text-blue-900 border border-blue-300 rounded-lg font-bold">ملاحظات موجودة فقط</span>
                            )}
                            {match.notesSimilarity === 'incoming-only' && (
                              <span className="px-2 py-0.5 bg-blue-100 text-blue-900 border border-blue-300 rounded-lg font-bold">ملاحظات جديدة فقط</span>
                            )}
                            {match.notesSimilarity === 'none' && (
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-700 border border-gray-300 rounded-lg font-bold">لا توجد ملاحظات في الطرفين</span>
                            )}
                          </div>

                          {/* Per-match action selector */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-gray-200">
                            <span className="text-xs font-bold text-gray-700">الإجراء المطلوب لهذا التطابق:</span>
                            <select
                              value={decision}
                              onChange={(e) => setDuplicateDecisions(prev => ({
                                ...prev,
                                [match.parsedIndex]: e.target.value as ImportDuplicateDecision
                              }))}
                              className="px-3 py-2 bg-white border border-gray-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-amber-500 cursor-pointer"
                            >
                              <option value="merge">دمج الملاحظات مع السجل الأصلي (مستحسن)</option>
                              <option value="replace">استبدال بيانات السجل الأصلي</option>
                              <option value="separate">حفظ كسجل منفصل رغم التطابق</option>
                              <option value="skip">تخطي وعدم استيراد هذا السجل</option>
                            </select>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Decision summary */}
                  <div className="p-3 bg-gray-100 rounded-xl text-xs font-medium text-gray-700 flex flex-wrap items-center gap-x-4 gap-y-1">
                    <span className="font-bold text-gray-900">ملخص الإجراءات:</span>
                    <span className="text-emerald-700">دمج: {decisionSummary.merge}</span>
                    <span className="text-amber-700">استبدال: {decisionSummary.replace}</span>
                    <span className="text-blue-700">سجل منفصل: {decisionSummary.separate}</span>
                    <span className="text-gray-500">تخطي: {decisionSummary.skip}</span>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-gray-500 font-medium flex items-center gap-1.5">
            <Info className="w-4 h-4 text-emerald-600" />
            <span>يتم فور الاستيراد فرز وترتيب السجلات أبجدياً وتحديث الفهارس تلقائياً</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => { handleResetModal(); onClose(); }}
              className="px-5 py-2.5 text-gray-600 hover:bg-gray-200/70 rounded-xl font-medium text-sm transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleConfirmImport}
              disabled={parsedRecords.length === 0}
              className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl font-bold text-sm shadow-md transition cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>
                تأكيد واستيراد {parsedRecords.length > 0 ? `${parsedRecords.length.toLocaleString('ar-EG')} شارع` : ''}
              </span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
