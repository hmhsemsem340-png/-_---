import React, { useState, useMemo } from 'react';
import { 
  MapPin, 
  Globe, 
  Download, 
  CheckCircle2, 
  Search, 
  ExternalLink, 
  Layers, 
  Sparkles, 
  CheckSquare, 
  Square, 
  X,
  Compass,
  Building2,
  Navigation
} from 'lucide-react';
import { RecordItem } from '../types';
import { DAMANHOUR_CENTER_COORDINATES, DAMANHOUR_MAPS_URBAN_STREETS } from '../data/damanhourUrbanStreets';

interface GoogleMapsImportModalProps {
  existingRecords: RecordItem[];
  isOpen: boolean;
  onClose: () => void;
  onImportAndUpdate: (importedStreets: RecordItem[]) => void;
}

export function GoogleMapsImportModal({
  existingRecords,
  isOpen,
  onClose,
  onImportAndUpdate
}: GoogleMapsImportModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [selectedIndices, setSelectedIndices] = useState<Set<number>>(() => {
    return new Set(DAMANHOUR_MAPS_URBAN_STREETS.map((_, i) => i));
  });
  const [showOnlyNew, setShowOnlyNew] = useState(false);

  // Normalize name for matching
  const existingNamesSet = useMemo(() => {
    const set = new Set<string>();
    existingRecords.forEach(r => {
      set.add(r.name.trim().toLowerCase());
    });
    return set;
  }, [existingRecords]);

  // Catalog with "isAlreadyInDb" status
  const catalogWithStatus = useMemo(() => {
    return DAMANHOUR_MAPS_URBAN_STREETS.map((street, idx) => {
      const isAlreadyInDb = existingNamesSet.has(street.name.trim().toLowerCase());
      return {
        ...street,
        index: idx,
        isAlreadyInDb
      };
    });
  }, [existingNamesSet]);

  // Unique districts in catalog
  const districts = useMemo(() => {
    const d = new Set<string>();
    DAMANHOUR_MAPS_URBAN_STREETS.forEach(s => {
      if (s.permission) d.add(s.permission);
    });
    return Array.from(d);
  }, []);

  // Filtered list
  const filteredList = useMemo(() => {
    return catalogWithStatus.filter(item => {
      if (selectedDistrict !== 'all' && item.permission !== selectedDistrict) return false;
      if (showOnlyNew && item.isAlreadyInDb) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = item.name.toLowerCase().includes(q);
        const matchMeta = item.metadata.toLowerCase().includes(q);
        const matchPerm = item.permission.toLowerCase().includes(q);
        if (!matchName && !matchMeta && !matchPerm) return false;
      }
      return true;
    });
  }, [catalogWithStatus, selectedDistrict, showOnlyNew, searchQuery]);

  const toggleSelectAll = () => {
    if (selectedIndices.size === filteredList.length) {
      setSelectedIndices(new Set());
    } else {
      setSelectedIndices(new Set(filteredList.map(item => item.index)));
    }
  };

  const toggleItem = (index: number) => {
    setSelectedIndices(prev => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  const handleExecuteImport = () => {
    const selectedItems = catalogWithStatus.filter(item => selectedIndices.has(item.index));
    if (selectedItems.length === 0) return;

    const newRecords: RecordItem[] = selectedItems.map((item, i) => ({
      id: `gmaps_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`,
      name: item.name,
      permission: item.permission,
      metadata: item.metadata,
      category: item.category
    }));

    onImportAndUpdate(newRecords);
    onClose();
  };

  if (!isOpen) return null;

  const googleMapsUrl = `https://www.google.com/maps?q=${DAMANHOUR_CENTER_COORDINATES.lat},${DAMANHOUR_CENTER_COORDINATES.lng}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto" dir="rtl">
      <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 w-full max-w-4xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-emerald-800 via-teal-800 to-cyan-900 text-white flex items-center justify-between shadow-md shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-white/10 rounded-2xl border border-white/20 shadow-inner">
              <Compass className="w-7 h-7 text-emerald-300 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">استيراد وتحديث شوارع خرائط جوجل (Google Maps)</h2>
                <span className="px-2.5 py-0.5 bg-emerald-400 text-emerald-950 font-black rounded-full text-xs shadow-xs">
                  دمنهور
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-100/90 mt-0.5">
                تحديث بيانات الشوارع والمأذونيات داخل الكتلة العمرانية للإحداثيات: <strong className="font-mono text-emerald-200">{DAMANHOUR_CENTER_COORDINATES.dms}</strong>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Coordinates Information Banner */}
        <div className="px-6 py-3.5 bg-emerald-50/80 border-b border-emerald-100 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-4 flex-wrap text-emerald-950">
            <span className="flex items-center gap-1.5 font-bold">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>الإحداثيات الجغرافية:</span>
              <strong className="font-mono bg-white px-2 py-0.5 rounded-lg border border-emerald-200 shadow-2xs">
                {DAMANHOUR_CENTER_COORDINATES.dms}
              </strong>
            </span>
            <span className="flex items-center gap-1 text-emerald-800">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <span>الكتلة الحضرية: <strong>{DAMANHOUR_CENTER_COORDINATES.city} - {DAMANHOUR_CENTER_COORDINATES.governorate}</strong></span>
            </span>
          </div>

          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold rounded-xl transition shadow-2xs"
          >
            <span>فتح الموقع في خرائط Google</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-4 sm:p-5 border-b border-gray-100 bg-gray-50/70 space-y-3 shrink-0">
          <div className="flex flex-wrap items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث في شوارع دمنهور المعرفة..."
                className="w-full pr-10 pl-4 py-2 bg-white border border-gray-200 rounded-xl text-xs sm:text-sm font-medium text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-2xs"
              />
            </div>

            {/* District Selector */}
            <div className="flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-gray-500" />
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs sm:text-sm font-semibold text-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-2xs cursor-pointer"
              >
                <option value="all">كل المأذونيات والقطاعات ({catalogWithStatus.length})</option>
                {districts.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            {/* Only New Toggle */}
            <label className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-700 cursor-pointer shadow-2xs select-none">
              <input
                type="checkbox"
                checked={showOnlyNew}
                onChange={(e) => setShowOnlyNew(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 cursor-pointer"
              />
              <span>إظهار غير المسجل فقط</span>
            </label>
          </div>

          {/* Quick Stats & Select All */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-3 text-xs text-gray-600">
              <button
                type="button"
                onClick={toggleSelectAll}
                className="inline-flex items-center gap-1.5 font-bold text-emerald-800 hover:text-emerald-950 transition cursor-pointer"
              >
                {selectedIndices.size === filteredList.length ? (
                  <CheckSquare className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Square className="w-4 h-4 text-gray-400" />
                )}
                <span>تحديد الكل ({filteredList.length})</span>
              </button>
              <span>|</span>
              <span>المحدد للاستيراد: <strong className="text-emerald-700">{selectedIndices.size}</strong> شارع</span>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-gray-500">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span>شوارع حديثة ومؤكدة بخرائط جوجل</span>
              </span>
            </div>
          </div>
        </div>

        {/* Streets Grid List */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-2.5 bg-gray-50/30">
          {filteredList.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <MapPin className="w-10 h-10 mx-auto text-gray-300 mb-2 opacity-50" />
              <p className="text-sm font-semibold">لا توجد شوارع مطابقة للبحث الحالي</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {filteredList.map((item) => {
                const isSelected = selectedIndices.has(item.index);
                return (
                  <div
                    key={item.index}
                    onClick={() => toggleItem(item.index)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-start gap-3 select-none ${
                      isSelected
                        ? 'bg-emerald-50/90 border-emerald-300 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-white border-gray-200 hover:border-gray-300 shadow-2xs'
                    }`}
                  >
                    <div className="pt-0.5 shrink-0">
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4 text-gray-300" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1.5 mb-1">
                        <h4 className="text-xs sm:text-sm font-black text-gray-900 truncate">
                          {item.name}
                        </h4>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200 shrink-0">
                          {item.permission}
                        </span>
                      </div>

                      <p className="text-[11px] text-gray-500 line-clamp-2 leading-relaxed">
                        {item.metadata || 'ضمن الكتلة العمرانية المعتمدة لمدينة دمنهور'}
                      </p>

                      <div className="mt-2 flex items-center justify-between text-[10px]">
                        <span className="text-gray-400 font-medium">النوع: {item.category}</span>
                        {item.isAlreadyInDb ? (
                          <span className="text-gray-400 flex items-center gap-1 font-bold">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                            مسجل مسبقاً (سيتم تحديثه)
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-bold flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-amber-500" />
                            شارع جديد للإضافة
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-white border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-gray-500">
            سيتم استيراد وتحديث <strong className="text-gray-900 font-black">{selectedIndices.size}</strong> شارع داخل قاعدة البيانات النشطة.
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="button"
              onClick={handleExecuteImport}
              disabled={selectedIndices.size === 0}
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs sm:text-sm font-black transition flex items-center gap-2 shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Download className="w-4 h-4" />
              <span>استيراد وتحديث قاعدة البيانات فوراً</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
