import React, { useState, useMemo } from 'react';
import { 
  ArrowRight, 
  Settings, 
  Type, 
  Palette, 
  Layout, 
  Sliders, 
  Download, 
  Upload, 
  ShieldCheck, 
  BarChart3, 
  Database, 
  RefreshCw, 
  FileSpreadsheet, 
  AlertTriangle, 
  Building, 
  CheckCircle2, 
  TrendingUp, 
  Grid3X3, 
  Sparkles, 
  Command, 
  Undo2, 
  Zap, 
  Eye, 
  EyeOff, 
  Columns, 
  SlidersHorizontal,
  Keyboard,
  Maximize2,
  Table,
  Check,
  BookOpen,
  MousePointerClick,
  Lock,
  Edit3,
  Trash2,
  FileCheck2,
  Hash,
  Clock,
  Tag,
  ArrowLeft,
  Plus,
  RotateCcw,
  Layers,
  FolderPlus,
  BookmarkCheck,
  ListPlus
} from 'lucide-react';
import { 
  ThemeType, 
  RecordItem, 
  AppSettings, 
  AccentColorType, 
  ColumnStyleConfig, 
  ViewModeType,
  DEFAULT_STREET_CATEGORIES,
  DEFAULT_UNOFFICIAL_SUBTYPES,
  OFFICIAL_SEVEN_NOTARIZATIONS
} from '../types';
import { OFFICIAL_DISTRICTS } from '../utils/districtColors';
import { ACCENT_PALETTES } from '../utils/themeConfig';

interface SettingsPageProps {
  onBack: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  records: RecordItem[];
  onExportJSON: () => void;
  onImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetData: () => void;
  onRepairMojibake?: () => void;
  onOpenImport?: () => void;
  onOpenAdvancedExport?: () => void;
  onOpenBackupRestore?: () => void;
  onOpenHelp?: () => void;
  onMarkAllUnderReview?: (preserveLocked?: boolean, customReason?: string) => void;
  initialTab?: 'workspace' | 'modes' | 'appearance' | 'columns' | 'stats' | 'productivity' | 'data' | 'audit';
}

export function SettingsPage({
  onBack,
  settings,
  onUpdateSettings,
  theme,
  setTheme,
  records,
  onExportJSON,
  onImportJSON,
  onResetData,
  onRepairMojibake,
  onOpenImport,
  onOpenAdvancedExport,
  onOpenBackupRestore,
  onOpenHelp,
  onMarkAllUnderReview,
  initialTab = 'workspace'
}: SettingsPageProps) {
  const [activeTab, setActiveTab] = useState<'workspace' | 'modes' | 'appearance' | 'columns' | 'stats' | 'productivity' | 'data' | 'audit'>(initialTab);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Custom Street Categories Management State
  const streetCategories = useMemo(() => {
    return (settings.customStreetCategories && settings.customStreetCategories.length > 0)
      ? settings.customStreetCategories
      : Array.from(DEFAULT_STREET_CATEGORIES);
  }, [settings.customStreetCategories]);

  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [editingCategoryIdx, setEditingCategoryIdx] = useState<number | null>(null);
  const [editingCategoryVal, setEditingCategoryVal] = useState('');
  const [categoryFeedback, setCategoryFeedback] = useState<string | null>(null);

  const handleAddCategory = () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    if (streetCategories.includes(trimmed)) {
      setCategoryFeedback(`التصنيف "${trimmed}" موجود بالفعل في القائمة.`);
      return;
    }
    const updated = [...streetCategories, trimmed];
    onUpdateSettings({
      ...settings,
      customStreetCategories: updated
    });
    setNewCategoryInput('');
    setCategoryFeedback(`✓ تمت إضافة تصنيف الشارع: "${trimmed}"`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  const handleSaveEditCategory = (index: number) => {
    const trimmed = editingCategoryVal.trim();
    if (!trimmed) return;
    const updated = [...streetCategories];
    updated[index] = trimmed;
    onUpdateSettings({
      ...settings,
      customStreetCategories: updated
    });
    setEditingCategoryIdx(null);
    setEditingCategoryVal('');
    setCategoryFeedback(`✓ تم تحديث التصنيف إلى: "${trimmed}"`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  const handleDeleteCategory = (index: number) => {
    const item = streetCategories[index];
    const updated = streetCategories.filter((_, i) => i !== index);
    onUpdateSettings({
      ...settings,
      customStreetCategories: updated.length > 0 ? updated : Array.from(DEFAULT_STREET_CATEGORIES)
    });
    setCategoryFeedback(`تم حذف التصنيف: "${item}"`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  const handleResetCategories = () => {
    onUpdateSettings({
      ...settings,
      customStreetCategories: Array.from(DEFAULT_STREET_CATEGORIES)
    });
    setCategoryFeedback('✓ تمت استعادة تصنيفات الشوارع الافتراضية بنجاح');
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  // Custom Unofficial SubTypes Management State
  const unofficialSubTypes = useMemo(() => {
    return (settings.customUnofficialSubTypes && settings.customUnofficialSubTypes.length > 0)
      ? settings.customUnofficialSubTypes
      : Array.from(DEFAULT_UNOFFICIAL_SUBTYPES);
  }, [settings.customUnofficialSubTypes]);

  const [newUnofficialInput, setNewUnofficialInput] = useState('');
  const [editingUnofficialIdx, setEditingUnofficialIdx] = useState<number | null>(null);
  const [editingUnofficialVal, setEditingUnofficialVal] = useState('');
  const [unofficialFeedback, setUnofficialFeedback] = useState<string | null>(null);

  const handleAddUnofficialSubType = () => {
    const trimmed = newUnofficialInput.trim();
    if (!trimmed) return;
    if (unofficialSubTypes.includes(trimmed)) {
      setUnofficialFeedback(`تصنيف البيانات غير الرسمية "${trimmed}" موجود بالفعل.`);
      return;
    }
    const updated = [...unofficialSubTypes, trimmed];
    onUpdateSettings({
      ...settings,
      customUnofficialSubTypes: updated
    });
    setNewUnofficialInput('');
    setUnofficialFeedback(`✓ تمت إضافة تصنيف البيانات غير الرسمية: "${trimmed}"`);
    setTimeout(() => setUnofficialFeedback(null), 3000);
  };

  const handleSaveEditUnofficialSubType = (index: number) => {
    const trimmed = editingUnofficialVal.trim();
    if (!trimmed) return;
    const updated = [...unofficialSubTypes];
    updated[index] = trimmed;
    onUpdateSettings({
      ...settings,
      customUnofficialSubTypes: updated
    });
    setEditingUnofficialIdx(null);
    setEditingUnofficialVal('');
    setUnofficialFeedback(`✓ تم تحديث تصنيف البيانات غير الرسمية إلى: "${trimmed}"`);
    setTimeout(() => setUnofficialFeedback(null), 3000);
  };

  const handleDeleteUnofficialSubType = (index: number) => {
    const item = unofficialSubTypes[index];
    const updated = unofficialSubTypes.filter((_, i) => i !== index);
    onUpdateSettings({
      ...settings,
      customUnofficialSubTypes: updated.length > 0 ? updated : Array.from(DEFAULT_UNOFFICIAL_SUBTYPES)
    });
    setUnofficialFeedback(`تم حذف تصنيف البيانات غير الرسمية: "${item}"`);
    setTimeout(() => setUnofficialFeedback(null), 3000);
  };

  const handleResetUnofficialSubTypes = () => {
    onUpdateSettings({
      ...settings,
      customUnofficialSubTypes: Array.from(DEFAULT_UNOFFICIAL_SUBTYPES)
    });
    setUnofficialFeedback('✓ تمت استعادة تصنيفات البيانات غير الرسمية الافتراضية بنجاح');
    setTimeout(() => setUnofficialFeedback(null), 3000);
  };

  // Suggested 7 Notarizations Management
  const suggestedNotarizations = useMemo(() => {
    return (settings.suggestedOfficialNotarizations && settings.suggestedOfficialNotarizations.length > 0)
      ? settings.suggestedOfficialNotarizations
      : Array.from(OFFICIAL_SEVEN_NOTARIZATIONS);
  }, [settings.suggestedOfficialNotarizations]);

  const stats = useMemo(() => {
    const total = records.length;
    if (total === 0) {
      return {
        total: 0,
        officialTotal: 0,
        unofficialTotal: 0,
        officialDistricts: [],
        categories: []
      };
    }

    const officialDistricts = OFFICIAL_DISTRICTS.map(dist => {
      const count = records.filter(r => `${r.permission || ''} ${r.metadata || ''} ${r.name || ''}`.includes(dist.key)).length;
      const percentage = total > 0 ? ((count / total) * 100).toFixed(1) : '0';
      return { ...dist, count, percentage };
    });

    const officialTotal = officialDistricts.reduce((acc, curr) => acc + curr.count, 0);
    const unofficialTotal = total - officialTotal;

    const categoryMap: Record<string, number> = {};
    records.forEach(r => {
      const cat = r.category || 'شارع';
      categoryMap[cat] = (categoryMap[cat] || 0) + 1;
    });

    const categories = Object.entries(categoryMap)
      .map(([name, count]) => ({
        name,
        count,
        percentage: ((count / total) * 100).toFixed(1)
      }))
      .sort((a, b) => b.count - a.count);

    return {
      total,
      officialTotal,
      unofficialTotal,
      officialDistricts,
      categories
    };
  }, [records]);

  const updateColumnConfig = (colKey: keyof AppSettings['dynamicTheme']['columns'], updates: Partial<ColumnStyleConfig>) => {
    onUpdateSettings({
      ...settings,
      dynamicTheme: {
        ...settings.dynamicTheme,
        columns: {
          ...settings.dynamicTheme.columns,
          [colKey]: {
            ...settings.dynamicTheme.columns[colKey],
            ...updates
          }
        }
      }
    });
  };

  const handleAccentChange = (accent: AccentColorType) => {
    onUpdateSettings({
      ...settings,
      dynamicTheme: {
        ...settings.dynamicTheme,
        accentColor: accent
      }
    });
    if (accent === 'emerald') setTheme('excel');
    else if (accent === 'cyan') setTheme('libreoffice');
    else if (accent === 'indigo') setTheme('modern');
    else setTheme('custom');
  };

  const fontOptions = [
    { label: 'الافتراضي (System Sans)', value: 'sans' },
    { label: 'خط تجوال (Tajawal)', value: 'tajawal' },
    { label: 'خط كايرو (Cairo)', value: 'cairo' },
    { label: 'خط المراعي (Almarai)', value: 'almarai' }
  ];

  return (
    <div className="w-full bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden flex flex-col min-h-[750px]" dir="rtl">
      
      {/* Header */}
      <div className="px-6 py-4 bg-gray-900 text-white flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/10 rounded-2xl">
            <Settings className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-lg font-black tracking-tight">صفحة الإعدادات والتحكم المركزية</h3>
            <p className="text-xs text-gray-300 font-medium">
              تخصيص مساحة العمل الصافية • الثيم الديناميكي الموحد • التحكم في الأعمدة والصفوف • إدارة البيانات
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onOpenHelp && (
            <button
              type="button"
              onClick={onOpenHelp}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
              title="لوحة التعليمات واختصارات لوحة المفاتيح (F1)"
            >
              <Keyboard className="w-4 h-4" />
              <span>تعليمات F1</span>
            </button>
          )}
          <button 
            type="button"
            onClick={onBack} 
            className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-bold transition text-white cursor-pointer"
            title="العودة إلى مساحة العمل"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة لمساحة العمل</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 pt-3 flex flex-wrap gap-2 shrink-0">
        
        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <FileCheck2 className="w-4 h-4 text-emerald-600" />
          <span>ورقة التدقيق والترقيم المتسلسل (Audit & Serial)</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900">
            جديد
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('modes')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'modes'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <BookOpen className="w-4 h-4 text-emerald-600" />
          <span>أوضاع العمل (القراءة / التعديل بالماوس)</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
            settings.viewMode === 'reading' 
              ? 'bg-blue-100 text-blue-800' 
              : settings.viewMode === 'mouse_edit' 
                ? 'bg-amber-100 text-amber-800' 
                : 'bg-gray-200 text-gray-700'
          }`}>
            {settings.viewMode === 'reading' ? 'وضع القراءة نشط' : settings.viewMode === 'mouse_edit' ? 'وضع الماوس نشط' : 'الوضع العادي'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('workspace')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'workspace'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <Maximize2 className="w-4 h-4 text-emerald-600" />
          <span>مساحة العمل الصافية (Distraction-Free)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('appearance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'appearance'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <Palette className="w-4 h-4 text-purple-600" />
          <span>الثيم الديناميكي الموحد والمقاسات</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('columns')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'columns'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <Columns className="w-4 h-4 text-blue-600" />
          <span>تخصيص أعمدة وصفوف الجدول</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('productivity')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'productivity'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-600" />
          <span>الإنتاجية والاختصارات وخطة الأمان</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('stats')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'stats'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-teal-600" />
          <span>الإحصائيات والتحليلات الرقمية</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('data')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
            activeTab === 'data'
              ? 'bg-white text-emerald-800 border-emerald-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
          }`}
        >
          <Database className="w-4 h-4 text-indigo-600" />
          <span>إدارة البيانات والنسخ الاحتياطي</span>
        </button>

      </div>

      {/* Tab Body */}
      <div className="p-6 overflow-y-auto flex-1 text-right">
        
        {/* ===================== TAB: AUDIT & SERIAL NUMBERING SYSTEM ===================== */}
        {activeTab === 'audit' && (
          <div className="space-y-6 max-w-4xl">
            
            {/* Header Banner */}
            <div className="p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-amber-50 rounded-3xl border border-emerald-200 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 font-black text-gray-950 text-base">
                <FileCheck2 className="w-5 h-5 text-emerald-700" />
                <span>التحكم في ورقة التدقيق والمراجعة المتتالية والترقيم التسلسلي</span>
              </div>
              <p className="text-xs text-gray-700 leading-relaxed">
                لوحة التحكم المركزية لضبط سلوك ورقة التدقيق والمراجعة: تفعيل الحفظ الفوري التلقائي (Auto-Save)، إظهار عمود الترقيم التسلسلي في الجدول، التنقل بالأسهم ولوحة المفاتيح دون لمس الماوس، وإخفاء تعقيد البادئات في قائمة جانبية لتقليل التشتت البصري.
              </p>
            </div>

            {/* SECTION 1: الترقيم التسلسلي للسجلات (Serial Numbering) */}
            <div className="p-5 bg-white rounded-3xl border border-gray-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-amber-100 text-amber-900 rounded-xl">
                    <Hash className="w-5 h-5 text-amber-700" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">الترقيم التسلسلي للسجلات (Serial Numbering)</h4>
                    <p className="text-xs text-gray-500">عرض رقم التسلسل الثابت لكل سجل بالجدول وورقة التدقيق</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Toggle Show Serial in Table */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900 block">إظهار رقم التسلسل (#) في الجدول</span>
                    <span className="text-[11px] text-gray-500">عرض شارة رقم التسلسل المميزة (#1, #2...) في عمود مستقل</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({
                      ...settings,
                      auditShowSerialInTable: settings.auditShowSerialInTable === false ? true : false
                    })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      settings.auditShowSerialInTable !== false ? 'bg-emerald-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        settings.auditShowSerialInTable !== false ? 'translate-x-0' : '-translate-x-5'
                      }`}
                    />
                  </button>
                </div>

                {/* Serial Column Custom Label */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 space-y-2">
                  <span className="text-xs font-bold text-gray-900 block">تسمية عنوان عمود التسلسل</span>
                  <input
                    type="text"
                    value={settings.dynamicTheme.columns.index.label || 'التسلسل #'}
                    onChange={(e) => updateColumnConfig('index', { label: e.target.value })}
                    placeholder="التسلسل # أو م"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none font-bold"
                  />
                  <span className="text-[10px] text-gray-400 block">النص الظاهر في رأس عمود الترقيم بجدول البيانات</span>
                </div>
              </div>
            </div>

            {/* SECTION 2: خاصية الحفظ الفوري التلقائي (Auto-Save System) */}
            <div className="p-5 bg-white rounded-3xl border border-gray-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-emerald-100 text-emerald-900 rounded-xl">
                    <Zap className="w-5 h-5 text-emerald-700" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">خاصية الحفظ الفوري التلقائي (Auto-Save)</h4>
                    <p className="text-xs text-gray-500">حفظ كل حرف أو بيان يتم إدخاله تلقائياً فوراً دون الحاجة للنقر على زر الحفظ</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Auto-Save Toggle */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900 block">تفعيل الحفظ الفوري افتراضياً</span>
                    <span className="text-[11px] text-gray-500">تطبيق الحفظ الفوري تلقائياً بمجرد فتح ورقة التدقيق</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({
                      ...settings,
                      auditAutoSave: settings.auditAutoSave === false ? true : false
                    })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      settings.auditAutoSave !== false ? 'bg-emerald-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        settings.auditAutoSave !== false ? 'translate-x-0' : '-translate-x-5'
                      }`}
                    />
                  </button>
                </div>

                {/* Auto-Save Debounce Delay */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 space-y-2">
                  <span className="text-xs font-bold text-gray-900 block">مهلة وسرعة الحفظ التلقائي</span>
                  <div className="flex gap-2">
                    {[
                      { label: 'سريع (400ms)', value: 400 },
                      { label: 'متزن قياسي (600ms)', value: 600 },
                      { label: 'هادئ (1000ms)', value: 1000 }
                    ].map((d) => (
                      <button
                        key={d.value}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, auditAutoSaveDelay: d.value })}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer flex-1 ${
                          (settings.auditAutoSaveDelay || 600) === d.value
                            ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                  <span className="text-[10px] text-gray-400 block">الفاصل الزمني بالمللي ثانية بعد توقف الكتابة لإتمام الحفظ</span>
                </div>
              </div>
            </div>

            {/* SECTION 3: التنقل السريع بالأسهم ولوحة المفاتيح والماوس (Keyboard & Mouse Navigation) */}
            <div className="p-5 bg-white rounded-3xl border border-gray-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-indigo-100 text-indigo-900 rounded-xl">
                    <Keyboard className="w-5 h-5 text-indigo-700" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">التنقل السريع بالماوس ولوحة المفاتيح</h4>
                    <p className="text-xs text-gray-500">تنظيم التنقل بمفاتيح الأسهم، القفز بالأبجدية، وحماية الماوس من النقرات الخاطئة</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Arrow Keys Navigation Toggle */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900 block">التنقل السريع بمفاتيح الأسهم (Arrow Keys)</span>
                    <span className="text-[11px] text-gray-500">الانتقال الفوري للسجل التالي/السابق بالأسهم (↑ ↓) أو (PageUp/Down) دون لمس الماوس</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({
                      ...settings,
                      auditArrowKeyNavigation: settings.auditArrowKeyNavigation === false ? true : false
                    })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      settings.auditArrowKeyNavigation !== false ? 'bg-indigo-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        settings.auditArrowKeyNavigation !== false ? 'translate-x-0' : '-translate-x-5'
                      }`}
                    />
                  </button>
                </div>

                {/* Show Alphabet Jump Ribbon Toggle */}
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900 block">إظهار شريط القفز بالأبجدية (أ-ي)</span>
                    <span className="text-[11px] text-gray-500">شريط الحروف الأبجدية في أعلى ورقة التدقيق للقفز السريع لأي حرف بنقرة واحدة</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({
                      ...settings,
                      auditShowAlphabetRibbon: settings.auditShowAlphabetRibbon === false ? true : false
                    })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      settings.auditShowAlphabetRibbon !== false ? 'bg-indigo-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        settings.auditShowAlphabetRibbon !== false ? 'translate-x-0' : '-translate-x-5'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Keyboard Shortcuts Summary Box */}
              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-2">
                <span className="text-xs font-bold text-amber-400 block">اختصارات لوحة المفاتيح النشطة في ورقة التدقيق والمراجعة:</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="text-gray-300 block">العودة للجدول:</span>
                    <strong className="text-white font-mono">Esc / Alt + X</strong>
                  </div>
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="text-gray-300 block">السجل التالي:</span>
                    <strong className="text-white font-mono">↓ / PageDown / Alt+N</strong>
                  </div>
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="text-gray-300 block">السجل السابق:</span>
                    <strong className="text-white font-mono">↑ / PageUp / Alt+P</strong>
                  </div>
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="text-gray-300 block">مربع الانتقال السريع:</span>
                    <strong className="text-white font-mono">Ctrl + G / Alt + J</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION 4: تقليل التشتت البصري وتنظيم قائمة البادئات الجانبية */}
            <div className="p-5 bg-white rounded-3xl border border-gray-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-purple-100 text-purple-900 rounded-xl">
                    <Tag className="w-5 h-5 text-purple-700" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">تقليل التشتت البصري وقائمة البادئات الجانبية</h4>
                    <p className="text-xs text-gray-500">إبقاء واجهة التدقيق صافية ومريحة للعين، مع قائمة جانبية للبادئات المتقدمة</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900 block">تفعيل القائمة الجانبية للبادئات (Prefix Drawer)</span>
                    <span className="text-[11px] text-gray-500">إخفاء خيارات إضافة وحذف البادئات في قائمة جانبية تفتح عند الحاجة فقط</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({
                      ...settings,
                      auditPrefixDrawerMode: settings.auditPrefixDrawerMode === false ? true : false
                    })}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      settings.auditPrefixDrawerMode !== false ? 'bg-purple-600' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        settings.auditPrefixDrawerMode !== false ? 'translate-x-0' : '-translate-x-5'
                      }`}
                    />
                  </button>
                </div>

                <div className="p-4 rounded-2xl border border-gray-200 bg-gray-50/70 space-y-2">
                  <span className="text-xs font-bold text-gray-900 block">مسؤول التوثيق والمراجعة المعتمد</span>
                  <input
                    type="text"
                    value={settings.reviewerName || 'الأستاذ/ حسام الدين الخولي'}
                    onChange={(e) => onUpdateSettings({ ...settings, reviewerName: e.target.value })}
                    placeholder="اسم المراجع / الموثق..."
                    className="w-full px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-lg focus:ring-1 focus:ring-purple-500 focus:outline-none font-bold"
                  />
                  <span className="text-[10px] text-gray-400 block">يظهر هذا الاسم في سجلات التدقيق والتصدير المعتمدة</span>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ===================== TAB: WORK & INTERACTION MODES ===================== */}
        {activeTab === 'modes' && (
          <div className="space-y-6 max-w-4xl">
            
            <div className="p-5 bg-gradient-to-r from-blue-50 via-indigo-50 to-emerald-50 rounded-3xl border border-blue-200 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 font-black text-gray-950 text-base">
                <Sliders className="w-5 h-5 text-emerald-700" />
                <span>أنماط العمل: «وضع القراءة الآمن» و «وضع التعديل المريح بالماوس»</span>
              </div>
              <p className="text-xs text-gray-700 leading-relaxed">
                خصص تجربة الاستخدام وفقاً لنوعية مهمتك: تصفح وتدقيق البيانات بأمان تام دون خوف من الحذف أو التعديل بالخطأ، أو تعديل سريع بالماوس بأزرار واضحة وسهلة النقر.
              </p>
            </div>

            {/* Mode Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* 1. Reading Mode Card */}
              <div 
                onClick={() => onUpdateSettings({ ...settings, viewMode: 'reading' })}
                className={`rounded-3xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                  settings.viewMode === 'reading'
                    ? 'border-blue-600 bg-blue-50/80 shadow-md ring-2 ring-blue-500/20'
                    : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50/30'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 bg-blue-100 text-blue-800 rounded-2xl">
                      <Eye className="w-6 h-6 text-blue-700" />
                    </div>
                    {settings.viewMode === 'reading' ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 bg-blue-600 text-white rounded-full text-xs font-black shadow-xs">
                        <Check className="w-3.5 h-3.5" />
                        <span>نشط حالياً</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                        انقر للتفعيل
                      </span>
                    )}
                  </div>

                  <div>
                    <h4 className="text-base font-black text-blue-950 flex items-center gap-1.5">
                      <span>1- وضع القراءة الآمن</span>
                      <Lock className="w-4 h-4 text-blue-600" />
                    </h4>
                    <p className="text-xs text-blue-800 font-bold mt-0.5">
                      (إخفاء أزرار التعديل والحذف + خط كبير + تباين عالي)
                    </p>
                  </div>

                  <div className="space-y-2 text-xs text-gray-700 border-t border-blue-200/60 pt-3">
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span><strong>إخفاء أزرار التعديل والحذف</strong> لحماية البيانات من التعديلات أو الحذف العرضي بالخطأ.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span><strong>تكبير حجم الخط تلقائياً</strong> لأسماء الشوارع والتصنيفات لراحة العين.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span><strong>تباين ألوان عالي وواضح</strong> مع حدود واضحة بين الخلايا والصفوف.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span><strong>تعطيل النقر المزدوج للتعديل</strong> لضمان حماية السجلات بنسبة 100%.</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUpdateSettings({ ...settings, viewMode: 'reading' });
                  }}
                  className={`mt-5 w-full py-2.5 rounded-2xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                    settings.viewMode === 'reading'
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'bg-white hover:bg-blue-100 text-blue-900 border border-blue-300'
                  }`}
                >
                  <Eye className="w-4 h-4" />
                  <span>{settings.viewMode === 'reading' ? 'مفعل الآن' : 'تفعيل وضع القراءة'}</span>
                </button>
              </div>

              {/* 2. Mouse Edit Mode Card */}
              <div 
                onClick={() => onUpdateSettings({ ...settings, viewMode: 'mouse_edit' })}
                className={`rounded-3xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                  settings.viewMode === 'mouse_edit'
                    ? 'border-amber-600 bg-amber-50/80 shadow-md ring-2 ring-amber-500/20'
                    : 'border-gray-200 bg-white hover:border-amber-300 hover:bg-amber-50/30'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 bg-amber-100 text-amber-900 rounded-2xl">
                      <MousePointerClick className="w-6 h-6 text-amber-700" />
                    </div>
                    {settings.viewMode === 'mouse_edit' ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-600 text-white rounded-full text-xs font-black shadow-xs">
                        <Check className="w-3.5 h-3.5" />
                        <span>نشط حالياً</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                        انقر للتفعيل
                      </span>
                    )}
                  </div>

                  <div>
                    <h4 className="text-base font-black text-amber-950 flex items-center gap-1.5">
                      <span>2- وضع التعديل المريح بالماوس</span>
                      <Sparkles className="w-4 h-4 text-amber-600" />
                    </h4>
                    <p className="text-xs text-amber-800 font-bold mt-0.5">
                      (أزرار كبيرة + نقرة واحدة للمأذونية والملاحظات)
                    </p>
                  </div>

                  <div className="space-y-2 text-xs text-gray-700 border-t border-amber-200/60 pt-3">
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span><strong>أزرار تعديل وحذف وملاحظات كبيرة</strong> واضحة في كل صف لسهولة الاستهداف بالفأرة.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span><strong>تغيير المأذونية بنقرة واحدة سريعة</strong> مباشرة على الشارة دون فتح نوافذ ثقيلة.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span><strong>شريط إجراءات عائم عند تمرير الماوس</strong> (Hover Bar) لسرعة اتخاذ القرار.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span><strong>مساحات نقر رحبة (40px+)</strong> تمنع إجهاد اليد ودقة التصويب أثناء العمل الطويل.</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUpdateSettings({ ...settings, viewMode: 'mouse_edit' });
                  }}
                  className={`mt-5 w-full py-2.5 rounded-2xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                    settings.viewMode === 'mouse_edit'
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-white hover:bg-amber-100 text-amber-900 border border-amber-300'
                  }`}
                >
                  <MousePointerClick className="w-4 h-4" />
                  <span>{settings.viewMode === 'mouse_edit' ? 'مفعل الآن' : 'تفعيل وضع التعديل بالماوس'}</span>
                </button>
              </div>

              {/* 3. Standard Mode Card */}
              <div 
                onClick={() => onUpdateSettings({ ...settings, viewMode: 'normal' })}
                className={`rounded-3xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                  settings.viewMode === 'normal' || !settings.viewMode
                    ? 'border-emerald-600 bg-emerald-50/80 shadow-md ring-2 ring-emerald-500/20'
                    : 'border-gray-200 bg-white hover:border-emerald-300 hover:bg-emerald-50/30'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 bg-emerald-100 text-emerald-900 rounded-2xl">
                      <Sliders className="w-6 h-6 text-emerald-700" />
                    </div>
                    {settings.viewMode === 'normal' || !settings.viewMode ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 text-white rounded-full text-xs font-black shadow-xs">
                        <Check className="w-3.5 h-3.5" />
                        <span>نشط حالياً</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                        انقر للتفعيل
                      </span>
                    )}
                  </div>

                  <div>
                    <h4 className="text-base font-black text-emerald-950">3- الوضع القياسي المعتاد</h4>
                    <p className="text-xs text-emerald-800 font-bold mt-0.5">
                      (التخطيط المكتبي المتوازن الافتراضي)
                    </p>
                  </div>

                  <div className="space-y-2 text-xs text-gray-700 border-t border-emerald-200/60 pt-3">
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>التنسيق المكتبي المتوازن مع كافة أزرار التعديل والحذف القياسية.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>يدعم النقر المزدوج للتعديل السريع وقوائم النقر الأيمن.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>مناسب للشاشات والأجهزة المكتبية ذات الكثافة المعتادة.</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUpdateSettings({ ...settings, viewMode: 'normal' });
                  }}
                  className={`mt-5 w-full py-2.5 rounded-2xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                    settings.viewMode === 'normal' || !settings.viewMode
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                  }`}
                >
                  <Sliders className="w-4 h-4" />
                  <span>{settings.viewMode === 'normal' || !settings.viewMode ? 'مفعل الآن' : 'تفعيل الوضع القياسي'}</span>
                </button>
              </div>

            </div>

            {/* Reading Mode Detailed Customization */}
            <div className="bg-white border border-gray-200 rounded-3xl p-5 space-y-4 shadow-xs">
              <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <Eye className="w-4 h-4 text-blue-600" />
                <span>تخصيص تفاصيل «1- وضع القراءة الآمن»</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Reading Mode Font Size */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-gray-700">حجم خط أسماء الشوارع في وضع القراءة:</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: 'كبير (LG)', value: 'lg' },
                      { label: 'كبير جداً (XL)', value: 'xl' },
                      { label: 'ضخم مريح (2XL)', value: '2xl' }
                    ].map(item => (
                      <button
                        key={item.value}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, readingModeFontSize: item.value as any })}
                        className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                          (settings.readingModeFontSize || 'xl') === item.value
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reading Mode Contrast Option */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-gray-700">مستوى تباين الألوان في وضع القراءة:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, readingModeHighContrast: true })}
                      className={`py-2 px-2 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                        settings.readingModeHighContrast !== false
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      تباين عالي فائق الوضوح
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, readingModeHighContrast: false })}
                      className={`py-2 px-2 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                        settings.readingModeHighContrast === false
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      تباين مكتبي ناعم
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Mouse Edit Mode Detailed Customization */}
            <div className="bg-white border border-gray-200 rounded-3xl p-5 space-y-4 shadow-xs">
              <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <MousePointerClick className="w-4 h-4 text-amber-600" />
                <span>تخصيص تفاصيل «2- وضع التعديل المريح بالماوس»</span>
              </h4>

              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-amber-50/50 rounded-2xl border border-amber-200 cursor-pointer">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-amber-950">تفعيل أزرار التعديل والحذف الواسعة (Touch/Click Expanded Targets)</span>
                    <p className="text-[11px] text-amber-800">يمنح الأزرار مساحات نقر كبيرة 40px+ لسرعة وسهولة الضغط بالماوس.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.mouseEditQuickTouch !== false}
                    onChange={(e) => onUpdateSettings({ ...settings, mouseEditQuickTouch: e.target.checked })}
                    className="w-4 h-4 text-amber-600 rounded border-gray-300 focus:ring-amber-500 cursor-pointer"
                  />
                </label>
              </div>
            </div>

          </div>
        )}
        
        {/* ===================== TAB 1: WORKSPACE CLEANLINESS ===================== */}
        {activeTab === 'workspace' && (
          <div className="space-y-6 max-w-3xl">
            
            <div className="p-5 bg-gradient-to-l from-emerald-50 via-teal-50 to-white rounded-3xl border border-emerald-200 space-y-2">
              <div className="flex items-center gap-2.5 font-black text-emerald-950 text-sm">
                <Maximize2 className="w-5 h-5 text-emerald-700" />
                <span>مفهوم مساحة العمل الصافية والتركيز المهني</span>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed font-medium">
                تتيح لك هذه الخيارات التحكم الكامل في ما يظهر وما يختفي من مساحة العمل الرئيسية. أي أداة تقوم بتعطيلها هنا ستختفي فوراً من شاشة العمل لتوفير مساحة رؤية واسعة وتركيز خالص على مراجعة وإدخال الشوارع.
              </p>
            </div>

            {/* Workspace Clean Mode Master Preset */}
            <div className="p-4 bg-white rounded-2xl border-2 border-emerald-500 shadow-xs flex items-center justify-between gap-4">
              <div>
                <span className="text-sm font-black text-gray-900 block">
                  ✨ وضع مساحة العمل الصافية الفائقة (Ultra-Clean Focus Mode)
                </span>
                <span className="text-xs text-gray-600">
                  إخفاء كافة الأشرطة والبطاقات الإضافية، والتركيز على شريط البحث والجدول فقط
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={settings.cleanWorkspaceMode || false}
                  onChange={(e) => {
                    const clean = e.target.checked;
                    onUpdateSettings({
                      ...settings,
                      cleanWorkspaceMode: clean,
                      showDataHealthBar: !clean,
                      showSmartShortcutsBar: !clean,
                      showQuickDistrictTags: !clean,
                      showExportImportInHeader: !clean
                    });
                  }}
                  className="sr-only peer"
                />
                <div className="w-12 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {/* Individual Workspace Widget Toggles */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-gray-500 uppercase tracking-wider">
                التحكم التفصيلي في عناصر مساحة العمل
              </h4>

              {/* 1. Data Health Bar */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-white rounded-2xl border border-gray-200 transition">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">
                    شريط صحة واكتمال البيانات (Data Health Bar)
                  </span>
                  <span className="text-[11px] text-gray-500">
                    شريط المؤشر والنسب المئوية للشوارع الناقصة والمكتملة أعلى الجدول
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showDataHealthBar ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, showDataHealthBar: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              {/* 2. Quick District Tags */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-white rounded-2xl border border-gray-200 transition">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">
                    شريط وسوم المأذونيات السريعة أسفل البحث
                  </span>
                  <span className="text-[11px] text-gray-500">
                    أزرار التصفية السريعة بالدوائر اللونية للمأذونيات السبع (تتوفر دائماً أيضاً في القائمة الجانبية Alt+S)
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showQuickDistrictTags ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, showQuickDistrictTags: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              {/* 3. Floating Shortcuts Bar */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-white rounded-2xl border border-gray-200 transition">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">
                    الشريط العائم للاختصارات السريعة والتراجع أسفل الشاشة
                  </span>
                  <span className="text-[11px] text-gray-500">
                    شريط الأدوات السريعة العائم أسفل الشاشة
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showSmartShortcutsBar ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, showSmartShortcutsBar: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              {/* 4. Sequential Audit Mode Button */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-white rounded-2xl border border-gray-200 transition">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">
                    زر التدقيق المتتالي (Sequential Audit) في الشريط العلوي
                  </span>
                  <span className="text-[11px] text-gray-500">
                    زر التدقيق والمراجعة السريعة للسجلات
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showAuditButton ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, showAuditButton: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              {/* 5. Header Import/Export Menus */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-white rounded-2xl border border-gray-200 transition">
                <div>
                  <span className="text-xs font-bold text-gray-900 block">
                    قوائم الاستيراد والتصدير في الشريط العلوي
                  </span>
                  <span className="text-[11px] text-gray-500">
                    عند إخفائها، تبقى متاحة بشكل كامل في القائمة الجانبية (Alt+S) وصفحة الإعدادات
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showExportImportInHeader ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, showExportImportInHeader: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

            </div>

          </div>
        )}

        {/* ===================== TAB 2: UNIFIED DYNAMIC THEME & VISUAL ERGONOMICS ===================== */}
        {activeTab === 'appearance' && (
          <div className="space-y-6 max-w-3xl">
            
            {/* 1. Dynamic Accent Color Palette */}
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm font-black text-gray-900">
                <Palette className="w-4 h-4 text-emerald-600" />
                <span>لون التمييز الأساسي للثيم الديناميكي (Dynamic Palette)</span>
              </label>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {(Object.keys(ACCENT_PALETTES) as AccentColorType[]).map(accentKey => {
                  const pal = ACCENT_PALETTES[accentKey];
                  const isSelected = settings.dynamicTheme.accentColor === accentKey;

                  return (
                    <button
                      key={accentKey}
                      type="button"
                      onClick={() => handleAccentChange(accentKey)}
                      className={`p-3.5 rounded-2xl border text-right transition cursor-pointer relative ${
                        isSelected 
                          ? 'bg-white ring-2 ring-emerald-600 border-emerald-600 shadow-md' 
                          : 'bg-gray-50/70 border-gray-200 hover:bg-gray-100/80'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span 
                            className="w-4 h-4 rounded-full border border-black/10 shadow-2xs" 
                            style={{ backgroundColor: pal.hexAccent }} 
                          />
                          <span className="text-xs font-black text-gray-900">{pal.name}</span>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-emerald-600" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <hr className="border-gray-200" />

            {/* 2. Visual Ergonomics: Typography & Font Sizing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-gray-800">
                  <Type className="w-4 h-4 text-emerald-600" />
                  <span>خط الواجهة والعرض</span>
                </label>
                <select
                  value={settings.fontFamily}
                  onChange={(e) => onUpdateSettings({ ...settings, fontFamily: e.target.value })}
                  className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl bg-white text-gray-900 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  {fontOptions.map(font => (
                    <option key={font.value} value={font.value}>{font.label}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-gray-800">
                  <Sliders className="w-4 h-4 text-emerald-600" />
                  <span>حجم خط الواجهة والجداول (المقاسات المريحة)</span>
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { label: 'صغير (13px)', value: 'sm' },
                    { label: 'عادي (14px)', value: 'base' },
                    { label: 'مريح (16px)', value: 'lg' },
                    { label: 'كبير (18px)', value: 'xl' }
                  ].map(item => (
                    <button
                      key={item.value}
                      type="button"
                      onClick={() => onUpdateSettings({ ...settings, fontSize: item.value as any })}
                      className={`py-2 rounded-xl border text-[11px] font-bold transition cursor-pointer ${
                        settings.fontSize === item.value 
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs' 
                          : 'border-gray-200 text-gray-700 bg-white hover:bg-gray-50'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            <hr className="border-gray-200" />

            {/* 3. Table Density & Row Comfort */}
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-xs font-bold text-gray-800">
                <Layout className="w-4 h-4 text-blue-600" />
                <span>كثافة سطور الجدول والمسافات الرأسية (Table Density)</span>
              </label>
              
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'compact', label: 'مكثف (Dense)', desc: 'عرض عدد أكبر من الصفوف في الشاشة' },
                  { id: 'normal', label: 'متوازن (Standard)', desc: 'المقاس الموصى به للعمل اليومي' },
                  { id: 'relaxed', label: 'مريح واسع (Relaxed)', desc: 'مسافات واسعة تمنع إجهاد العين' }
                ].map(den => (
                  <button
                    key={den.id}
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, tableDensity: den.id as any })}
                    className={`p-3 rounded-2xl border text-right transition cursor-pointer ${
                      settings.tableDensity === den.id
                        ? 'bg-blue-50 border-blue-600 ring-2 ring-blue-500 shadow-xs'
                        : 'bg-white border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <span className="text-xs font-bold text-gray-900 block">{den.label}</span>
                    <span className="text-[10px] text-gray-500 mt-0.5 block">{den.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <hr className="border-gray-200" />

            {/* 4. Striping & Borders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              <div className="flex items-center justify-between p-3.5 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex items-center gap-2">
                  <Layout className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-gray-800">تلوين السطور بالتبادل (Zebra Striping)</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.enableZebra}
                  onChange={(e) => onUpdateSettings({ ...settings, enableZebra: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex items-center gap-2">
                  <Grid3X3 className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-gray-800">إظهار شبكة وحدود الخلايا</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.cellBorders}
                  onChange={(e) => onUpdateSettings({ ...settings, cellBorders: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer"
                />
              </div>

            </div>

          </div>
        )}

        {/* ===================== TAB 3: COLUMN & ROW CUSTOMIZATION ===================== */}
        {activeTab === 'columns' && (
          <div className="space-y-6 max-w-3xl">
            
            <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl space-y-1">
              <h4 className="text-xs font-black text-blue-950 flex items-center gap-2">
                <Columns className="w-4 h-4 text-blue-700" />
                <span>التحكم في أي عمود أو صف في الجدول وتصديره</span>
              </h4>
              <p className="text-[11px] text-blue-900 font-medium">
                يمكنك إخفاء أو إظهار أي عمود في الجدول، وتغيير محاذاته وسمك خطه. تنعكس هذه الإعدادات مباشرة في مساحة العمل وتصدير Excel/PDF.
              </p>
            </div>

            {/* Column Configuration Cards */}
            <div className="space-y-3">
              
              {/* Column 1: Index (م) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-gray-100 text-gray-700 font-black text-xs flex items-center justify-center font-mono">
                      1
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود الرقم المتسلسل (م)</span>
                      <span className="text-[11px] text-gray-500 block">ترقيم السطور 1، 2، 3...</span>
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700">
                    <span>{settings.dynamicTheme.columns.index.visible ? 'ظاهر' : 'مخفي'}</span>
                    <input
                      type="checkbox"
                      checked={settings.dynamicTheme.columns.index.visible}
                      onChange={(e) => updateColumnConfig('index', { visible: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Column 2: Street Name (اسم الشارع) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center">
                      اسم
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود اسم الشارع / الحارة</span>
                      <span className="text-[11px] text-gray-500 block">العمود الأساسي للبيانات</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <select
                      value={settings.dynamicTheme.columns.name.fontWeight || 'bold'}
                      onChange={(e) => updateColumnConfig('name', { fontWeight: e.target.value as any })}
                      className="text-xs font-bold border border-gray-300 rounded-lg px-2 py-1 bg-white"
                    >
                      <option value="normal">خط عادي</option>
                      <option value="semibold">خط متوسط</option>
                      <option value="bold">خط عريض (Bold)</option>
                      <option value="black">خط أسود غامق (Black)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Column 3: Permission (المأذونية) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-purple-100 text-purple-800 font-black text-xs flex items-center justify-center">
                      مأذون
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود المأذونية / جهة الاختصاص</span>
                      <span className="text-[11px] text-gray-500 block">عرض شارة المأذونية الرسمية</span>
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700">
                    <span>{settings.dynamicTheme.columns.permission.visible ? 'ظاهر' : 'مخفي'}</span>
                    <input
                      type="checkbox"
                      checked={settings.dynamicTheme.columns.permission.visible}
                      onChange={(e) => updateColumnConfig('permission', { visible: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Column 4: Category (نوع السجل) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-amber-100 text-amber-800 font-black text-xs flex items-center justify-center">
                      نوع
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود نوع السجل (شارع / حارة / زقاق)</span>
                      <span className="text-[11px] text-gray-500 block">تصنيف الشارع</span>
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700">
                    <span>{settings.dynamicTheme.columns.category.visible ? 'ظاهر' : 'مخفي'}</span>
                    <input
                      type="checkbox"
                      checked={settings.dynamicTheme.columns.category.visible}
                      onChange={(e) => updateColumnConfig('category', { visible: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Column 5: Metadata (البيان الوصفي والملاحظات) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-teal-100 text-teal-800 font-black text-xs flex items-center justify-center">
                      وصف
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود البيان الوصفي والملاحظات</span>
                      <span className="text-[11px] text-gray-500 block">المعالم، حدود الشارع وملاحظات الاشتراك</span>
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700">
                    <span>{settings.dynamicTheme.columns.metadata.visible ? 'ظاهر' : 'مخفي'}</span>
                    <input
                      type="checkbox"
                      checked={settings.dynamicTheme.columns.metadata.visible}
                      onChange={(e) => updateColumnConfig('metadata', { visible: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Column 6: Actions (الإجراءات) */}
              <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-gray-100 text-gray-700 font-black text-xs flex items-center justify-center">
                      تحكم
                    </span>
                    <div>
                      <span className="text-xs font-black text-gray-900">عمود أزرار الإجراءات السريعة (تعديل / حذف)</span>
                      <span className="text-[11px] text-gray-500 block">أزرار التعديل والحذف المباشر في كل صف</span>
                    </div>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700">
                    <span>{settings.dynamicTheme.columns.actions.visible ? 'ظاهر' : 'مخفي'}</span>
                    <input
                      type="checkbox"
                      checked={settings.dynamicTheme.columns.actions.visible}
                      onChange={(e) => updateColumnConfig('actions', { visible: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* ===================== TAB 4: PRODUCTIVITY & ROLLBACK ===================== */}
        {activeTab === 'productivity' && (
          <div className="space-y-6 max-w-3xl">
            
            <div className="p-5 rounded-2xl border bg-gradient-to-l from-emerald-50 to-teal-50 border-emerald-300">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-600 text-white rounded-2xl">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-gray-900">
                      حزمة أدوات تسريع الإنتاجية واختصارات F1
                    </h4>
                    <p className="text-xs text-gray-600 mt-0.5">
                      تتضمن اختصارات لوحة المفاتيح، المطابقة التلقائية لشوارع دمنهور، واللصق الذكي.
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.enableProductivitySuite}
                    onChange={(e) => onUpdateSettings({
                      ...settings,
                      enableProductivitySuite: e.target.checked,
                      enableKeyboardShortcuts: e.target.checked,
                      enableSmartAutoCorrect: e.target.checked
                    })}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                    <Command className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-gray-900 block">
                      اختصارات لوحة المفاتيح السريعة (F1, Ctrl+N, Ctrl+F, Ctrl+Z)
                    </span>
                    <span className="text-xs text-gray-500">
                      تنقل سريع بين السطور، فتح النماذج، والبحث الفوري
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  disabled={!settings.enableProductivitySuite}
                  checked={settings.enableKeyboardShortcuts && settings.enableProductivitySuite}
                  onChange={(e) => onUpdateSettings({ ...settings, enableKeyboardShortcuts: e.target.checked })}
                  className="w-5 h-5 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer disabled:opacity-40"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-50 text-amber-700 rounded-xl">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-gray-900 block">
                      المطابقة والاقتراح التلقائي للمأذونيات السبع
                    </span>
                    <span className="text-xs text-gray-500">
                      اقتراح المأذونية تلقائياً عند كتابة اسم الشارع بناءً على معالم دمنهور
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  disabled={!settings.enableProductivitySuite}
                  checked={settings.enableSmartAutoCorrect && settings.enableProductivitySuite}
                  onChange={(e) => onUpdateSettings({ ...settings, enableSmartAutoCorrect: e.target.checked })}
                  className="w-5 h-5 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer disabled:opacity-40"
                />
              </div>
            </div>

            {/* Rollback Plan Banner */}
            <div className="bg-cyan-50 border border-cyan-200 rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2.5 text-cyan-950 font-black text-sm">
                <Undo2 className="w-5 h-5 text-cyan-700" />
                <span>خطة الأمان والتراجع الفوري (Rollback Guarantee)</span>
              </div>
              <p className="text-xs text-cyan-900 leading-relaxed font-medium">
                يمكنك في أي لحظة الضغط على <kbd className="bg-white px-1.5 py-0.5 rounded border border-cyan-300 font-mono text-[11px] font-bold">Ctrl+Z</kbd> للتراجع عن أي خطوة، أو إعادة التعيين من تبويب إدارة البيانات.
              </p>
            </div>

          </div>
        )}

        {/* ===================== TAB 5: STATS ===================== */}
        {activeTab === 'stats' && (
          <div className="space-y-6">
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-emerald-700">إجمالي شوارع المنظومة</p>
                  <p className="text-2xl font-black text-emerald-950 mt-1">{stats.total} شارع</p>
                </div>
                <div className="p-3 bg-emerald-600 text-white rounded-xl shadow-xs">
                  <Building className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-blue-700">شوارع المأذونيات الرسمية السبع</p>
                  <p className="text-2xl font-black text-blue-950 mt-1">{stats.officialTotal} شارع</p>
                </div>
                <div className="p-3 bg-blue-600 text-white rounded-xl shadow-xs">
                  <ShieldCheck className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-amber-700">بيانات غير رسمية / مخصصة</p>
                  <p className="text-2xl font-black text-amber-950 mt-1">{stats.unofficialTotal} شارع</p>
                </div>
                <div className="p-3 bg-amber-600 text-white rounded-xl shadow-xs">
                  <TrendingUp className="w-6 h-6" />
                </div>
              </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4 shadow-xs">
              <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>توزيع الشوارع حسب المأذونيات الرسمية السبع بدمنهور</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {stats.officialDistricts.map((dist) => (
                  <div key={dist.key} className="p-3 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold text-gray-800">
                      <span className="font-bold flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${dist.dot} shrink-0`} />
                        <span>{dist.name}</span>
                      </span>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-gray-900 font-bold">{dist.count} شارع</span>
                        <span className="text-gray-500 text-[11px]">({dist.percentage}%)</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`${dist.bar} h-2 rounded-full transition-all duration-500`} 
                        style={{ width: `${Math.min(100, Math.max(3, parseFloat(dist.percentage) * 2))}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ===================== TAB 6: DATA MANAGEMENT & BACKUP ===================== */}
        {activeTab === 'data' && (
          <div className="space-y-6">

            {/* 🏷️ Custom Street Categories Management */}
            <div className="bg-white border border-gray-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
                    <Layers className="w-5 h-5 text-emerald-700" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-black text-gray-900 flex items-center gap-2">
                      <span>إدارة وتخصيص تصنيفات الشوارع (Street Categories)</span>
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                        {streetCategories.length} تصنيف
                      </span>
                    </h4>
                    <p className="text-xs text-gray-500 mt-0.5">
                      إضافة وتعديل وحذف التصنيفات (مثل: رئيسي، فرعي، حارة، عطفة، ميدان) التي تظهر بقائمة الاختيار بنموذج الإدخال DataForm.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleResetCategories}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition cursor-pointer self-start sm:self-auto"
                  title="استعادة التصنيفات الافتراضية"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>استعادة الافتراضيات</span>
                </button>
              </div>

              {categoryFeedback && (
                <div className="p-2.5 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{categoryFeedback}</span>
                </div>
              )}

              {/* Add New Category Input Form */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={newCategoryInput}
                    onChange={(e) => setNewCategoryInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCategory();
                      }
                    }}
                    placeholder="اكتب تصنيفاً جديداً (مثال: رئيسي، فرعي، كورنيش، ممر)..."
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-xs sm:text-sm font-semibold text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddCategory}
                  disabled={!newCategoryInput.trim()}
                  className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shadow-xs flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة تصنيف</span>
                </button>
              </div>

              {/* Street Categories Chips & Inline Edit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-2">
                {streetCategories.map((cat, idx) => {
                  const isEditing = editingCategoryIdx === idx;
                  const recordsUsingCount = records.filter(r => (r.category || 'شارع') === cat).length;

                  return (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl border transition flex items-center justify-between gap-2 ${
                        isEditing 
                          ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-300' 
                          : 'bg-gray-50/80 hover:bg-white border-gray-200 shadow-2xs'
                      }`}
                    >
                      {isEditing ? (
                        <div className="flex items-center gap-1.5 w-full">
                          <input
                            type="text"
                            value={editingCategoryVal}
                            onChange={(e) => setEditingCategoryVal(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveEditCategory(idx);
                              if (e.key === 'Escape') setEditingCategoryIdx(null);
                            }}
                            autoFocus
                            className="flex-1 px-2.5 py-1 bg-white border border-emerald-400 rounded-lg text-xs font-bold text-gray-900 focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditCategory(idx)}
                            className="p-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                            title="حفظ التعديل"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingCategoryIdx(null)}
                            className="p-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-xs cursor-pointer"
                            title="إلغاء"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                            <span className="text-xs font-bold text-gray-900 truncate">{cat}</span>
                            <span className="px-1.5 py-0.2 bg-gray-200/70 text-gray-600 rounded text-[10px] font-mono" title={`${recordsUsingCount} شارع بهذا التصنيف`}>
                              {recordsUsingCount}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingCategoryIdx(idx);
                                setEditingCategoryVal(cat);
                              }}
                              className="p-1 text-gray-400 hover:text-emerald-700 hover:bg-emerald-50 rounded transition cursor-pointer"
                              title="تعديل اسم التصنيف"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteCategory(idx)}
                              className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition cursor-pointer"
                              title="حذف هذا التصنيف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 📑 Custom Unofficial Notarizations & Suggested 7 Regions Management */}
            <div className="bg-white border border-gray-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-amber-100 text-amber-900 rounded-2xl">
                    <BookmarkCheck className="w-5 h-5 text-amber-700" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-black text-gray-900 flex items-center gap-2">
                      <span>إدارة تصنيفات المأذونيات غير الرسمية واقتراح المأذونيات السبع</span>
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-950">
                        {unofficialSubTypes.length} تصنيفات غير رسمية
                      </span>
                    </h4>
                    <p className="text-xs text-gray-500 mt-0.5">
                      تخصيص تصنيفات البيانات غير الرسمية (داتا خاصة، عقود، بطاقات، خرائط) واقتراح المأذونية من السبع الرسمية لضمان دقة التنظيم.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleResetUnofficialSubTypes}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition cursor-pointer self-start sm:self-auto"
                  title="استعادة التصنيفات غير الرسمية الافتراضية"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>استعادة الافتراضيات</span>
                </button>
              </div>

              {unofficialFeedback && (
                <div className="p-2.5 bg-amber-50 text-amber-950 border border-amber-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>{unofficialFeedback}</span>
                </div>
              )}

              {/* Add New Unofficial SubType Form */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={newUnofficialInput}
                    onChange={(e) => setNewUnofficialInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddUnofficialSubType();
                      }
                    }}
                    placeholder="اكتب تصنيفاً غير رسمي جديد (مثال: حصر ميداني، شهادة ميلاد، مستند شهر عقاري)..."
                    className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-300 rounded-xl text-xs sm:text-sm font-semibold text-amber-950 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddUnofficialSubType}
                  disabled={!newUnofficialInput.trim()}
                  className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shadow-xs flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة تصنيف غير رسمي</span>
                </button>
              </div>

              {/* Unofficial Sub-Types Chips */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {unofficialSubTypes.map((sub, idx) => {
                  const isEditing = editingUnofficialIdx === idx;

                  return (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl border transition flex items-center justify-between gap-2 ${
                        isEditing 
                          ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-300' 
                          : 'bg-amber-50/40 hover:bg-white border-amber-200/80 shadow-2xs'
                      }`}
                    >
                      {isEditing ? (
                        <div className="flex items-center gap-1.5 w-full">
                          <input
                            type="text"
                            value={editingUnofficialVal}
                            onChange={(e) => setEditingUnofficialVal(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveEditUnofficialSubType(idx);
                              if (e.key === 'Escape') setEditingUnofficialIdx(null);
                            }}
                            autoFocus
                            className="flex-1 px-2.5 py-1 bg-white border border-amber-400 rounded-lg text-xs font-bold text-gray-900 focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditUnofficialSubType(idx)}
                            className="p-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingUnofficialIdx(null)}
                            className="p-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-xs cursor-pointer"
                            title="إلغاء"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                            <span className="text-xs font-bold text-amber-950 truncate">{sub}</span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingUnofficialIdx(idx);
                                setEditingUnofficialVal(sub);
                              }}
                              className="p-1 text-gray-400 hover:text-amber-800 hover:bg-amber-100/60 rounded transition cursor-pointer"
                              title="تعديل التصنيف"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteUnofficialSubType(idx)}
                              className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition cursor-pointer"
                              title="حذف التصنيف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Suggested 7 Official Notarizations Display */}
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-950 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>المأذونيات السبع المعتمدة رسمياً والمتاحة للاقتراح المباشر بالبيانات غير الرسمية:</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {suggestedNotarizations.map(r => (
                    <span key={r} className="px-3 py-1 bg-white rounded-xl border border-emerald-300 text-emerald-900 text-xs font-bold shadow-2xs">
                      {r}
                    </span>
                  ))}
                </div>
                <p className="text-[11px] text-emerald-800">
                  تظهر هذه المأذونيات السبع تلقائياً في قائمة اقتراح جهة الاختصاص المرجحة عند تسجيل بيانات غير رسمية في نموذج الإدخال.
                </p>
              </div>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-blue-950 font-bold text-sm">
                  <Upload className="w-5 h-5 text-blue-700" />
                  <span>استيراد وتغذية البيانات من ملفات Excel و CSV</span>
                </div>
                {onOpenImport && (
                  <button
                    type="button"
                    onClick={() => {
                      onBack();
                      onOpenImport();
                    }}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                  >
                    فتح نافذة الاستيراد
                  </button>
                )}
              </div>
              <p className="text-xs text-blue-800 leading-relaxed">
                يتيح استيراد ملفات Excel مع دعم المعاينة المسبقة والمطابقة الذكية للأعمدة العربية وتخطي التكرار تلقائياً.
              </p>
            </div>

            {onRepairMojibake && (
              <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-amber-950 font-bold text-sm">
                    <RefreshCw className="w-5 h-5 text-amber-700" />
                    <span>إصلاح وتصحيح الحروف العربية المشوهة (Mojibake Fixer)</span>
                  </div>
                  <button
                    type="button"
                    onClick={onRepairMojibake}
                    className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                  >
                    فحص وإصلاح الترميز الآن
                  </button>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  إذا تم فتح ملف بترميز غير متوافق (Windows-1256 / UTF-8) وظهرت رموز مشوهة، يقوم هذا المحرك بتصحيحها فوراً دون أي فقدان للبيانات.
                </p>
              </div>
            )}

            {/* Encrypted Cloud-Ready Local Backup & Restore */}
            <div className="bg-purple-50/80 border border-purple-200 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-purple-950 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5 text-purple-700" />
                  <span>الاستعادة السحابية المحلية والنسخ المشفر (AES-256)</span>
                </div>
                {onOpenBackupRestore && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenBackupRestore();
                    }}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>فتح نافذة النسخ والاستعادة السحابية</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-purple-800 leading-relaxed">
                تتيح تصدير قاعدة البيانات كاملة مع تشفير فائق الأمان (AES-GCM 256) بكلمة مرور، وتضمين التوقيت الهجري والميلادي واسم المراجع لنقلها واستعادتها بأمان على أجهزة أخرى.
              </p>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                <Database className="w-5 h-5 text-emerald-700" />
                <span>النسخ الاحتياطي الكامل بصيغة JSON</span>
              </div>
              <p className="text-xs text-emerald-800 leading-relaxed">
                تنزيل نسخة احتياطية شاملة لجميع السجلات والتصنيفات والملاحظات، واستعادتها في أي وقت على أي جهاز آخر.
              </p>
              
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={onExportJSON}
                  className="flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل نسخة احتياطية كاملة (JSON)</span>
                </button>

                <label className="flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer">
                  <Upload className="w-4 h-4 text-emerald-700" />
                  <span>استعادة البيانات من ملف JSON</span>
                  <input type="file" accept=".json" onChange={onImportJSON} className="hidden" />
                </label>
              </div>
            </div>

            {/* Bulk Under-Review & Data Preservation Tool */}
            <div className="bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 border border-sky-300 rounded-2xl p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-sky-950 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5 text-sky-700" />
                  <span>وضع جميع البيانات قيد المراجعة (إجراء احترازي بقرار إداري)</span>
                </div>
                <span className="px-2.5 py-0.5 bg-sky-200 text-sky-950 font-black text-xs rounded-full">
                  {records.filter(r => r.status === 'قيد المراجعة').length} / {records.length} قيد المراجعة
                </span>
              </div>
              <p className="text-xs text-sky-900 leading-relaxed">
                يسمح هذا الخيار بوضع كافة سجلات المنظومة ({records.length} شارع) في حالة «قيد المراجعة» كإجراء احترازي إداري للحفاظ على جودة البيانات. <strong className="font-black text-sky-950 underline">يتم توثيق هذا الإجراء الإداري في سجل التدقيق لكل سجل تلقائياً</strong> مع الحفاظ التام 100% على كافة أسماء الشوارع والمأذونيات والملاحظات دون أي مساس.
              </p>

              {/* Automatic Precautionary Toggle */}
              <div className="pt-2 border-t border-sky-200/80">
                <label className="flex items-center justify-between p-3 bg-white/80 rounded-xl border border-sky-200 cursor-pointer hover:bg-white transition">
                  <div className="space-y-0.5">
                    <span className="text-xs font-black text-sky-950 block">
                      🛡️ تفعيل الإجراء الاحترازي التلقائي للشوارع الجديدة والمستوردة
                    </span>
                    <span className="text-[11px] text-sky-800 block">
                      عند التفعيل، سيتم وسم أي شارع جديد أو مستورد كـ «قيد المراجعة» تلقائياً حتى يقوم المراجع باعتماده رسمياً.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(settings.autoPrecautionUnderReview)}
                    onChange={(e) => onUpdateSettings({ ...settings, autoPrecautionUnderReview: e.target.checked })}
                    className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer shrink-0"
                  />
                </label>
              </div>

              {onMarkAllUnderReview && (
                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`هل ترغب في وضع جميع البيانات (${records.length} شارع) في حالة «قيد المراجعة» كإجراء احترازي بقرار إداري؟\n\n• سيتم توثيق القرار في سجل التدقيق لكل سجل حفاظاً على جودة البيانات.\n• يتم الحفاظ التام والكامل على كافة النصوص والملاحظات دون أي حذف.`)) {
                        onMarkAllUnderReview(false, 'تم وضع السجل في حالة قيد المراجعة كإجراء احترازي بقرار إداري حفاظاً على جودة البيانات');
                      }
                    }}
                    className="flex items-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black shadow-xs transition cursor-pointer"
                  >
                    <FileCheck2 className="w-4 h-4 text-sky-200" />
                    <span>وضع جميع البيانات قيد المراجعة ({records.length} سجل)</span>
                  </button>

                  {records.some(r => r.status === 'تام' || r.isLocked) && (
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`هل ترغب في وضع السجلات غير المعتمدة فقط «قيد المراجعة» مع استثناء البيانات المعتمدة كـ «بيان تام 🔒»؟`)) {
                          onMarkAllUnderReview(true, 'تم وضع السجل في حالة قيد المراجعة كإجراء احترازي بقرار إداري حفاظاً على جودة البيانات');
                        }
                      }}
                      className="flex items-center gap-1.5 px-4 py-2.5 bg-white hover:bg-sky-100 text-sky-950 border border-sky-300 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                    >
                      <Lock className="w-3.5 h-3.5 text-amber-600" />
                      <span>استثناء السجلات المعتمدة كـ «بيان تام 🔒»</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="bg-red-50/70 border border-red-200 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2 text-red-900 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <span>منطقة الأمان القصوى: إعادة تعيين البيانات النموذجية</span>
              </div>
              <p className="text-xs text-red-800 leading-relaxed">
                يؤدي هذا الإجراء إلى مسح أية تعديلات تم إدخالها محلياً واستعادة الداتا النموذجية المعتمدة ({records.length} شارع).
              </p>

              {!showResetConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-red-100 hover:bg-red-200 text-red-900 border border-red-300 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
                >
                  <RefreshCw className="w-4 h-4 text-red-700" />
                  <span>طلب إعادة ضبط البيانات الأصلية</span>
                </button>
              ) : (
                <div className="p-3 bg-red-100/90 border border-red-300 rounded-xl space-y-3">
                  <p className="text-xs font-bold text-red-950">
                    ⚠️ هل أنت متأكد تماماً؟ سيتم استبدال البيانات الحالية بالسجلات الأصلية. يُفضل تنزيل نسخة احتياطية JSON أولاً.
                  </p>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        onResetData();
                        setShowResetConfirm(false);
                        onBack();
                      }}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow cursor-pointer"
                    >
                      نعم، إعادة التعيين الآن
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowResetConfirm(false)}
                      className="px-4 py-2 bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                    >
                      إلغاء التراجع
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </div>

      {/* Footer */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between shrink-0">
        <span className="text-xs text-gray-500 font-medium">
          يتم حفظ كافة تفضيلات المظهر ومساحة العمل تلقائياً
        </span>
        <button
          type="button"
          onClick={onBack}
          className="px-6 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-bold text-xs sm:text-sm transition shadow cursor-pointer"
        >
          العودة لمساحة العمل
        </button>
      </div>

    </div>
  );
}
