import React from 'react';
import { 
  AlertTriangle, 
  X, 
  GitMerge, 
  RefreshCw, 
  CopyPlus, 
  Ban, 
  Building2, 
  FileText, 
  Tag, 
  ShieldAlert,
  Info,
  Lock,
  ShieldCheck,
  Eye,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { RecordItem, ThemeType } from '../types';
import { ArabicUtils } from '../utils/arabicUtils';

export interface DuplicateConflictData {
  item: Omit<RecordItem, 'id'>;
  editId?: string;
  existingRecord: RecordItem;
  isSamePermission: boolean;
  isMetadataEqual?: boolean;
  similarityScore?: number;
  matchReason?: string;
}

interface DuplicateRecordModalProps {
  isOpen: boolean;
  conflict: DuplicateConflictData | null;
  onClose: () => void;
  onMergeNotes: (existingId: string, incomingItemOrMetadata: Omit<RecordItem, 'id'> | string, incomingCategory?: string) => void;
  onReplaceExisting: (existingId: string, newItem: Omit<RecordItem, 'id'>) => void;
  onSaveAsDuplicate: (newItem: Omit<RecordItem, 'id'>) => void;
  onViewExisting?: (existingRecord: RecordItem) => void;
  theme: ThemeType;
}

export const DuplicateRecordModal: React.FC<DuplicateRecordModalProps> = ({
  isOpen,
  conflict,
  onClose,
  onMergeNotes,
  onReplaceExisting,
  onSaveAsDuplicate,
  onViewExisting,
  theme
}) => {
  // Keyboard shortcut listener (Escape to close)
  React.useEffect(() => {
    if (!isOpen || !conflict) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown, { capture: true });
    return () => window.removeEventListener('keydown', handleKeyDown, { capture: true });
  }, [isOpen, conflict, onClose]);

  if (!isOpen || !conflict) return null;

  const { item, existingRecord, isSamePermission, similarityScore, matchReason } = conflict;
  const isExistingTruth = existingRecord.status === 'تام' || existingRecord.isLocked || existingRecord.isTruthRecord;
  const existingNotes = existingRecord.metadata?.trim() || '';
  const incomingNotes = item.metadata?.trim() || '';
  const simPercent = similarityScore ? Math.round(similarityScore * 100) : 100;
  const isExactMatch = !similarityScore || similarityScore >= 0.99;

  // Calculate metadata equality and street name change
  const isMetadataEqual = conflict.isMetadataEqual ?? ArabicUtils.areMetadataEqual(existingNotes, incomingNotes);
  const isNameChanged = item.name.trim() !== existingRecord.name.trim();

  // Calculate merged notes preview using smart semantic deduplication
  const mergedNotesPreview = ArabicUtils.smartMergeNotes(existingNotes, incomingNotes) || '(لا توجد ملاحظات)';

  const getThemeBg = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-800 text-white';
      case 'libreoffice': return 'bg-cyan-900 text-white';
      case 'modern':
      default: return 'bg-indigo-900 text-white';
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      dir="rtl"
    >
      <div 
        className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[92vh] relative"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header with High-Visibility Alert Styling */}
        <div className={`px-6 py-4 flex items-center justify-between shrink-0 ${
          isExistingTruth 
            ? 'bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 text-white' 
            : !isExactMatch
            ? 'bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white'
            : isSamePermission 
            ? 'bg-amber-600 text-white' 
            : getThemeBg()
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-2xl shrink-0">
              {isExistingTruth ? (
                <Lock className="w-6 h-6 text-amber-300" />
              ) : !isExactMatch ? (
                <Sparkles className="w-6 h-6 text-amber-200" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-black">
                  {isExistingTruth 
                    ? 'تنبيه: تشابه مع «عنوان الحقيقة» المعتمد نهائياً 🔒' 
                    : !isExactMatch 
                    ? 'نظام التنبيه الذكي: اسم شارع مشابه جداً لشارع مسجل مسبقاً' 
                    : 'تنبيه: تم اكتشاف تكرار لشارع موجود مسبقاً'}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-white/25 text-white backdrop-blur-xs border border-white/30">
                  {isExactMatch ? 'تطابق 100%' : `نسبة التشابه: ${simPercent}%`}
                </span>
              </div>
              <p className="text-xs text-white/90 mt-0.5">
                {matchReason || (isExistingTruth
                  ? '⭐ السجل الأصلي بيان تام نهائي مغلق ومحمي كمرجع أساسي للحقيقة'
                  : isSamePermission 
                  ? '⚠️ تطابق كامل في الاسم والمأذونية الأصلية — يرجى تحديد الإجراء المناسب'
                  : 'ℹ️ تطابق في اسم الشارع مع اختلاف المأذونية أو التبعية')}
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/20 transition text-white cursor-pointer shrink-0"
            title="إغلاق النافذة والعودة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-right flex-1">

          {/* Ground Truth Banner if existing is Truth Record */}
          {isExistingTruth && (
            <div className="p-3.5 bg-emerald-800 text-white rounded-2xl flex items-center gap-3 shadow-md border border-emerald-600/50">
              <ShieldCheck className="w-6 h-6 text-amber-300 shrink-0" />
              <div className="text-xs leading-relaxed">
                <strong className="block text-sm font-black text-amber-200">
                  السجل الأصلي هو «عنوان الحقيقة» المعتمد (بيان تام مغلق 🔒)
                </strong>
                <span>
                  هذا البيان مغلق لمنع التعديلات العرضية. يُفضل دمج الملاحظات فيه أو عرض السجل الحالي ومراجعته بدلاً من حفظ شارع مكرر.
                </span>
              </div>
            </div>
          )}

          {/* Conflict Street Name Banner */}
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-gray-500 block mb-0.5">اسم الشارع المراد حفظه:</span>
              <h2 className="text-xl font-black text-gray-950 tracking-wide font-sans">{item.name}</h2>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {isSamePermission ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold shrink-0">
                  <ShieldAlert className="w-4 h-4 text-amber-700" />
                  <span>تطابق في نفس المأذونية: ({existingRecord.permission})</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-100 text-blue-900 border border-blue-300 rounded-xl text-xs font-bold shrink-0">
                  <Info className="w-4 h-4 text-blue-700" />
                  <span>مأذونيتان مختلفتان</span>
                </div>
              )}
            </div>
          </div>

          {/* Side-by-Side Comparison of Existing vs Incoming */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. Existing Record in DB */}
            <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-3 relative group">
              <div className="flex items-center justify-between border-b border-emerald-200/60 pb-2">
                <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  السجل الحالي المسجل بالنظام:
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md font-bold flex items-center gap-1">
                  {isExistingTruth && <Lock className="w-3 h-3 text-emerald-700" />}
                  <span>{isExistingTruth ? 'بيان تام 🔒' : 'موجود بالنظام'}</span>
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-gray-500 block text-[11px]">اسم الشارع الحالي:</span>
                  <span className="font-black text-gray-950 text-sm">{existingRecord.name}</span>
                </div>

                <div className="flex items-start gap-2">
                  <Building2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-gray-500 block text-[11px]">المأذونية التابع لها:</span>
                    <span className="font-bold text-gray-900">{existingRecord.permission}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Tag className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-gray-500 block text-[11px]">التصنيف:</span>
                    <span className="font-semibold text-gray-800">{existingRecord.category || 'شارع'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2 pt-1 border-t border-emerald-100">
                  <FileText className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div className="w-full">
                    <span className="text-gray-500 block text-[11px]">الملاحظات والبيانات الوصفية الحالية:</span>
                    <p className="text-gray-800 font-medium bg-white p-2 rounded-xl border border-emerald-200 mt-1 max-h-24 overflow-y-auto break-words leading-relaxed">
                      {existingNotes || <span className="text-gray-400 italic">لا توجد ملاحظات سابقة</span>}
                    </p>
                  </div>
                </div>

                {onViewExisting && (
                  <button
                    type="button"
                    onClick={() => onViewExisting(existingRecord)}
                    className="w-full mt-2 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 font-bold text-xs rounded-xl border border-emerald-300 transition cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-emerald-700" />
                    <span>عرض وفتح هذا السجل في المحرر</span>
                  </button>
                )}
              </div>
            </div>

            {/* 2. Incoming Record */}
            <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-200 space-y-3">
              <div className="flex items-center justify-between border-b border-amber-200/60 pb-2">
                <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                  البيانات الجديدة المطلوب إضافتها:
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md font-bold">
                  إدخال جديد
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-gray-500 block text-[11px]">اسم الشارع الجديد:</span>
                  <span className="font-black text-gray-950 text-sm">{item.name}</span>
                </div>

                <div className="flex items-start gap-2">
                  <Building2 className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-gray-500 block text-[11px]">المأذونية التابع لها:</span>
                    <span className="font-bold text-gray-900">{item.permission}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Tag className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-gray-500 block text-[11px]">التصنيف:</span>
                    <span className="font-semibold text-gray-800">{item.category || 'شارع'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2 pt-1 border-t border-amber-100">
                  <FileText className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div className="w-full">
                    <span className="text-gray-500 block text-[11px]">الملاحظات المدخلة الجديدة:</span>
                    <p className="text-gray-800 font-medium bg-white p-2 rounded-xl border border-amber-200 mt-1 max-h-24 overflow-y-auto break-words leading-relaxed">
                      {incomingNotes || <span className="text-gray-400 italic">لا توجد ملاحظات جديدة</span>}
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Metadata Equality Notice */}
          {isMetadataEqual && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center gap-2 shadow-2xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span><strong>معيار التساوي للبيانات الوصفية:</strong> الملاحظات متطابقة دلالياً بين السجلين، وسيعتمد الدمج النص الأحدث دون تكرار الصفوف.</span>
            </div>
          )}

          {/* Merge Preview if user chooses to merge */}
          {(incomingNotes || existingNotes) && (
            <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-2xl text-xs space-y-1.5 shadow-2xs">
              <span className="font-bold text-indigo-950 flex items-center gap-1.5">
                <GitMerge className="w-4 h-4 text-indigo-700" />
                <span>معاينة نتيجة دمج البيانات والملاحظات في السجل الحالي:</span>
              </span>
              <p className="text-indigo-900 bg-white p-2.5 rounded-xl border border-indigo-200 font-medium whitespace-pre-line leading-relaxed text-xs">
                {mergedNotesPreview}
              </p>
            </div>
          )}

          {/* Smart Decision Recommendation */}
          <div className="bg-sky-50 border border-sky-200 rounded-2xl p-3 text-xs text-sky-900 flex items-start gap-2">
            <Info className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="font-bold text-sky-950">التوصية الذكية لتفادي التكرار: </strong>
              اختر <strong className="font-black text-sky-950">«دمج الملاحظات»</strong> لإثراء السجل الحالي دون تكرار صفوف الجدول، أو <strong className="font-black text-sky-950">«عرض السجل الحالي»</strong> لمعاينة وتعديل الشارع المسجل مسبقاً.
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-2.5 shrink-0">
          
          {/* Cancel Button */}
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2.5 text-gray-700 hover:bg-gray-200 rounded-xl font-bold text-xs transition cursor-pointer"
          >
            <Ban className="w-4 h-4 text-gray-500" />
            <span>إلغاء الإضافة (تراجع)</span>
          </button>

          {/* Action Buttons */}
          <div className="w-full sm:w-auto flex flex-wrap items-center justify-end gap-2">
            
            {/* 1. View / Open Existing Record */}
            {onViewExisting && (
              <button
                type="button"
                onClick={() => onViewExisting(existingRecord)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-blue-50 border border-blue-300 hover:bg-blue-100 text-blue-950 rounded-xl font-bold text-xs transition cursor-pointer shadow-xs"
                title="فتح وعرض السجل الحالي في المحرر لمعاينته أو تعديله مباشرة"
              >
                <Eye className="w-4 h-4 text-blue-700" />
                <span>عرض السجل الحالي</span>
              </button>
            )}

            {/* 2. Save as Separate Duplicate Record */}
            <button
              type="button"
              onClick={() => onSaveAsDuplicate(item)}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-white border border-gray-300 hover:bg-gray-100 text-gray-800 rounded-xl font-bold text-xs transition cursor-pointer shadow-xs"
              title="حفظ كشارع إضافي منفصل رغم التشابه"
            >
              <CopyPlus className="w-4 h-4 text-gray-600" />
              <span>حفظ كشارع منفصل</span>
            </button>

            {/* 3. Replace Existing Record */}
            <button
              type="button"
              onClick={() => onReplaceExisting(existingRecord.id, item)}
              className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-white rounded-xl font-bold text-xs transition cursor-pointer shadow-xs ${
                isExistingTruth ? 'bg-slate-700 hover:bg-slate-800' : 'bg-amber-600 hover:bg-amber-700'
              }`}
              title="استبدال بيانات السجل الأصلي بالبيانات الجديدة"
            >
              <RefreshCw className="w-4 h-4 text-white" />
              <span>{isExistingTruth ? 'استبدال السجل التام' : 'استبدال السجل الحالي'}</span>
            </button>

            {/* 4. Merge Notes & Data (Primary Recommendation) */}
            <button
              type="button"
              onClick={() => onMergeNotes(existingRecord.id, item, item.category)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
              title="دمج البيانات والملاحظات مع السجل الحالي واعتماد التعديلات دون تكرار الصفوف"
            >
              <GitMerge className="w-4 h-4" />
              <span>{isNameChanged ? `دمج البيانات واعتماد اسم («${item.name}»)` : 'دمج وتحديث البيانات في السجل الحالي'}</span>
            </button>

          </div>

        </div>

      </div>
    </div>
  );
};
