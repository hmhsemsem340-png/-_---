import React, { useState } from 'react';
import { X, Printer, Building2, Edit3, Download, Settings2, UserCheck, Calendar, Clock } from 'lucide-react';
import { RecordItem, ThemeType, AppSettings } from '../types';
import { getDistrictColor } from '../utils/districtColors';
import { getFormattedDatabaseTimestamps } from '../utils/dateTimeUtils';
import { parseStreetPrefixAndName, isOfficialNotarization } from '../utils/streetSplitter';

interface PrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: RecordItem[];
  theme: ThemeType;
  settings: AppSettings;
}

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  isOpen,
  onClose,
  records,
  theme,
  settings
}) => {
  // Custom header and footer state
  const [reportTitle, setReportTitle] = useState('تقرير الشوارع والمأذونيات الرسمية');
  const [reportSubtitle, setReportSubtitle] = useState('كشف البيانات والمواقع المعتمدة بدمنهور');
  const [reportFooter, setReportFooter] = useState('تم الاعتماد والإصدار الآلي عبر منظومة الشوارع و المأذونيات بدمنهور');
  const [reviewerName, setReviewerName] = useState(settings.reviewerName || 'مراجع السجلات المعتمد');
  const [isEditingHeader, setIsEditingHeader] = useState(false);

  // Print layout customization
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [printMargin, setPrintMargin] = useState<string>('10mm');
  const [printThemeStyle, setPrintThemeStyle] = useState<'emerald' | 'dark' | 'classic'>('emerald');

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const timestamps = getFormattedDatabaseTimestamps();

  const getHeaderBgClass = () => {
    switch (printThemeStyle) {
      case 'emerald': return 'bg-emerald-800 text-white';
      case 'dark': return 'bg-gray-900 text-white';
      case 'classic':
      default: return 'bg-gray-200 text-gray-900 border-b-2 border-gray-900';
    }
  };

  return (
    <div className="print-report-modal-root fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      
      {/* Global Print Styles with dynamic orientation & margins */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-report-area, #printable-report-area * {
            visibility: visible;
          }
          .print-report-modal-root {
            position: static !important;
            overflow: visible !important;
            background: none !important;
            backdrop-filter: none !important;
          }
          .print-report-modal-root > * {
            overflow: visible !important;
          }
          #printable-report-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: ${printMargin} !important;
            background: white !important;
            box-shadow: none !important;
            border: none !important;
            border-radius: 0 !important;
            font-size: ${settings.printFontSize} !important;
            font-family: ${settings.fontFamily} !important;
            color: #000 !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          thead {
            display: table-header-group;
          }
          tr {
            page-break-inside: avoid;
          }
          .no-print {
            display: none !important;
          }
          @page {
            size: A4 ${orientation};
            margin: ${printMargin};
          }
        }
      ` }} />

      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-gray-100 flex flex-col max-h-[95vh] my-auto">
        
        {/* Toolbar Header (Hidden on print) */}
        <div className="px-6 py-4 bg-gray-900 text-white flex items-center justify-between shrink-0 print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold">معاينة تقرير الطباعة وتخصيص الصفحات (A4)</h3>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsEditingHeader(!isEditingHeader)}
              className="flex items-center gap-1 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-200 rounded-xl text-xs font-semibold transition border border-gray-700 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5 text-amber-400" />
              <span>{isEditingHeader ? 'إخفاء التخصيص' : 'تخصيص الترويسة والصفحة'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-gray-950 font-bold rounded-xl text-sm transition shadow cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تصدير وطباعة PDF</span>
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/20 transition text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Custom Header & Layout Options Editor Box (Hidden on print) */}
        {isEditingHeader && (
          <div className="bg-amber-50 border-b border-amber-200 px-6 py-4 space-y-4 print:hidden text-right">
            <p className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
              <Settings2 className="w-4 h-4 text-amber-700" />
              <span>خيارات تخصيص صفحة التقرير والترويسة:</span>
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">اتجاه الورقة:</label>
                <select
                  value={orientation}
                  onChange={(e) => setOrientation(e.target.value as any)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="portrait">عمودي (Portrait)</option>
                  <option value="landscape">أفقي (Landscape - مناسب للجداول العريضة)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">هوامش الطباعة:</label>
                <select
                  value={printMargin}
                  onChange={(e) => setPrintMargin(e.target.value)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="5mm">هوامش ضيقة (5 مم)</option>
                  <option value="10mm">هوامش عادية (10 مم)</option>
                  <option value="15mm">هوامش واسعة (15 مم)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">ثيم ولون الترويسة:</label>
                <select
                  value={printThemeStyle}
                  onChange={(e) => setPrintThemeStyle(e.target.value as any)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="emerald">أخضر رسمي فاخر</option>
                  <option value="dark">أسود داكن رسمي</option>
                  <option value="classic">كلاسيكي رمادي مبسط</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">عنوان التقرير الرئيسي:</label>
                <input
                  type="text"
                  value={reportTitle}
                  onChange={(e) => setReportTitle(e.target.value)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">العنوان الفرعي أو جهة الإصدار:</label>
                <input
                  type="text"
                  value={reportSubtitle}
                  onChange={(e) => setReportSubtitle(e.target.value)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-amber-900 mb-1">اسم المراجع / المدقق:</label>
                <input
                  type="text"
                  value={reviewerName}
                  onChange={(e) => setReviewerName(e.target.value)}
                  className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-amber-900 mb-1">نص تذييل الصفحة (Footer):</label>
              <input
                type="text"
                value={reportFooter}
                onChange={(e) => setReportFooter(e.target.value)}
                className="w-full px-3 py-1.5 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* Printable Report Sheet (A4 format) */}
        <div className="p-6 sm:p-10 overflow-y-auto flex-1 bg-gray-100 print:bg-white print:p-0">
          
          <div 
            id="printable-report-area" 
            className="max-w-[210mm] mx-auto bg-white p-8 sm:p-10 shadow-lg print:shadow-none print:w-full rounded-xl border border-gray-200 text-gray-900 text-right"
            style={{ fontFamily: settings.fontFamily }}
          >
            
            {/* Clean Minimalist Header */}
            <div className="border-b-2 border-emerald-900/40 pb-4 mb-5 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900 tracking-tight">{reportTitle}</h1>
                <p className="text-xs text-gray-600 mt-0.5">{reportSubtitle}</p>
              </div>
              <div className="text-left text-xs text-gray-700 space-y-1 font-medium bg-gray-50 border border-gray-200 px-3 py-2 rounded-lg">
                <p><span className="text-gray-500">التاريخ الميلادي:</span> <strong className="text-gray-900">{timestamps.gregorianDate} ({timestamps.gregorianTime})</strong></p>
                <p><span className="text-gray-500">التاريخ الهجري:</span> <strong className="text-emerald-800">{timestamps.hijriDate}</strong></p>
                <p><span className="text-gray-500">المراجع المعتمد:</span> <strong className="text-gray-900">{reviewerName}</strong></p>
                <p><span className="text-gray-500">إجمالي السجلات:</span> <strong className="text-gray-900">{records.length.toLocaleString('ar-EG')} سجل</strong></p>
              </div>
            </div>

            {/* Clean Records Table (Optimized font size & padding for A4) */}
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    <th className="p-2 border border-gray-800 w-10 text-center font-semibold" style={{ textAlign: (settings.dynamicTheme?.columns?.index?.align as any) || 'center' }}>م</th>
                    <th className="p-2 border border-gray-800 font-semibold" style={{ textAlign: (settings.dynamicTheme?.columns?.name?.align as any) || 'right' }}>اسم الشارع</th>
                    <th className="p-2 border border-gray-800 w-36 font-semibold" style={{ textAlign: (settings.dynamicTheme?.columns?.permission?.align as any) || 'right' }}>المأذونية</th>
                    <th className="p-2 border border-gray-800 w-24 font-semibold" style={{ textAlign: (settings.dynamicTheme?.columns?.category?.align as any) || 'center' }}>النوع</th>
                    <th className="p-2 border border-gray-800 font-semibold" style={{ textAlign: (settings.dynamicTheme?.columns?.metadata?.align as any) || 'right' }}>البيانات الوصفية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {records.map((record, index) => {
                    const parsed = parseStreetPrefixAndName(record.name, record.category);
                    const isOfficial = isOfficialNotarization(record.permission);
                    const colCfg = settings.dynamicTheme?.columns;
                    
                    const nameWeight = colCfg?.name?.fontWeight === 'bold' || colCfg?.name?.fontWeight === 'black' ? 'font-bold' : 'font-normal';
                    const permWeight = colCfg?.permission?.fontWeight === 'bold' || colCfg?.permission?.fontWeight === 'black' ? 'font-bold' : 'font-medium';
                    const catWeight = colCfg?.category?.fontWeight === 'bold' || colCfg?.category?.fontWeight === 'black' ? 'font-bold' : 'font-normal';
                    const metaWeight = colCfg?.metadata?.fontWeight === 'bold' || colCfg?.metadata?.fontWeight === 'black' ? 'font-bold' : 'font-normal';

                    return (
                      <tr key={record.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'}>
                        <td className="p-2 border border-gray-300 text-gray-500 font-medium" style={{ textAlign: (colCfg?.index?.align as any) || 'center' }}>{index + 1}</td>
                        <td className={`p-2 border border-gray-300 text-gray-900 ${nameWeight}`} style={{ textAlign: (colCfg?.name?.align as any) || 'right' }}>
                          {parsed.cleanName}
                        </td>
                        <td className={`p-2 border border-gray-300 text-gray-800 ${permWeight}`} style={{ textAlign: (colCfg?.permission?.align as any) || 'right' }}>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {(() => {
                              const district = getDistrictColor(record.permission, record.metadata, record.name);
                              return district ? (
                                <span className="inline-flex items-center gap-1">
                                  <span className={`w-2 h-2 rounded-full ${district.dot} shrink-0`} />
                                  <span className={`${district.text} font-bold`}>{record.permission || 'غير محدد'}</span>
                                </span>
                              ) : (
                                <span>{record.permission || 'غير محدد'}</span>
                              );
                            })()}
                            <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              isOfficial 
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-300' 
                                : 'bg-amber-50 text-amber-700 border border-amber-300'
                            }`}>
                              {isOfficial ? 'رسمية' : 'غير رسمية'}
                            </span>
                          </div>
                        </td>
                        <td className={`p-2 border border-gray-300 text-gray-700 ${catWeight}`} style={{ textAlign: (colCfg?.category?.align as any) || 'center' }}>
                          <span className="inline-block px-2 py-0.5 rounded bg-gray-100 text-gray-800 text-[11px] font-medium border border-gray-200">
                            {parsed.detectedType}
                          </span>
                        </td>
                        <td className={`p-2 border border-gray-300 text-gray-600 ${metaWeight}`} style={{ textAlign: (colCfg?.metadata?.align as any) || 'right' }}>
                          {record.metadata || '-'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Official Signature and Reviewer Footer */}
            <div className="mt-8 pt-4 border-t-2 border-gray-300 flex flex-wrap items-center justify-between text-xs text-gray-600 gap-4">
              <div>
                <p className="font-semibold text-gray-800">{reportFooter}</p>
                <p className="text-[11px] text-gray-500 mt-0.5">صدر بتاريخ: {timestamps.gregorianDate} الموافق {timestamps.hijriDate}</p>
              </div>
              <div className="border border-gray-300 rounded-lg p-3 min-w-[200px] text-center bg-gray-50/50">
                <span className="text-[11px] text-gray-500 block mb-1">اعتماد وتوقيع المراجع</span>
                <span className="font-bold text-gray-900 text-sm block">{reviewerName}</span>
                <div className="mt-4 border-b border-dashed border-gray-400 w-32 mx-auto"></div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
