import React, { useState } from 'react';
import { 
  X, 
  Keyboard, 
  Search, 
  Sliders, 
  FileSpreadsheet, 
  Plus, 
  Undo2, 
  Printer, 
  Zap, 
  HelpCircle, 
  Sparkles, 
  CheckCircle2, 
  MousePointer, 
  Layout, 
  Layers,
  Download,
  FileText
} from 'lucide-react';
import { ThemeType, AppSettings } from '../types';
import { downloadSystemFeaturesMarkdown } from '../utils/downloadMarkdown';

interface KeyboardHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: ThemeType;
  settings?: AppSettings;
}

interface ShortcutItem {
  keys: string[];
  description: string;
  category: 'table' | 'forms' | 'global' | 'data';
  badge?: string;
}

const SHORTCUTS_DATA: ShortcutItem[] = [
  // Global & General
  {
    keys: ['F1'],
    description: 'فتح لوحة التعليمات ودليل الاختصارات الشامل',
    category: 'global',
    badge: 'أساسي'
  },
  {
    keys: ['Ctrl', 'F'],
    description: 'التركيز الفوري في شريط البحث والتصفية',
    category: 'global',
    badge: 'سريع'
  },
  {
    keys: ['/'],
    description: 'اختصار بديل سريع للانتقال لمربع البحث في أي وقت',
    category: 'global'
  },
  {
    keys: ['Ctrl', 'Z'],
    description: 'التراجع الفوري (Undo) عن آخر عملية إضافة أو تعديل أو حذف',
    category: 'global',
    badge: 'أمان'
  },
  {
    keys: ['Ctrl', ','],
    description: 'فتح صفحة الإعدادات والتحليلات الموحدة',
    category: 'global'
  },
  {
    keys: ['Alt', 'S'],
    description: 'إظهار أو طي القائمة الجانبية للأدوات والتصفية السريعة',
    category: 'global',
    badge: 'جديد'
  },
  {
    keys: ['Esc'],
    description: 'إغلاق أي نافذة منبثقة أو إلغاء التحديد الجاري',
    category: 'global'
  },

  // Table Navigation & Management
  {
    keys: ['Ctrl', 'M'],
    description: 'فتح وضع «المراجعة السريعة»: التنقل بالأسهم وتحديث المأذونية بالأرقام 1-8 مباشرة دون فتح نموذج التعديل',
    category: 'table',
    badge: 'مراجعة سريعة'
  },
  {
    keys: ['↑', '↓'],
    description: 'التنقل بين صفوف وسجلات الجدول واحداً تلو الآخر',
    category: 'table'
  },
  {
    keys: ['Space'],
    description: 'تحديد / إلغاء تحديد السجل الحالي لإجراء العمليات الجماعية',
    category: 'table'
  },
  {
    keys: ['F2'],
    description: 'فتح نافذة التحرير السريع للسجل النشط',
    category: 'table',
    badge: 'تحرير'
  },
  {
    keys: ['Delete'],
    description: 'حذف السجل النشط أو السجلات المحددة مع تأكيد الحماية',
    category: 'table'
  },
  {
    keys: ['نقر مزدوج'],
    description: 'النقر المزدوج بالفأرة على أي صف يفتح نموذج التعديل مباشرة',
    category: 'table'
  },
  {
    keys: ['زر الفأرة الأيمن'],
    description: 'فتح القائمة السياقية السريعة (تعديل، نسخ، ملاحظة سريعة، مأذونية)',
    category: 'table'
  },

  // Forms & Entry
  {
    keys: ['Esc', 'أو', 'Alt', 'X'],
    description: 'العودة فوراً من ورقة التدقيق والمراجعة إلى جدول البيانات دون لمس الفأرة',
    category: 'forms',
    badge: 'خروج آمن'
  },
  {
    keys: ['↓', 'أو', 'PageDown'],
    description: 'التنقل السريع للشارع التالي في ورقة التدقيق والمراجعة المتتالية بالترقيم',
    category: 'forms',
    badge: 'تنقل بالأسهم'
  },
  {
    keys: ['↑', 'أو', 'PageUp'],
    description: 'التنقل السريع للشارع السابق في ورقة التدقيق والمراجعة المتتالية بالترقيم',
    category: 'forms',
    badge: 'تنقل بالأسهم'
  },
  {
    keys: ['Ctrl', 'G', 'أو', 'Alt', 'J'],
    description: 'التركيز المباشر على مربع الانتقال والقفز برقم التسلسل أو الحرف',
    category: 'forms',
    badge: 'قفز مباشر'
  },
  {
    keys: ['Alt', 'N'],
    description: 'الانتقال للشارع التالي رقمياً في ورقة التدقيق المتتالية',
    category: 'forms'
  },
  {
    keys: ['Alt', 'P'],
    description: 'الانتقال للشارع السابق رقمياً في ورقة التدقيق المتتالية',
    category: 'forms'
  },
  {
    keys: ['Alt', 'B'],
    description: 'العودة لآخر شارع تمت زيارته مسبقاً (سجل التنقل التاريخي)',
    category: 'forms'
  },
  {
    keys: ['Ctrl', 'N'],
    description: 'فتح نموذج إضافة شارع أو حارة جديدة فوراً',
    category: 'forms',
    badge: 'إدخال'
  },
  {
    keys: ['Ctrl', 'Enter'],
    description: 'حفظ الشارع الجاري وإغلاق النموذج فوراً',
    category: 'forms',
    badge: 'حفظ'
  },
  {
    keys: ['Ctrl', 'Shift', 'Enter'],
    description: 'حفظ الشارع والانتقال مباشرة لإضافة شارع جديد متتالي',
    category: 'forms'
  },
  {
    keys: ['Tab'],
    description: 'الانتقال التلقائي بين حقول النموذج (الاسم -> المأذونية -> الملاحظات)',
    category: 'forms'
  },

  // Data & Quick Tools
  {
    keys: ['Ctrl', 'Shift', 'F'],
    description: 'فتح أداة التعبئة والضبط السريع للمأذونيات والملاحظات الفارغة',
    category: 'data',
    badge: 'إنتاجية'
  },
  {
    keys: ['Ctrl', 'P'],
    description: 'فتح تقرير الطباعة ومعاينة PDF المجهزة',
    category: 'data'
  },
  {
    keys: ['Ctrl', 'E'],
    description: 'تصدير سريع لملف Excel لكافة السجلات الحالية',
    category: 'data'
  },
  {
    keys: ['Ctrl', 'B'],
    description: 'فتح نافذة إدخال قائمة شوارع متعددة دفعة واحدة',
    category: 'data'
  }
];

export function KeyboardHelpModal({ isOpen, onClose }: KeyboardHelpModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'table' | 'forms' | 'global' | 'data'>('all');

  if (!isOpen) return null;

  const filteredShortcuts = SHORTCUTS_DATA.filter(item => {
    const matchCat = activeCategory === 'all' || item.category === activeCategory;
    const matchSearch = searchQuery.trim() === '' || 
      item.description.includes(searchQuery.trim()) ||
      item.keys.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-gray-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-l from-gray-900 via-gray-800 to-gray-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-2xl shadow-inner">
              <Keyboard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  لوحة التعليمات ودليل الاختصارات السريعة
                </h3>
                <span className="px-2 py-0.5 bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 rounded-lg text-[11px] font-black">
                  مفتاح F1
                </span>
              </div>
              <p className="text-xs text-gray-300 font-medium">
                دليل كامل للتحكم السريع في الجدول، إدارة النماذج، والعمليات بإنتاجية فائقة
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white rounded-xl hover:bg-white/10 transition cursor-pointer"
            title="إغلاق (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Categories Bar */}
        <div className="p-4 bg-gray-50 border-b border-gray-200 space-y-3 shrink-0">
          
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن اختصار أو وظيفة (مثال: بحث، تعديل، حفظ، تراجع، إضافة)..."
              className="w-full pr-10 pl-4 py-2 bg-white border border-gray-300 rounded-xl text-xs font-semibold text-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
            {[
              { id: 'all', label: 'كافة الاختصارات' },
              { id: 'table', label: 'التنقل في الجدول والسطور' },
              { id: 'forms', label: 'النماذج والإدخال' },
              { id: 'data', label: 'البيانات والأدوات السريعة' },
              { id: 'global', label: 'التحكم العام' },
            ].map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-xl transition cursor-pointer text-xs ${
                  activeCategory === cat.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white hover:bg-gray-200 text-gray-700 border border-gray-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

        </div>

        {/* Shortcuts List */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-2.5">
          {filteredShortcuts.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-xs font-semibold">
              لم يتم العثور على اختصارات تطابق بحثك
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredShortcuts.map((item, idx) => (
                <div 
                  key={idx}
                  className="p-3 bg-gray-50/80 hover:bg-white rounded-2xl border border-gray-200 hover:border-emerald-300 hover:shadow-xs transition flex items-center justify-between gap-3"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-black text-gray-900">
                        {item.description}
                      </span>
                      {item.badge && (
                        <span className="px-1.5 py-0.2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-[10px] font-bold">
                          {item.badge}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Keys Badges */}
                  <div className="flex items-center gap-1 shrink-0 font-mono" dir="ltr">
                    {item.keys.map((k, kIdx) => (
                      <React.Fragment key={kIdx}>
                        <kbd className="px-2.5 py-1 bg-white border border-gray-300 rounded-lg text-xs font-black text-gray-800 shadow-2xs">
                          {k}
                        </kbd>
                        {kIdx < item.keys.length - 1 && (
                          <span className="text-gray-400 text-xs font-bold">+</span>
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Quick Tips Section */}
          <div className="mt-4 p-4 bg-gradient-to-l from-emerald-50 via-teal-50 to-white rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-2">
            <div className="flex items-center gap-2 font-black text-xs">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>نصائح الإنتاجية المريحة:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-emerald-900 font-medium leading-relaxed pr-1">
              <li>
                <strong>مساحة العمل الصافية:</strong> يمكنك إخفاء أو إظهار الأشرطة والأدوات غير المستخدمة من صفحة الإعدادات لتبقى مساحة التحرير صافية 100%.
              </li>
              <li>
                <strong>القائمة الجانبية:</strong> استخدم <kbd className="bg-white px-1.5 py-0.5 rounded border border-emerald-300 font-mono text-[10px]">Alt+S</kbd> لفتح القائمة الجانبية للفرز والتنقل دون استهلاك مساحة رأسية في الجدول.
              </li>
              <li>
                <strong>التعبئة التلقائية الذكية:</strong> زر التعبئة السريعة يقوم بنسخ المأذونيات للشوارع المتطابقة في خطوة واحدة.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={downloadSystemFeaturesMarkdown}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
              title="تحميل الدليل الشامل لجميع مميزات وإمكانيات المنظومة الفائقة بصيغة Markdown (.md)"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>تحميل دليل المميزات (Markdown .md)</span>
              <Download className="w-3 h-3 text-emerald-200" />
            </button>
            <span className="text-xs text-gray-500 font-medium hidden sm:inline">
              اضغط <kbd className="bg-white px-1.5 py-0.5 rounded border text-[11px] font-mono font-bold">Esc</kbd> للإغلاق
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
          >
            إغلاق التعليمات
          </button>
        </div>

      </div>
    </div>
  );
}
