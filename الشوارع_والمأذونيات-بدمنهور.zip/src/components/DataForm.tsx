import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  X, 
  AlertTriangle, 
  CheckCircle2, 
  Save, 
  ChevronRight, 
  ChevronLeft, 
  Search, 
  ChevronsRight, 
  ChevronsLeft, 
  History, 
  SlidersHorizontal, 
  FileCheck2, 
  FileText,
  MapPin, 
  Sparkles, 
  Tag, 
  User, 
  Clock, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  RotateCcw, 
  FolderPlus, 
  LogOut, 
  ArrowLeft, 
  ArrowRight, 
  Building2, 
  Compass, 
  Hash, 
  Type, 
  Zap, 
  Loader2, 
  Sliders, 
  Check, 
  Eye, 
  Keyboard,
  Lock,
  Unlock,
  ShieldAlert,
  Layers,
  FileSearch,
  GitMerge,
  ListPlus,
  Eraser,
  Scissors,
  ArrowDownAZ
} from 'lucide-react';
import { 
  RecordItem, 
  ThemeType, 
  AppSettings, 
  RecordStatus,
  DEFAULT_STREET_CATEGORIES,
  DEFAULT_UNOFFICIAL_SUBTYPES,
  OFFICIAL_SEVEN_NOTARIZATIONS
} from '../types';
import { normalizeArabicText } from '../utils/arabicEncoding';
import { ArabicUtils } from '../utils/arabicUtils';
import { SimilarityEngine } from '../utils/similarityEngine';
import { extractStreetRootName } from '../utils/streetSimilarity';
import { OFFICIAL_DISTRICTS } from '../utils/districtColors';
import { getAuditUserName, setAuditUserName } from '../utils/auditLogger';
import { 
  getAllAvailablePrefixes, 
  addCustomPrefix, 
  removeCustomPrefix, 
  resetCustomPrefixes, 
  getCustomPrefixes, 
  DEFAULT_STREET_PREFIXES, 
  parseStreetPrefixAndName, 
  isOfficialNotarization 
} from '../utils/streetSplitter';
import { AuditLogModal } from './AuditLogModal';

interface DataFormProps {
  onClose: () => void;
  onSave: (record: Omit<RecordItem, 'id'>, editId?: string, isAutoSave?: boolean) => void;
  onSaveBulk?: (records: Omit<RecordItem, 'id'>[], strategy?: 'merge' | 'skip' | 'separate') => void;
  existingRecords: RecordItem[];
  editRecord?: RecordItem | null;
  theme: ThemeType;
  settings?: AppSettings;
  onUpdateSettings?: (newSettings: AppSettings) => void;
  onOpenSimilarModal?: (rootName?: string) => void;
  onOpenUnderReviewPage?: () => void;
}

const ARABIC_ALPHABET = [
  'أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 
  'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 
  'ق', 'ك', 'ل', 'م', 'ن', 'هـ', 'و', 'ي'
];

export const DataForm: React.FC<DataFormProps> = ({
  onClose,
  onSave,
  onSaveBulk,
  existingRecords,
  editRecord,
  theme,
  settings,
  onUpdateSettings,
  onOpenSimilarModal,
  onOpenUnderReviewPage
}) => {
  const totalCount = existingRecords.length;

  // Current index for sequential number-based navigation (0-indexed)
  const [currentIndex, setCurrentIndex] = useState<number>(() => {
    if (editRecord && existingRecords.length > 0) {
      const idx = existingRecords.findIndex(r => r.id === editRecord.id);
      return idx >= 0 ? idx : 0;
    }
    return 0;
  });

  // Tracked Record ID being edited to guarantee save operations never target the wrong record
  const [currentRecordId, setCurrentRecordId] = useState<string | null>(() => editRecord ? editRecord.id : null);

  const [isAuditMode, setIsAuditMode] = useState<boolean>(() => Boolean(editRecord));

  // History stack to answer "كيف أعود للشارع؟" - remembers previous visited index
  const [visitedHistory, setVisitedHistory] = useState<number[]>([]);

  // After a save the records are re-sorted alphabetically, so index-based navigation
  // becomes stale. We navigate by record ID instead via this pending target.
  const [pendingNavId, setPendingNavId] = useState<string | null>(null);

  // Unified jump input for jumping directly by serial number or letter (e.g. 50 or "س")
  const [jumpInput, setJumpInput] = useState<string>('');
  const jumpInputRef = useRef<HTMLInputElement>(null);

  // Quick street search autocomplete for 3000+ streets without lag
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const searchDropdownRef = useRef<HTMLDivElement>(null);

  // Notifications
  const [notification, setNotification] = useState<string | null>(null);

  // Auto-Save System State
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(() => settings?.auditAutoSave ?? true);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [lastAutoSavedTime, setLastAutoSavedTime] = useState<string | null>(null);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isInitialLoadRef = useRef<boolean>(true);

  // Prefixes Management in Clean Side Drawer (تقليل التشتت البصري عبر إخفاء خيارات إضافة البادئات المعقدة في قائمة جانبية)
  const [prefixesList, setPrefixesList] = useState<string[]>(() => getAllAvailablePrefixes());
  const [isPrefixDrawerOpen, setIsPrefixDrawerOpen] = useState<boolean>(false);
  const [newPrefixInput, setNewPrefixInput] = useState<string>('');
  const [prefixSearchFilter, setPrefixSearchFilter] = useState<string>('');

  // Form Fields
  const [name, setName] = useState('');
  const [prefix, setPrefix] = useState('شارع');
  const [permissionType, setPermissionType] = useState('مأذونية رسمية');
  const [officialRegion, setOfficialRegion] = useState('شبرا بحري');
  
  // Unofficial permission sub-fields & Flexible Sources
  const [unofficialSubType, setUnofficialSubType] = useState('داتا خاصة');
  const [suggestedRegion, setSuggestedRegion] = useState('');
  const [unofficialDefinition, setUnofficialDefinition] = useState('');
  const [contractNumber, setContractNumber] = useState('');
  const [contractDate, setContractDate] = useState('');
  const [nationalIdRef, setNationalIdRef] = useState('');
  const [mapType, setMapType] = useState('');
  const [mapSheetNo, setMapSheetNo] = useState('');
  const [mapScale, setMapScale] = useState('');

  // 1. Notary Data (مأذونية محددة / دفاتر مأذون)
  const [notaryName, setNotaryName] = useState('');
  const [notaryBookNo, setNotaryBookNo] = useState('');
  const [notaryDeedNo, setNotaryDeedNo] = useState('');
  const [notaryDate, setNotaryDate] = useState('');

  // 2. Bailiffs / Process Servers (محضرين / إعلانات قضائية)
  const [bailiffReportNo, setBailiffReportNo] = useState('');
  const [bailiffCourt, setBailiffCourt] = useState('');
  const [bailiffName, setBailiffName] = useState('');
  const [bailiffDate, setBailiffDate] = useState('');
  const [bailiffCircuit, setBailiffCircuit] = useState('');

  // 3. Real Estate Registry & Survey (شهر عقاري / توثيق / سجل عيني)
  const [registryDocNo, setRegistryDocNo] = useState('');
  const [registryOffice, setRegistryOffice] = useState('');
  const [cadastralParcelNo, setCadastralParcelNo] = useState('');

  // 4. Real Estate Tax (ضرائب عقارية / عوائد)
  const [taxPropertyNo, setTaxPropertyNo] = useState('');
  const [taxDistrict, setTaxDistrict] = useState('');

  // 5. Courts & Litigation (محاكم وقضايا)
  const [courtCaseNo, setCourtCaseNo] = useState('');
  const [courtYear, setCourtYear] = useState('');
  const [courtName, setCourtName] = useState('');

  // 6. Custom Source (مصدر مخصص)
  const [customSourceName, setCustomSourceName] = useState('');

  const [metadata, setMetadata] = useState('');
  const [category, setCategory] = useState('شارع');
  const [status, setStatus] = useState<RecordStatus>(() => {
    if (editRecord) return editRecord.status || 'نشط';
    return settings?.autoPrecautionUnderReview ? 'قيد المراجعة' : 'نشط';
  });
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [isTruthRecord, setIsTruthRecord] = useState<boolean>(false);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [matchedDuplicateRecord, setMatchedDuplicateRecord] = useState<RecordItem | null>(null);
  const [matchedDuplicateSimilarity, setMatchedDuplicateSimilarity] = useState<number>(0);
  const [matchedDuplicateReason, setMatchedDuplicateReason] = useState<string>('');

  // Audit Log & LocalStorage Auditor State
  const [auditorName, setAuditorName] = useState<string>(() => getAuditUserName());
  const [isEditingAuditor, setIsEditingAuditor] = useState<boolean>(false);
  const [tempAuditor, setTempAuditor] = useState<string>(() => getAuditUserName());
  const [savedAuditorToast, setSavedAuditorToast] = useState<boolean>(false);
  const [showAuditModal, setShowAuditModal] = useState<boolean>(false);

  // Dynamic Lists from AppSettings
  const officialRegionsList = useMemo(() => {
    return settings?.suggestedOfficialNotarizations && settings.suggestedOfficialNotarizations.length > 0
      ? settings.suggestedOfficialNotarizations
      : Array.from(OFFICIAL_SEVEN_NOTARIZATIONS);
  }, [settings?.suggestedOfficialNotarizations]);

  const streetCategoriesList = useMemo(() => {
    return settings?.customStreetCategories && settings.customStreetCategories.length > 0
      ? settings.customStreetCategories
      : Array.from(DEFAULT_STREET_CATEGORIES);
  }, [settings?.customStreetCategories]);

  const unofficialSubTypesList = useMemo(() => {
    return settings?.customUnofficialSubTypes && settings.customUnofficialSubTypes.length > 0
      ? settings.customUnofficialSubTypes
      : Array.from(DEFAULT_UNOFFICIAL_SUBTYPES);
  }, [settings?.customUnofficialSubTypes]);

  const officialDistricts = [
    'شبرا_1',
    'شبرا_2',
    'شبرا_3',
    'قرطسا',
    'نقرها أول',
    'إفلاقة',
    'ابو الريش'
  ];

  const [selectedDistrict, setSelectedDistrict] = useState('شبرا_1');
  const [customDistrict, setCustomDistrict] = useState('');

  // Batch List Entry for Specific Notary State & Processing
  const [formEntryMode, setFormEntryMode] = useState<'single' | 'batch_list'>('single');
  const [batchRawText, setBatchRawText] = useState<string>('');
  const [batchDuplicateStrategy, setBatchDuplicateStrategy] = useState<'merge' | 'skip' | 'separate'>('merge');

  // Street Name Dynamic Autocomplete State
  const [isNameAutocompleteOpen, setIsNameAutocompleteOpen] = useState<boolean>(false);
  const [selectedSuggestionIdx, setSelectedSuggestionIdx] = useState<number>(-1);
  const nameInputContainerRef = useRef<HTMLDivElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  // Alphabetical Index Mapping for fast jumps by Arabic letter
  const alphabetNavigation = useMemo(() => {
    const firstIndexMap = new Map<string, number>();
    const countMap = new Map<string, number>();

    ARABIC_ALPHABET.forEach(letter => {
      countMap.set(letter, 0);
    });

    existingRecords.forEach((r, idx) => {
      const parsed = parseStreetPrefixAndName(r.name, r.category);
      const clean = parsed.cleanName.trim();
      if (!clean) return;

      let firstChar = clean.charAt(0);
      if (['ا', 'أ', 'إ', 'آ'].includes(firstChar)) {
        firstChar = 'أ';
      } else if (firstChar === 'ه') {
        firstChar = 'هـ';
      }

      if (countMap.has(firstChar)) {
        countMap.set(firstChar, (countMap.get(firstChar) || 0) + 1);
        if (!firstIndexMap.has(firstChar)) {
          firstIndexMap.set(firstChar, idx);
        }
      }
    });

    return { firstIndexMap, countMap };
  }, [existingRecords]);

  // Active letter of the current viewed street
  const currentActiveLetter = useMemo(() => {
    const rec = isAuditMode && existingRecords[currentIndex] ? existingRecords[currentIndex] : editRecord;
    if (!rec) return null;
    const parsed = parseStreetPrefixAndName(rec.name, rec.category);
    const clean = parsed.cleanName.trim();
    if (!clean) return null;
    let firstChar = clean.charAt(0);
    if (['ا', 'أ', 'إ', 'آ'].includes(firstChar)) return 'أ';
    if (firstChar === 'ه') return 'هـ';
    return firstChar;
  }, [isAuditMode, existingRecords, currentIndex, editRecord]);

  // Build unique street dictionary from existing records with metadata & permissions
  const uniqueStreetDictionary = useMemo(() => {
    const map = new Map<string, {
      baseName: string;
      fullName: string;
      prefix: string;
      category: string;
      permissions: string[];
      count: number;
    }>();

    existingRecords.forEach(r => {
      let clean = r.name.trim();
      let detectedPrefix = '';
      const matched = prefixesList.find(p => clean.startsWith(p + ' '));
      if (matched) {
        detectedPrefix = matched;
        clean = clean.slice(matched.length + 1).trim();
      }
      if (!clean) clean = r.name.trim();

      const normalized = normalizeArabicText(clean);
      if (!normalized) return;

      if (!map.has(normalized)) {
        map.set(normalized, {
          baseName: clean,
          fullName: r.name,
          prefix: detectedPrefix || r.category || 'شارع',
          category: r.category || 'شارع',
          permissions: r.permission ? [r.permission] : [],
          count: 1
        });
      } else {
        const entry = map.get(normalized)!;
        entry.count += 1;
        if (r.permission && !entry.permissions.includes(r.permission)) {
          entry.permissions.push(r.permission);
        }
      }
    });

    return Array.from(map.values());
  }, [existingRecords, prefixesList]);

  // Dynamic filter for suggestions as user types
  const nameSuggestions = useMemo(() => {
    const query = normalizeArabicText(name.trim());
    if (!query || query.length < 1) return [];

    const matched = uniqueStreetDictionary.filter(item => {
      const itemNorm = normalizeArabicText(item.baseName);
      const fullNorm = normalizeArabicText(item.fullName);
      return itemNorm.includes(query) || fullNorm.includes(query);
    });

    matched.sort((a, b) => {
      const aNorm = normalizeArabicText(a.baseName);
      const bNorm = normalizeArabicText(b.baseName);
      const aStarts = aNorm.startsWith(query);
      const bStarts = bNorm.startsWith(query);
      if (aStarts && !bStarts) return -1;
      if (!aStarts && bStarts) return 1;
      return b.count - a.count;
    });

    return matched.slice(0, 10);
  }, [name, uniqueStreetDictionary]);

  // Close autocomplete on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (nameInputContainerRef.current && !nameInputContainerRef.current.contains(e.target as Node)) {
        setIsNameAutocompleteOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle selecting an autocomplete suggestion
  const handleSelectSuggestion = (sug: typeof uniqueStreetDictionary[0]) => {
    setName(sug.baseName);
    if (sug.prefix && prefixesList.includes(sug.prefix)) {
      setPrefix(sug.prefix);
    }
    if (sug.category) {
      setCategory(sug.category);
    }
    setIsNameAutocompleteOpen(false);
    setSelectedSuggestionIdx(-1);
    if (nameInputRef.current) {
      nameInputRef.current.focus();
    }
  };

  // Keyboard navigation for autocomplete list
  const handleNameInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isNameAutocompleteOpen || nameSuggestions.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedSuggestionIdx(prev => (prev < nameSuggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedSuggestionIdx(prev => (prev > 0 ? prev - 1 : nameSuggestions.length - 1));
    } else if (e.key === 'Enter') {
      if (selectedSuggestionIdx >= 0 && selectedSuggestionIdx < nameSuggestions.length) {
        e.preventDefault();
        handleSelectSuggestion(nameSuggestions[selectedSuggestionIdx]);
      }
    } else if (e.key === 'Escape') {
      setIsNameAutocompleteOpen(false);
      setSelectedSuggestionIdx(-1);
    }
  };

  // Helper to cleanly strip structured tags from free-form notes to avoid duplication
  const cleanMetadataNotes = useCallback((metaStr: string): string => {
    if (!metaStr) return '';
    return metaStr
      .replace(/\[نوع غير رسمي:\s*[^\]]+\]/g, '')
      .replace(/\[مأذونية مقترحة:\s*[^\]]+\]/g, '')
      .replace(/التعريف:[^|\n-]+/g, '')
      .replace(/اسم المأذون:[^|\n-]+/g, '')
      .replace(/رقم الدفتر:[^|\n-]+/g, '')
      .replace(/رقم الإشهاد:[^|\n-]+/g, '')
      .replace(/تاريخ الإشهاد:[^|\n-]+/g, '')
      .replace(/رقم المحضر:[^|\n-]+/g, '')
      .replace(/المحكمة:[^|\n-]+/g, '')
      .replace(/اسم المحضر:[^|\n-]+/g, '')
      .replace(/تاريخ الإعلان:[^|\n-]+/g, '')
      .replace(/الدائرة:[^|\n-]+/g, '')
      .replace(/رقم التوثيق:[^|\n-]+/g, '')
      .replace(/مكتب التوثيق:[^|\n-]+/g, '')
      .replace(/رقم القطعة\/الحوض:[^|\n-]+/g, '')
      .replace(/رقم العقار\/المكلفة:[^|\n-]+/g, '')
      .replace(/الشياخة\/المأمورية:[^|\n-]+/g, '')
      .replace(/رقم القضية:[^|\n-]+/g, '')
      .replace(/السنة القضائية:[^|\n-]+/g, '')
      .replace(/المحكمة\/الدائرة:[^|\n-]+/g, '')
      .replace(/رقم اللوحة:[^|\n-]+/g, '')
      .replace(/مقياس الرسم:[^|\n-]+/g, '')
      .replace(/المصدر المخصص:[^|\n-]+/g, '')
      .replace(/رقم العقد:[^|\n-]+/g, '')
      .replace(/التاريخ:[^|\n-]+/g, '')
      .replace(/الرقم القومي(\s*المرجع)?:[^|\n-]+/g, '')
      .replace(/نوع الخرائط:[^|\n-]+/g, '')
      .replace(/^[|\s-]+|[|\s-]+$/g, '')
      .trim();
  }, []);

  // Reset all form fields to defaults for a fresh "add new" entry
  const resetFormFields = useCallback(() => {
    setName('');
    setPrefix('شارع');
    setPermissionType('مأذونية رسمية');
    setOfficialRegion(officialRegionsList[0] || 'شبرا بحري');
    setUnofficialSubType(unofficialSubTypesList[0] || 'داتا خاصة');
    setSuggestedRegion('');
    setUnofficialDefinition('');
    setContractNumber('');
    setContractDate('');
    setNationalIdRef('');
    setMapType('');
    setMapSheetNo('');
    setMapScale('');
    setNotaryName('');
    setNotaryBookNo('');
    setNotaryDeedNo('');
    setNotaryDate('');
    setBailiffReportNo('');
    setBailiffCourt('');
    setBailiffName('');
    setBailiffDate('');
    setBailiffCircuit('');
    setRegistryDocNo('');
    setRegistryOffice('');
    setCadastralParcelNo('');
    setTaxPropertyNo('');
    setTaxDistrict('');
    setCourtCaseNo('');
    setCourtYear('');
    setCourtName('');
    setCustomSourceName('');
    setMetadata('');
    setCategory(streetCategoriesList[0] || 'شارع');
    setSelectedDistrict('شبرا_1');
    setCustomDistrict('');
    setStatus(settings?.autoPrecautionUnderReview ? 'قيد المراجعة' : 'نشط');
    setIsLocked(false);
    setIsTruthRecord(false);
    setDuplicateWarning(null);
  }, [officialRegionsList, unofficialSubTypesList, streetCategoriesList, settings?.autoPrecautionUnderReview]);

  // Load record data into form fields
  const loadRecordData = useCallback((rec: RecordItem) => {
    if (!rec) return;

    setCurrentRecordId(rec.id);
    isInitialLoadRef.current = true;

    // Load status & ground truth lock
    const recStatus = rec.status || (rec.isTruthRecord ? 'تام' : 'نشط');
    const recLocked = Boolean(rec.isLocked || rec.status === 'تام' || rec.isTruthRecord);
    const recTruth = Boolean(rec.isTruthRecord || rec.status === 'تام');
    setStatus(recStatus);
    setIsLocked(recLocked);
    setIsTruthRecord(recTruth);

    // Reset all sub-fields to avoid stale values leaking between records
    setUnofficialSubType('داتا خاصة');
    setSuggestedRegion('');
    setUnofficialDefinition('');
    setContractNumber('');
    setContractDate('');
    setNationalIdRef('');
    setMapType('');
    setMapSheetNo('');
    setMapScale('');
    setNotaryName('');
    setNotaryBookNo('');
    setNotaryDeedNo('');
    setNotaryDate('');
    setBailiffReportNo('');
    setBailiffCourt('');
    setBailiffName('');
    setBailiffDate('');
    setBailiffCircuit('');
    setRegistryDocNo('');
    setRegistryOffice('');
    setCadastralParcelNo('');
    setTaxPropertyNo('');
    setTaxDistrict('');
    setCourtCaseNo('');
    setCourtYear('');
    setCourtName('');
    setCustomSourceName('');

    // Extract prefix if available
    const parsed = parseStreetPrefixAndName(rec.name, rec.category);
    if (parsed.hasPrefix && parsed.prefix && prefixesList.includes(parsed.prefix)) {
      setPrefix(parsed.prefix);
      setName(parsed.cleanName);
    } else {
      const matchedPrefix = prefixesList.find(p => rec.name.trim().startsWith(p + ' '));
      if (matchedPrefix) {
        setPrefix(matchedPrefix);
        setName(rec.name.trim().slice(matchedPrefix.length + 1));
      } else {
        setPrefix('');
        setName(rec.name);
      }
    }

    setCategory(rec.category || parsed.detectedType || 'شارع');

    if (rec.category === 'حي') {
      setPermissionType('مأذونية رسمية');
      setOfficialRegion(officialRegionsList[0] || 'شبرا بحري');
      if (officialDistricts.includes(rec.permission)) {
        setSelectedDistrict(rec.permission);
        setCustomDistrict('');
      } else {
        setSelectedDistrict('CUSTOM');
        setCustomDistrict(rec.permission);
      }
      setMetadata(rec.metadata || '');
    } else if (officialRegionsList.includes(rec.permission)) {
      setPermissionType('مأذونية رسمية');
      setOfficialRegion(rec.permission);
      setMetadata(rec.metadata || '');
    } else if (rec.permission.includes('رسمية')) {
      setPermissionType('مأذونية رسمية');
      setOfficialRegion(officialRegionsList[0] || 'شبرا بحري');
      setMetadata(rec.metadata || '');
    } else if (rec.permission.includes('غير رسمي') || (rec.metadata && rec.metadata.includes('[نوع غير رسمي:'))) {
      setPermissionType('مأذونية غير رسمي');
      const meta = rec.metadata || '';
      const typeMatch = meta.match(/\[نوع غير رسمي:\s*([^\]]+)\]/);
      if (typeMatch) {
        setUnofficialSubType(typeMatch[1].trim());
      }
      const suggMatch = meta.match(/\[مأذونية مقترحة:\s*([^\]]+)\]/);
      if (suggMatch) {
        setSuggestedRegion(suggMatch[1].trim());
      }
      const defMatch = meta.match(/التعريف:\s*([^|\n-]+)/);
      if (defMatch) setUnofficialDefinition(defMatch[1].trim());

      const contractMatch = meta.match(/رقم العقد:\s*([^|\n-]+)/);
      if (contractMatch) setContractNumber(contractMatch[1].trim());

      const dateMatch = meta.match(/التاريخ:\s*([^|\n-]+)/);
      if (dateMatch) setContractDate(dateMatch[1].trim());

      const natMatch = meta.match(/الرقم القومي(\s*المرجع)?:\s*([^|\n-]+)/);
      if (natMatch) setNationalIdRef(natMatch[2]?.trim() || natMatch[1]?.trim() || '');

      const mapMatch = meta.match(/نوع الخرائط:\s*([^|\n-]+)/);
      if (mapMatch) setMapType(mapMatch[1].trim());

      const mapSheetMatch = meta.match(/رقم اللوحة:\s*([^|\n-]+)/);
      if (mapSheetMatch) setMapSheetNo(mapSheetMatch[1].trim());

      const mapScaleMatch = meta.match(/مقياس الرسم:\s*([^|\n-]+)/);
      if (mapScaleMatch) setMapScale(mapScaleMatch[1].trim());

      // Notary
      const notaryNameMatch = meta.match(/اسم المأذون:\s*([^|\n-]+)/);
      if (notaryNameMatch) setNotaryName(notaryNameMatch[1].trim());

      const notaryBookMatch = meta.match(/رقم الدفتر:\s*([^|\n-]+)/);
      if (notaryBookMatch) setNotaryBookNo(notaryBookMatch[1].trim());

      const notaryDeedMatch = meta.match(/رقم الإشهاد:\s*([^|\n-]+)/);
      if (notaryDeedMatch) setNotaryDeedNo(notaryDeedMatch[1].trim());

      const notaryDateMatch = meta.match(/تاريخ الإشهاد:\s*([^|\n-]+)/);
      if (notaryDateMatch) setNotaryDate(notaryDateMatch[1].trim());

      // Bailiff
      const bailiffRepMatch = meta.match(/رقم المحضر:\s*([^|\n-]+)/);
      if (bailiffRepMatch) setBailiffReportNo(bailiffRepMatch[1].trim());

      const bailiffCourtMatch = meta.match(/المحكمة:\s*([^|\n-]+)/);
      if (bailiffCourtMatch) setBailiffCourt(bailiffCourtMatch[1].trim());

      const bailiffNameMatch = meta.match(/اسم المحضر:\s*([^|\n-]+)/);
      if (bailiffNameMatch) setBailiffName(bailiffNameMatch[1].trim());

      const bailiffDateMatch = meta.match(/تاريخ الإعلان:\s*([^|\n-]+)/);
      if (bailiffDateMatch) setBailiffDate(bailiffDateMatch[1].trim());

      const bailiffCircMatch = meta.match(/الدائرة:\s*([^|\n-]+)/);
      if (bailiffCircMatch) setBailiffCircuit(bailiffCircMatch[1].trim());

      // Real Estate Registry
      const regDocMatch = meta.match(/رقم التوثيق:\s*([^|\n-]+)/);
      if (regDocMatch) setRegistryDocNo(regDocMatch[1].trim());

      const regOffMatch = meta.match(/مكتب التوثيق:\s*([^|\n-]+)/);
      if (regOffMatch) setRegistryOffice(regOffMatch[1].trim());

      const cadMatch = meta.match(/رقم القطعة\/الحوض:\s*([^|\n-]+)/);
      if (cadMatch) setCadastralParcelNo(cadMatch[1].trim());

      // Real Estate Tax
      const taxPropMatch = meta.match(/رقم العقار\/المكلفة:\s*([^|\n-]+)/);
      if (taxPropMatch) setTaxPropertyNo(taxPropMatch[1].trim());

      const taxDistMatch = meta.match(/الشياخة\/المأمورية:\s*([^|\n-]+)/);
      if (taxDistMatch) setTaxDistrict(taxDistMatch[1].trim());

      // Courts
      const courtCaseMatch = meta.match(/رقم القضية:\s*([^|\n-]+)/);
      if (courtCaseMatch) setCourtCaseNo(courtCaseMatch[1].trim());

      const courtYrMatch = meta.match(/السنة القضائية:\s*([^|\n-]+)/);
      if (courtYrMatch) setCourtYear(courtYrMatch[1].trim());

      const courtNmMatch = meta.match(/المحكمة\/الدائرة:\s*([^|\n-]+)/);
      if (courtNmMatch) setCourtName(courtNmMatch[1].trim());

      // Custom Source
      const customSrcMatch = meta.match(/المصدر المخصص:\s*([^|\n-]+)/);
      if (customSrcMatch) setCustomSourceName(customSrcMatch[1].trim());

      setMetadata(cleanMetadataNotes(meta));
    } else {
      setPermissionType(rec.permission || 'غير محدد');
      setMetadata(rec.metadata || '');
    }

    setTimeout(() => {
      isInitialLoadRef.current = false;
    }, 100);
  }, [prefixesList, officialRegionsList, officialDistricts, cleanMetadataNotes]);

  // Synchronize jumpInput with currentIndex
  useEffect(() => {
    if (isAuditMode && totalCount > 0) {
      setJumpInput(String(currentIndex + 1));
    }
  }, [currentIndex, isAuditMode, totalCount]);

  // Initial load ref guards to prevent form reset when saving records
  const hasInitializedRef = useRef<boolean>(false);
  const prevEditRecordIdRef = useRef<string | undefined>(editRecord?.id);

  // Initial load
  useEffect(() => {
    if (hasInitializedRef.current && prevEditRecordIdRef.current === editRecord?.id) {
      return;
    }
    hasInitializedRef.current = true;
    prevEditRecordIdRef.current = editRecord?.id;

    if (editRecord) {
      setIsAuditMode(true);
      setCurrentRecordId(editRecord.id);
      const idx = existingRecords.findIndex(r => r.id === editRecord.id);
      if (idx >= 0) {
        setCurrentIndex(idx);
        loadRecordData(editRecord);
      } else {
        loadRecordData(editRecord);
      }
    } else if (existingRecords.length > 0 && isAuditMode) {
      setCurrentRecordId(existingRecords[0].id);
      loadRecordData(existingRecords[0]);
    } else {
      setCurrentRecordId(null);
      resetFormFields();
    }
    setDuplicateWarning(null);
  }, [editRecord, loadRecordData, isAuditMode, existingRecords, resetFormFields]);

  // After a save the records are re-sorted alphabetically, so navigate by record ID
  useEffect(() => {
    if (!pendingNavId) return;
    const idx = existingRecords.findIndex(r => r.id === pendingNavId);
    if (idx >= 0) {
      setCurrentIndex(idx);
      setCurrentRecordId(existingRecords[idx].id);
      loadRecordData(existingRecords[idx]);
    }
    setPendingNavId(null);
  }, [existingRecords, pendingNavId, loadRecordData]);

  // Active record
  const activeRecord = isAuditMode && totalCount > 0 ? existingRecords[currentIndex] : editRecord;

  // Previous visited record for "كيف أعود للشارع؟"
  const previousVisitedIndex = visitedHistory.length > 0 ? visitedHistory[visitedHistory.length - 1] : null;
  const previousVisitedRecord = previousVisitedIndex !== null && existingRecords[previousVisitedIndex] 
    ? existingRecords[previousVisitedIndex] 
    : null;

  // Smart Duplicate & High Similarity Detection
  useEffect(() => {
    const rawName = name.trim();
    if (!rawName || rawName.length < 2) {
      setDuplicateWarning(null);
      setMatchedDuplicateRecord(null);
      setMatchedDuplicateSimilarity(0);
      setMatchedDuplicateReason('');
      return;
    }

    const trimmed = normalizeArabicText(rawName);
    const searchIncoming = ArabicUtils.normalizeForSearch(rawName);
    const rootIncoming = extractStreetRootName(rawName);

    // 1. Direct exact normalized match
    const exactMatch = existingRecords.find(
      r => normalizeArabicText(r.name) === trimmed && (!activeRecord || r.id !== activeRecord.id)
    );
    if (exactMatch) {
      const isFoundTruth = exactMatch.status === 'تام' || exactMatch.isLocked || exactMatch.isTruthRecord;
      setMatchedDuplicateRecord(exactMatch);
      setMatchedDuplicateSimilarity(1.0);
      setMatchedDuplicateReason('تطابق تام ومباشر في اسم الشارع');
      if (isFoundTruth) {
        setDuplicateWarning(`⭐ يتطابق مع «عنوان الحقيقة» المعتمد نهائياً: "${exactMatch.name}" (مأذونية: ${exactMatch.permission}) — بيان تام مغلق 🔒`);
      } else {
        setDuplicateWarning(`الشارع "${exactMatch.name}" مسجل بالفعل بالنظام (المأذونية: ${exactMatch.permission || 'غير محدد'})`);
      }
      return;
    }

    // 2. Search match (ignoring al-ta'rif, hamza variants, and spaces)
    const searchMatch = existingRecords.find(
      r => (!activeRecord || r.id !== activeRecord.id) && ArabicUtils.normalizeForSearch(r.name) === searchIncoming
    );
    if (searchMatch) {
      setMatchedDuplicateRecord(searchMatch);
      setMatchedDuplicateSimilarity(0.98);
      setMatchedDuplicateReason('تطابق مع اختلاف طفيف في الهمزات أو أل التعريف');
      setDuplicateWarning(`تطابق فائق مع الشارع المسجل "${searchMatch.name}" (المأذونية: ${searchMatch.permission || 'غير محدد'})`);
      return;
    }

    // 3. Root name match (without prefixes like شارع / حارة / عطفة / درب)
    if (rootIncoming && rootIncoming.length >= 3) {
      const rootMatch = existingRecords.find(
        r => (!activeRecord || r.id !== activeRecord.id) && extractStreetRootName(r.name) === rootIncoming
      );
      if (rootMatch) {
        setMatchedDuplicateRecord(rootMatch);
        setMatchedDuplicateSimilarity(0.92);
        setMatchedDuplicateReason(`تشابه في جذر الاسم («${rootIncoming}») مع اختلاف البادئة`);
        setDuplicateWarning(`تشابه في جذر التسمية مع الشارع المسجل "${rootMatch.name}" (المأذونية: ${rootMatch.permission || 'غير محدد'})`);
        return;
      }
    }

    // 4. Fuzzy similarity score >= 0.80
    let bestCandidate: RecordItem | null = null;
    let bestScore = 0;
    for (const r of existingRecords) {
      if (activeRecord && r.id === activeRecord.id) continue;
      const score = SimilarityEngine.calculateSimilarity(rawName, r.name);
      if (score > bestScore) {
        bestScore = score;
        bestCandidate = r;
      }
    }

    if (bestCandidate && bestScore >= 0.80) {
      setMatchedDuplicateRecord(bestCandidate);
      setMatchedDuplicateSimilarity(bestScore);
      setMatchedDuplicateReason(`تشابه عالي بنسبة ${Math.round(bestScore * 100)}%`);
      setDuplicateWarning(`مشابه جداً للشارع المسجل "${bestCandidate.name}" (المأذونية: ${bestCandidate.permission || 'غير محدد'})`);
      return;
    }

    setDuplicateWarning(null);
    setMatchedDuplicateRecord(null);
    setMatchedDuplicateSimilarity(0);
    setMatchedDuplicateReason('');
  }, [name, existingRecords, activeRecord]);

  // Quick Action Handlers for Duplicate/Similar Matches
  const handleOpenMatchedRecordInForm = (rec: RecordItem) => {
    const idx = existingRecords.findIndex(r => r.id === rec.id);
    if (idx >= 0) {
      setIsAuditMode(true);
      setCurrentIndex(idx);
      loadRecordData(existingRecords[idx]);
      setNotification(`✓ تم فتح السجل الحالي المسجل مسبقاً بالنظام: ("${rec.name}")`);
    } else {
      loadRecordData(rec);
    }
  };

  const handleQuickMergeIntoMatched = (rec: RecordItem) => {
    const { record } = buildCurrentRecord();
    const currentMeta = rec.metadata?.trim() || '';
    const incomingMeta = record.metadata?.trim() || metadata.trim();
    const merged = ArabicUtils.smartMergeNotes(currentMeta, incomingMeta);

    onSave({
      ...rec,
      metadata: merged
    }, rec.id);

    setNotification(`✓ تم بنجاح دمج الملاحظات في السجل الحالي: ("${rec.name}")`);
    resetFormFields();
  };

  // Safe navigation to any index by record number
  const navigateToIndex = useCallback((newIdx: number, recordHistory = true) => {
    if (newIdx < 0 || newIdx >= totalCount) return;
    if (newIdx === currentIndex) return;

    if (recordHistory) {
      setVisitedHistory(prev => {
        const next = [...prev, currentIndex];
        return next.slice(-10); // keep last 10 visited
      });
    }

    setCurrentIndex(newIdx);
    loadRecordData(existingRecords[newIdx]);
    setDuplicateWarning(null);
    setNotification(`تم الانتقال للشارع رقم ${newIdx + 1}: "${existingRecords[newIdx].name}"`);
  }, [currentIndex, totalCount, existingRecords, loadRecordData]);

  // Next Record by Number (التالي بحسب الترقيم)
  const handleGoNext = useCallback(() => {
    if (currentIndex < totalCount - 1) {
      navigateToIndex(currentIndex + 1);
    } else {
      setNotification('وصلت إلى آخر شارع مسجل في النظام.');
    }
  }, [currentIndex, totalCount, navigateToIndex]);

  // Previous Record by Number (السابق بحسب الترقيم)
  const handleGoPrev = useCallback(() => {
    if (currentIndex > 0) {
      navigateToIndex(currentIndex - 1);
    } else {
      setNotification('أنت في أول شارع مسجل في النظام (#1).');
    }
  }, [currentIndex, navigateToIndex]);

  // Return to Previous Street (العودة للشارع السابق الذي كنت فيه)
  const handleReturnToPreviousStreet = useCallback(() => {
    if (visitedHistory.length === 0) return;
    const lastVisited = visitedHistory[visitedHistory.length - 1];
    setVisitedHistory(prev => prev.slice(0, -1));
    navigateToIndex(lastVisited, false);
  }, [visitedHistory, navigateToIndex]);

  // Direct Jump by Letter (القفز بالحرف الأبجدي)
  const handleJumpToLetter = useCallback((letter: string) => {
    const targetIdx = alphabetNavigation.firstIndexMap.get(letter);
    if (targetIdx !== undefined && targetIdx >= 0) {
      navigateToIndex(targetIdx);
      setNotification(`✓ تم القفز لأول شارع بحرف "${letter}" (#${targetIdx + 1}: ${existingRecords[targetIdx].name})`);
    } else {
      setNotification(`لا توجد شوارع مسجلة تبدأ بحرف "${letter}"`);
    }
  }, [alphabetNavigation, existingRecords, navigateToIndex]);

  // Unified Jump (الانتقال لبيان محدد بالرقم التسلسلي أو بالحرف أو بالاسم)
  const handleUniversalJump = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const val = jumpInput.trim();
    if (!val) return;

    // 1. Is it a serial number?
    const num = parseInt(val, 10);
    if (!isNaN(num) && num >= 1 && num <= totalCount) {
      navigateToIndex(num - 1);
      return;
    }

    // 2. Is it a single Arabic letter?
    let normLetter = val;
    if (['ا', 'أ', 'إ', 'آ'].includes(normLetter)) normLetter = 'أ';
    else if (normLetter === 'ه') normLetter = 'هـ';

    if (alphabetNavigation.firstIndexMap.has(normLetter)) {
      handleJumpToLetter(normLetter);
      return;
    }

    // 3. Search matching street name
    const normQuery = normalizeArabicText(val);
    const foundIdx = existingRecords.findIndex(r => normalizeArabicText(r.name).includes(normQuery));
    if (foundIdx >= 0) {
      navigateToIndex(foundIdx);
      setNotification(`تم الانتقال للشارع المطابق (#${foundIdx + 1}: "${existingRecords[foundIdx].name}")`);
      return;
    }

    setNotification(`لم يتم العثور على نتيجة تطابق "${val}". أدخل رقم التسلسل (1 إلى ${totalCount}) أو حرفاً أبجدياً.`);
  };

  // Prefix Management Handlers
  const handleAddCustomPrefix = (prefixName: string) => {
    const clean = prefixName.trim();
    if (!clean) return;
    const updated = addCustomPrefix(clean);
    setPrefixesList(updated);
    setPrefix(clean);
    setCategory(clean);
    setNewPrefixInput('');
    setNotification(`✓ تم حفظ وإضافة البادئة الجديدة: "${clean}" وتطبيقها فوراً.`);
  };

  const handleRemoveCustomPrefix = (prefixToRemove: string) => {
    const updated = removeCustomPrefix(prefixToRemove);
    setPrefixesList(updated);
    if (prefix === prefixToRemove) {
      setPrefix('شارع');
      setCategory('شارع');
    }
    setNotification(`تم حذف البادئة المخصصة: "${prefixToRemove}"`);
  };

  const handleResetPrefixes = () => {
    const updated = resetCustomPrefixes();
    setPrefixesList(updated);
    setPrefix('شارع');
    setCategory('شارع');
    setNotification('✓ تمت استعادة قائمة البادئات القياسية المعتمدة بنجاح');
  };

  // Build record object
  const buildCurrentRecord = useCallback(() => {
    let finalPermission = 'مأذونية رسمية';
    let finalMetadata = metadata.trim();

    if (permissionType === 'مأذونية رسمية') {
      finalPermission = officialRegion;
      finalMetadata = metadata.trim();
    } else if (permissionType === 'مأذونية غير رسمي') {
      finalPermission = 'مأذونية غير رسمي';
      const pureNotes = metadata.trim();
      const tags: string[] = [];
      if (unofficialSubType && unofficialSubType !== 'داتا خاصة') {
        tags.push(`[نوع غير رسمي: ${unofficialSubType}]`);
      }
      if (suggestedRegion && suggestedRegion.trim()) {
        tags.push(`[مأذونية مقترحة: ${suggestedRegion.trim()}]`);
      }
      if (unofficialDefinition.trim()) tags.push(`التعريف: ${unofficialDefinition.trim()}`);
      if (customSourceName.trim()) tags.push(`المصدر المخصص: ${customSourceName.trim()}`);

      // Notary specific fields
      if (notaryName.trim()) tags.push(`اسم المأذون: ${notaryName.trim()}`);
      if (notaryBookNo.trim()) tags.push(`رقم الدفتر: ${notaryBookNo.trim()}`);
      if (notaryDeedNo.trim()) tags.push(`رقم الإشهاد: ${notaryDeedNo.trim()}`);
      if (notaryDate.trim()) tags.push(`تاريخ الإشهاد: ${notaryDate.trim()}`);

      // Bailiff fields
      if (bailiffReportNo.trim()) tags.push(`رقم المحضر: ${bailiffReportNo.trim()}`);
      if (bailiffCourt.trim()) tags.push(`المحكمة: ${bailiffCourt.trim()}`);
      if (bailiffName.trim()) tags.push(`اسم المحضر: ${bailiffName.trim()}`);
      if (bailiffDate.trim()) tags.push(`تاريخ الإعلان: ${bailiffDate.trim()}`);
      if (bailiffCircuit.trim()) tags.push(`الدائرة: ${bailiffCircuit.trim()}`);

      // Registry & Cadastral
      if (registryDocNo.trim()) tags.push(`رقم التوثيق: ${registryDocNo.trim()}`);
      if (registryOffice.trim()) tags.push(`مكتب التوثيق: ${registryOffice.trim()}`);
      if (cadastralParcelNo.trim()) tags.push(`رقم القطعة/الحوض: ${cadastralParcelNo.trim()}`);

      // Tax
      if (taxPropertyNo.trim()) tags.push(`رقم العقار/المكلفة: ${taxPropertyNo.trim()}`);
      if (taxDistrict.trim()) tags.push(`الشياخة/المأمورية: ${taxDistrict.trim()}`);

      // Courts
      if (courtCaseNo.trim()) tags.push(`رقم القضية: ${courtCaseNo.trim()}`);
      if (courtYear.trim()) tags.push(`السنة القضائية: ${courtYear.trim()}`);
      if (courtName.trim()) tags.push(`المحكمة/الدائرة: ${courtName.trim()}`);

      // Other fields
      if (contractNumber.trim()) tags.push(`رقم العقد: ${contractNumber.trim()}`);
      if (contractDate.trim()) tags.push(`التاريخ: ${contractDate.trim()}`);
      if (nationalIdRef.trim()) tags.push(`الرقم القومي: ${nationalIdRef.trim()}`);
      if (mapType.trim()) tags.push(`نوع الخرائط: ${mapType.trim()}`);
      if (mapSheetNo.trim()) tags.push(`رقم اللوحة: ${mapSheetNo.trim()}`);
      if (mapScale.trim()) tags.push(`مقياس الرسم: ${mapScale.trim()}`);

      if (tags.length > 0) {
        const tagHeader = tags.join(' | ');
        finalMetadata = pureNotes ? `${tagHeader} - ${pureNotes}` : tagHeader;
      } else {
        finalMetadata = pureNotes;
      }
    } else {
      finalPermission = permissionType;
      finalMetadata = metadata.trim();
    }

    if (category.trim() === 'حي') {
      finalPermission = selectedDistrict === 'CUSTOM' ? (customDistrict.trim() || 'حي غير أصلي مخصص') : selectedDistrict;
    }

    const trimmedName = name.trim();
    let finalName = trimmedName;

    if (prefix && prefix !== 'بدون بادئة') {
      if (trimmedName.startsWith(prefix)) {
        finalName = trimmedName;
      } else if (/^(\d+|[٠-٩]+)[\s\.\-\/\)]/.test(trimmedName)) {
        finalName = trimmedName;
      } else {
        finalName = `${prefix} ${trimmedName}`;
      }
    }

    const isLockedRecord = status === 'تام' ? true : isLocked;
    const isTruth = status === 'تام' ? true : isTruthRecord;

    return {
      record: {
        name: finalName,
        permission: finalPermission.trim(),
        metadata: finalMetadata,
        category: category.trim(),
        status,
        isLocked: isLockedRecord,
        isTruthRecord: isTruth
      },
      finalName
    };
  }, [
    category, 
    contractDate, 
    contractNumber, 
    customDistrict, 
    mapType, 
    mapSheetNo,
    mapScale,
    notaryName,
    notaryBookNo,
    notaryDeedNo,
    notaryDate,
    bailiffReportNo,
    bailiffCourt,
    bailiffName,
    bailiffDate,
    bailiffCircuit,
    registryDocNo,
    registryOffice,
    cadastralParcelNo,
    taxPropertyNo,
    taxDistrict,
    courtCaseNo,
    courtYear,
    courtName,
    customSourceName,
    metadata, 
    name, 
    nationalIdRef, 
    officialRegion, 
    permissionType, 
    prefix, 
    selectedDistrict, 
    status,
    isLocked,
    isTruthRecord,
    suggestedRegion,
    unofficialDefinition, 
    unofficialSubType,
    cleanMetadataNotes
  ]);

  // ══════════════════════════════════════════════════════════
  // 📋 Batch List Processing Utilities for Specific Notary Entry
  // ══════════════════════════════════════════════════════════
  const handleBatchCleanNumbers = () => {
    const cleaned = batchRawText
      .split('\n')
      .map(line => line.replace(/^[\s]*[\(\[\{]?[0-9\u0660-\u0669]+[\)\]\}]?[\.\-:\/\s_]+/, '').trim())
      .filter(Boolean)
      .join('\n');
    setBatchRawText(cleaned);
    setNotification('✓ تم تنظيف الأرقام والترقيم من بدايات السطور');
  };

  const handleBatchCleanPrefixes = () => {
    const cleaned = batchRawText
      .split('\n')
      .map(line => {
        let l = line.trim();
        l = l.replace(/^[\s]*(?:ش[\.\/\:\-]|ش\.|\/ش|ح[\.\/\:\-]|ح\.)\s*/i, '');
        l = l.replace(/^[\s]*(?:شارع|حارة|زقاق|عطفة|ميدان|طريق|درب|سكة|برج|عمارة|مساكن)\s+/i, '');
        return l.trim();
      })
      .filter(Boolean)
      .join('\n');
    setBatchRawText(cleaned);
    setNotification('✓ تم تنظيف البوادئ والزوائد المتكررة من السطور');
  };

  const handleBatchSortAlphabetical = () => {
    const lines = batchRawText.split('\n').map(l => l.trim()).filter(Boolean);
    lines.sort((a, b) => a.localeCompare(b, 'ar', { sensitivity: 'base' }));
    setBatchRawText(lines.join('\n'));
    setNotification('✓ تم فرز قائمة الشوارع أبجدياً');
  };

  const handleBatchRemoveDuplicates = () => {
    const lines = batchRawText.split('\n').map(l => l.trim()).filter(Boolean);
    const seen = new Set<string>();
    const unique: string[] = [];
    lines.forEach(l => {
      const norm = normalizeArabicText(l);
      if (!seen.has(norm)) {
        seen.add(norm);
        unique.push(l);
      }
    });
    setBatchRawText(unique.join('\n'));
    setNotification(`✓ تم حذف التكرار الداخلي (المتبقي: ${unique.length} شارع)`);
  };

  const handleBatchCleanSpaces = () => {
    const cleaned = batchRawText.split('\n').map(l => l.trim()).filter(Boolean).join('\n');
    setBatchRawText(cleaned);
  };

  // Preview List for Batch Entry
  const batchPreviewList = useMemo(() => {
    if (formEntryMode !== 'batch_list') return [];
    const lines = batchRawText.split('\n').map(l => l.trim()).filter(Boolean);
    const { record: sampleRecord } = buildCurrentRecord();

    return lines.map(line => {
      const hasPrefix = prefix && prefix !== 'بدون بادئة' ? line.startsWith(prefix) : false;
      const finalName = hasPrefix || !prefix || prefix === 'بدون بادئة' ? line : `${prefix} ${line}`;
      return {
        name: finalName,
        permission: sampleRecord.permission,
        category: category || prefix || 'شارع',
        metadata: sampleRecord.metadata,
        status: sampleRecord.status || 'نشط'
      };
    });
  }, [formEntryMode, batchRawText, buildCurrentRecord, prefix, category]);

  // Save entire batch list with the current notary specifications
  const handleSaveBatchList = () => {
    if (batchPreviewList.length === 0) {
      setNotification('يرجى كتابة أو لصق أسماء الشوارع أولاً في مربع القائمة');
      return;
    }

    if (onSaveBulk) {
      onSaveBulk(batchPreviewList, batchDuplicateStrategy);
    } else {
      batchPreviewList.forEach(item => {
        onSave(item);
      });
    }

    setBatchRawText('');
    setNotification(`✓ تم بنجاح إدراج (${batchPreviewList.length}) شارع للمأذونية المحددة`);
    onClose();
  };

  // ══════════════════════════════════════════════════════════
  // ⚡ Auto-Save System (الحفظ الفوري التلقائي لكل بيان يتم إدخاله)
  // ══════════════════════════════════════════════════════════
  useEffect(() => {
    if (!autoSaveEnabled || !isAuditMode || isInitialLoadRef.current || !name.trim()) {
      return;
    }

    // Do NOT auto-save modifications to a locked truth record
    if (activeRecord && (activeRecord.status === 'تام' || activeRecord.isLocked) && isLocked) {
      return;
    }

    const targetAutoSaveId = currentRecordId || editRecord?.id || activeRecord?.id || existingRecords[currentIndex]?.id;
    if (!targetAutoSaveId) return;

    // Clear previous timer
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }

    setAutoSaveStatus('saving');

    const delay = settings?.auditAutoSaveDelay || 600;
    autoSaveTimerRef.current = setTimeout(() => {
      const { record } = buildCurrentRecord();
      onSave(record, targetAutoSaveId, true);
      
      setAutoSaveStatus('saved');
      const now = new Date();
      setLastAutoSavedTime(`${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`);

      // Reset to idle after 2.5 seconds
      setTimeout(() => {
        setAutoSaveStatus('idle');
      }, 2500);
    }, delay);

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [
    name, 
    prefix, 
    permissionType, 
    officialRegion, 
    unofficialSubType, 
    unofficialDefinition, 
    contractNumber, 
    contractDate, 
    nationalIdRef, 
    mapType, 
    metadata, 
    category, 
    selectedDistrict, 
    customDistrict, 
    autoSaveEnabled, 
    isAuditMode, 
    currentIndex, 
    existingRecords, 
    buildCurrentRecord, 
    onSave, 
    settings?.auditAutoSaveDelay
  ]);

  // 1. Save as NEW Record (إضافة وحفظ بيان جديد بالمنظومة فورياً)
  const handleSaveAsNewRecord = () => {
    if (!name.trim()) {
      setNotification('يرجى كتابة اسم الشارع أولاً لإضافته كبيان جديد');
      if (nameInputRef.current) nameInputRef.current.focus();
      return;
    }

    const { record, finalName } = buildCurrentRecord();
    onSave(record, undefined);

    if (!isAuditMode) {
      resetFormFields();
      if (nameInputRef.current) nameInputRef.current.focus();
    }
    setNotification(`✓ تم حفظ وإضافة البيان الجديد بنجاح في المنظومة: ("${finalName}")`);
  };

  // 2. Save and Add Next New Entry (حفظ البيان وإفراغ النموذج للبيان التالي)
  const handleSaveAndAddNew = () => {
    if (!name.trim()) return;
    const { record, finalName } = buildCurrentRecord();
    onSave(record, undefined);
    resetFormFields();
    if (nameInputRef.current) nameInputRef.current.focus();
    setNotification(`✓ تم حفظ وإضافة ("${finalName}") وإعداد النموذج لإضافة البيان التالي فوراً.`);
  };

  // 3. Save and Close (يحفظ التعديل ويعود للجدول مباشرة)
  const handleSaveAndClose = () => {
    if (!name.trim()) return;

    const { record } = buildCurrentRecord();
    const targetId = isAuditMode
      ? (currentRecordId || editRecord?.id || activeRecord?.id || existingRecords[currentIndex]?.id)
      : undefined;

    onSave(record, targetId);
    onClose();
  };

  // 4. Save and Stay (يحفظ التعديل ويُبقي نفس الشارع معروضاً)
  const handleSaveAndStay = () => {
    if (!name.trim()) return;

    const { record, finalName } = buildCurrentRecord();
    const targetId = isAuditMode
      ? (currentRecordId || editRecord?.id || activeRecord?.id || existingRecords[currentIndex]?.id)
      : undefined;

    onSave(record, targetId);
    if (targetId) {
      setPendingNavId(targetId);
      setCurrentRecordId(targetId);
    }
    setNotification(`✓ تم حفظ التعديل بنجاح ("${finalName}"). أنت الآن تشاهد السجل بعد التحديث.`);
  };

  // Immediate Unlock Handler without blocking popups
  const handleUnlockRecord = () => {
    setIsLocked(false);
    setStatus('نشط');
    setIsTruthRecord(false);
    setNotification('✓ تم فك قفل السجل بنجاح وأصبحت كافة الحقول وملاحظات الشارع متاحة للتعديل والتحرير الآن');
  };

  // 5. Sequential Save & Advance (يحفظ وينتقل للشارع التالي بحسب الترقيم)
  const handleSaveAndNext = () => {
    if (!name.trim()) return;

    const { record, finalName } = buildCurrentRecord();
    const targetId = isAuditMode
      ? (currentRecordId || editRecord?.id || activeRecord?.id || existingRecords[currentIndex]?.id)
      : undefined;

    const nextRecord = isAuditMode && currentIndex < totalCount - 1
      ? existingRecords[currentIndex + 1]
      : null;

    onSave(record, targetId);

    if (nextRecord) {
      setPendingNavId(nextRecord.id);
      setCurrentRecordId(nextRecord.id);
      setNotification(`✓ تم حفظ "${finalName}" بنجاح، وجاري الآن استعراض الشارع التالي`);
    } else {
      setNotification(`✓ تم حفظ "${finalName}" بنجاح.`);
    }
  };

  // Standard submit on enter press
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAuditMode) {
      handleSaveAndStay();
    } else {
      handleSaveAsNewRecord();
    }
  };

  // Close search dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchDropdownRef.current && !searchDropdownRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Fast Top 8 search results for 3000+ streets
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = normalizeArabicText(searchQuery);
    const results: { index: number; record: RecordItem }[] = [];

    for (let i = 0; i < existingRecords.length; i++) {
      const rec = existingRecords[i];
      if (
        normalizeArabicText(rec.name).includes(q) || 
        normalizeArabicText(rec.permission).includes(q) ||
        String(i + 1) === q
      ) {
        results.push({ index: i, record: rec });
        if (results.length >= 8) break;
      }
    }
    return results;
  }, [searchQuery, existingRecords]);

  // ══════════════════════════════════════════════════════════
  // ⌨️ Comprehensive Keyboard Navigation & Arrow Keys (تنظيم عمل الكيبورد والماوس)
  // ══════════════════════════════════════════════════════════
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 1. Escape key: return to table or close drawers
      if (e.key === 'Escape') {
        if (isPrefixDrawerOpen) {
          setIsPrefixDrawerOpen(false);
          return;
        }
        if (isNameAutocompleteOpen) {
          setIsNameAutocompleteOpen(false);
          return;
        }
        if (isSearchOpen) {
          setIsSearchOpen(false);
          return;
        }
        e.preventDefault();
        onClose();
        return;
      }

      // 2. Alt + X or Alt + T or F2: Return to table directly
      if ((e.altKey && (e.key === 'x' || e.key === 'X' || e.key === 'ء' || e.key === 't' || e.key === 'T' || e.key === 'ف')) || e.key === 'F2') {
        e.preventDefault();
        onClose();
        return;
      }

      // 3. Ctrl + G or Alt + J or F3: Focus Jump Box by Serial or Letter
      if ((e.ctrlKey && (e.key === 'g' || e.key === 'G' || e.key === 'ل')) || (e.altKey && (e.key === 'j' || e.key === 'J' || e.key === 'ت')) || e.key === 'F3') {
        e.preventDefault();
        if (jumpInputRef.current) {
          jumpInputRef.current.focus();
          jumpInputRef.current.select();
        }
        return;
      }

      // 4. Ctrl + Enter: Save and Next / Save as New
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        if (isAuditMode && currentIndex < totalCount - 1) {
          handleSaveAndNext();
        } else {
          handleSaveAsNewRecord();
        }
        return;
      }

      // 5. Arrow Keys & Page Navigation (التنقل السريع بين السجلات بمفاتيح الأسهم)
      const isInputActive = ['INPUT', 'TEXTAREA', 'SELECT'].includes((document.activeElement?.tagName || ''));

      // If user presses Alt + Down / PageDown -> Go Next
      if ((e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowLeft')) || e.key === 'PageDown') {
        e.preventDefault();
        handleGoNext();
        return;
      }

      // If user presses Alt + Up / PageUp -> Go Prev
      if ((e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowRight')) || e.key === 'PageUp') {
        e.preventDefault();
        handleGoPrev();
        return;
      }

      // If focus is NOT inside an input field, simple Arrow keys step forward and backward
      if (!isInputActive && settings?.auditArrowKeyNavigation !== false) {
        if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') {
          e.preventDefault();
          handleGoNext();
          return;
        }
        if (e.key === 'ArrowUp' || e.key === 'ArrowRight') {
          e.preventDefault();
          handleGoPrev();
          return;
        }
      }

      // 6. Alt + N: Next record
      if (e.altKey && (e.key === 'n' || e.key === 'N' || e.key === 'ى')) {
        e.preventDefault();
        handleGoNext();
        return;
      }

      // 7. Alt + P: Prev record
      if (e.altKey && (e.key === 'p' || e.key === 'P' || e.key === 'ح')) {
        e.preventDefault();
        handleGoPrev();
        return;
      }

      // 8. Alt + B: Return to previous street visited
      if (e.altKey && (e.key === 'b' || e.key === 'B' || e.key === 'لا')) {
        e.preventDefault();
        handleReturnToPreviousStreet();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    onClose, 
    isPrefixDrawerOpen, 
    isNameAutocompleteOpen, 
    isSearchOpen, 
    isAuditMode, 
    currentIndex, 
    totalCount, 
    handleSaveAndNext, 
    handleGoNext, 
    handleGoPrev, 
    handleReturnToPreviousStreet,
    settings?.auditArrowKeyNavigation
  ]);

  const getThemeHeaderBg = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-800 text-white';
      case 'libreoffice': return 'bg-cyan-900 text-white';
      case 'hybrid': return 'bg-gradient-to-l from-emerald-800 via-cyan-900 to-indigo-950 text-white';
      case 'modern':
      default: return 'bg-slate-900 text-white';
    }
  };

  const isCurrentOfficial = activeRecord ? isOfficialNotarization(activeRecord.permission) : false;

  return (
    <div className="w-full bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden flex flex-col min-h-[750px] relative" dir="rtl">
      
      {/* 1. Header Bar: Organised with Serial Number, Auto-Save Status & Protected Table Return */}
      <div className={`px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 border-b border-white/10 ${getThemeHeaderBg()}`}>
        
        {/* Title, Serial Number Badge & Subtitle */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/15 rounded-xl shadow-xs">
            <FileCheck2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-base sm:text-lg font-bold">
                {isAuditMode 
                  ? 'ورقة التدقيق والمراجعة المتتالية بالترقيم التسلسلي' 
                  : 'ورقة إدخال وقيد بيان شارع جديد'}
              </h1>
              {isAuditMode && totalCount > 0 && (
                <span className="px-2.5 py-0.5 bg-amber-400 text-gray-900 rounded-full text-xs font-black shadow-xs flex items-center gap-1">
                  <Hash className="w-3 h-3 text-gray-950" />
                  <span>التسلسل: #{currentIndex + 1} من {totalCount}</span>
                </span>
              )}

              {/* Auto-Save Toggle & Real-Time Status Indicator */}
              {isAuditMode && (
                <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-0.5 rounded-lg border border-white/15 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      const next = !autoSaveEnabled;
                      setAutoSaveEnabled(next);
                      if (onUpdateSettings && settings) {
                        onUpdateSettings({ ...settings, auditAutoSave: next });
                      }
                      setNotification(next ? '✓ تم تفعيل الحفظ الفوري (Auto-save)' : 'تم إيقاف الحفظ الفوري (Auto-save)');
                    }}
                    className={`flex items-center gap-1 px-1.5 py-0.5 rounded font-bold transition cursor-pointer ${
                      autoSaveEnabled ? 'text-emerald-300 hover:text-emerald-200' : 'text-gray-300 hover:text-white'
                    }`}
                    title="انقر لتفعيل/تعطيل الحفظ الفوري التلقائي أثناء الكتابة"
                  >
                    <Zap className={`w-3.5 h-3.5 ${autoSaveEnabled ? 'text-emerald-400 fill-emerald-400' : 'text-gray-400'}`} />
                    <span>الحفظ الفوري: {autoSaveEnabled ? 'مفعل' : 'معطل'}</span>
                  </button>

                  {autoSaveEnabled && (
                    <span className="text-[11px] border-r border-white/20 pr-1.5 font-medium">
                      {autoSaveStatus === 'saving' ? (
                        <span className="text-amber-300 flex items-center gap-1 animate-pulse">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          <span>جاري الحفظ...</span>
                        </span>
                      ) : autoSaveStatus === 'saved' ? (
                        <span className="text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>تم الحفظ ({lastAutoSavedTime || 'الآن'})</span>
                        </span>
                      ) : (
                        <span className="text-white/60">جاهز للتسجيل</span>
                      )}
                    </span>
                  )}
                </div>
              )}
            </div>
            <p className="text-xs text-white/80 mt-0.5">
              {isAuditMode 
                ? 'التدقيق الفوري والانتقال بالأسهم أو الأبجدية مع الحفظ التلقائي وقائمة البادئات الجانبية الصافية' 
                : 'قيد بيان جديد في المنظومة مع الفلترة والتصنيف والترتيب الآلي'}
            </p>
          </div>
        </div>

        {/* Right Tools: Mode Switcher & Protected Return to Table */}
        <div className="flex items-center gap-2.5">
          {totalCount > 0 && (
            <button
              type="button"
              onClick={() => {
                const nextMode = !isAuditMode;
                setIsAuditMode(nextMode);
                if (nextMode) {
                  loadRecordData(existingRecords[currentIndex]);
                } else {
                  resetFormFields();
                }
              }}
              className="px-3 py-2 bg-white/15 hover:bg-white/25 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer text-white border border-white/20"
              title="التبديل بين وضع التدقيق المتتالي وإضافة بيان جديد"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{isAuditMode ? 'تبديل إلى: إضافة بيان جديد' : 'تفعيل: المراجعة بالترقيم'}</span>
            </button>
          )}

          {/* Protected Return Option (خيار الانتقال للجدول بعيد عن متناول الماوس ومع اختصار لوحة المفاتيح) */}
          <div className="border-r border-white/20 pr-2.5 mr-0.5">
            <button 
              type="button"
              onClick={onClose}
              className="flex items-center gap-2 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer group"
              title="العودة لجدول البيانات فوراً دون الحاجة للماوس عبر الضغط على [Esc] أو [Alt + X]"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-600 group-hover:-translate-x-0.5 transition-transform" />
              <span>العودة للجدول</span>
              <kbd className="px-1.5 py-0.5 bg-rose-200/80 text-rose-950 rounded text-[10px] font-mono font-bold">
                Esc
              </kbd>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Organized Sequential & Alphabetical Navigation Ribbon (شريط التنقل والتسلسل والأبجدية) */}
      {isAuditMode && totalCount > 0 && (
        <div className="bg-amber-50/90 border-b border-amber-200 px-5 py-3 space-y-3">
          
          {/* Row A: Primary Steppers, Jump by Serial Number/Letter, History & Search */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            
            {/* Stepper Controls: First, Prev (Arrow Up), Jump Box, Next (Arrow Down), Last */}
            <div className="flex flex-wrap items-center gap-1.5">
              
              {/* Jump to Start */}
              <button
                type="button"
                onClick={() => navigateToIndex(0)}
                disabled={currentIndex === 0}
                className="px-2.5 py-1.5 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-gray-700 rounded-lg text-xs font-bold border border-gray-300 shadow-xs transition cursor-pointer flex items-center gap-1"
                title="الشارع الأول (#1)"
              >
                <ChevronsRight className="w-4 h-4" />
                <span className="hidden sm:inline">الأول #1</span>
              </button>

              {/* Previous Record (# N-1) with Arrow Key Badge */}
              <button
                type="button"
                onClick={handleGoPrev}
                disabled={currentIndex === 0}
                className="px-3 py-1.5 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-gray-900 rounded-lg text-xs font-bold border border-gray-300 shadow-xs transition cursor-pointer flex items-center gap-1.5"
                title="الانتقال للشارع السابق (مفتاح ↑ أو PageUp أو Alt + P)"
              >
                <ChevronRight className="w-4 h-4 text-amber-700" />
                <span>السابق {currentIndex > 0 ? `(#${currentIndex})` : ''}</span>
                <kbd className="px-1 py-0.2 bg-gray-100 text-gray-600 rounded text-[10px] font-mono">↑</kbd>
              </button>

              {/* Direct Jump Box: Jump by Serial Number (#) OR Letter (أ-ي) */}
              <form onSubmit={handleUniversalJump} className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-amber-300 shadow-xs">
                <span className="text-xs font-bold text-gray-700 flex items-center gap-1">
                  <Hash className="w-3.5 h-3.5 text-amber-600" />
                  <span>انتقال بالرقم أو الحرف:</span>
                </span>
                <input
                  ref={jumpInputRef}
                  type="text"
                  value={jumpInput}
                  onChange={(e) => setJumpInput(e.target.value)}
                  placeholder="رقم التسلسل أو حرف..."
                  className="w-32 px-2 py-0.5 text-center font-bold text-amber-950 text-xs bg-amber-50 border border-amber-300 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                  title="أدخل رقم التسلسل (1 إلى N) أو حرفاً أبجدياً واضغط Enter [اختصار: Ctrl + G]"
                />
                <button
                  type="submit"
                  className="px-2 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-bold transition cursor-pointer"
                  title="تنفيذ الانتقال"
                >
                  انتقال ↵
                </button>
              </form>

              {/* Next Record (# N+1) with Arrow Key Badge */}
              <button
                type="button"
                onClick={handleGoNext}
                disabled={currentIndex >= totalCount - 1}
                className="px-3 py-1.5 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-gray-900 rounded-lg text-xs font-bold border border-gray-300 shadow-xs transition cursor-pointer flex items-center gap-1.5"
                title="الانتقال للشارع التالي (مفتاح ↓ أو PageDown أو Alt + N)"
              >
                <kbd className="px-1 py-0.2 bg-gray-100 text-gray-600 rounded text-[10px] font-mono">↓</kbd>
                <span>التالي {currentIndex < totalCount - 1 ? `(#${currentIndex + 2})` : ''}</span>
                <ChevronLeft className="w-4 h-4 text-amber-700" />
              </button>

              {/* Jump to Last */}
              <button
                type="button"
                onClick={() => navigateToIndex(totalCount - 1)}
                disabled={currentIndex >= totalCount - 1}
                className="px-2.5 py-1.5 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-gray-700 rounded-lg text-xs font-bold border border-gray-300 shadow-xs transition cursor-pointer flex items-center gap-1"
                title={`الشارع الأخير (#${totalCount})`}
              >
                <span className="hidden sm:inline">الأخير #{totalCount}</span>
                <ChevronsLeft className="w-4 h-4" />
              </button>

              {/* Step +10 / -10 */}
              <div className="hidden md:flex items-center gap-1 mr-1">
                <button
                  type="button"
                  onClick={() => navigateToIndex(Math.max(0, currentIndex - 10))}
                  disabled={currentIndex === 0}
                  className="px-2 py-1 bg-white hover:bg-gray-100 disabled:opacity-40 text-gray-600 rounded text-[11px] font-bold border border-gray-300"
                  title="الرجوع 10 شوارع للخلف"
                >
                  -10
                </button>
                <button
                  type="button"
                  onClick={() => navigateToIndex(Math.min(totalCount - 1, currentIndex + 10))}
                  disabled={currentIndex >= totalCount - 1}
                  className="px-2 py-1 bg-white hover:bg-gray-100 disabled:opacity-40 text-gray-600 rounded text-[11px] font-bold border border-gray-300"
                  title="التقدم 10 شوارع للأمام"
                >
                  +10
                </button>
              </div>
            </div>

            {/* Right Tools: History Return & Fast Search */}
            <div className="flex flex-wrap items-center gap-2">
              
              {/* Return to Previous Street visited ("كيف أعود للشارع؟") */}
              {previousVisitedRecord && (
                <button
                  type="button"
                  onClick={handleReturnToPreviousStreet}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-100 hover:bg-orange-200 text-orange-900 border border-orange-300 rounded-lg text-xs font-bold shadow-xs transition cursor-pointer"
                  title={`العودة للشارع الذي كنت فيه مسبقاً: ${previousVisitedRecord.name} (Alt + B)`}
                >
                  <History className="w-3.5 h-3.5 text-orange-700" />
                  <span>العودة للشارع السابق (#{previousVisitedIndex! + 1})</span>
                </button>
              )}

              {/* Fast Autocomplete Finder */}
              <div className="relative" ref={searchDropdownRef}>
                <div className="flex items-center bg-white border border-gray-300 rounded-lg px-2.5 py-1 shadow-xs focus-within:ring-2 focus-within:ring-amber-500">
                  <Search className="w-3.5 h-3.5 text-gray-400 ml-1.5 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setIsSearchOpen(true);
                    }}
                    onFocus={() => setIsSearchOpen(true)}
                    placeholder="بحث سريع بالاسم..."
                    className="text-xs text-gray-800 bg-transparent focus:outline-none w-36 sm:w-44"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="text-gray-400 hover:text-gray-600 text-xs px-1"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {isSearchOpen && searchQuery.trim() && (
                  <div className="absolute left-0 mt-1 w-72 bg-white rounded-xl shadow-xl border border-gray-200 py-1.5 z-50 text-right">
                    <div className="px-3 py-1 text-[11px] font-bold text-gray-400 border-b border-gray-100">
                      نتائج البحث للقفز المباشر:
                    </div>
                    {searchResults.length === 0 ? (
                      <div className="p-3 text-xs text-gray-400 text-center">لا توجد شوارع مطابقة للبحث</div>
                    ) : (
                      searchResults.map((item) => (
                        <div
                          key={item.record.id}
                          onClick={() => {
                            navigateToIndex(item.index);
                            setIsSearchOpen(false);
                            setSearchQuery('');
                          }}
                          className="px-3 py-2 hover:bg-amber-50 cursor-pointer flex items-center justify-between border-b border-gray-50 last:border-0"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-900 truncate">{item.record.name}</p>
                            <p className="text-[10px] text-gray-500 truncate">{item.record.permission}</p>
                          </div>
                          <span className="text-xs font-mono font-bold px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md">
                            #{item.index + 1}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

            </div>

          </div>

          {/* Row B: Alphabetical Jump Ribbon (الانتقال لبيان محدد بالحرف الأبجدي) */}
          {settings?.auditShowAlphabetRibbon !== false && (
            <div className="pt-2 border-t border-amber-200/70 flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-bold text-amber-950 flex items-center gap-1 shrink-0">
                <Type className="w-3.5 h-3.5 text-amber-700" />
                <span>القفز بالحرف:</span>
              </span>
              <div className="flex items-center gap-1 flex-wrap flex-1 overflow-x-auto py-0.5">
                {ARABIC_ALPHABET.map((letter) => {
                  const count = alphabetNavigation.countMap.get(letter) || 0;
                  const hasStreets = count > 0;
                  const isActive = currentActiveLetter === letter;

                  return (
                    <button
                      key={letter}
                      type="button"
                      onClick={() => handleJumpToLetter(letter)}
                      disabled={!hasStreets}
                      title={hasStreets ? `حرف "${letter}" (${count} شارع) - انقر للقفز للشارع الأول` : `لا توجد شوارع بحرف "${letter}"`}
                      className={`min-w-6 px-1.5 py-0.5 rounded text-xs font-bold transition flex items-center justify-center cursor-pointer ${
                        isActive 
                          ? 'bg-amber-600 text-white shadow-xs ring-2 ring-amber-300 scale-105' 
                          : hasStreets
                            ? 'bg-white hover:bg-amber-200/70 text-gray-800 border border-amber-300/80 shadow-2xs'
                            : 'bg-gray-100/60 text-gray-300 border border-gray-200/60 cursor-not-allowed opacity-50'
                      }`}
                    >
                      <span>{letter}</span>
                      {hasStreets && (
                        <span className={`text-[9px] mr-0.5 font-normal ${isActive ? 'text-amber-100' : 'text-gray-400'}`}>
                          {count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Notification Toast */}
          {notification && (
            <div className="p-2.5 bg-emerald-100 text-emerald-950 border border-emerald-300 rounded-xl text-xs font-bold flex items-center justify-between animate-in fade-in duration-150 shadow-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{notification}</span>
              </div>
              <button
                type="button"
                onClick={() => setNotification(null)}
                className="text-emerald-700 hover:text-emerald-950 font-bold px-1.5 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. Organized Form Workspace (ورقة التحرير المنظمة في بطاقات واضحة بتسلسل منطقي) */}
      <div className="flex-1 p-5 sm:p-7 overflow-y-auto bg-slate-50/50">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-5">
          
          {/* Active Record Info Banner in Audit Mode */}
          {isAuditMode && activeRecord && (
            <div className="p-3.5 bg-gradient-to-r from-amber-50 via-orange-50/50 to-white border border-amber-200 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-amber-600 text-white rounded-lg text-xs font-black shadow-xs flex items-center gap-1 font-mono">
                  <Hash className="w-3.5 h-3.5" />
                  رقم التسلسل: #{currentIndex + 1}
                </span>
                <div>
                  <span className="text-[11px] text-gray-500 font-bold block">الشارع الحالي قيد المراجعة والتدقيق:</span>
                  <h2 className="text-base sm:text-lg font-black text-gray-900 flex items-center gap-2">
                    <span>{activeRecord.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold border ${
                      isCurrentOfficial 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                        : 'bg-amber-50 text-amber-700 border-amber-300'
                    }`}>
                      {isCurrentOfficial ? 'مأذونية رسمية معتمدة' : 'مأذونية غير رسمية'}
                    </span>
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-gray-700 font-medium shadow-2xs">
                  المأذونية: <strong className="text-gray-900 font-bold">{activeRecord.permission}</strong>
                </span>
                <span className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-gray-700 font-medium shadow-2xs">
                  التصنيف: <strong className="text-gray-900 font-bold">{activeRecord.category || 'شارع'}</strong>
                </span>
              </div>
            </div>
          )}

          {/* Ground Truth & Record Status Card */}
          <div className={`p-4 rounded-2xl border transition-all shadow-xs ${
            status === 'تام' || isLocked
              ? 'bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 text-white border-emerald-600 shadow-md'
              : 'bg-white border-gray-200 text-gray-900'
          }`}>
            {(status === 'تام' || isLocked) ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-800/90 rounded-2xl text-amber-300 border border-emerald-600/50 shadow-inner">
                    <Lock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black flex items-center gap-2">
                      <span>هذا البيان معتمد نهائياً كـ «عنوان الحقيقة 🔒»</span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-amber-950">
                        بيان تام مغلق
                      </span>
                    </h4>
                    <p className="text-xs text-emerald-100/90 mt-0.5">
                      تم غلق هذا البيان ليكون المرجع الثابت لجميع البيانات المشابهة. تم قفل حقول التعديل لحمايته من التغييرات غير المقصودة.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleUnlockRecord}
                    className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-amber-950 rounded-xl text-xs font-black transition cursor-pointer shadow-md flex items-center gap-1.5 active:scale-95"
                    title="فك قفل البيان فوراً للسماح بالتعديل"
                  >
                    <Unlock className="w-4 h-4 text-amber-950" />
                    <span>فك قفل البيان للتعديل 🔓</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gray-700 flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      حالة اعتماد السجل:
                    </span>
                    <select
                      value={status}
                      onChange={(e) => {
                        const newStatus = e.target.value as RecordStatus;
                        setStatus(newStatus);
                        if (newStatus === 'تام') {
                          setIsLocked(true);
                          setIsTruthRecord(true);
                          setNotification('تم اعتماد السجل كـ «بيان تام - عنوان الحقيقة 🔒» وتفعيل قفل البيان');
                        } else {
                          setIsLocked(false);
                          setIsTruthRecord(false);
                        }
                      }}
                      className="px-3.5 py-1.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value="نشط">نشط (سجل عادي)</option>
                      <option value="تام">🔒 بيان تام (عنوان الحقيقة المغلق نهائياً)</option>
                      <option value="معلّق">معلّق</option>
                      <option value="قيد المراجعة">قيد المراجعة</option>
                      <option value="ملغي">ملغي</option>
                    </select>
                  </div>

                  {/* Explicit isLocked Boolean Toggle */}
                  <label className="flex items-center gap-2 px-3 py-1.5 bg-gray-100/90 hover:bg-gray-200/80 rounded-xl border border-gray-300/80 text-xs font-bold cursor-pointer transition select-none">
                    <input
                      type="checkbox"
                      checked={Boolean(isLocked || status === 'تام')}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setIsLocked(checked);
                        if (checked) {
                          setStatus('تام');
                          setIsTruthRecord(true);
                          setNotification('تم تفعيل قفل البيان (isLocked = true) واعتماده كبيان تام 🔒');
                        } else {
                          setStatus('نشط');
                          setIsTruthRecord(false);
                          setNotification('تم إلغاء قفل البيان (isLocked = false)');
                        }
                      }}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                    />
                    <Lock className={`w-3.5 h-3.5 ${isLocked ? 'text-emerald-700' : 'text-gray-400'}`} />
                    <span className={isLocked ? 'text-emerald-950 font-black' : 'text-gray-700'}>
                      حقل قفل البيان (isLocked): {isLocked ? '🔒 مقفول (نهائي تام)' : 'مفتوح للتعديل'}
                    </span>
                  </label>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      setStatus('تام');
                      setIsLocked(true);
                      setIsTruthRecord(true);
                      setNotification('تم اعتماد السجل كـ «بيان تام - عنوان الحقيقة 🔒»');
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-xs"
                    title="اعتماد هذا السجل كعنوان الحقيقة النهائي وتأمينه بالقفل"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-300" />
                    <span>اعتماد كـ «بيان تام 🔒»</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setStatus('قيد المراجعة');
                      setIsLocked(false);
                      setIsTruthRecord(false);
                      setNotification('تم تعيين حالة السجل إلى «قيد المراجعة 🔍» لإخضاعه للتدقيق الإضافي');
                    }}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer shadow-xs border ${
                      status === 'قيد المراجعة'
                        ? 'bg-sky-700 text-white border-sky-800'
                        : 'bg-sky-50 hover:bg-sky-100 text-sky-950 border-sky-300'
                    }`}
                    title="إحالة السجل إلى قائمة التدقيق والمراجعة الإضافية"
                  >
                    <FileSearch className="w-3.5 h-3.5 text-sky-600" />
                    <span>إحالة إلى «قيد المراجعة 🔍»</span>
                  </button>
                </div>
              </div>
            )}

            {/* Specialized Under Review Queue Banner */}
            {status === 'قيد المراجعة' && (
              <div className="mt-3 p-3.5 bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 border border-sky-300 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-sky-100 text-sky-800 rounded-xl">
                    <FileSearch className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <strong className="block font-black text-sky-950">السجل محال كـ «قيد المراجعة والتدقيق الإضافي 🔍»</strong>
                    <span className="text-[11px] text-sky-800">
                      سيظهر هذا السجل بشارة مميزة في الجدول لتسهيل تتبعه وتدقيقه، ويمكن إدارته ضمن صفحة السجلات قيد المراجعة المستقلة.
                    </span>
                  </div>
                </div>

                {onOpenUnderReviewPage && (
                  <button
                    type="button"
                    onClick={onOpenUnderReviewPage}
                    className="px-3.5 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <FileSearch className="w-3.5 h-3.5" />
                    <span>فتح صفحة قيد المراجعة المستقلة</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Smart Duplicate & Similarity Alert Banner */}
          {duplicateWarning && (
            <div className={`p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border shadow-md animate-in fade-in ${
              duplicateWarning.includes('عنوان الحقيقة')
                ? 'bg-gradient-to-r from-emerald-950 via-teal-900 to-emerald-900 text-white border-emerald-600'
                : matchedDuplicateSimilarity && matchedDuplicateSimilarity < 0.99
                ? 'bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/20 text-amber-950 border-amber-400'
                : 'bg-amber-50 text-amber-900 border-amber-300'
            }`}>
              <div className="flex items-start gap-3">
                {duplicateWarning.includes('عنوان الحقيقة') ? (
                  <Lock className="w-6 h-6 text-amber-300 shrink-0 mt-0.5" />
                ) : matchedDuplicateSimilarity && matchedDuplicateSimilarity < 0.99 ? (
                  <Sparkles className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <strong className="block font-black text-sm">
                      {duplicateWarning.includes('عنوان الحقيقة') 
                        ? 'تطابق مع عنوان الحقيقة المعتمد 🔒' 
                        : matchedDuplicateSimilarity && matchedDuplicateSimilarity < 0.99
                        ? 'نظام التنبيه الذكي للمتشابهات'
                        : 'تنبيه تكرار شارع مسجل مسبقاً'}
                    </strong>
                    {matchedDuplicateSimilarity > 0 && (
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                        duplicateWarning.includes('عنوان الحقيقة') ? 'bg-white/20 text-white' : 'bg-amber-200 text-amber-950'
                      }`}>
                        {matchedDuplicateSimilarity >= 0.99 ? 'تطابق تام 100%' : `تشابه ${Math.round(matchedDuplicateSimilarity * 100)}%`}
                      </span>
                    )}
                  </div>
                  <p className="text-xs sm:text-sm font-medium leading-relaxed">{duplicateWarning}</p>
                </div>
              </div>

              {/* Direct Quick-Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto justify-end shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-amber-200">
                {matchedDuplicateRecord && (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenMatchedRecordInForm(matchedDuplicateRecord)}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs flex items-center gap-1.5"
                      title="فتح وعرض السجل المسجل مسبقاً في النموذج لتعديله مباشرة بدلاً من الإضافة المتكررة"
                    >
                      <Eye className="w-3.5 h-3.5 text-white" />
                      <span>عرض السجل الحالي 👁️</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleQuickMergeIntoMatched(matchedDuplicateRecord)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs flex items-center gap-1.5"
                      title="دمج الملاحظات الحالية مع السجل المسجل مسبقاً لتفادي تكرار الشارع"
                    >
                      <GitMerge className="w-3.5 h-3.5 text-white" />
                      <span>دمج الملاحظات 🔗</span>
                    </button>
                  </>
                )}

                {onOpenSimilarModal && (
                  <button
                    type="button"
                    onClick={() => onOpenSimilarModal(name)}
                    className="px-3 py-1.5 bg-white text-gray-900 hover:bg-gray-100 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs flex items-center gap-1.5 border border-gray-300"
                    title="فتح مركز فحص وتصنيف المتشابهات لهذا الشارع وعنوان الحقيقة"
                  >
                    <Layers className="w-3.5 h-3.5 text-indigo-700" />
                    <span>فحص المتشابهات 🔍</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Sub-Mode Switcher: Single Street Entry vs Batch List for Current Notary */}
          <div className="bg-white p-1.5 rounded-2xl border border-gray-200 shadow-xs flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFormEntryMode('single')}
              className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                formEntryMode === 'single'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>إدخال وتدقيق شارع فردي 📝</span>
            </button>

            <button
              type="button"
              onClick={() => setFormEntryMode('batch_list')}
              className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                formEntryMode === 'batch_list'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <ListPlus className="w-4 h-4 text-amber-300" />
              <span>إدخال قائمة شوارع لهذه المأذونية (معالجة القوائم) 📋</span>
            </button>
          </div>

          {/* CARD 1: Either Batch List Input Card OR Single Street Input Card */}
          {formEntryMode === 'batch_list' ? (
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                    1
                  </span>
                  <label className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                    <ListPlus className="w-4 h-4 text-emerald-600" />
                    <span>إدخال ومعالجة قائمة الشوارع للمأذونية المحددة</span>
                    <span className="text-red-500">*</span>
                  </label>
                </div>

                {/* Quick List Processing Actions */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleBatchCleanNumbers}
                    className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    title="تنظيف الأرقام والترقيم التلقائي من بداية السطور"
                  >
                    <Eraser className="w-3.5 h-3.5 text-amber-600" />
                    <span>تنظيف الأرقام</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleBatchCleanPrefixes}
                    className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    title="تنظيف البوادئ المتكررة مثل ش. أو ش/ أو حارة"
                  >
                    <Scissors className="w-3.5 h-3.5 text-blue-600" />
                    <span>تنظيف البوادئ</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleBatchSortAlphabetical}
                    className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    title="فرز أسطر القائمة أبجدياً"
                  >
                    <ArrowDownAZ className="w-3.5 h-3.5 text-purple-600" />
                    <span>فرز أبجدي</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleBatchRemoveDuplicates}
                    className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    title="حذف التكرار الداخلي في القائمة"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>حذف التكرار الداخلي</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleBatchCleanSpaces}
                    className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 rounded-lg text-xs font-medium transition cursor-pointer"
                    title="إزالة الأسطر الفارغة"
                  >
                    <span>تنظيف الفراغات</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    البادئة التلقائية للسطور:
                  </label>
                  <select
                    value={prefix}
                    onChange={(e) => {
                      setPrefix(e.target.value);
                      if (e.target.value) setCategory(e.target.value);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-xl text-xs font-bold bg-white text-gray-900 focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="شارع">شارع</option>
                    <option value="حارة">حارة</option>
                    <option value="زقاق">زقاق</option>
                    <option value="عطفة">عطفة</option>
                    <option value="ميدان">ميدان</option>
                    <option value="طريق">طريق</option>
                    <option value="درب">درب</option>
                    <option value="سكة">سكة</option>
                    <option value="برج">برج</option>
                    <option value="">بدون بادئة (كما هي)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    طريقة معالجة وتفادي التكرار مع قاعدة البيانات:
                  </label>
                  <select
                    value={batchDuplicateStrategy}
                    onChange={(e) => setBatchDuplicateStrategy(e.target.value as any)}
                    className="w-full px-3 py-2 border border-emerald-300 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-950 focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="merge">دمج وتحديث الملاحظات (الموصى به لمنع التكرار)</option>
                    <option value="skip">تخطي السجلات الموجودة مسبقاً</option>
                    <option value="separate">إدراج الكل كسجلات منفصلة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  مربع إدخال قائمة الشوارع (اكتب أو الصق كل اسم في سطر مستقل):
                </label>
                <textarea
                  rows={8}
                  value={batchRawText}
                  onChange={(e) => setBatchRawText(e.target.value)}
                  placeholder={`عبد السلام الشاذلي\nالروضة\nالمحطة\nشجرة الدر\nالصاغة\n...`}
                  className="w-full p-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-xs sm:text-sm font-mono whitespace-pre text-gray-900 leading-relaxed"
                />
              </div>

              {/* Batch Preview & Count */}
              {batchPreviewList.length > 0 && (
                <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-stone-800">
                    <span>معاينة القائمة ({batchPreviewList.length} شارع جاهز للإضافة):</span>
                    <span className="text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded">
                      جاهز للإدراج بالمواصفات المحددة أدناه
                    </span>
                  </div>
                  <div className="max-h-36 overflow-y-auto space-y-1 text-xs">
                    {batchPreviewList.slice(0, 8).map((item, idx) => (
                      <div key={idx} className="p-1.5 bg-white rounded border border-stone-200 flex items-center justify-between">
                        <span className="font-bold text-gray-900">{idx + 1}. {item.name}</span>
                        <span className="text-gray-500">{item.permission}</span>
                      </div>
                    ))}
                    {batchPreviewList.length > 8 && (
                      <div className="text-center text-gray-500 text-[11px] pt-1">
                        ... و {batchPreviewList.length - 8} شوارع أخرى
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* One-Click Batch Save Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleSaveBatchList}
                  disabled={batchPreviewList.length === 0}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold text-sm shadow-md transition cursor-pointer"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>إدراج قائمة الشوارع للمأذونية المحددة ({batchPreviewList.length} شارع)</span>
                </button>
              </div>
            </div>
          ) : (
            /* CARD 1: Clean Street Details & Prefix Selector (مع زر القائمة الجانبية للبادئات لتقليل التشتت البصري) */
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3.5" ref={nameInputContainerRef}>
              <div className="flex items-center justify-between border-b border-gray-100 pb-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                    1
                  </span>
                  <label className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-emerald-600" />
                    <span>تسمية الشارع وتحديد البادئة</span>
                    <span className="text-red-500">*</span>
                    {isLocked && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                        <Lock className="w-3 h-3 text-emerald-700" />
                        مغلق ومحمي
                      </span>
                    )}
                  </label>
                </div>

                {/* Collapsible Prefix Drawer Trigger: Minimal & Distraction-Free */}
                <button
                  type="button"
                  disabled={isLocked}
                  onClick={() => setIsPrefixDrawerOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 hover:bg-indigo-100 disabled:opacity-50 text-indigo-900 border border-indigo-200 rounded-lg text-xs font-bold transition cursor-pointer"
                  title="فتح القائمة الجانبية لإدارة وتنظيم وإضافة البادئات"
                >
                  <Tag className="w-3.5 h-3.5 text-indigo-600" />
                  <span>قائمة البادئات الجانبية</span>
                  <span className="px-1.5 py-0.2 bg-indigo-200/80 rounded text-[10px] font-mono">
                    {prefixesList.length}
                  </span>
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex gap-2 relative">
                  {/* Prefix Dropdown - Clean & Simple */}
                  <select
                    disabled={isLocked}
                    tabIndex={1}
                    value={prefix}
                    onChange={(e) => {
                      const newPrefix = e.target.value;
                      if (newPrefix === '__OPEN_DRAWER__') {
                        setIsPrefixDrawerOpen(true);
                        return;
                      }
                      setPrefix(newPrefix);
                      if (newPrefix) setCategory(newPrefix);
                    }}
                    className="w-36 px-3 py-2.5 bg-emerald-50 disabled:bg-gray-100 disabled:text-gray-400 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-950 focus:ring-2 focus:ring-emerald-500 focus:outline-none shrink-0"
                    title="تحديد نوع البادئة"
                  >
                    <option value="">بدون بادئة</option>
                    <optgroup label="البادئات المتاحة">
                      {prefixesList.map((p) => (
                        <option key={p} value={p}>
                          {p}
                        </option>
                      ))}
                    </optgroup>
                    <option value="__OPEN_DRAWER__" className="text-indigo-700 font-bold bg-indigo-50">
                      ⚙ فتح القائمة الجانبية للبادئات...
                    </option>
                  </select>

                  {/* Street Name Input */}
                  <div className="relative flex-1">
                    <input
                      ref={nameInputRef}
                      disabled={isLocked}
                      tabIndex={2}
                      type="text"
                      required
                      value={name}
                      onChange={(e) => {
                        if (isLocked) return;
                        setName(e.target.value);
                        setIsNameAutocompleteOpen(true);
                        setSelectedSuggestionIdx(-1);
                      }}
                      onFocus={() => {
                        if (name.trim().length > 0 && !isLocked) setIsNameAutocompleteOpen(true);
                      }}
                      onKeyDown={handleNameInputKeyDown}
                      placeholder={isLocked ? "هذا السجل بيان تام مغلق للحماية..." : "اكتب اسم الشارع بدون البادئة (مثال: الجمهورية)..."}
                      className={`w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-sm font-semibold ${
                        isLocked 
                          ? 'bg-gray-100 text-gray-500 border-gray-300 cursor-not-allowed' 
                          : 'border-gray-300 text-gray-900 bg-white'
                      }`}
                      autoComplete="off"
                    />

                    {isLocked ? (
                      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-700 flex items-center gap-1 font-bold text-xs">
                        <Lock className="w-3.5 h-3.5" />
                      </div>
                    ) : name ? (
                      <button
                        type="button"
                        onClick={() => {
                          setName('');
                          setIsNameAutocompleteOpen(false);
                          if (nameInputRef.current) nameInputRef.current.focus();
                        }}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs px-1 cursor-pointer"
                        title="مسح النص"
                      >
                        ✕
                      </button>
                    ) : null}

                    {/* Autocomplete Suggestions Dropdown */}
                    {isNameAutocompleteOpen && nameSuggestions.length > 0 && (
                      <div className="absolute right-0 left-0 mt-1 bg-white rounded-2xl shadow-2xl border border-gray-200 py-2 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                        <div className="px-3 py-1.5 text-[11px] font-bold text-gray-500 border-b border-gray-100 flex items-center justify-between bg-gray-50/80">
                          <div className="flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                            <span>اقتراحات أسماء مطابقة من قاعدة البيانات:</span>
                          </div>
                          <span className="text-[10px] text-gray-400">
                            استخدم الأسهم ↑ ↓ ثم اضغط Enter
                          </span>
                        </div>

                        <div className="max-h-60 overflow-y-auto divide-y divide-gray-100">
                          {nameSuggestions.map((sug, idx) => {
                            const isSelected = idx === selectedSuggestionIdx;
                            return (
                              <div
                                key={idx}
                                onMouseDown={(e) => {
                                  e.preventDefault();
                                  handleSelectSuggestion(sug);
                                }}
                                onMouseEnter={() => setSelectedSuggestionIdx(idx)}
                                className={`px-3.5 py-2.5 flex items-center justify-between gap-3 cursor-pointer transition text-right ${
                                  isSelected ? 'bg-emerald-50/90 text-emerald-950 font-bold' : 'hover:bg-gray-50 text-gray-800'
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <span className="p-1.5 rounded-lg bg-emerald-100/70 text-emerald-800">
                                    <MapPin className="w-3.5 h-3.5" />
                                  </span>
                                  <div>
                                    <span className="text-sm font-black text-gray-900">
                                      {sug.baseName}
                                    </span>
                                    {sug.prefix && (
                                      <span className="mr-2 text-xs text-gray-500 font-medium">
                                        (البادئة: {sug.prefix})
                                      </span>
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center gap-1.5 flex-wrap justify-end">
                                  {sug.permissions.map((p, pIdx) => (
                                    <span 
                                      key={pIdx} 
                                      className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200"
                                    >
                                      {p}
                                    </span>
                                  ))}
                                  <span className="text-[10px] text-gray-400 font-semibold px-1.5 py-0.5 bg-gray-100 rounded">
                                    {sug.count} {sug.count === 1 ? 'سجل' : 'سجلات'}
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub-strip: Quick Suggestions & Google Maps Preview */}
                <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs">
                  {nameSuggestions.length > 0 && !isNameAutocompleteOpen ? (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] font-bold text-gray-500 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        مقترحات سريعة:
                      </span>
                      {nameSuggestions.slice(0, 3).map((sug, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleSelectSuggestion(sug)}
                          className="px-2.5 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold border border-emerald-200 transition cursor-pointer flex items-center gap-1"
                        >
                          <span>{sug.baseName}</span>
                          <span className="text-[10px] text-emerald-600 opacity-70">({sug.permissions[0] || 'سجل'})</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <span className="text-[11px] text-gray-500">
                      تُحفظ البادئة بشكل مستقل عن اسم الشارع لتيسير الترتيب والبحث الأبجدي الدقيق.
                    </span>
                  )}

                  {name.trim() && (
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                        metadata && (metadata.includes('31.') || metadata.includes('31°'))
                          ? (metadata.match(/31[°\.\d\s'N]+30[°\.\d\s'E]+/i)?.[0] || (name.trim() + ' دمنهور'))
                          : (name.trim() + ' دمنهور البحيرة')
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition cursor-pointer"
                      title="معاينة موقع الشارع على خرائط جوجل في نافذة جديدة"
                    >
                      <Compass className="w-3.5 h-3.5 text-emerald-600" />
                      <span>معاينة موقع «{name.trim()}» على خرائط جوجل ↗</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* CARD 2: Permission Type & Sub-Details (المأذونية وجهة الاختصاص) */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 border-b border-gray-100 pb-2.5">
              <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-xs">
                2
              </span>
              <label className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                <span>المأذونية وجهة الاختصاص</span>
                <span className="text-red-500">*</span>
              </label>
            </div>

            {/* Radio options: Official vs Unofficial */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label 
                className={`flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition ${
                  permissionType === 'مأذونية رسمية' 
                    ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-bold shadow-xs' 
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <input
                  tabIndex={3}
                  type="radio"
                  name="permissionType"
                  value="مأذونية رسمية"
                  checked={permissionType === 'مأذونية رسمية'}
                  onChange={(e) => setPermissionType(e.target.value)}
                  className="text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-sm block font-bold">مأذونية رسمية</span>
                  <span className="text-xs text-gray-500">من ضمن المأذونيات السبع المعتمدة رسمياً ببندر دمنهور</span>
                </div>
              </label>

              <label 
                className={`flex items-center gap-3 p-3.5 border rounded-xl cursor-pointer transition ${
                  permissionType === 'مأذونية غير رسمي' 
                    ? 'border-amber-500 bg-amber-50/80 text-amber-950 font-bold shadow-xs' 
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <input
                  type="radio"
                  name="permissionType"
                  value="مأذونية غير رسمي"
                  checked={permissionType === 'مأذونية غير رسمي'}
                  onChange={(e) => setPermissionType(e.target.value)}
                  className="text-amber-600 focus:ring-amber-500"
                />
                <div>
                  <span className="text-sm block font-bold">مأذونية غير رسمي</span>
                  <span className="text-xs text-gray-500">داتا خاصة، عقود زواج، بطاقة رقم قومي، أو خريطة</span>
                </div>
              </label>
            </div>

            {/* Official 7 Regions Selector */}
            {permissionType === 'مأذونية رسمية' && (
              <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-2 animate-in fade-in duration-150">
                <label className="block text-xs sm:text-sm font-bold text-emerald-900">
                  اختر المأذونية الرسمية المعتمدة <span className="text-red-500">*</span>
                </label>
                <select
                  tabIndex={4}
                  value={officialRegion}
                  onChange={(e) => setOfficialRegion(e.target.value)}
                  className="w-full px-4 py-2.5 border border-emerald-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-900 text-sm bg-white font-semibold"
                >
                  {officialRegionsList.map((region) => {
                    const district = OFFICIAL_DISTRICTS.find(d => d.key === region);
                    return (
                      <option key={region} value={region} style={district ? { color: district.hex, fontWeight: 700 } : undefined}>
                        {region}
                      </option>
                    );
                  })}
                </select>
                <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px] text-emerald-800">
                  <span className="font-bold">المأذونيات السبع:</span>
                  {officialRegionsList.map(r => (
                    <span key={r} className="px-2 py-0.5 bg-white rounded border border-emerald-200 text-emerald-900 font-semibold">
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Unofficial Permission Sub-details */}
            {permissionType === 'مأذونية غير رسمي' && (
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-4 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-amber-900 mb-2">
                    تصنيف البيانات غير الرسمية <span className="text-red-500">*</span>
                  </label>
                  
                  {/* Dynamic Unofficial SubTypes from AppSettings */}
                  <div className="flex flex-wrap gap-2">
                    {unofficialSubTypesList.map((subType) => (
                      <button
                        key={subType}
                        type="button"
                        onClick={() => setUnofficialSubType(subType)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer border ${
                          unofficialSubType === subType
                            ? 'border-amber-500 bg-amber-200 text-amber-950 shadow-xs ring-1 ring-amber-400'
                            : 'border-amber-200 bg-white hover:bg-amber-100/70 text-gray-700'
                        }`}
                      >
                        {subType}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Suggested Official Notarization from the 7 Official Regions */}
                <div className="p-3 bg-white/80 border border-amber-300/80 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      <span>المأذونية المقترحة (من المأذونيات السبع الرسمية)</span>
                    </label>
                    {suggestedRegion && (
                      <button
                        type="button"
                        onClick={() => setSuggestedRegion('')}
                        className="text-[11px] text-red-600 hover:underline cursor-pointer"
                      >
                        إلغاء الاقتراح
                      </button>
                    )}
                  </div>

                  <select
                    value={suggestedRegion}
                    onChange={(e) => setSuggestedRegion(e.target.value)}
                    className="w-full px-3 py-2 border border-amber-300 rounded-lg text-xs bg-white text-gray-900 font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  >
                    <option value="">-- بدون اقتراح محدد (غير منسوب لمأذونية معينة) --</option>
                    {officialRegionsList.map((region) => (
                      <option key={region} value={region}>
                        مقترح تبع مأذونية: {region}
                      </option>
                    ))}
                  </select>

                  {/* Quick Click Chips for Official 7 */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
                    <span className="font-semibold text-gray-500">اقتراح سريع:</span>
                    {officialRegionsList.map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setSuggestedRegion(r)}
                        className={`px-2 py-0.5 rounded text-[11px] font-semibold border transition cursor-pointer ${
                          suggestedRegion === r
                            ? 'bg-amber-600 text-white border-amber-700'
                            : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      تعريف البيان / وصف المصدر العام
                    </label>
                    <input
                      type="text"
                      value={unofficialDefinition}
                      onChange={(e) => setUnofficialDefinition(e.target.value)}
                      placeholder="مثال: من واقع دفاتر المأذون، إعلانات قلم المحضرين، حصر الضرائب العقارية..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>

                  {/* 1. Notary Specific Fields (مأذونية محددة / دفاتر مأذون) */}
                  {unofficialSubType.includes('مأذون') && (
                    <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2.5 animate-in fade-in">
                      <div className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                        <span>بيانات المأذونية ودفاتر المأذون التفصيلية:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">اسم المأذون الشرعي</label>
                          <input
                            type="text"
                            value={notaryName}
                            onChange={(e) => setNotaryName(e.target.value)}
                            placeholder="اسم المأذون..."
                            className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم الدفتر / السجل</label>
                          <input
                            type="text"
                            value={notaryBookNo}
                            onChange={(e) => setNotaryBookNo(e.target.value)}
                            placeholder="رقم الدفتر أو السجل..."
                            className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم الإشهاد / العقد</label>
                          <input
                            type="text"
                            value={notaryDeedNo}
                            onChange={(e) => setNotaryDeedNo(e.target.value)}
                            placeholder="رقم الإشهاد أو القيد..."
                            className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">تاريخ الإشهاد / القيد</label>
                          <input
                            type="date"
                            value={notaryDate}
                            onChange={(e) => setNotaryDate(e.target.value)}
                            className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 2. Process Server / Bailiffs Fields (محضرين / إعلانات قضائية) */}
                  {unofficialSubType.includes('محضر') && (
                    <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2.5 animate-in fade-in">
                      <div className="font-bold text-xs text-blue-950 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-blue-700" />
                        <span>بيانات قلم المحضرين والإعلانات القضائية:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم المحضر / الإعلان</label>
                          <input
                            type="text"
                            value={bailiffReportNo}
                            onChange={(e) => setBailiffReportNo(e.target.value)}
                            placeholder="رقم المحضر أو الإعلان..."
                            className="w-full px-3 py-1.5 border border-blue-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">المحكمة المختصة</label>
                          <input
                            type="text"
                            value={bailiffCourt}
                            onChange={(e) => setBailiffCourt(e.target.value)}
                            placeholder="مثال: محكمة دمنهور الابتدائية / بندر..."
                            className="w-full px-3 py-1.5 border border-blue-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">اسم المحضر / قلم المحضرين</label>
                          <input
                            type="text"
                            value={bailiffName}
                            onChange={(e) => setBailiffName(e.target.value)}
                            placeholder="اسم المحضر القائم بالإعلان..."
                            className="w-full px-3 py-1.5 border border-blue-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">تاريخ الإعلان</label>
                          <input
                            type="date"
                            value={bailiffDate}
                            onChange={(e) => setBailiffDate(e.target.value)}
                            className="w-full px-3 py-1.5 border border-blue-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">الدائرة القضائية / جهة المتابعة</label>
                          <input
                            type="text"
                            value={bailiffCircuit}
                            onChange={(e) => setBailiffCircuit(e.target.value)}
                            placeholder="الدائرة (مثال: مدني كلي دمنهور، أسرة بندر دمنهور)..."
                            className="w-full px-3 py-1.5 border border-blue-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 3. Real Estate Registry & Survey (شهر عقاري / توثيق / سجل عيني) */}
                  {(unofficialSubType.includes('شهر عقاري') || unofficialSubType.includes('توثيق') || unofficialSubType.includes('سجل عيني')) && (
                    <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2.5 animate-in fade-in">
                      <div className="font-bold text-xs text-indigo-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-indigo-700" />
                        <span>بيانات الشهر العقاري والسجل العيني:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم التوثيق / المشهر</label>
                          <input
                            type="text"
                            value={registryDocNo}
                            onChange={(e) => setRegistryDocNo(e.target.value)}
                            placeholder="رقم التوثيق أو المشهر..."
                            className="w-full px-3 py-1.5 border border-indigo-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">مكتب التوثيق / المأمورية</label>
                          <input
                            type="text"
                            value={registryOffice}
                            onChange={(e) => setRegistryOffice(e.target.value)}
                            placeholder="مكتب توثيق دمنهور..."
                            className="w-full px-3 py-1.5 border border-indigo-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم القطعة / الحوض المساحي</label>
                          <input
                            type="text"
                            value={cadastralParcelNo}
                            onChange={(e) => setCadastralParcelNo(e.target.value)}
                            placeholder="رقم القطعة أو الحوض..."
                            className="w-full px-3 py-1.5 border border-indigo-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 4. Real Estate Tax (ضرائب عقارية / عوائد) */}
                  {unofficialSubType.includes('ضرائب') && (
                    <div className="p-3 bg-amber-50/90 border border-amber-300 rounded-xl space-y-2.5 animate-in fade-in">
                      <div className="font-bold text-xs text-amber-950 flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-amber-700" />
                        <span>بيانات الضرائب العقارية والعوائد:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم العقار / المكلفة</label>
                          <input
                            type="text"
                            value={taxPropertyNo}
                            onChange={(e) => setTaxPropertyNo(e.target.value)}
                            placeholder="رقم العقار أو رقم المكلفة..."
                            className="w-full px-3 py-1.5 border border-amber-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">الشياخة / المأمورية المختصة</label>
                          <input
                            type="text"
                            value={taxDistrict}
                            onChange={(e) => setTaxDistrict(e.target.value)}
                            placeholder="الشياخة أو المأمورية..."
                            className="w-full px-3 py-1.5 border border-amber-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 5. Courts & Litigation (محاكم وقضايا) */}
                  {unofficialSubType.includes('محاكم') && (
                    <div className="p-3 bg-purple-50/70 border border-purple-200 rounded-xl space-y-2.5 animate-in fade-in">
                      <div className="font-bold text-xs text-purple-950 flex items-center gap-1.5">
                        <FileSearch className="w-3.5 h-3.5 text-purple-700" />
                        <span>بيانات الدعاوى والقضايا:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم القضية / الدعوى</label>
                          <input
                            type="text"
                            value={courtCaseNo}
                            onChange={(e) => setCourtCaseNo(e.target.value)}
                            placeholder="رقم الدعوى..."
                            className="w-full px-3 py-1.5 border border-purple-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">السنة القضائية</label>
                          <input
                            type="text"
                            value={courtYear}
                            onChange={(e) => setCourtYear(e.target.value)}
                            placeholder="مثال: 2023 قضائية..."
                            className="w-full px-3 py-1.5 border border-purple-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">المحكمة / الدائرة</label>
                          <input
                            type="text"
                            value={courtName}
                            onChange={(e) => setCourtName(e.target.value)}
                            placeholder="اسم المحكمة أو الدائرة..."
                            className="w-full px-3 py-1.5 border border-purple-300 rounded-lg bg-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 6. Marriage contracts (عقود زواج) */}
                  {unofficialSubType.includes('عقود') && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          رقم العقد
                        </label>
                        <input
                          type="text"
                          value={contractNumber}
                          onChange={(e) => setContractNumber(e.target.value)}
                          placeholder="رقم العقد المرجعي..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          التاريخ
                        </label>
                        <input
                          type="date"
                          value={contractDate}
                          onChange={(e) => setContractDate(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                        />
                      </div>
                    </div>
                  )}

                  {/* 7. National ID (بطاقة رقم قومي) */}
                  {unofficialSubType.includes('بطاقة') && (
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        الرقم القومي المرجعي
                      </label>
                      <input
                        type="text"
                        maxLength={14}
                        value={nationalIdRef}
                        onChange={(e) => setNationalIdRef(e.target.value)}
                        placeholder="أدخل الرقم القومي (14 رقم)..."
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  )}

                  {/* 8. Cadastral Maps (خرائط مساحية) */}
                  {unofficialSubType.includes('خريطة') && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          نوع الخريطة / المخطط
                        </label>
                        <input
                          type="text"
                          value={mapType}
                          onChange={(e) => setMapType(e.target.value)}
                          placeholder="مثال: خريطة مساحية 1995..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          رقم اللوحة المساحية
                        </label>
                        <input
                          type="text"
                          value={mapSheetNo}
                          onChange={(e) => setMapSheetNo(e.target.value)}
                          placeholder="رقم اللوحة..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          مقياس الرسم
                        </label>
                        <input
                          type="text"
                          value={mapScale}
                          onChange={(e) => setMapScale(e.target.value)}
                          placeholder="مثال: 1:500 أو 1:2500..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                        />
                      </div>
                    </div>
                  )}

                  {/* 9. Custom Source (أخرى / مخصص) */}
                  {unofficialSubType.includes('مخصص') && (
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        اسم وتوصيف المصدر المخصص
                      </label>
                      <input
                        type="text"
                        value={customSourceName}
                        onChange={(e) => setCustomSourceName(e.target.value)}
                        placeholder="اكتب اسم المصدر المخصص وتفاصيله المرجعية..."
                        className="w-full px-3 py-2 border border-amber-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Category & District Options */}
            <div className="pt-2 border-t border-gray-100 space-y-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1.5">
                  التصنيف النوعي للشارع / السجل
                </label>
                
                {/* Dynamic Category Chips from AppSettings */}
                <div className="flex flex-wrap gap-1.5 mb-2.5">
                  {streetCategoriesList.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer border ${
                        category.trim() === cat.trim()
                          ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                          : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2 items-center">
                  <div className="flex-1">
                    <input
                      tabIndex={5}
                      type="text"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      placeholder="اكتب تصنيفاً مخصصاً (مثال: رئيسي، فرعي، حارة، عطفة، ميدان...)"
                      className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-800 text-sm"
                    />
                  </div>
                  {category.trim() !== 'حي' && (
                    <button
                      type="button"
                      onClick={() => setCategory('حي')}
                      className="px-3 py-2 bg-purple-100 hover:bg-purple-200 text-purple-900 text-xs font-bold rounded-xl transition border border-purple-300 cursor-pointer"
                    >
                      تعيين كـ "حي"
                    </button>
                  )}
                </div>
              </div>

              {category.trim() === 'حي' && (
                <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-xl space-y-2.5 animate-in fade-in duration-150">
                  <label className="block text-xs sm:text-sm font-bold text-purple-900">
                    اسم الحي (الأحياء الأصلية أو حي مخصص) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={selectedDistrict}
                    onChange={(e) => setSelectedDistrict(e.target.value)}
                    className="w-full px-3.5 py-2 border border-purple-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-none text-gray-900 text-sm bg-white font-semibold"
                  >
                    <optgroup label="الأحياء الأصلية المعتمدة">
                      {officialDistricts.map((d) => (
                        <option key={d} value={d}>
                          {d} (أصلي)
                        </option>
                      ))}
                    </optgroup>
                    <option value="CUSTOM">حي آخر (غير أصلي / مخصص...)</option>
                  </select>

                  {selectedDistrict === 'CUSTOM' && (
                    <div>
                      <input
                        type="text"
                        value={customDistrict}
                        onChange={(e) => setCustomDistrict(e.target.value)}
                        placeholder="اكتب اسم الحي الجديد..."
                        className="w-full px-3 py-2 border border-purple-300 rounded-lg text-sm bg-white focus:outline-none"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* CARD 3: Metadata & Notes (الملاحظات والمعالم الوصفية) */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-2">
            <div className="flex items-center gap-2 border-b border-gray-100 pb-2">
              <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-xs">
                3
              </span>
              <label className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <FileCheck2 className="w-4 h-4 text-amber-600" />
                <span>البيانات الوصفية / الملاحظات والمعالم</span>
              </label>
            </div>
            <textarea
              tabIndex={6}
              rows={3}
              value={metadata}
              onChange={(e) => setMetadata(e.target.value)}
              placeholder="تفاصيل الموقع، المتفرعات، الشارع الرئيسي، معالم مميزة، تفاصيل تاريخية أو عقارية..."
              className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-800 text-sm"
            />
          </div>

          {/* CARD 4: Audit Log & Legal Documentation (التوثيق القانوني ومسؤول المراجعة) */}
          <div className="bg-white p-4.5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-xs">
                  4
                </span>
                <span className="font-bold text-gray-900 text-xs flex items-center gap-1.5">
                  <History className="w-4 h-4 text-indigo-600" />
                  <span>سجل التعديلات والتوثيق القانوني (Audit Log)</span>
                </span>
                {activeRecord?.auditLogs && activeRecord.auditLogs.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-black text-[10px]">
                    {activeRecord.auditLogs.length} تعديل مسجل
                  </span>
                )}
              </div>

              {activeRecord && (
                <button
                  type="button"
                  onClick={() => setShowAuditModal(true)}
                  className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                >
                  <FileCheck2 className="w-3.5 h-3.5" />
                  <span>عرض السجل القانوني الكامل والشهادة</span>
                </button>
              )}
            </div>

            {/* Auditor Name stored in LocalStorage */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-gray-600 text-xs">
              <div className="flex items-center gap-1.5 flex-wrap">
                <User className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-medium text-[11px]">المستخدم القائم بالتوثيق (LocalStorage):</span>
                {isEditingAuditor ? (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempAuditor}
                      onChange={(e) => setTempAuditor(e.target.value)}
                      className="px-2 py-0.5 text-xs border border-emerald-400 rounded bg-white font-bold text-gray-900"
                      placeholder="اسم الموثق..."
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (tempAuditor.trim()) {
                          setAuditUserName(tempAuditor.trim());
                          setAuditorName(tempAuditor.trim());
                          setIsEditingAuditor(false);
                          setSavedAuditorToast(true);
                          setTimeout(() => setSavedAuditorToast(false), 2000);
                        }
                      }}
                      className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold cursor-pointer"
                    >
                      حفظ
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTempAuditor(auditorName);
                        setIsEditingAuditor(false);
                      }}
                      className="px-1.5 py-0.5 bg-gray-200 text-gray-700 rounded text-[11px] cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <strong className="text-gray-900 bg-slate-50 px-2 py-0.5 rounded border border-gray-200 text-[11px]">
                      {auditorName}
                    </strong>
                    <button
                      type="button"
                      onClick={() => {
                        setTempAuditor(auditorName);
                        setIsEditingAuditor(true);
                      }}
                      className="text-[11px] text-blue-600 hover:underline cursor-pointer"
                    >
                      (تعديل الاسم)
                    </button>
                    {savedAuditorToast && (
                      <span className="text-[10px] text-emerald-600 font-bold">✓ تم الحفظ</span>
                    )}
                  </div>
                )}
              </div>

              {activeRecord && (
                <div className="flex items-center gap-1 text-slate-500 text-[11px]">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>
                    آخر تعديل: <strong className="text-slate-700">{activeRecord.lastModifiedAt || (activeRecord.auditLogs?.[0]?.formattedDate) || 'سجل معتمد'}</strong>
                    {activeRecord.lastModifiedBy && ` (${activeRecord.lastModifiedBy})`}
                  </span>
                </div>
              )}
            </div>

            {/* Quick Preview of previous changes */}
            {activeRecord?.auditLogs && activeRecord.auditLogs.length > 0 && (
              <div className="mt-1 pt-2 border-t border-slate-100">
                <div className="text-[11px] text-slate-500 mb-1 font-semibold flex items-center justify-between">
                  <span>آخر عملية تعديل مسجلة:</span>
                  <span className="text-slate-400">{activeRecord.auditLogs[0].formattedDate}</span>
                </div>
                <div className="space-y-1">
                  {activeRecord.auditLogs[0].changes.map((ch, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-[11px] bg-slate-50 p-1.5 rounded-lg border border-slate-200">
                      <span className="font-bold text-gray-700 min-w-16">{ch.fieldLabel}:</span>
                      <span className="text-rose-700 line-through bg-rose-50 px-1.5 py-0.5 rounded text-[10px] font-medium">{ch.oldValue || 'فارغ'}</span>
                      <ArrowLeft className="w-3 h-3 text-slate-400 shrink-0" />
                      <span className="text-emerald-800 font-bold bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">{ch.newValue || 'فارغ'}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 4. Action Bar with Saving Every New Entry & Safe Return to Table */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-gray-200">
            
            {/* Safe Return Option: Protected from Accidental Mouse Hits */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-bold text-xs transition border border-gray-300 cursor-pointer shadow-2xs group"
                title="العودة لجدول البيانات الرئيسي دون الحاجة للمس الماوس عبر الضغط على [Esc] أو [Alt + X]"
              >
                <LogOut className="w-3.5 h-3.5 text-gray-500 group-hover:-translate-x-0.5 transition-transform" />
                <span>العودة للجدول</span>
                <kbd className="px-1.5 py-0.5 bg-gray-200 text-gray-800 rounded text-[10px] font-mono">
                  Esc
                </kbd>
              </button>
              <span className="hidden lg:inline text-[11px] text-gray-400">
                (خيار الخروج محمي ومتاح أيضاً عبر لوحة المفاتيح)
              </span>
            </div>

            {/* Action Buttons: Explicitly Save as New Record & Sequential Actions */}
            <div className="flex flex-wrap items-center gap-2">
              
              {/* Button: "حفظ كبيان جديد (+ إضافة للمنظومة)" */}
              <button
                type="button"
                onClick={handleSaveAsNewRecord}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-xl font-bold text-xs transition cursor-pointer shadow-xs"
                title="حفظ المدخلات الحالية كبيان شارع جديد مستقل وإضافته فوراً للمنظومة دون تعديل السجل الحالي"
              >
                <FolderPlus className="w-4 h-4 text-amber-700" />
                <span>حفظ كبيان جديد (+ إضافة)</span>
              </button>

              {/* Mode-Specific Action Buttons */}
              {isLocked ? (
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-emerald-100 text-emerald-950 rounded-xl font-black text-xs border border-emerald-300">
                    <Lock className="w-4 h-4 text-emerald-800" />
                    <span>البيان مغلق ومحمي كـ «عنوان الحقيقة 🔒»</span>
                  </span>

                  <button
                    type="button"
                    onClick={handleUnlockRecord}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-amber-950 rounded-xl font-black text-xs transition cursor-pointer shadow-md active:scale-95"
                    title="فك قفل هذا البيان فوراً لتعديل اسم الشارع والملاحظات"
                  >
                    <Unlock className="w-4 h-4 text-amber-950" />
                    <span>فك قفل البيان لتعديل البيانات 🔓</span>
                  </button>

                  {isAuditMode && currentIndex < totalCount - 1 && (
                    <button
                      type="button"
                      onClick={handleGoNext}
                      className="flex items-center gap-1.5 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
                      title="متابعة التالي دون تعديل"
                    >
                      <span>الانتقال للتالي (#{currentIndex + 2})</span>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ) : isAuditMode ? (
                <>
                  <button
                    type="button"
                    onClick={handleSaveAndStay}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-xs transition border border-slate-300 cursor-pointer shadow-xs"
                    title="حفظ التعديلات والبقاء على نفس الشارع لمواصلة الفحص"
                  >
                    <Save className="w-4 h-4 text-slate-600" />
                    <span>حفظ التعديل والبقاء</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveAndClose}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
                    title="حفظ التعديلات والعودة لجدول البيانات"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>حفظ والعودة للجدول</span>
                  </button>

                  {currentIndex < totalCount - 1 && (
                    <button
                      type="button"
                      onClick={handleSaveAndNext}
                      className="flex items-center gap-1.5 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
                      title="حفظ التعديلات والانتقال لمراجعة الشارع التالي رقمياً (Ctrl + Enter)"
                    >
                      <span>حفظ ومتابعة التالي (#{currentIndex + 2}) ↵</span>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  )}
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={handleSaveAndAddNew}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl font-bold text-xs transition cursor-pointer shadow-xs"
                    title="حفظ هذا الشارع ثم إفراغ النموذج لإضافة شارع آخر جديد فوراً"
                  >
                    <Plus className="w-4 h-4 text-emerald-700" />
                    <span>حفظ وإضافة بيان آخر</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveAndClose}
                    className="flex items-center gap-1.5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer"
                    title="حفظ هذا الشارع والعودة لجدول البيانات"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>حفظ البيان والعودة للجدول</span>
                  </button>
                </>
              )}
            </div>

          </div>

        </form>
      </div>

      {/* 5. SIDE DRAWER: Prefix Management System (القائمة الجانبية الصافية لإدارة البادئات لتقليل التشتت البصري) */}
      {isPrefixDrawerOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end animate-in fade-in duration-200">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity cursor-pointer"
            onClick={() => setIsPrefixDrawerOpen(false)}
          />

          {/* Lateral Slide-out Drawer Panel */}
          <div className="relative w-full max-w-md bg-white shadow-2xl border-r border-gray-200 flex flex-col h-full z-10 animate-in slide-in-from-left duration-200" dir="rtl">
            
            {/* Drawer Header */}
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Tag className="w-5 h-5 text-indigo-400" />
                <div>
                  <h3 className="font-bold text-base">القائمة الجانبية لإدارة البادئات</h3>
                  <p className="text-[11px] text-white/70">تنظيم وإضافة وحذف البادئات بدون تشتيت مساحة العمل</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPrefixDrawerOpen(false)}
                className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
                title="إغلاق القائمة الجانبية (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Content */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              
              {/* Add New Prefix Box */}
              <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2">
                <label className="block text-xs font-bold text-indigo-950">
                  إضافة بادئة مخصصة جديدة للمنظومة:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newPrefixInput}
                    onChange={(e) => setNewPrefixInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomPrefix(newPrefixInput);
                      }
                    }}
                    placeholder="مثال: نجع، درب، حوش، عمارة..."
                    className="flex-1 px-3 py-2 border border-indigo-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-gray-900"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => handleAddCustomPrefix(newPrefixInput)}
                    disabled={!newPrefixInput.trim()}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة وحفظ</span>
                  </button>
                </div>
                <p className="text-[11px] text-indigo-800">
                  تُحفظ البادئة المضافة في LocalStorage وتطبق تلقائياً على الشارع الحالي وكافة النماذج.
                </p>
              </div>

              {/* Filter */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={prefixSearchFilter}
                  onChange={(e) => setPrefixSearchFilter(e.target.value)}
                  placeholder="تصفية البادئات..."
                  className="w-full pr-8 pl-3 py-2 border border-gray-200 rounded-lg text-xs bg-slate-50 focus:outline-none focus:ring-1 focus:ring-indigo-400"
                />
              </div>

              {/* User Custom Prefixes */}
              {(() => {
                const custom = getCustomPrefixes().filter(p => !prefixSearchFilter || p.includes(prefixSearchFilter));
                return custom.length > 0 ? (
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-gray-700 block">
                      البادئات المخصصة المضافة من قبلك ({custom.length}):
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {custom.map((p) => (
                        <span 
                          key={p} 
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-purple-50 text-purple-950 border border-purple-300 rounded-lg text-xs font-bold"
                        >
                          <span 
                            onClick={() => {
                              setPrefix(p);
                              setCategory(p);
                              setIsPrefixDrawerOpen(false);
                            }}
                            className="cursor-pointer hover:underline"
                            title="اختيار هذه البادئة للشارع الحالي"
                          >
                            {p}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleRemoveCustomPrefix(p)}
                            className="text-purple-600 hover:text-red-700 p-0.5 cursor-pointer"
                            title="حذف هذه البادئة المخصصة"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                ) : null;
              })()}

              {/* Default Standard Prefixes */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-gray-700 block">
                  البادئات القياسية المعتمدة بالمنظومة ({DEFAULT_STREET_PREFIXES.length}):
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {DEFAULT_STREET_PREFIXES
                    .filter(p => !prefixSearchFilter || p.includes(prefixSearchFilter))
                    .map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => {
                          setPrefix(p);
                          setCategory(p);
                          setIsPrefixDrawerOpen(false);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition cursor-pointer ${
                          prefix === p 
                            ? 'bg-emerald-600 text-white border-emerald-700 font-bold' 
                            : 'bg-gray-50 hover:bg-gray-100 text-gray-800 border-gray-200'
                        }`}
                        title="انقر لتطبيق هذه البادئة فوراً"
                      >
                        {p}
                      </button>
                    ))}
                </div>
              </div>

            </div>

            {/* Drawer Footer */}
            <div className="px-5 py-3.5 bg-slate-50 border-t border-gray-200 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetPrefixes}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                title="استعادة قائمة البادئات الافتراضية الأصلية"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>استعادة القياسية</span>
              </button>

              <button
                type="button"
                onClick={() => setIsPrefixDrawerOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition cursor-pointer"
              >
                إغلاق القائمة
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 6. MODAL: Audit Log Full Certificate Modal */}
      {showAuditModal && (
        <AuditLogModal
          record={(isAuditMode && existingRecords[currentIndex]) ? existingRecords[currentIndex] : (editRecord || null)}
          onClose={() => setShowAuditModal(false)}
        />
      )}

    </div>
  );
};
