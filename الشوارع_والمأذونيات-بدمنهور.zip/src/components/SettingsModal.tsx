import React, { useState, useMemo } from 'react';
import { 
  X, 
  Settings, 
  Type, 
  Palette, 
  Layout, 
  Sliders, 
  Download, 
  Upload, 
  ShieldCheck, 
  BarChart3, 
  Database, 
  RefreshCw, 
  FileSpreadsheet, 
  AlertTriangle, 
  Building, 
  CheckCircle2, 
  TrendingUp, 
  UserCheck, 
  Calendar, 
  Clock,
  Eye,
  BookOpen,
  MousePointerClick,
  Lock,
  Edit3,
  Trash2,
  Sparkles,
  Check
} from 'lucide-react';
import { ThemeType, RecordItem, AppSettings, ViewModeType } from '../types';
import { getFormattedDatabaseTimestamps } from '../utils/dateTimeUtils';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  records: RecordItem[];
  onExportJSON: () => void;
  onImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetData: () => void;
  onRepairMojibake?: () => void;
  onOpenImport?: () => void;
  onOpenAdvancedExport?: () => void;
  initialTab?: 'stats' | 'modes' | 'appearance' | 'data' | 'workspace';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  theme,
  setTheme,
  records,
  onExportJSON,
  onImportJSON,
  onResetData,
  onRepairMojibake,
  onOpenImport,
  onOpenAdvancedExport,
  initialTab = 'stats'
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'modes' | 'appearance' | 'data'>(
    initialTab === 'modes' ? 'modes' : initialTab === 'appearance' ? 'appearance' : initialTab === 'data' ? 'data' : 'stats'
  );
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Sync initial tab when opened
  React.useEffect(() => {
    if (isOpen && initialTab) {
      if (initialTab === 'modes') setActiveTab('modes');
      else if (initialTab === 'appearance') setActiveTab('appearance');
      else if (initialTab === 'data') setActiveTab('data');
      else setActiveTab('stats');
      setShowResetConfirm(false);
    }
  }, [isOpen, initialTab]);

  // Statistics computations
  const stats = useMemo(() => {
    const total = records.length;
    if (total === 0) {
      return {
        total: 0,
        officialTotal: 0,
        unofficialTotal: 0,
        officialDistricts: [],
        categories: []
      };
    }

    const officialKeys = [
      { name: 'شبرا بحري', key: 'شبرا بحري' },
      { name: 'شبرا قبلي', key: 'شبرا قبلي' },
      { name: 'إفلاقة وتوابعها', key: 'إفلاقة' },
      { name: 'قرطسا وتوابعها', key: 'قرطسا' },
      { name: 'نقرها أول وتوابعها', key: 'نقرها أول' },
      { name: 'نقرها ثان وتوابعها', key: 'نقرها ثان' },
      { name: 'أبو الريش وتوابعها', key: 'الريش' }
    ];

    const officialDistricts = officialKeys.map(dist => {
      const count = records.filter(r => (r.permission || '').includes(dist.key)).length;
      const percentage = total > 0 ? ((count / total) * 100).toFixed(1) : '0';
      return { ...dist, count, percentage };
    });

    const officialTotal = officialDistricts.reduce((acc, curr) => acc + curr.count, 0);
    const unofficialTotal = total - officialTotal;

    // Category distribution
    const categoryMap: Record<string, number> = {};
    records.forEach(r => {
      const cat = r.category || 'شارع';
      categoryMap[cat] = (categoryMap[cat] || 0) + 1;
    });

    const categories = Object.entries(categoryMap)
      .map(([name, count]) => ({
        name,
        count,
        percentage: ((count / total) * 100).toFixed(1)
      }))
      .sort((a, b) => b.count - a.count);

    return {
      total,
      officialTotal,
      unofficialTotal,
      officialDistricts,
      categories
    };
  }, [records]);

  if (!isOpen) return null;

  const fontOptions = [
    { label: 'كاهرو (Cairo)', value: 'font-cairo, sans-serif' },
    { label: 'تجوال (Tajawal)', value: 'font-tajawal, sans-serif' },
    { label: 'دبي (Dubai)', value: 'font-dubai, sans-serif' },
    { label: 'أميري (Amiri - رسمي كلاسيكي)', value: 'font-amiri, serif' },
    { label: 'تاهوما / الافتراضي', value: 'Tahoma, Arial, sans-serif' }
  ];

  const handleFontChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onUpdateSettings({ ...settings, fontFamily: e.target.value });
  };

  const handleFontSizeChange = (size: 'sm' | 'base' | 'lg' | 'xl') => {
    onUpdateSettings({ ...settings, fontSize: size });
  };

  const handlePrintFontSizeChange = (size: string) => {
    onUpdateSettings({ ...settings, printFontSize: size });
  };

  const handleDensityChange = (density: 'compact' | 'normal' | 'relaxed') => {
    onUpdateSettings({ ...settings, tableDensity: density });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-gray-100 flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header */}
        <div className="px-6 py-4 bg-gray-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <Settings className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold">لوحة الإعدادات والإحصائيات الشاملة</h3>
              <p className="text-xs text-gray-300">التحليلات الرقمية • المظهر والثيم • إدارة النسخ الاحتياطي والبيانات</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 rounded-xl hover:bg-white/20 transition text-gray-300 hover:text-white cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation Navigation Bar */}
        <div className="bg-gray-50 border-b border-gray-200 px-6 pt-3 flex flex-wrap gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'stats'
                ? 'bg-white text-emerald-700 border-emerald-600 shadow-xs'
                : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-emerald-600" />
            <span>الإحصائيات والتحليلات الرقمية</span>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black">
              {records.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('modes')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'modes'
                ? 'bg-white text-emerald-700 border-emerald-600 shadow-xs'
                : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <span>أوضاع العمل (القراءة / التعديل بالماوس)</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
              settings.viewMode === 'reading' 
                ? 'bg-blue-100 text-blue-800' 
                : settings.viewMode === 'mouse_edit' 
                  ? 'bg-amber-100 text-amber-800' 
                  : 'bg-gray-200 text-gray-700'
            }`}>
              {settings.viewMode === 'reading' ? 'وضع القراءة نشط' : settings.viewMode === 'mouse_edit' ? 'وضع الماوس نشط' : 'الوضع العادي'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('appearance')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'appearance'
                ? 'bg-white text-emerald-700 border-emerald-600 shadow-xs'
                : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
            }`}
          >
            <Palette className="w-4 h-4 text-purple-600" />
            <span>المظهر، الثيم، والخطوط</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('data')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-b-2 cursor-pointer ${
              activeTab === 'data'
                ? 'bg-white text-emerald-700 border-emerald-600 shadow-xs'
                : 'text-gray-600 hover:text-gray-900 border-transparent hover:bg-gray-100'
            }`}
          >
            <Database className="w-4 h-4 text-blue-600" />
            <span>إدارة البيانات، الاستيراد، والنسخ الاحتياطي</span>
          </button>
        </div>

        {/* Tab Contents Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-right">
          
          {/* TAB: WORK & INTERACTION MODES */}
          {activeTab === 'modes' && (
            <div className="space-y-6">
              
              <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-emerald-50 border border-blue-200/80 rounded-2xl p-4 sm:p-5 text-gray-900 space-y-2 shadow-xs">
                <div className="flex items-center gap-2.5 text-base font-bold text-gray-950">
                  <Sliders className="w-5 h-5 text-emerald-700" />
                  <span>تخصيص نمط التفاعل وتجربة العمل مع السجلات</span>
                </div>
                <p className="text-xs text-gray-700 leading-relaxed">
                  يمكنك الاختيار بين <strong>«وضع القراءة الآمن»</strong> لاستعراض وبحث البيانات بنصوص واضحة وحماية تامة ضد التعديل أو الحذف بالخطأ، أو <strong>«وضع التعديل المريح بالماوس»</strong> لتسريع عمليات التعديل والتنقل المباشر، أو <strong>«الوضع القياسي»</strong> المعتاد.
                </p>
              </div>

              {/* Mode Selection Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* 1. Reading Mode Card */}
                <div 
                  onClick={() => onUpdateSettings({ ...settings, viewMode: 'reading' })}
                  className={`rounded-2xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                    settings.viewMode === 'reading'
                      ? 'border-blue-600 bg-blue-50/70 shadow-md ring-2 ring-blue-500/20'
                      : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50/30'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="p-2.5 bg-blue-100 text-blue-800 rounded-xl">
                        <Eye className="w-6 h-6 text-blue-700" />
                      </div>
                      {settings.viewMode === 'reading' ? (
                        <span className="flex items-center gap-1 px-2.5 py-1 bg-blue-600 text-white rounded-full text-xs font-black shadow-xs">
                          <Check className="w-3.5 h-3.5" />
                          <span>الوضع النشط حالياً</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                          انقر للتفعيل
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="text-base font-black text-blue-950 flex items-center gap-1.5">
                        <span>1- وضع القراءة الآمن</span>
                        <Lock className="w-4 h-4 text-blue-600" />
                      </h4>
                      <p className="text-xs text-blue-800 font-bold mt-0.5">
                        (حماية فائقة + خطوط كبيرة + تباين عالي)
                      </p>
                    </div>

                    <div className="space-y-1.5 text-xs text-gray-700 border-t border-blue-200/60 pt-3">
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span><strong>إخفاء أزرار التعديل والحذف</strong> بالكامل من كافة الصفوف لتجنب أي تغيير غير مقصود.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span><strong>تكبير حجم الخط</strong> تلقائياً مع تباعد مريح للأسطر لسهولة القراءة.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span><strong>تباين ألوان عالي</strong> وحواف واضحة للتمييز البصري المريح.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span><strong>تعطيل التعديل بالنقر المزدوج</strong> لحماية السجلات من أي نقرة خاطئة.</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateSettings({ ...settings, viewMode: 'reading' });
                    }}
                    className={`mt-4 w-full py-2.5 rounded-xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                      settings.viewMode === 'reading'
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-white hover:bg-blue-100 text-blue-900 border border-blue-300'
                    }`}
                  >
                    <Eye className="w-4 h-4" />
                    <span>{settings.viewMode === 'reading' ? 'مفعل الآن' : 'تفعيل وضع القراءة'}</span>
                  </button>
                </div>

                {/* 2. Mouse Edit Mode Card */}
                <div 
                  onClick={() => onUpdateSettings({ ...settings, viewMode: 'mouse_edit' })}
                  className={`rounded-2xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                    settings.viewMode === 'mouse_edit'
                      ? 'border-amber-600 bg-amber-50/70 shadow-md ring-2 ring-amber-500/20'
                      : 'border-gray-200 bg-white hover:border-amber-300 hover:bg-amber-50/30'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="p-2.5 bg-amber-100 text-amber-900 rounded-xl">
                        <MousePointerClick className="w-6 h-6 text-amber-700" />
                      </div>
                      {settings.viewMode === 'mouse_edit' ? (
                        <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-600 text-white rounded-full text-xs font-black shadow-xs">
                          <Check className="w-3.5 h-3.5" />
                          <span>الوضع النشط حالياً</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                          انقر للتفعيل
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="text-base font-black text-amber-950 flex items-center gap-1.5">
                        <span>2- وضع التعديل المريح بالماوس</span>
                        <Sparkles className="w-4 h-4 text-amber-600" />
                      </h4>
                      <p className="text-xs text-amber-800 font-bold mt-0.5">
                        (أزرار كبيرة + نقرة واحدة للمأذونية والملاحظات)
                      </p>
                    </div>

                    <div className="space-y-1.5 text-xs text-gray-700 border-t border-amber-200/60 pt-3">
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>أزرار تعديل وحذف وملاحظات كبيرة</strong> واضحة في كل صف لسهولة الاستهداف بالفأرة.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>تغيير المأذونية بنقرة واحدة سريعة</strong> مباشرة على الشارة دون فتح نوافذ ثقيلة.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>شريط إجراءات عائم عند تمرير الماوس</strong> (Hover Bar) لسرعة اتخاذ القرار.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>مساحات نقر رحبة (40px+)</strong> تمنع إجهاد اليد ودقة التصويب أثناء العمل الطويل.</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateSettings({ ...settings, viewMode: 'mouse_edit' });
                    }}
                    className={`mt-4 w-full py-2.5 rounded-xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                      settings.viewMode === 'mouse_edit'
                        ? 'bg-amber-600 hover:bg-amber-700 text-white'
                        : 'bg-white hover:bg-amber-100 text-amber-900 border border-amber-300'
                    }`}
                  >
                    <MousePointerClick className="w-4 h-4" />
                    <span>{settings.viewMode === 'mouse_edit' ? 'مفعل الآن' : 'تفعيل وضع التعديل بالماوس'}</span>
                  </button>
                </div>

                {/* 3. Standard Mode Card */}
                <div 
                  onClick={() => onUpdateSettings({ ...settings, viewMode: 'normal' })}
                  className={`rounded-2xl border-2 p-5 flex flex-col justify-between transition-all cursor-pointer relative ${
                    settings.viewMode === 'normal' || !settings.viewMode
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-md ring-2 ring-emerald-500/20'
                      : 'border-gray-200 bg-white hover:border-emerald-300 hover:bg-emerald-50/30'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="p-2.5 bg-emerald-100 text-emerald-900 rounded-xl">
                        <Sliders className="w-6 h-6 text-emerald-700" />
                      </div>
                      {settings.viewMode === 'normal' || !settings.viewMode ? (
                        <span className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 text-white rounded-full text-xs font-black shadow-xs">
                          <Check className="w-3.5 h-3.5" />
                          <span>الوضع النشط حالياً</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md text-[10px] font-bold">
                          انقر للتفعيل
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="text-base font-black text-emerald-950">3- الوضع القياسي المعتاد</h4>
                      <p className="text-xs text-emerald-800 font-bold mt-0.5">
                        (التخطيط المتوازن الافتراضي)
                      </p>
                    </div>

                    <div className="space-y-1.5 text-xs text-gray-700 border-t border-emerald-200/60 pt-3">
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>التنسيق المكتبي المتوازن مع كافة أزرار التعديل والحذف القياسية.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>يدعم النقر المزدوج للتعديل السريع وقوائم النقر الأيمن.</span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>مناسب للأجهزة المكتبية والشاشات العادية بكثافة قياسية.</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateSettings({ ...settings, viewMode: 'normal' });
                    }}
                    className={`mt-4 w-full py-2.5 rounded-xl text-xs font-black transition shadow-xs flex items-center justify-center gap-1.5 ${
                      settings.viewMode === 'normal' || !settings.viewMode
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                    }`}
                  >
                    <Sliders className="w-4 h-4" />
                    <span>{settings.viewMode === 'normal' || !settings.viewMode ? 'مفعل الآن' : 'تفعيل الوضع القياسي'}</span>
                  </button>
                </div>

              </div>

              {/* Advanced Customizations for Reading Mode */}
              <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4 shadow-xs">
                <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <Eye className="w-4 h-4 text-blue-600" />
                  <span>تخصيص تفاصيل «وضع القراءة الآمن»</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Reading Mode Font Size */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-gray-700">حجم خط أسماء الشوارع في وضع القراءة:</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { label: 'كبير (LG)', value: 'lg' },
                        { label: 'كبير جداً (XL)', value: 'xl' },
                        { label: 'ضخم مريح (2XL)', value: '2xl' }
                      ].map(item => (
                        <button
                          key={item.value}
                          type="button"
                          onClick={() => onUpdateSettings({ ...settings, readingModeFontSize: item.value as any })}
                          className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                            (settings.readingModeFontSize || 'xl') === item.value
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Reading Mode Contrast Option */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-gray-700">مستوى تباين الألوان في وضع القراءة:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, readingModeHighContrast: true })}
                        className={`py-2 px-2 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                          settings.readingModeHighContrast !== false
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        تباين عالي فائق الوضوح
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, readingModeHighContrast: false })}
                        className={`py-2 px-2 text-center rounded-xl border text-xs font-bold transition cursor-pointer ${
                          settings.readingModeHighContrast === false
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        تباين مكتبي ناعم
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Advanced Customizations for Mouse Edit Mode */}
              <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4 shadow-xs">
                <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <MousePointerClick className="w-4 h-4 text-amber-600" />
                  <span>تخصيص تفاصيل «وضع التعديل المريح بالماوس»</span>
                </h4>

                <div className="space-y-3">
                  <label className="flex items-center justify-between p-3 bg-amber-50/50 rounded-xl border border-amber-200 cursor-pointer">
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-amber-950">تفعيل أزرار التعديل والحذف الواسعة (Touch/Click Expanded Targets)</span>
                      <p className="text-[11px] text-amber-800">يمنح الأزرار مساحات نقر كبيرة 40px+ لسرعة وسهولة الضغط بالماوس.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.mouseEditQuickTouch !== false}
                      onChange={(e) => onUpdateSettings({ ...settings, mouseEditQuickTouch: e.target.checked })}
                      className="w-4 h-4 text-amber-600 rounded border-gray-300 focus:ring-amber-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

            </div>
          )}
          
          {/* TAB 1: STATISTICS & ANALYTICS */}
          {activeTab === 'stats' && (
            <div className="space-y-6">
              
              {/* Summary KPIs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">إجمالي الشوارع والسجلات</span>
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-emerald-950">
                    {stats.total.toLocaleString('ar-EG')}
                  </div>
                  <p className="text-[11px] text-emerald-700 mt-1">مرتبة ومفهرسة أبجدياً بالكامل</p>
                </div>

                <div className="p-4 bg-purple-50/80 border border-purple-200 rounded-2xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-800">شوارع المأذونيات الرسمية</span>
                    <Building className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-purple-950">
                    {stats.officialTotal.toLocaleString('ar-EG')}
                  </div>
                  <p className="text-[11px] text-purple-700 mt-1">
                    تمثل {stats.total > 0 ? ((stats.officialTotal / stats.total) * 100).toFixed(1) : 0}% من إجمالي المنظومة
                  </p>
                </div>

                <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-800">الشوارع الحرة / داتا خاصة</span>
                    <TrendingUp className="w-4 h-4 text-amber-600" />
                  </div>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-amber-950">
                    {stats.unofficialTotal.toLocaleString('ar-EG')}
                  </div>
                  <p className="text-[11px] text-amber-700 mt-1">
                    تمثل {stats.total > 0 ? ((stats.unofficialTotal / stats.total) * 100).toFixed(1) : 0}% خارج النطاق الرسمي
                  </p>
                </div>
              </div>

              {/* Breakdown by 7 Official Districts */}
              <div className="bg-white border border-gray-200 rounded-2xl p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Building className="w-4 h-4 text-emerald-600" />
                    <span>توزيع المأذونيات السبع الرسمية المعتمدة</span>
                  </h4>
                  <span className="text-xs text-gray-500 font-medium">النسبة من الإجمالي الكلي</span>
                </div>

                <div className="space-y-3">
                  {stats.officialDistricts.map((dist, idx) => (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-semibold text-gray-800">
                        <span className="font-bold">{dist.name}</span>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-gray-900 font-bold">{dist.count} شارع</span>
                          <span className="text-gray-500 text-[11px]">({dist.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div 
                          className="bg-emerald-600 h-2 rounded-full transition-all duration-500" 
                          style={{ width: `${Math.min(100, Math.max(3, parseFloat(dist.percentage) * 2))}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Category Breakdown & Advanced Export Launcher */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Categories */}
                <div className="bg-white border border-gray-200 rounded-2xl p-4 space-y-3 shadow-xs">
                  <h4 className="text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Layout className="w-4 h-4 text-blue-600" />
                    <span>توزيع أنواع السجلات (شارع / حارة / زقاق...)</span>
                  </h4>
                  <div className="space-y-2">
                    {stats.categories.slice(0, 6).map((cat, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-gray-50 last:border-0">
                        <span className="font-medium text-gray-700">{cat.name}</span>
                        <span className="font-bold text-gray-900 bg-gray-100 px-2 py-0.5 rounded-md">
                          {cat.count} ({cat.percentage}%)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Direct Action for Advanced Export */}
                <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-5 flex flex-col justify-between">
                  <div className="space-y-2">
                    <h4 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
                      <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                      <span>تصدير تقرير الإحصائيات والتصنيفات</span>
                    </h4>
                    <p className="text-xs text-emerald-800 leading-relaxed">
                      يمكنك استخراج ملف Excel متكامل مع أوراق عمل مخصصة ومفصولة لكل مأذونية رسمية على حدة، مع ترقيم متسلسل وجداول مقارنة.
                    </p>
                  </div>
                  {onOpenAdvancedExport && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAdvancedExport();
                      }}
                      className="mt-4 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                      <span>فتح نافذة التصدير المتقدم والتصنيفي</span>
                    </button>
                  )}
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: APPEARANCE & THEME */}
          {activeTab === 'appearance' && (
            <div className="space-y-6">
              
              {/* Theme selection */}
              <div className="space-y-3">
                <label className="flex items-center gap-2 text-sm font-bold text-gray-900">
                  <Palette className="w-4 h-4 text-purple-600" />
                  <span>ثيم وألوان الواجهة العامة للمنظومة</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setTheme('excel')}
                    className={`p-3.5 rounded-xl border text-right transition cursor-pointer ${
                      theme === 'excel' 
                        ? 'bg-emerald-50 border-emerald-600 ring-2 ring-emerald-500 shadow-xs' 
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-950">اكسيل أخضر كلاسيكي</span>
                      {theme === 'excel' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-emerald-800 mt-1">مظهر مكتبي مألوف ومريح للعين مع ألوان الجداول الرسمية</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTheme('libreoffice')}
                    className={`p-3.5 rounded-xl border text-right transition cursor-pointer ${
                      theme === 'libreoffice' 
                        ? 'bg-cyan-50 border-cyan-600 ring-2 ring-cyan-500 shadow-xs' 
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-950">ليبراأوفيس لينكس</span>
                      {theme === 'libreoffice' && <CheckCircle2 className="w-4 h-4 text-cyan-600" />}
                    </div>
                    <p className="text-[11px] text-cyan-800 mt-1">ثيم سماوي هادئ مطابق لبرمجيات لينكس والمؤسسات</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTheme('modern')}
                    className={`p-3.5 rounded-xl border text-right transition cursor-pointer ${
                      theme === 'modern' 
                        ? 'bg-indigo-50 border-indigo-600 ring-2 ring-indigo-500 shadow-xs' 
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-indigo-950">عصري كحلي (Modern)</span>
                      {theme === 'modern' && <CheckCircle2 className="w-4 h-4 text-indigo-600" />}
                    </div>
                    <p className="text-[11px] text-indigo-800 mt-1">طراز حديث عالي التباين مع عناصر بصرية متطورة</p>
                  </button>
                </div>
              </div>

              <hr className="border-gray-200" />

              {/* Program Font Family */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-gray-800">
                  <Type className="w-4 h-4 text-emerald-600" />
                  <span>خط البرنامج والنصوص (واجهة العرض)</span>
                </label>
                <select
                  value={settings.fontFamily}
                  onChange={handleFontChange}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-xl bg-white text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium cursor-pointer"
                >
                  {fontOptions.map(font => (
                    <option key={font.value} value={font.value}>{font.label}</option>
                  ))}
                </select>
              </div>

              {/* Program Font Size */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-gray-800">
                  <Sliders className="w-4 h-4 text-emerald-600" />
                  <span>حجم خط الواجهة والعرض</span>
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: 'صغير', value: 'sm' },
                    { label: 'متوسط (عادي)', value: 'base' },
                    { label: 'كبير', value: 'lg' },
                    { label: 'كبير جداً', value: 'xl' }
                  ].map(item => (
                    <button
                      key={item.value}
                      type="button"
                      onClick={() => handleFontSizeChange(item.value as any)}
                      className={`py-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                        settings.fontSize === item.value 
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs' 
                          : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-gray-200" />

              {/* Print Font Size */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-gray-800">
                  <Type className="w-4 h-4 text-amber-600" />
                  <span>حجم خط الطباعة وتقارير PDF</span>
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {['10pt', '11pt', '12pt', '14pt'].map(size => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => handlePrintFontSizeChange(size)}
                      className={`py-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                        settings.printFontSize === size 
                          ? 'bg-amber-600 text-white border-amber-600 shadow-xs' 
                          : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Table Density & Coloring */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-gray-800">
                  <Layout className="w-4 h-4 text-emerald-600" />
                  <span>كثافة الخلايا والتلوين التناوبي (Zebra Striping)</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'مضغوط', value: 'compact' },
                    { label: 'عادي', value: 'normal' },
                    { label: 'مريح وواسع', value: 'relaxed' }
                  ].map(item => (
                    <button
                      key={item.value}
                      type="button"
                      onClick={() => handleDensityChange(item.value as any)}
                      className={`py-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                        settings.tableDensity === item.value 
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs' 
                          : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                <span className="text-xs font-bold text-gray-800">تفعيل تلوين الصفوف بالتناوب (أبيض / رمادي فاتح)</span>
                <input
                  type="checkbox"
                  checked={settings.enableZebra}
                  onChange={(e) => onUpdateSettings({ ...settings, enableZebra: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              <hr className="border-gray-200" />

              {/* Reviewer & Documentation Stamps in Exports */}
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold text-emerald-950">
                    <UserCheck className="w-4 h-4 text-emerald-700" />
                    <span>بيانات المراجع وتوثيق مستندات التصدير</span>
                  </div>
                  <label className="flex items-center gap-2 text-xs font-bold text-emerald-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.includeTimestampsInExports ?? true}
                      onChange={(e) => onUpdateSettings({ ...settings, includeTimestampsInExports: e.target.checked })}
                      className="w-4 h-4 accent-emerald-600 rounded"
                    />
                    <span>تضمين التاريخ والمراجع تلقائياً</span>
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">اسم المراجع الافتراضي للسجلات:</label>
                    <input
                      type="text"
                      value={settings.reviewerName ?? 'مراجع السجلات المعتمد'}
                      onChange={(e) => onUpdateSettings({ ...settings, reviewerName: e.target.value })}
                      placeholder="أدخل اسم المراجع أو الصفة الرسمية"
                      className="w-full px-3 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-bold"
                    />
                  </div>
                  <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-100 flex flex-col justify-center text-[11px] text-emerald-900">
                    {(() => {
                      const ts = getFormattedDatabaseTimestamps();
                      return (
                        <>
                          <span className="font-bold flex items-center gap-1">
                            <Clock className="w-3 h-3 text-emerald-600" />
                            التاريخ الميلادي: {ts.gregorianDate} ({ts.gregorianTime})
                          </span>
                          <span className="font-bold text-emerald-700 flex items-center gap-1 mt-0.5">
                            <Calendar className="w-3 h-3 text-emerald-600" />
                            التاريخ الهجري: {ts.hijriDate}
                          </span>
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: DATA MANAGEMENT & BACKUP */}
          {activeTab === 'data' && (
            <div className="space-y-6">
              
              {/* Import Excel / CSV Quick Link */}
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-blue-950 font-bold text-sm">
                    <Upload className="w-5 h-5 text-blue-700" />
                    <span>استيراد وتغذية البيانات من ملفات Excel و CSV</span>
                  </div>
                  {onOpenImport && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenImport();
                      }}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      فتح نافذة الاستيراد
                    </button>
                  )}
                </div>
                <p className="text-xs text-blue-800 leading-relaxed">
                  يمكنك رفع ملفات Excel (.xlsx, .xls) أو CSV وإضافتها لقاعدة البيانات مع مطابقة الأعمدة تلقائياً وفرزها أبجدياً فوراً.
                </p>
              </div>

              {/* Arabic Mojibake Repair Tool */}
              {onRepairMojibake && (
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-950 font-bold text-sm">
                      <RefreshCw className="w-5 h-5 text-amber-700" />
                      <span>فحص وإصلاح تشويه الحروف والرموز العربية (Mojibake Fixer)</span>
                    </div>
                    <button
                      type="button"
                      onClick={onRepairMojibake}
                      className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>إصلاح فوري للترميز</span>
                    </button>
                  </div>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    إذا ظهرت بعض الشوارع برموز لاتينية أو مشوهة (مثل Ø أو © أو علامات استفهام) ناتجة عن استيراد ملفات قديمة، يقوم هذا الزر بفحص كافة سجلات قاعدة البيانات وترميم الكلمات العربية تلقائياً وإعادة ترتيبها أبجدياً.
                  </p>
                </div>
              )}

              {/* JSON Auto Backup & Restore Section */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5 text-emerald-700" />
                  <span>النسخ الاحتياطي التلقائي الشامل (ملف JSON)</span>
                </div>
                <p className="text-xs text-emerald-800 leading-relaxed">
                  يقوم النظام بحفظ نسختك في الذاكرة المحلية دورياً كل دقيقة. يمكنك تنزيل ملف النسخ الاحتياطي الكامل، أو استعادته في أي وقت وعلى أي جهاز لضمان سلامة كامل البيانات.
                </p>
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onExportJSON}
                    className="flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل نسخة احتياطية كاملة (JSON)</span>
                  </button>

                  <label className="flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer">
                    <Upload className="w-4 h-4 text-emerald-700" />
                    <span>استعادة البيانات من ملف JSON</span>
                    <input type="file" accept=".json" onChange={onImportJSON} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Danger Zone: Reset to Default Data */}
              <div className="bg-red-50/70 border border-red-200 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-red-900 font-bold text-sm">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  <span>منطقة الأمان القصوى: إعادة تعيين البيانات الأصلية</span>
                </div>
                <p className="text-xs text-red-800 leading-relaxed">
                  تم نقل هذا الإجراء من الشريط العلوي إلى هنا لمنع الضغط غير المقصود. يؤدي هذا الإجراء إلى مسح أية تعديلات تم إدخالها محلياً واستعادة الداتا النموذجية المعتمدة (أكثر من 3000 شارع).
                </p>

                {!showResetConfirm ? (
                  <button
                    type="button"
                    onClick={() => setShowResetConfirm(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-red-100 hover:bg-red-200 text-red-900 border border-red-300 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
                  >
                    <RefreshCw className="w-4 h-4 text-red-700" />
                    <span>طلب إعادة ضبط البيانات الأصلية</span>
                  </button>
                ) : (
                  <div className="p-3 bg-red-100/90 border border-red-300 rounded-xl space-y-3">
                    <p className="text-xs font-bold text-red-950">
                      ⚠️ هل أنت متأكد تماماً؟ سيتم استبدال البيانات الحالية بالسجلات الأصلية. يُفضل تنزيل نسخة احتياطية JSON أولاً.
                    </p>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          onResetData();
                          setShowResetConfirm(false);
                          onClose();
                        }}
                        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow cursor-pointer"
                      >
                        نعم، إعادة التعيين الآن
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowResetConfirm(false)}
                        className="px-4 py-2 bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                      >
                        إلغاء التراجع
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-gray-500 font-medium">
            يتم حفظ الإعدادات والمظهر تلقائياً في المتصفح
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-bold text-xs sm:text-sm transition shadow cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
