import React, { useState, useRef, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  Printer, 
  Upload, 
  Plus, 
  Palette, 
  ListPlus,
  Settings,
  CheckCircle,
  BarChart3,
  Download,
  ChevronDown,
  FileDown,
  FileJson,
  Database,
  Menu,
  Keyboard,
  ShieldCheck,
  Compass,
  MapPin,
  Eye,
  MousePointerClick,
  Sliders,
  BookOpen,
  Wrench,
  Layers,
  FileSearch
} from 'lucide-react';
import { ThemeType, AppSettings, ViewModeType } from '../types';
import { getThemeColors } from '../utils/themeConfig';

interface HeaderProps {
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  settings: AppSettings;
  onUpdateSettings?: (newSettings: AppSettings) => void;
  totalCount: number;
  underReviewCount?: number;
  onOpenAdd: () => void;
  onOpenBulk: () => void;
  onOpenImport: () => void;
  onOpenGoogleMapsImport?: () => void;
  onOpenSimilarModal?: () => void;
  onOpenUnderReviewPage?: () => void;
  onOpenPrint: () => void;
  onOpenSettings: (defaultTab?: 'workspace' | 'appearance' | 'columns' | 'stats' | 'productivity' | 'data' | 'modes') => void;
  onExportExcel: () => void;
  onExportCSV?: () => void;
  onOpenAdvancedExport: () => void;
  onResetData: () => void;
  onOpenAudit?: () => void;
  onExportJSON: () => void;
  onImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onOpenBackupRestore?: () => void;
  onToggleSidebar?: () => void;
  onOpenHelp?: () => void;
  onOpenMojibakeScanner?: () => void;
}

function DropdownMenu({ trigger, children }: { trigger: React.ReactNode; children: (close: () => void) => React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-black/20 hover:bg-black/30 text-white font-semibold rounded-xl transition text-xs sm:text-sm cursor-pointer border border-white/15"
      >
        {trigger}
        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute top-full mt-2 right-0 z-50 bg-white rounded-2xl shadow-2xl border border-gray-200 py-2 min-w-64">
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

function MenuItem({ icon, label, onClick, title }: { icon: React.ReactNode; label: string; onClick: () => void; title?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs font-semibold text-gray-800 hover:bg-gray-100 transition text-right cursor-pointer"
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

export function Header({
  theme,
  setTheme,
  settings,
  totalCount,
  underReviewCount = 0,
  onOpenAdd,
  onOpenBulk,
  onOpenImport,
  onOpenGoogleMapsImport,
  onOpenSimilarModal,
  onOpenUnderReviewPage,
  onOpenPrint,
  onOpenSettings,
  onExportExcel,
  onExportCSV,
  onOpenAdvancedExport,
  onResetData,
  onOpenAudit,
  onExportJSON,
  onImportJSON,
  onOpenBackupRestore,
  onToggleSidebar,
  onOpenHelp,
  onOpenMojibakeScanner,
  onUpdateSettings
}: HeaderProps) {
  const themeColors = getThemeColors(theme, settings.dynamicTheme);
  const showExportImport = settings.showExportImportInHeader ?? true;
  const showAuditBtn = settings.showAuditButton ?? true;

  return (
    <header className={`${themeColors.headerBg} ${themeColors.headerText} shadow-md transition-colors duration-300 py-3.5 px-4 sm:px-6`}>
      {/* Top Bar */}
      <div className="max-w-[1560px] mx-auto flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4">
        
        {/* Title & Branding */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              type="button"
              onClick={onToggleSidebar}
              className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition cursor-pointer border border-white/20"
              title="القائمة الجانبية (Alt+S)"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="p-2.5 bg-white/10 rounded-2xl backdrop-blur-xs shrink-0 shadow-inner">
            <FileSpreadsheet className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-2xl font-black tracking-tight">منظومة الشوارع و المأذونيات بدمنهور</h1>
              {settings.cleanWorkspaceMode && (
                <span className="px-2 py-0.5 bg-white/20 rounded-full text-[10px] font-black text-white/90">
                  وضع التركيز الصافي
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-white/85">فرز أبجدي فوري • استيراد وتصدير Excel/PDF • تدقيق متسلسل ذكي</p>
            <p className="text-[10px] sm:text-[11px] text-white/60 mt-0.5 font-medium">إعداد: الأستاذ/ حسام الدين الخولي</p>
          </div>
        </div>

        {/* Quick Stats Chip & Actions */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          
          {onOpenHelp && (
            <button
              type="button"
              onClick={onOpenHelp}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/15 hover:bg-white/25 text-white font-bold rounded-xl text-xs transition border border-white/20 cursor-pointer shadow-xs"
              title="دليل التعليمات واختصارات لوحة المفاتيح (F1)"
            >
              <Keyboard className="w-4 h-4 text-amber-300" />
              <span>تعليمات F1</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onOpenSettings('stats')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition hover:opacity-95 cursor-pointer shadow-xs bg-black/20 text-white border border-white/20`}
            title="انقر لعرض لوحة الإحصائيات الشاملة والنسب الرقمية"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>إجمالي السجلات: {totalCount.toLocaleString('ar-EG')} شارع</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenSettings('workspace')}
            className="flex items-center gap-1.5 px-4 py-1.5 bg-white text-gray-900 hover:bg-gray-100 font-bold rounded-xl shadow-xs transition text-xs cursor-pointer border border-white/30"
            title="فتح صفحة الإعدادات وتخصيص مساحة العمل"
          >
            <Settings className="w-3.5 h-3.5 text-emerald-700" />
            <span>الإعدادات والتحكم</span>
          </button>
        </div>

      </div>

      {/* Action Toolbar */}
      <div className="max-w-[1560px] mx-auto mt-3 pt-2.5 border-t border-white/15 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex flex-wrap items-center gap-2">
          
          {/* 1. Add Record */}
          <button
            onClick={onOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white text-gray-900 font-bold rounded-xl shadow-sm hover:bg-gray-100 transition text-xs sm:text-sm cursor-pointer"
            title="إضافة شارع أو حارة جديدة (Ctrl+N)"
          >
            <Plus className="w-4 h-4 text-emerald-600" />
            <span>إضافة شارع جديد</span>
          </button>

          {/* 2. Sequential Audit Mode */}
          {showAuditBtn && onOpenAudit && (
            <button
              onClick={onOpenAudit}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-gray-950 font-black rounded-xl transition text-xs sm:text-sm cursor-pointer shadow-sm border border-amber-300"
              title="وضع التدقيق والمراجعة المتتالية"
            >
              <CheckCircle className="w-4 h-4 text-gray-950" />
              <span>تدقيق متتالي</span>
            </button>
          )}

          {/* 2.1 Dedicated Under Review Center Button */}
          {onOpenUnderReviewPage && (
            <button
              onClick={onOpenUnderReviewPage}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-500 hover:bg-sky-400 text-gray-950 font-black rounded-xl transition text-xs sm:text-sm cursor-pointer shadow-sm border border-sky-400"
              title="فتح مركز السجلات قيد المراجعة والتدقيق الإضافي"
            >
              <FileSearch className="w-4 h-4 text-gray-950" />
              <span>قيد المراجعة</span>
              {underReviewCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-gray-950 text-sky-300">
                  {underReviewCount.toLocaleString('ar-EG')}
                </span>
              )}
            </button>
          )}

          {/* 3. Import Dropdown (Hidden if Clean Workspace or disabled in settings) */}
          {showExportImport && (
            <DropdownMenu trigger={<><Upload className="w-4 h-4 text-blue-300" /><span>استيراد</span></>}>
              {(close) => (
                <>
                  <div className="px-4 py-1.5 border-b border-gray-100">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">خيارات الاستيراد</span>
                  </div>
                  <MenuItem
                    icon={<Upload className="w-4 h-4 text-blue-600" />}
                    label="استيراد Excel / CSV"
                    onClick={() => { onOpenImport(); close(); }}
                    title="استيراد وتغذية بيانات من ملفات إكسيل أو CSV"
                  />
                  {onOpenGoogleMapsImport && (
                    <MenuItem
                      icon={<Compass className="w-4 h-4 text-emerald-600" />}
                      label="تحديث شوارع دمنهور (خرائط جوجل)"
                      onClick={() => { onOpenGoogleMapsImport(); close(); }}
                      title="استيراد وتحديث شوارع الكتلة العمرانية لدمنهور من إحداثيات خرائط جوجل"
                    />
                  )}
                  {onOpenSimilarModal && (
                    <MenuItem
                      icon={<Layers className="w-4 h-4 text-indigo-600" />}
                      label="مركز فحص وتصنيف المتشابهات (عناوين الحقيقة)"
                      onClick={() => { onOpenSimilarModal(); close(); }}
                      title="فحص ومراجعة وتصنيف البيانات المتشابهة والمشتركة واعتماد عناوين الحقيقة المغلقة"
                    />
                  )}
                  {onOpenUnderReviewPage && (
                    <MenuItem
                      icon={<FileSearch className="w-4 h-4 text-sky-600" />}
                      label="مركز السجلات قيد المراجعة والتدقيق"
                      onClick={() => { onOpenUnderReviewPage(); close(); }}
                      title="استعراض ومراجعة واعتماد السجلات التي تتطلب تدقيقاً وبحثاً إضافياً"
                    />
                  )}
                  <label className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs font-semibold text-gray-800 hover:bg-gray-100 transition text-right cursor-pointer">
                    <FileJson className="w-4 h-4 text-emerald-600" />
                    <span>استيراد نسخة احتياطية JSON</span>
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={(e) => { onImportJSON(e); close(); }}
                    />
                  </label>
                  {onOpenBackupRestore && (
                    <MenuItem
                      icon={<ShieldCheck className="w-4 h-4 text-purple-600" />}
                      label="الاستعادة والنسخ المشفر (Cloud/AES)"
                      onClick={() => { onOpenBackupRestore(); close(); }}
                      title="استعادة سحابية ونسخ احتياطي مشفر ومحمي بكلمة مرور"
                    />
                  )}
                  {onOpenMojibakeScanner && (
                    <MenuItem
                      icon={<Wrench className="w-4 h-4 text-rose-600" />}
                      label="ترميم نصوص الـ Mojibake التالفة"
                      onClick={() => { onOpenMojibakeScanner(); close(); }}
                      title="فحص وترميم الكلمات العربية المشوهة نتيجة ترميزات Windows-1256 التالفة"
                    />
                  )}
                  <MenuItem
                    icon={<ListPlus className="w-4 h-4 text-amber-600" />}
                    label="إدخال قائمة دفعة واحدة"
                    onClick={() => { onOpenBulk(); close(); }}
                    title="إدخال قائمة شوارع أو حارات متعددة الأسطر دفعة واحدة"
                  />
                </>
              )}
            </DropdownMenu>
          )}

          {/* 4. Export Dropdown */}
          {showExportImport && (
            <DropdownMenu trigger={<><FileDown className="w-4 h-4 text-emerald-300" /><span>تصدير</span></>}>
              {(close) => (
                <>
                  <div className="px-4 py-1.5 border-b border-gray-100">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">خيارات التصدير</span>
                  </div>
                  <MenuItem
                    icon={<FileSpreadsheet className="w-4 h-4 text-emerald-600" />}
                    label="تصدير Excel سريع"
                    onClick={() => { onExportExcel(); close(); }}
                    title="تصدير السجلات الحالية كملف Excel كامل"
                  />
                  {onExportCSV && (
                    <MenuItem
                      icon={<FileDown className="w-4 h-4 text-cyan-600" />}
                      label="تصدير CSV عربي سريع (UTF-8 BOM)"
                      onClick={() => { onExportCSV(); close(); }}
                      title="تصدير السجلات الحالية كملف CSV مع ترميز عربي سليم 100%"
                    />
                  )}
                  <MenuItem
                    icon={<FileDown className="w-4 h-4 text-indigo-600" />}
                    label="تصدير متقدم (Excel/ODS/CSV/PDF)"
                    onClick={() => { onOpenAdvancedExport(); close(); }}
                    title="نافذة التصدير المتقدم مع خيارات متعددة"
                  />
                  <MenuItem
                    icon={<Printer className="w-4 h-4 text-amber-600" />}
                    label="تقرير PDF للطباعة"
                    onClick={() => { onOpenPrint(); close(); }}
                    title="معاينة التقرير وطباعته أو حفظه PDF"
                  />
                  <MenuItem
                    icon={<Database className="w-4 h-4 text-blue-600" />}
                    label="نسخة احتياطية JSON"
                    onClick={() => { onExportJSON(); close(); }}
                    title="تحميل نسخة احتياطية كاملة بصيغة JSON"
                  />
                  {onOpenBackupRestore && (
                    <MenuItem
                      icon={<ShieldCheck className="w-4 h-4 text-purple-600" />}
                      label="نسخ احتياطي مشفر بكلمة سر (AES)"
                      onClick={() => { onOpenBackupRestore(); close(); }}
                      title="تصدير مشفر مع تضمين التاريخ والوقت الهجري والميلادي"
                    />
                  )}
                </>
              )}
            </DropdownMenu>
          )}

        </div>

        {/* Quick link to Settings Tabs */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onOpenSettings('workspace')}
            className="flex items-center gap-1.5 px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs transition border border-white/15 cursor-pointer"
            title="تخصيص ظهور أدوات مساحة العمل والوضع الصافي"
          >
            <span>مساحة العمل</span>
          </button>
          <button
            type="button"
            onClick={() => onOpenSettings('appearance')}
            className="flex items-center gap-1.5 px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs transition border border-white/15 cursor-pointer"
            title="تغيير الثيم، الخط، وأحجام النصوص"
          >
            <Palette className="w-3.5 h-3.5 text-purple-200" />
            <span>الثيم والمقاسات</span>
          </button>
        </div>
      </div>
    </header>
  );
}
