import React from 'react';
import { 
  X, 
  Filter, 
  BarChart3, 
  Upload, 
  FileDown, 
  Settings, 
  Sparkles, 
  ShieldCheck, 
  HeartPulse, 
  Zap, 
  RefreshCw, 
  Printer, 
  ListPlus, 
  Plus, 
  SlidersHorizontal,
  Compass,
  FileSpreadsheet,
  CheckCircle,
  HelpCircle,
  Keyboard,
  FileSearch
} from 'lucide-react';
import { RecordItem, ThemeType, AppSettings } from '../types';
import { OFFICIAL_DISTRICTS } from '../utils/districtColors';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  records: RecordItem[];
  theme: ThemeType;
  settings: AppSettings;
  activeDistrictFilter: string;
  onSelectDistrictFilter: (district: string) => void;
  onOpenAdd: () => void;
  onOpenBulk: () => void;
  onOpenImport: () => void;
  onOpenGoogleMapsImport?: () => void;
  onOpenUnderReviewPage?: () => void;
  onOpenPrint: () => void;
  onOpenAdvancedExport: () => void;
  onOpenBackupRestore?: () => void;
  onOpenSettings: (tab?: 'stats' | 'appearance' | 'productivity' | 'data') => void;
  onOpenHelp: () => void;
  onRepairMojibake?: () => void;
  onQuickFill?: () => void;
  onOpenAudit?: () => void;
}

export function Sidebar({
  isOpen,
  onClose,
  records,
  theme,
  settings,
  activeDistrictFilter,
  onSelectDistrictFilter,
  onOpenAdd,
  onOpenBulk,
  onOpenImport,
  onOpenGoogleMapsImport,
  onOpenUnderReviewPage,
  onOpenPrint,
  onOpenAdvancedExport,
  onOpenBackupRestore,
  onOpenSettings,
  onOpenHelp,
  onRepairMojibake,
  onQuickFill,
  onOpenAudit
}: SidebarProps) {
  if (!isOpen) return null;

  // Calculate quick district stats
  const total = records.length;
  const missingPermCount = records.filter(r => !r.permission || !r.permission.trim() || r.permission === 'غير محدد').length;
  const missingMetaCount = records.filter(r => !r.metadata || !r.metadata.trim()).length;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200 lg:hidden"
        onClick={onClose}
      />

      {/* Lateral Sidebar Drawer */}
      <aside 
        className="fixed top-0 right-0 bottom-0 z-50 w-80 sm:w-96 bg-white shadow-2xl border-l border-gray-200 flex flex-col overflow-hidden animate-in slide-in-from-right duration-250"
        dir="rtl"
      >
        {/* Sidebar Header */}
        <div className="p-4 bg-gray-900 text-white flex items-center justify-between shrink-0 border-b border-gray-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black tracking-tight">لوحة الأدوات والفرز الجانبية</h3>
              <p className="text-[11px] text-gray-400 font-medium">الوصول السريع دون التشويش على مساحة العمل</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/10 transition cursor-pointer"
            title="إغلاق القائمة الجانبية (Esc أو Alt+S)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-5 text-right">
          
          {/* 1. Quick Primary Actions */}
          <div className="space-y-2">
            <span className="text-[11px] font-black text-gray-400 uppercase tracking-wider block">
              الإجراءات السريعة
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => { onOpenAdd(); onClose(); }}
                className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة شارع</span>
              </button>

              {onOpenAudit && (
                <button
                  type="button"
                  onClick={() => { onOpenAudit(); onClose(); }}
                  className="p-2.5 bg-amber-400 hover:bg-amber-500 text-gray-950 rounded-xl text-xs font-black shadow-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4 text-gray-950" />
                  <span>تدقيق متتالي</span>
                </button>
              )}

              {onOpenUnderReviewPage && (
                <button
                  type="button"
                  onClick={() => { onOpenUnderReviewPage(); onClose(); }}
                  className="p-2.5 bg-sky-100 hover:bg-sky-200 text-sky-950 border border-sky-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <FileSearch className="w-4 h-4 text-sky-700" />
                  <span>قيد المراجعة 🔍</span>
                </button>
              )}

              {onQuickFill && (
                <button
                  type="button"
                  onClick={() => { onQuickFill(); onClose(); }}
                  className="p-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-indigo-600" />
                  <span>تعبئة سريعة</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => { onOpenHelp(); onClose(); }}
                className="p-2.5 bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Keyboard className="w-4 h-4 text-purple-600" />
                <span>تعليمات F1</span>
              </button>
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* 2. Official District Quick Filters */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black text-gray-400 uppercase tracking-wider">
                التصفية بالمأذونية الرسمية
              </span>
              {activeDistrictFilter && (
                <button
                  type="button"
                  onClick={() => onSelectDistrictFilter('')}
                  className="text-[10px] text-emerald-700 font-bold hover:underline"
                >
                  إلغاء التصفية
                </button>
              )}
            </div>

            <div className="space-y-1">
              <button
                type="button"
                onClick={() => { onSelectDistrictFilter(''); }}
                className={`w-full p-2 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                  !activeDistrictFilter 
                    ? 'bg-gray-900 text-white shadow-xs' 
                    : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200'
                }`}
              >
                <span>كافة المأذونيات والسجلات</span>
                <span className={`text-[11px] px-2 py-0.5 rounded-md ${!activeDistrictFilter ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'}`}>
                  {total}
                </span>
              </button>

              {OFFICIAL_DISTRICTS.map(dist => {
                const count = records.filter(r => `${r.permission || ''} ${r.metadata || ''} ${r.name || ''}`.includes(dist.key)).length;
                const isSelected = activeDistrictFilter === dist.name || activeDistrictFilter === dist.key;

                return (
                  <button
                    key={dist.key}
                    type="button"
                    onClick={() => onSelectDistrictFilter(isSelected ? '' : dist.name)}
                    className={`w-full p-2 rounded-xl text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-700 text-white shadow-xs font-bold'
                        : 'bg-gray-50/70 hover:bg-gray-100 text-gray-800 border border-gray-100'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${dist.dot} shrink-0`} />
                      <span>{dist.name}</span>
                    </div>
                    <span className={`text-[11px] px-2 py-0.5 rounded-md font-mono ${
                      isSelected ? 'bg-white/20 text-white font-bold' : 'bg-gray-200/70 text-gray-700'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* 3. Lateral Import / Export & Maintenance */}
          <div className="space-y-2">
            <span className="text-[11px] font-black text-gray-400 uppercase tracking-wider block">
              الاستيراد والتصدير والصيانة
            </span>

            <div className="space-y-1.5 text-xs">
              {onOpenGoogleMapsImport && (
                <button
                  type="button"
                  onClick={() => { onOpenGoogleMapsImport(); onClose(); }}
                  className="w-full p-2.5 bg-teal-50/70 hover:bg-teal-100 text-teal-900 border border-teal-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-teal-600" />
                  <span>تحديث شوارع دمنهور (خرائط جوجل)</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => { onOpenImport(); onClose(); }}
                className="w-full p-2.5 bg-blue-50/70 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
              >
                <Upload className="w-4 h-4 text-blue-600" />
                <span>استيراد ملفات Excel / CSV</span>
              </button>

              <button
                type="button"
                onClick={() => { onOpenBulk(); onClose(); }}
                className="w-full p-2.5 bg-amber-50/70 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
              >
                <ListPlus className="w-4 h-4 text-amber-600" />
                <span>إدخال قائمة شوارع دفعة واحدة</span>
              </button>

              <button
                type="button"
                onClick={() => { onOpenAdvancedExport(); onClose(); }}
                className="w-full p-2.5 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>تصدير متقدم (Excel / PDF / ODS)</span>
              </button>

              <button
                type="button"
                onClick={() => { onOpenPrint(); onClose(); }}
                className="w-full p-2.5 bg-gray-50 hover:bg-gray-100 text-gray-800 border border-gray-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
              >
                <Printer className="w-4 h-4 text-gray-600" />
                <span>طباعة التقرير ومعاينة PDF</span>
              </button>

              {onOpenBackupRestore && (
                <button
                  type="button"
                  onClick={() => { onOpenBackupRestore(); onClose(); }}
                  className="w-full p-2.5 bg-purple-50/70 hover:bg-purple-100 text-purple-900 border border-purple-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                  <span>الاستعادة السحابية والنسخ المشفر</span>
                </button>
              )}

              {onRepairMojibake && (
                <button
                  type="button"
                  onClick={() => { onRepairMojibake(); onClose(); }}
                  className="w-full p-2.5 bg-amber-50/70 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-xl font-bold flex items-center gap-2 transition cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4 text-amber-600" />
                  <span>فحص وتصحيح ترميز الحروف العربي</span>
                </button>
              )}
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* 4. Quick Settings Link */}
          <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200 space-y-2">
            <div className="flex items-center justify-between text-xs font-black text-gray-900">
              <div className="flex items-center gap-1.5">
                <Settings className="w-4 h-4 text-emerald-600" />
                <span>تخصيص مساحة العمل</span>
              </div>
            </div>
            <p className="text-[11px] text-gray-500 font-medium leading-relaxed">
              يمكنك إخفاء الأشرطة والأدوات غير المستخدمة لجعل مساحة التحرير صافية وخالية من المشتتات.
            </p>
            <button
              type="button"
              onClick={() => { onOpenSettings('appearance'); onClose(); }}
              className="w-full py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-black transition shadow-xs cursor-pointer text-center"
            >
              فتح صفحة الإعدادات والمظهر
            </button>
          </div>

        </div>

        {/* Sidebar Footer */}
        <div className="p-3.5 bg-gray-50 border-t border-gray-200 text-center shrink-0">
          <span className="text-[11px] text-gray-400 font-medium">
            اختصار اللوحة: <kbd className="bg-white px-1.5 py-0.5 rounded border text-[10px] font-mono text-gray-700 font-bold">Alt+S</kbd>
          </span>
        </div>

      </aside>
    </>
  );
}
