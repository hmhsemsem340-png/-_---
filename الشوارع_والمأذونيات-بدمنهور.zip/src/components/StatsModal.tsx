// ============================================================
// 📊 نافذة الإحصائيات الشاملة وتوزيع الشوارع
// Comprehensive Analytics & Street Distribution Dashboard
// ============================================================

import React, { useMemo } from 'react';
import { StreetRecord, OFFICIAL_NOTARIZATIONS, RECORD_TYPES } from '../types';
import { BarChart3, X, PieChart, Layers, MapPin, Link2, FileCheck } from 'lucide-react';
import { NOTARIZATION_COLOR_CONFIG } from './NotarizationTags';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: StreetRecord[];
}

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  records
}) => {
  // إحصائيات المأذونيات
  const notarizationCounts = useMemo(() => {
    if (!isOpen) return {};
    const counts: Record<string, number> = {};
    records.forEach((r) => {
      counts[r.notarization] = (counts[r.notarization] || 0) + 1;
    });
    return counts;
  }, [records, isOpen]);

  // إحصائيات الأنواع الجغرافية
  const typeCounts = useMemo(() => {
    if (!isOpen) return {};
    const counts: Record<string, number> = {};
    records.forEach((r) => {
      counts[r.recordType] = (counts[r.recordType] || 0) + 1;
    });
    return counts;
  }, [records, isOpen]);

  // إحصائيات الحالات
  const statusCounts = useMemo(() => {
    if (!isOpen) return {};
    const counts: Record<string, number> = {};
    records.forEach((r) => {
      counts[r.status] = (counts[r.status] || 0) + 1;
    });
    return counts;
  }, [records, isOpen]);

  if (!isOpen) return null;

  // الشوارع المشتركة
  const sharedCount = records.filter((r) => !!r.sharedNotarization).length;
  const officialCount = records.filter((r) => r.category === 'مأذونية رسمية').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                الإحصائيات والتحليلات الجغرافية الشاملة
              </h2>
              <p className="text-xs text-stone-400">
                مؤشرات التوزيع المكاني للشوارع والمأذونيات ببندر دمنهور
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ المحتوى ═══ */}
        <div className="p-5 space-y-5 flex-1 overflow-y-auto">
          {/* البطاقات الإحصائية الرئيسية */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-stone-50 border border-stone-200 rounded-lg p-3 text-center">
              <span className="text-[11px] text-stone-500 font-semibold block">إجمالي الشوارع</span>
              <span className="text-2xl font-bold text-stone-900 mt-1 block">
                {records.length}
              </span>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-center">
              <span className="text-[11px] text-emerald-700 font-semibold block">مأذونية رسمية</span>
              <span className="text-2xl font-bold text-emerald-900 mt-1 block">
                {officialCount}
              </span>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center">
              <span className="text-[11px] text-amber-700 font-semibold block">شوارع مشتركة</span>
              <span className="text-2xl font-bold text-amber-900 mt-1 block">
                {sharedCount}
              </span>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
              <span className="text-[11px] text-blue-700 font-semibold block">سجلات نشطة</span>
              <span className="text-2xl font-bold text-blue-900 mt-1 block">
                {statusCounts['نشط'] || 0}
              </span>
            </div>
          </div>

          {/* توزيع السجلات حسب المأذونيات الرسمية السبع */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-3">
            <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-2">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>توزيع الشوارع حسب المأذونيات السبع المعتمدة</span>
            </h3>

            <div className="space-y-2">
              {OFFICIAL_NOTARIZATIONS.map((name) => {
                const count = notarizationCounts[name] || 0;
                const percentage = records.length > 0 ? (count / records.length) * 100 : 0;
                const config = NOTARIZATION_COLOR_CONFIG[name] || {
                  bg: 'bg-stone-100',
                  text: 'text-stone-800',
                  border: 'border-stone-300'
                };

                return (
                  <div key={name} className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold text-stone-700">
                      <span className="flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${config.bg} border ${config.border}`}></span>
                        {name}
                      </span>
                      <span>
                        <strong>{count}</strong> سجل ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-stone-200 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* توزيع الأنواع الجغرافية والحالات */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* الأنواع */}
            <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-2.5">
              <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-1.5">
                <Layers className="w-4 h-4 text-emerald-700" />
                <span>التوزيع حسب النوع الجغرافي</span>
              </h3>

              <div className="space-y-1.5 text-xs">
                {RECORD_TYPES.map((type) => {
                  const count = typeCounts[type] || 0;
                  if (count === 0) return null;
                  return (
                    <div key={type} className="flex justify-between py-1 border-b border-stone-100">
                      <span className="text-stone-700">{type}</span>
                      <span className="font-bold text-stone-900">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* الحالات */}
            <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-2.5">
              <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-1.5">
                <FileCheck className="w-4 h-4 text-emerald-700" />
                <span>حالة السجلات والمراجعة</span>
              </h3>

              <div className="space-y-1.5 text-xs">
                {['نشط', 'معلّق', 'قيد المراجعة', 'ملغي'].map((status) => {
                  const count = statusCounts[status] || 0;
                  return (
                    <div key={status} className="flex justify-between py-1 border-b border-stone-100">
                      <span className="text-stone-700">{status}</span>
                      <span className="font-bold text-stone-900">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* التذييل */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-md text-xs font-semibold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
