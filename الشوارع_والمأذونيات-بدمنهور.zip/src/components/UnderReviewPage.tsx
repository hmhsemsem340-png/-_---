// ===================================================================
// 🏛️ صفحة السجلات قيد المراجعة المستقلة (Under Review Dedicated Center)
// Dedicated Workspace for Reviewing, Auditing & Authorizing Pending Records
// ===================================================================

import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileSearch, 
  ArrowRight, 
  CheckCircle2, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  AlertTriangle, 
  Share2, 
  Layers, 
  ChevronRight, 
  ChevronLeft, 
  Save, 
  RotateCcw, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  Check, 
  Clock, 
  Building, 
  Tag, 
  FileText,
  Sparkles,
  Info
} from 'lucide-react';
import { RecordItem, ThemeType, AppSettings, RecordStatus } from '../types';
import { OFFICIAL_NOTARIZATIONS } from '../types';
import { getDistrictColor } from '../utils/districtColors';
import { groupSimilarRecords } from '../utils/streetSimilarity';

interface UnderReviewPageProps {
  onBack: () => void;
  records: RecordItem[];
  onUpdateRecord: (record: RecordItem) => void;
  onBatchUpdateRecords?: (records: RecordItem[]) => void;
  onDeleteRecord: (id: string) => void;
  onToast: (msg: string) => void;
  theme: ThemeType;
  settings: AppSettings;
  onOpenSimilarModal?: (rootName?: string) => void;
  onMarkAllUnderReview?: (preserveLocked?: boolean, customReason?: string) => void;
}

export const UnderReviewPage: React.FC<UnderReviewPageProps> = ({
  onBack,
  records,
  onUpdateRecord,
  onBatchUpdateRecords,
  onDeleteRecord,
  onToast,
  theme,
  settings,
  onOpenSimilarModal,
  onMarkAllUnderReview
}) => {
  // Filter only records that are 'قيد المراجعة'
  const underReviewRecords = useMemo(() => {
    return records.filter(r => r.status === 'قيد المراجعة');
  }, [records]);

  // Current active record index for sequential auditing
  const [currentIndex, setCurrentIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [permissionFilter, setPermissionFilter] = useState('all');

  // Filtered under review records
  const filteredList = useMemo(() => {
    return underReviewRecords.filter(r => {
      const matchSearch = searchQuery.trim() === '' || 
        r.name.toLowerCase().includes(searchQuery.trim().toLowerCase()) ||
        (r.metadata && r.metadata.toLowerCase().includes(searchQuery.trim().toLowerCase()));
      const matchPerm = permissionFilter === 'all' || r.permission === permissionFilter;
      return matchSearch && matchPerm;
    });
  }, [underReviewRecords, searchQuery, permissionFilter]);

  // Keep index within bounds
  useEffect(() => {
    if (currentIndex >= filteredList.length && filteredList.length > 0) {
      setCurrentIndex(0);
    }
  }, [filteredList.length, currentIndex]);

  const activeRecord = filteredList[currentIndex] || null;

  // Form states for the currently reviewed record
  const [editName, setEditName] = useState('');
  const [editPermission, setEditPermission] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editMetadata, setEditMetadata] = useState('');
  const [reviewNote, setReviewNote] = useState('');
  const [isDirty, setIsDirty] = useState(false);

  // Sync edit form when active record changes
  useEffect(() => {
    if (activeRecord) {
      setEditName(activeRecord.name);
      setEditPermission(activeRecord.permission);
      setEditCategory(activeRecord.category);
      setEditMetadata(activeRecord.metadata || '');
      setReviewNote('');
      setIsDirty(false);
    }
  }, [activeRecord?.id]);

  // Similar records for active record
  const similarToActive = useMemo(() => {
    if (!activeRecord) return [];
    const groups = groupSimilarRecords(records);
    for (const g of groups) {
      if (g.records.some(r => r.id === activeRecord.id)) {
        return g.records.filter(r => r.id !== activeRecord.id);
      }
    }
    return [];
  }, [activeRecord, records]);

  // Handle save current changes
  const handleSaveCurrent = (nextStatus?: RecordStatus, lockState?: boolean) => {
    if (!activeRecord) return;
    const targetStatus = nextStatus || activeRecord.status || 'قيد المراجعة';
    const isLocked = lockState !== undefined ? lockState : (targetStatus === 'تام');

    let updatedMeta = editMetadata.trim();
    if (reviewNote.trim()) {
      const timestamp = new Date().toLocaleDateString('ar-EG');
      const auditStamp = `[تدقيق: ${reviewNote.trim()} - ${timestamp}]`;
      updatedMeta = updatedMeta ? `${updatedMeta}\n${auditStamp}` : auditStamp;
    }

    const updated: RecordItem = {
      ...activeRecord,
      name: editName.trim(),
      permission: editPermission.trim(),
      category: editCategory.trim(),
      metadata: updatedMeta,
      status: targetStatus,
      isLocked: isLocked,
      isTruthRecord: isLocked,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      lastModifiedBy: 'مراجع المنظومة',
      auditLogs: [
        ...(activeRecord.auditLogs || []),
        {
          id: `audit-${Date.now()}`,
          timestamp: new Date().toISOString(),
          operation: 'update',
          details: `تمت مراجعة السجل وتحديث حالته إلى (${targetStatus})`,
          user: 'مراجع المنظومة'
        }
      ]
    };

    onUpdateRecord(updated);
    setIsDirty(false);
    onToast(`✓ تم حفظ وتحديث السجل (${updated.name}) بنجاح إلى حالة: ${targetStatus}`);

    // If moved out of 'قيد المراجعة', keep index valid
    if (targetStatus !== 'قيد المراجعة') {
      if (currentIndex >= filteredList.length - 1) {
        setCurrentIndex(Math.max(0, filteredList.length - 2));
      }
    }
  };

  // Keyboard navigation for reviewing
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (currentIndex < filteredList.length - 1) setCurrentIndex(c => c + 1);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (currentIndex > 0) setCurrentIndex(c => c - 1);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, filteredList.length]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16" dir="rtl">
      {/* Header & Breadcrumb */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-gradient-to-r from-sky-900 via-sky-800 to-indigo-950 text-white rounded-3xl shadow-xl border border-sky-700/50">
        <div className="flex items-center gap-3.5">
          <button
            type="button"
            onClick={onBack}
            className="p-2.5 bg-white/10 hover:bg-white/20 rounded-2xl transition cursor-pointer text-white flex items-center gap-1.5 text-xs font-bold"
            title="العودة إلى جدول السجلات الرئيسي"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للجدول الرئيسي</span>
          </button>

          <div className="h-6 w-px bg-white/20 hidden sm:block" />

          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-500/20 rounded-2xl border border-sky-400/30">
              <FileSearch className="w-6 h-6 text-sky-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black tracking-tight">مركز السجلات قيد المراجعة والتدقيق</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-sky-400 text-sky-950 shadow-xs">
                  {underReviewRecords.length} سجل بحاجة لتدقيق
                </span>
              </div>
              <p className="text-xs text-sky-200 mt-0.5">
                صفحة مستقلة متكاملة لفحص ومراجعة السجلات التي تتطلب تدقيقاً إضافياً واعتمادها كبيانات تامة أو نشطة
              </p>
            </div>
          </div>
        </div>

        {/* Quick Hub Navigation */}
        <div className="flex items-center gap-2">
          {onOpenSimilarModal && (
            <button
              type="button"
              onClick={() => onOpenSimilarModal()}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-md cursor-pointer"
            >
              <Layers className="w-4 h-4 text-amber-300" />
              <span>مركز المتشابهات</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-sky-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-500 font-bold">إجمالي السجلات قيد المراجعة</span>
            <p className="text-2xl font-black text-sky-950">{underReviewRecords.length}</p>
          </div>
          <div className="p-3 bg-sky-50 text-sky-700 rounded-xl">
            <FileSearch className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-purple-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-500 font-bold">سجلات لها شوارع متشابهة</span>
            <p className="text-2xl font-black text-purple-950">
              {underReviewRecords.filter(r => {
                const groups = groupSimilarRecords(records);
                return groups.some(g => g.records.length > 1 && g.records.some(rec => rec.id === r.id));
              }).length}
            </p>
          </div>
          <div className="p-3 bg-purple-50 text-purple-700 rounded-xl">
            <Share2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-emerald-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-500 font-bold">السجلات المعتمدة كـ «بيان تام 🔒»</span>
            <p className="text-2xl font-black text-emerald-950">
              {records.filter(r => r.status === 'تام' || r.isLocked).length}
            </p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl">
            <Lock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Data Preservation & Bulk Under Review Action Card */}
      {records.length > 0 && (
        <div className="p-4 bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 rounded-2xl border border-sky-300 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-sky-600 text-white rounded-xl shrink-0 mt-0.5 shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <strong className="text-sm font-black text-sky-950">حفظ المجهود والبيانات مع وضعها «قيد المراجعة 🔍»</strong>
                <span className="px-2 py-0.5 bg-sky-200 text-sky-900 rounded-md text-[11px] font-bold">حفاظ كامل 100%</span>
              </div>
              <p className="text-xs text-sky-900 leading-relaxed max-w-3xl">
                نظراً لعدم تأكيد صحة بعض البيانات، يمكنك وسم جميع سجلات وقواعد البيانات ({records.length} شارع) بـ «قيد المراجعة» لتدقيقها سجلًا تلو الآخر عبر هذه الصفحة. <strong className="font-black text-sky-950 underline">يتم الحفاظ الكامل على كافة الملاحظات والمأذونيات والمقاطعات والتصنيفات دون حذف أو تعديل أي نص</strong> مع إمكانية التراجع الفوري.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {onMarkAllUnderReview && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`هل ترغب في تحويل كافة سجلات المنظومة (${records.length} سجل) إلى حالة «قيد المراجعة 🔍» مع الحفاظ التام والكامل على كافة النصوص والملاحظات؟`)) {
                      onMarkAllUnderReview(false);
                    }
                  }}
                  className="flex items-center gap-1.5 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black transition shadow-sm cursor-pointer"
                  title="تحويل كافة السجلات دون استثناء إلى قيد المراجعة"
                >
                  <FileSearch className="w-4 h-4 text-sky-200" />
                  <span>تحويل الكل ({records.length}) إلى «قيد المراجعة»</span>
                </button>

                {records.some(r => r.status === 'تام' || r.isLocked) && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`هل ترغب في تحويل السجلات غير المعتمدة فقط إلى «قيد المراجعة 🔍» مع استثناء السجلات المعتمدة كـ «بيان تام 🔒»؟`)) {
                        onMarkAllUnderReview(true);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-sky-100 text-sky-900 border border-sky-300 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                    title="تحويل السجلات غير المعتمدة فقط والإبقاء على البيانات التامة المعتمدة"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>استثناء البيانات التامة 🔒</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* Main Review Workspace */}
      {filteredList.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-gray-200 shadow-sm space-y-4">
          <div className="w-16 h-16 mx-auto bg-sky-50 text-sky-600 rounded-full flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-lg font-black text-gray-900">لا توجد سجلات موسومة بـ «قيد المراجعة» حالياً</h3>
            <p className="text-xs text-gray-600 max-w-lg mx-auto leading-relaxed">
              هل ترغب في وضع البيانات الحالية قيد التدقيق؟ يمكنك تحويل جميع سجلات قاعدة البيانات ({records.length} شارع) إلى «قيد المراجعة» للبدء في مراجعتها واعتمادها سجلاً تلو الآخر مع الحفاظ الكامل على البيانات والملاحظات.
            </p>
          </div>
          <div className="flex items-center justify-center gap-3 pt-2 flex-wrap">
            {onMarkAllUnderReview && (
              <button
                type="button"
                onClick={() => onMarkAllUnderReview(false)}
                className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black transition cursor-pointer shadow-md flex items-center gap-2"
              >
                <FileSearch className="w-4 h-4 text-sky-200" />
                <span>تحويل كافة السجلات ({records.length}) إلى «قيد المراجعة 🔍»</span>
              </button>
            )}
            <button
              type="button"
              onClick={onBack}
              className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              العودة لجدول البيانات الرئيسي
            </button>
          </div>
        </div>
      ) : activeRecord ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Active Record Review Editor (8 cols) */}
          <div className="lg:col-span-8 space-y-5">
            {/* Sequential Navigation Toolbar */}
            <div className="flex items-center justify-between p-3.5 bg-white rounded-2xl border border-gray-200 shadow-xs">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentIndex(c => Math.max(0, c - 1))}
                  disabled={currentIndex === 0}
                  className="p-2 rounded-xl border border-gray-300 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                  title="السجل السابق (سهم يمين)"
                >
                  <ChevronRight className="w-4 h-4 text-gray-700" />
                </button>
                <span className="text-xs font-bold text-gray-800">
                  السجل <span className="text-sky-700 font-black">{currentIndex + 1}</span> من أصل <span className="font-black">{filteredList.length}</span>
                </span>
                <button
                  type="button"
                  onClick={() => setCurrentIndex(c => Math.min(filteredList.length - 1, c + 1))}
                  disabled={currentIndex === filteredList.length - 1}
                  className="p-2 rounded-xl border border-gray-300 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                  title="السجل التالي (سهم يسار)"
                >
                  <ChevronLeft className="w-4 h-4 text-gray-700" />
                </button>
              </div>

              {/* Status Indicator */}
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-100 text-sky-950 border border-sky-300 rounded-xl text-xs font-black">
                  <FileSearch className="w-3.5 h-3.5 text-sky-700 animate-pulse" />
                  <span>قيد المراجعة 🔍</span>
                </span>
              </div>
            </div>

            {/* Editing Card */}
            <div className="bg-white rounded-3xl border border-gray-200 shadow-sm p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h2 className="text-sm font-black text-gray-900 flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-sky-700" />
                  <span>تدقيق وتصحيح بيانات السجل</span>
                </h2>
                {isDirty && (
                  <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                    توجد تعديلات غير محفوظة
                  </span>
                )}
              </div>

              {/* Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Street Name */}
                <div className="md:col-span-2 space-y-1">
                  <label className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-sky-600" />
                    <span>اسم الشارع / المسطح المعتمد:</span>
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => {
                      setEditName(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm font-bold text-gray-950 focus:ring-2 focus:ring-sky-500 focus:bg-white"
                  />
                </div>

                {/* Permission */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-sky-600" />
                    <span>المأذونية / الدائرة:</span>
                  </label>
                  <select
                    value={editPermission}
                    onChange={(e) => {
                      setEditPermission(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full px-3.5 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-sky-500 cursor-pointer"
                  >
                    <option value="">اختر المأذونية...</option>
                    {OFFICIAL_NOTARIZATIONS.map(notar => (
                      <option key={notar} value={notar}>{notar}</option>
                    ))}
                    {!OFFICIAL_NOTARIZATIONS.includes(editPermission as any) && editPermission && (
                      <option value={editPermission}>{editPermission}</option>
                    )}
                  </select>
                </div>

                {/* Category */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-sky-600" />
                    <span>التصنيف الإداري:</span>
                  </label>
                  <input
                    type="text"
                    value={editCategory}
                    onChange={(e) => {
                      setEditCategory(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder="مثال: شارع رئيسي، حارة، عزبة..."
                    className="w-full px-3.5 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-bold text-gray-900 focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                {/* Metadata & Notes */}
                <div className="md:col-span-2 space-y-1">
                  <label className="text-xs font-bold text-gray-700 flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-sky-600" />
                    <span>الملاحظات والبيانات الوصفية:</span>
                  </label>
                  <textarea
                    rows={3}
                    value={editMetadata}
                    onChange={(e) => {
                      setEditMetadata(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder="حدود الشارع، المعالم، ملاحظات الاشتراك بين المأذونيات..."
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                {/* Review Audit Reason Stamp */}
                <div className="md:col-span-2 p-3.5 bg-sky-50/70 border border-sky-200 rounded-2xl space-y-1.5">
                  <label className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                    <Info className="w-4 h-4 text-sky-700" />
                    <span>إضافة ملاحظة توثيقية لعملية التدقيق (اختياري):</span>
                  </label>
                  <input
                    type="text"
                    value={reviewNote}
                    onChange={(e) => setReviewNote(e.target.value)}
                    placeholder="مثال: تم التأكد من المأذونية ومطابقة الاسم مع عقد الملكية رقم..."
                    className="w-full px-3 py-2 bg-white border border-sky-300 rounded-xl text-xs font-medium text-gray-900 focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              {/* Action Decision Buttons */}
              <div className="pt-3 border-t border-gray-200 space-y-3">
                <div className="text-xs font-bold text-gray-700">اتخاذ القرار والاعتماد:</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Approve as Ground Truth Locked */}
                  <button
                    type="button"
                    onClick={() => handleSaveCurrent('تام', true)}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                    title="اعتماد السجل نهائياً وتاماً وإغلاقه كعنوان حقيقة موثق 🔒"
                  >
                    <Lock className="w-4 h-4 text-amber-300" />
                    <span>اعتماد كـ «بيان تام 🔒»</span>
                  </button>

                  {/* Approve as Active */}
                  <button
                    type="button"
                    onClick={() => handleSaveCurrent('نشط', false)}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                    title="اعتماد استيفاء المراجعة وإعادة السجل للحالة النشطة العادية"
                  >
                    <CheckCircle2 className="w-4 h-4 text-sky-200" />
                    <span>استيفاء المراجعة (نشط)</span>
                  </button>

                  {/* Keep Under Review with updates */}
                  <button
                    type="button"
                    onClick={() => handleSaveCurrent('قيد المراجعة', false)}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                    title="حفظ التعديلات مع إبقاء السجل قيد المراجعة لمزيد من التدقيق"
                  >
                    <Save className="w-4 h-4" />
                    <span>حفظ واستمرار المراجعة</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Similar Records & Context Panel (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            {/* Similar Streets Detection Card */}
            <div className="bg-white rounded-3xl border border-gray-200 shadow-sm p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                <span className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                  <Share2 className="w-4 h-4 text-purple-600" />
                  <span>الشوارع المشابهة لهذا السجل</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-900">
                  {similarToActive.length} سجل
                </span>
              </div>

              {similarToActive.length === 0 ? (
                <div className="p-4 text-center bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-xs text-gray-500">
                  لا توجد شوارع متشابهة مع هذا السجل في المنظومة
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {similarToActive.map(sim => (
                    <div 
                      key={sim.id}
                      className="p-3 bg-gray-50 hover:bg-purple-50 rounded-2xl border border-gray-200 hover:border-purple-300 transition space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-900">{sim.name}</span>
                        {sim.status === 'تام' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded-md">
                            <Lock className="w-3 h-3" />
                            <span>تام 🔒</span>
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                        <span className="font-semibold text-gray-700">{sim.permission}</span>
                        <span>•</span>
                        <span>{sim.category}</span>
                      </div>
                      {sim.metadata && (
                        <p className="text-[10px] text-gray-500 truncate">{sim.metadata}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {onOpenSimilarModal && (
                <button
                  type="button"
                  onClick={() => onOpenSimilarModal(activeRecord.name)}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-purple-100 hover:bg-purple-200 text-purple-950 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5 text-purple-700" />
                  <span>فتح مركز المقارنة المتجاورة ⚡</span>
                </button>
              )}
            </div>

            {/* Quick Record Queue List */}
            <div className="bg-white rounded-3xl border border-gray-200 shadow-sm p-4 space-y-2.5">
              <span className="text-xs font-bold text-gray-900 block border-b border-gray-100 pb-2">
                قائمة الانتظار قيد المراجعة ({filteredList.length})
              </span>
              <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                {filteredList.map((rec, idx) => (
                  <button
                    key={rec.id}
                    type="button"
                    onClick={() => setCurrentIndex(idx)}
                    className={`w-full text-right p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer flex items-center justify-between ${
                      idx === currentIndex
                        ? 'bg-sky-700 text-white border-sky-800 shadow-xs'
                        : 'bg-gray-50 hover:bg-gray-100 text-gray-800 border-gray-200'
                    }`}
                  >
                    <span className="truncate max-w-[180px]">{rec.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                      idx === currentIndex ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
                    }`}>
                      {rec.permission}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
