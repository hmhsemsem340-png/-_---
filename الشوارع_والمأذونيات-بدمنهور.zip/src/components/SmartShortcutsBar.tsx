import React, { useState, useEffect } from 'react';
import { 
  Keyboard, 
  RotateCcw, 
  Plus, 
  Search, 
  Sparkles, 
  ChevronUp, 
  ChevronDown, 
  Undo2, 
  Sliders, 
  Check,
  ExternalLink
} from 'lucide-react';
import { AppSettings, ThemeType } from '../types';

interface SmartShortcutsBarProps {
  onOpenAdd: () => void;
  onFocusSearch: () => void;
  onUndo: () => void;
  canUndo: boolean;
  undoCount: number;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  theme: ThemeType;
  onOpenHelp?: () => void;
}

export const SmartShortcutsBar: React.FC<SmartShortcutsBarProps> = ({
  onOpenAdd,
  onFocusSearch,
  onUndo,
  canUndo,
  undoCount,
  settings,
  onUpdateSettings,
  theme,
  onOpenHelp
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isEnabled = (settings.showSmartShortcutsBar ?? true) && (settings.enableProductivitySuite ?? true);
  const shortcutsEnabled = settings.enableKeyboardShortcuts ?? true;

  // Listen to keyboard shortcuts globally when enabled
  useEffect(() => {
    if (!shortcutsEnabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // F1 for keyboard help modal
      if (e.key === 'F1') {
        e.preventDefault();
        if (onOpenHelp) onOpenHelp();
        return;
      }

      // Don't trigger if target is an editable input unless it's Ctrl+Z or Escape
      const target = e.target as HTMLElement;
      const isInput = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);

      // Ctrl+Z or Cmd+Z for Global Undo (outside text fields or when pressing Ctrl+Shift+Z)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        if (!isInput) {
          e.preventDefault();
          if (canUndo) onUndo();
        }
      }

      // Ctrl+N or Alt+N to add new record
      if (((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') || (e.altKey && e.key.toLowerCase() === 'n')) {
        e.preventDefault();
        onOpenAdd();
      }

      // '/' or Ctrl+K / Ctrl+F to focus search if not in input
      if ((e.key === '/' && !isInput) || ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'k' || e.key.toLowerCase() === 'f'))) {
        e.preventDefault();
        onFocusSearch();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [shortcutsEnabled, canUndo, onUndo, onOpenAdd, onFocusSearch, onOpenHelp]);

  if (!isEnabled) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 z-40 flex flex-col items-start gap-2 select-none print:hidden">
      
      {/* Expanded Quick Guide Panel */}
      {isExpanded && (
        <div className="bg-gray-900/95 backdrop-blur-md text-white border border-gray-700 p-4 rounded-3xl shadow-2xl w-84 space-y-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-gray-200">مساعد الإنتاجية والاختصارات</span>
            </div>
            <div className="flex items-center gap-2">
              {onOpenHelp && (
                <button
                  type="button"
                  onClick={() => {
                    setIsExpanded(false);
                    onOpenHelp();
                  }}
                  className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-bold cursor-pointer"
                >
                  <span>دليل F1 الكامل</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setIsExpanded(false)}
                className="text-gray-400 hover:text-white text-xs cursor-pointer p-1"
              >
                ✕
              </button>
            </div>
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">لوحة التعليمات الشاملة</span>
              <kbd className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-[11px] font-mono text-purple-400">F1</kbd>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">القائمة الجانبية السريعة</span>
              <kbd className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-[11px] font-mono text-cyan-400">Alt + S</kbd>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">المراجعة السريعة والمأذونية</span>
              <kbd className="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 rounded text-[11px] font-mono text-amber-300 font-bold">Ctrl + M</kbd>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">إضافة شارع جديد</span>
              <kbd className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-[11px] font-mono text-emerald-400">Ctrl + N</kbd>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">البحث الفوري</span>
              <kbd className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-[11px] font-mono text-blue-400">Ctrl + F أو /</kbd>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-gray-800/60">
              <span className="text-gray-300">التراجع عن آخر إجراء</span>
              <kbd className="px-2 py-0.5 bg-gray-800 border border-gray-700 rounded text-[11px] font-mono text-amber-400">Ctrl + Z</kbd>
            </div>
          </div>

          <div className="pt-2 border-t border-gray-800 flex items-center justify-between text-[11px] text-gray-400">
            <span>تفعيل الاختصارات:</span>
            <button
              type="button"
              onClick={() => onUpdateSettings({
                ...settings,
                enableKeyboardShortcuts: !shortcutsEnabled
              })}
              className={`px-2.5 py-1 rounded-lg font-bold text-[10px] transition cursor-pointer flex items-center gap-1 ${
                shortcutsEnabled ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-400'
              }`}
            >
              {shortcutsEnabled ? <Check className="w-3 h-3" /> : null}
              <span>{shortcutsEnabled ? 'مفعلة' : 'معطلة'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Action Pill Bar */}
      <div className="flex items-center gap-1.5 p-1.5 bg-gray-900/90 hover:bg-gray-900 text-white rounded-full shadow-xl border border-gray-700/80 transition-all backdrop-blur-xs">
        
        {/* Undo Button */}
        {canUndo && (
          <button
            type="button"
            onClick={onUndo}
            title={`تراجع عن آخر إجراء (متبقي ${undoCount} خطوة تراجع)`}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-full text-xs font-bold transition cursor-pointer border border-amber-500/30"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>تراجع ({undoCount})</span>
          </button>
        )}

        {/* Quick Add Button */}
        <button
          type="button"
          onClick={onOpenAdd}
          title="إضافة شارع جديد (Ctrl + N)"
          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full text-xs font-bold transition cursor-pointer shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>شارع جديد</span>
        </button>

        {/* Quick Search Button */}
        <button
          type="button"
          onClick={onFocusSearch}
          title="الانتقال للبحث (Ctrl + F)"
          className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded-full transition cursor-pointer"
        >
          <Search className="w-3.5 h-3.5" />
        </button>

        {/* Expand / Collapse shortcuts hint */}
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          title="دليل اختصارات لوحة المفاتيح والإنتاجية"
          className="flex items-center gap-1 px-2.5 py-1 text-gray-300 hover:text-white hover:bg-white/10 rounded-full text-xs transition cursor-pointer"
        >
          <Keyboard className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[11px] font-medium hidden sm:inline">اختصارات</span>
          {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
        </button>
      </div>

    </div>
  );
};
