import React, { useState, useMemo } from 'react';
import { 
  X, 
  ListPlus, 
  CheckCircle, 
  FileSpreadsheet, 
  Layers, 
  AlertTriangle,
  Sparkles,
  Zap,
  Trash2,
  Filter,
  ArrowDownAZ,
  ArrowUpAZ,
  Scissors,
  Eraser,
  Tag,
  Building2,
  FileText,
  FileCheck2,
  RotateCcw,
  Check,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { 
  RecordItem, 
  ThemeType, 
  RecordStatus,
  DEFAULT_STREET_CATEGORIES,
  DEFAULT_UNOFFICIAL_SUBTYPES,
  OFFICIAL_SEVEN_NOTARIZATIONS 
} from '../types';
import { normalizeArabicText } from '../utils/arabicEncoding';
import { OFFICIAL_DISTRICTS } from '../utils/districtColors';
import { parseSmartBatchText } from '../utils/smartProductivity';
import { ArabicUtils } from '../utils/arabicUtils';

export type BulkDuplicateStrategy = 'merge' | 'skip' | 'separate';

interface BulkEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddBulk: (records: Omit<RecordItem, 'id'>[], strategy?: BulkDuplicateStrategy) => void;
  existingRecords: RecordItem[];
  theme: ThemeType;
}

export function BulkEntryModal({
  isOpen,
  onClose,
  onAddBulk,
  existingRecords,
  theme
}: BulkEntryModalProps) {
  // Modes:
  // 1. 'specific_notary': إدخال قائمة شوارع لمأذونية محددة بنفس المواصفات والبيانات التوثيقية مع المعالجة الأبجدية والتدقيق التلقائي
  // 2. 'smart_auto': اللصق الذكي المطور والتحليل التلقائي
  // 3. 'simple': إدخال أسماء مجردة سريعة
  // 4. 'excel_columns': لصق مباشر من جداول إكسيل (أعمدة مفصولة بـ Tab)
  const [entryMode, setEntryMode] = useState<'specific_notary' | 'smart_auto' | 'simple' | 'excel_columns'>('specific_notary');
  
  // ══════════════════════════════════════════════════════════════
  // Mode 1: Specific Notary State (المأذونية المحددة والمواصفات الموحدة)
  // ══════════════════════════════════════════════════════════════
  const [notaryStreetListText, setNotaryStreetListText] = useState('');
  const [permissionCategory, setPermissionCategory] = useState<'مأذونية رسمية' | 'مأذونية غير رسمية'>('مأذونية رسمية');
  const [officialRegion, setOfficialRegion] = useState('شبرا بحري');
  const [unofficialSubType, setUnofficialSubType] = useState('مأذونية محددة / دفاتر مأذون');
  const [suggestedRegion, setSuggestedRegion] = useState('');
  const [defaultPrefix, setDefaultPrefix] = useState('شارع');
  const [defaultCategory, setDefaultCategory] = useState('شارع');
  const [defaultStatus, setDefaultStatus] = useState<RecordStatus>('نشط');
  const [commonMetadata, setCommonMetadata] = useState('');

  // Structured fields for specific notary / flexible sources
  // 1. Notary specific
  const [notaryName, setNotaryName] = useState('');
  const [notaryBookNo, setNotaryBookNo] = useState('');
  const [notaryDeedNo, setNotaryDeedNo] = useState('');
  const [notaryDate, setNotaryDate] = useState('');

  // 2. Bailiffs
  const [bailiffReportNo, setBailiffReportNo] = useState('');
  const [bailiffCourt, setBailiffCourt] = useState('');
  const [bailiffName, setBailiffName] = useState('');
  const [bailiffDate, setBailiffDate] = useState('');
  const [bailiffCircuit, setBailiffCircuit] = useState('');

  // 3. Real Estate Registry
  const [registryDocNo, setRegistryDocNo] = useState('');
  const [registryOffice, setRegistryOffice] = useState('');
  const [cadastralParcelNo, setCadastralParcelNo] = useState('');

  // 4. Real Estate Tax
  const [taxPropertyNo, setTaxPropertyNo] = useState('');
  const [taxDistrict, setTaxDistrict] = useState('');

  // 5. Courts
  const [courtCaseNo, setCourtCaseNo] = useState('');
  const [courtYear, setCourtYear] = useState('');
  const [courtName, setCourtName] = useState('');

  // 6. Survey Maps
  const [mapType, setMapType] = useState('');
  const [mapSheetNo, setMapSheetNo] = useState('');
  const [mapScale, setMapScale] = useState('');

  // 7. Custom Contracts
  const [contractNumber, setContractNumber] = useState('');
  const [contractDate, setContractDate] = useState('');
  const [nationalIdRef, setNationalIdRef] = useState('');
  const [customSourceName, setCustomSourceName] = useState('');

  // Duplicate strategy selection: 'merge' | 'skip' | 'separate'
  const [duplicateStrategy, setDuplicateStrategy] = useState<BulkDuplicateStrategy>('merge');

  // Simple mode state
  const [simpleRawText, setSimpleRawText] = useState('');
  const [simplePrefix, setSimplePrefix] = useState('شارع');
  const [simplePermission, setSimplePermission] = useState('شبرا بحري');
  const [simpleMetadata, setSimpleMetadata] = useState('');

  // Excel columns mode state
  const [excelPasteText, setExcelPasteText] = useState('');

  // Smart Auto Paste mode state
  const [smartAutoText, setSmartAutoText] = useState('');

  // Audit Feedback Message state
  const [auditFeedback, setAuditFeedback] = useState<string | null>(null);

  // Existing normalized records for duplicate matching
  const existingRecordsMap = useMemo(() => {
    const map = new Map<string, RecordItem>();
    existingRecords.forEach(r => {
      const norm = normalizeArabicText(r.name);
      if (norm && !map.has(norm)) {
        map.set(norm, r);
      }
    });
    return map;
  }, [existingRecords]);

  // Existing counts per notary
  const existingCountsPerNotary = useMemo(() => {
    const counts = new Map<string, number>();
    existingRecords.forEach(r => {
      const p = r.permission || 'غير محدد';
      counts.set(p, (counts.get(p) || 0) + 1);
    });
    return counts;
  }, [existingRecords]);

  // Build combined metadata string for specific notary mode
  const buildSpecificNotaryMetadata = (): string => {
    const parts: string[] = [];

    if (permissionCategory === 'مأذونية غير رسمية') {
      if (unofficialSubType) parts.push(`[نوع غير رسمي: ${unofficialSubType}]`);
      if (suggestedRegion.trim()) parts.push(`[مأذونية مقترحة: ${suggestedRegion.trim()}]`);

      if (unofficialSubType === 'مأذونية محددة / دفاتر مأذون') {
        if (notaryName.trim()) parts.push(`اسم المأذون: ${notaryName.trim()}`);
        if (notaryBookNo.trim()) parts.push(`رقم الدفتر: ${notaryBookNo.trim()}`);
        if (notaryDeedNo.trim()) parts.push(`رقم الإشهاد: ${notaryDeedNo.trim()}`);
        if (notaryDate.trim()) parts.push(`تاريخ الإشهاد: ${notaryDate.trim()}`);
      } else if (unofficialSubType === 'محضرين / إعلانات قضائية') {
        if (bailiffReportNo.trim()) parts.push(`رقم المحضر: ${bailiffReportNo.trim()}`);
        if (bailiffCourt.trim()) parts.push(`المحكمة: ${bailiffCourt.trim()}`);
        if (bailiffName.trim()) parts.push(`اسم المحضر: ${bailiffName.trim()}`);
        if (bailiffDate.trim()) parts.push(`تاريخ الإعلان: ${bailiffDate.trim()}`);
        if (bailiffCircuit.trim()) parts.push(`الدائرة: ${bailiffCircuit.trim()}`);
      } else if (unofficialSubType === 'شهر عقاري / توثيق / سجل عيني') {
        if (registryDocNo.trim()) parts.push(`رقم التوثيق: ${registryDocNo.trim()}`);
        if (registryOffice.trim()) parts.push(`مكتب التوثيق: ${registryOffice.trim()}`);
        if (cadastralParcelNo.trim()) parts.push(`رقم القطعة/الحوض: ${cadastralParcelNo.trim()}`);
      } else if (unofficialSubType === 'ضرائب عقارية / عوائد') {
        if (taxPropertyNo.trim()) parts.push(`رقم العقار/المكلفة: ${taxPropertyNo.trim()}`);
        if (taxDistrict.trim()) parts.push(`الشياخة/المأمورية: ${taxDistrict.trim()}`);
      } else if (unofficialSubType === 'محاكم وقضايا') {
        if (courtCaseNo.trim()) parts.push(`رقم القضية: ${courtCaseNo.trim()}`);
        if (courtYear.trim()) parts.push(`السنة القضائية: ${courtYear.trim()}`);
        if (courtName.trim()) parts.push(`المحكمة/الدائرة: ${courtName.trim()}`);
      } else if (unofficialSubType === 'خرائط مساحية وهيئة المساحة') {
        if (mapSheetNo.trim()) parts.push(`رقم اللوحة: ${mapSheetNo.trim()}`);
        if (mapScale.trim()) parts.push(`مقياس الرسم: ${mapScale.trim()}`);
        if (mapType.trim()) parts.push(`نوع الخرائط: ${mapType.trim()}`);
      } else if (unofficialSubType === 'أخرى (مخصص)') {
        if (customSourceName.trim()) parts.push(`المصدر المخصص: ${customSourceName.trim()}`);
      } else if (unofficialSubType.includes('عقود') || unofficialSubType.includes('داتا خاصة')) {
        if (contractNumber.trim()) parts.push(`رقم العقد: ${contractNumber.trim()}`);
        if (contractDate.trim()) parts.push(`التاريخ: ${contractDate.trim()}`);
        if (nationalIdRef.trim()) parts.push(`الرقم القومي: ${nationalIdRef.trim()}`);
      }
    }

    if (commonMetadata.trim()) {
      parts.push(commonMetadata.trim());
    }

    return parts.join(' | ');
  };

  // ══════════════════════════════════════════════════════════════
  // List Processing & Cleaning Utilities (أدوات المعالجة الأبجدية والتدقيق)
  // ══════════════════════════════════════════════════════════════

  // 1. Remove line numbers (e.g. "1- ", "1. ", "[1] ", "١- ")
  const handleCleanNumbers = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    let countCleaned = 0;
    const cleaned = targetText
      .split('\n')
      .map(line => {
        const hasNum = /^[\s]*[\(\[\{]?[0-9\u0660-\u0669]+[\)\]\}]?[\.\-:\/\s_]+/.test(line);
        if (hasNum) countCleaned++;
        return line
          .replace(/^[\s]*[\(\[\{]?[0-9\u0660-\u0669]+[\)\]\}]?[\.\-:\/\s_]+/, '')
          .trim();
      })
      .filter(Boolean)
      .join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(cleaned);
    } else {
      setSimpleRawText(cleaned);
    }
    setAuditFeedback(`✓ تم تنظيف أرقام الترقيم من (${countCleaned}) سطر`);
  };

  // 2. Remove redundant prefixes like "ش.", "ش/", "ح/", "شارع ", "حارة "
  const handleCleanPrefixes = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    let countCleaned = 0;
    const cleaned = targetText
      .split('\n')
      .map(line => {
        let l = line.trim();
        const prev = l;
        l = l.replace(/^[\s]*(?:ش[\.\/\:\-]|ش\.|\/ش|ح[\.\/\:\-]|ح\.)\s*/i, '');
        l = l.replace(/^[\s]*(?:شارع|حارة|زقاق|عطفة|ميدان|طريق|درب|سكة|برج|عمارة|مساكن)\s+/i, '');
        if (l !== prev) countCleaned++;
        return l.trim();
      })
      .filter(Boolean)
      .join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(cleaned);
    } else {
      setSimpleRawText(cleaned);
    }
    setAuditFeedback(`✓ تم تنظيف البوادئ الزائدة من (${countCleaned}) اسم`);
  };

  // 3. Sort list alphabetically (أ - ي)
  const handleSortAlphabeticalAsc = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    const lines = targetText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean);

    lines.sort((a, b) => a.localeCompare(b, 'ar', { sensitivity: 'base' }));
    const sorted = lines.join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(sorted);
    } else {
      setSimpleRawText(sorted);
    }
    setAuditFeedback(`✓ تم ترتيب القائمة أبجدياً تصاعدياً (أ - ي) لعدد (${lines.length}) شارع`);
  };

  // 4. Sort list alphabetically (ي - أ)
  const handleSortAlphabeticalDesc = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    const lines = targetText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean);

    lines.sort((a, b) => b.localeCompare(a, 'ar', { sensitivity: 'base' }));
    const sorted = lines.join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(sorted);
    } else {
      setSimpleRawText(sorted);
    }
    setAuditFeedback(`✓ تم ترتيب القائمة أبجدياً تنازلياً (ي - أ) لعدد (${lines.length}) شارع`);
  };

  // 5. Remove internal duplicates in the text list
  const handleRemoveInternalDuplicates = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    const lines = targetText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean);

    const seen = new Set<string>();
    const uniqueLines: string[] = [];
    let dupsCount = 0;

    lines.forEach(line => {
      const norm = normalizeArabicText(line);
      if (!seen.has(norm)) {
        seen.add(norm);
        uniqueLines.push(line);
      } else {
        dupsCount++;
      }
    });

    const result = uniqueLines.join('\n');
    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(result);
    } else {
      setSimpleRawText(result);
    }
    setAuditFeedback(dupsCount > 0 ? `✓ تم حذف (${dupsCount}) اسم شارع مكرر داخل القائمة` : `✓ القائمة لا تحتوي على أي تكرار داخلي`);
  };

  // 6. Clean extra empty lines and trim whitespace
  const handleCleanEmptyLines = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    const cleaned = targetText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(cleaned);
    } else {
      setSimpleRawText(cleaned);
    }
    setAuditFeedback(`✓ تم إزالة الفراغات والأسطر الفارغة`);
  };

  // 7. Comprehensive 1-Click Auto Audit, Clean & Alphabetical Processing (التدقيق والمعالجة الأبجدية التلقائية الشاملة)
  const handleAutoAuditAndProcess = () => {
    const targetText = entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText;
    if (!targetText.trim()) return;

    const rawLines = targetText.split('\n').map(l => l.trim()).filter(Boolean);
    const originalCount = rawLines.length;

    // A. Strip numbering & leading prefixes
    const cleanedLines = rawLines.map(line => {
      let l = line.replace(/^[\s]*[\(\[\{]?[0-9\u0660-\u0669]+[\)\]\}]?[\.\-:\/\s_]+/, '').trim();
      l = l.replace(/^[\s]*(?:ش[\.\/\:\-]|ش\.|\/ش|ح[\.\/\:\-]|ح\.)\s*/i, '');
      l = l.replace(/^[\s]*(?:شارع|حارة|زقاق|عطفة|ميدان|طريق|درب|سكة|برج|عمارة|مساكن)\s+/i, '');
      return l.trim();
    }).filter(Boolean);

    // B. Deduplicate internally
    const seen = new Set<string>();
    const uniqueLines: string[] = [];
    let dupsRemoved = 0;

    cleanedLines.forEach(line => {
      const norm = normalizeArabicText(line);
      if (!seen.has(norm)) {
        seen.add(norm);
        uniqueLines.push(line);
      } else {
        dupsRemoved++;
      }
    });

    // C. Sort Alphabetically
    uniqueLines.sort((a, b) => a.localeCompare(b, 'ar', { sensitivity: 'base' }));

    const finalResult = uniqueLines.join('\n');

    if (entryMode === 'specific_notary') {
      setNotaryStreetListText(finalResult);
    } else {
      setSimpleRawText(finalResult);
    }

    setAuditFeedback(
      `✓ اكتمل التدقيق التلقائي والمعالجة الأبجدية بنجاح: تم استخراج (${uniqueLines.length}) شارع صالح، وحذف (${dupsRemoved}) تكرار، والترتيب أبجدياً (أ-ي).`
    );
  };

  if (!isOpen) return null;

  // ══════════════════════════════════════════════════════════════
  // Compute Preview Records based on Active Mode
  // ══════════════════════════════════════════════════════════════
  let previewRecords: Omit<RecordItem, 'id'>[] = [];

  const currentNotaryName = permissionCategory === 'مأذونية رسمية' 
    ? officialRegion 
    : (unofficialSubType || 'مأذونية غير رسمي');

  if (entryMode === 'specific_notary') {
    const fullMetadata = buildSpecificNotaryMetadata();
    const effectivePermission = currentNotaryName;

    const lines = notaryStreetListText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean);

    previewRecords = lines.map(line => {
      const hasPrefix = defaultPrefix ? line.startsWith(defaultPrefix) : false;
      const finalName = hasPrefix || !defaultPrefix ? line : `${defaultPrefix} ${line}`;

      return {
        name: finalName,
        permission: effectivePermission,
        category: defaultCategory || defaultPrefix || 'شارع',
        metadata: fullMetadata,
        status: defaultStatus
      };
    });
  } else if (entryMode === 'smart_auto') {
    previewRecords = parseSmartBatchText(smartAutoText).map(r => ({
      ...r,
      permission: r.permission || 'شبرا بحري',
      status: 'نشط'
    }));
  } else if (entryMode === 'simple') {
    const lines = simpleRawText
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean);

    previewRecords = lines.map(line => {
      const finalName = line.startsWith(simplePrefix) ? line : `${simplePrefix} ${line}`;
      return {
        name: finalName,
        permission: simplePermission,
        category: simplePrefix,
        metadata: simpleMetadata.trim(),
        status: 'نشط'
      };
    });
  } else {
    // Excel columns paste mode (Tab/Pipe/Comma-separated values)
    const rows = excelPasteText
      .split('\n')
      .map(r => r.trim())
      .filter(Boolean);

    previewRecords = rows.map(row => {
      const cols = row.includes('\t') 
        ? row.split('\t') 
        : row.includes('|') 
          ? row.split('|') 
          : row.split(',');

      const colName = (cols[0] || '').trim();
      const colPermission = (cols[1] || 'شبرا بحري').trim();
      const colMetadata = (cols[2] || '').trim();
      const colCategory = (cols[3] || 'شارع').trim();

      return {
        name: colName || 'بدون اسم',
        permission: colPermission || 'شبرا بحري',
        category: colCategory || 'شارع',
        metadata: colMetadata,
        status: 'نشط'
      };
    }).filter(r => r.name !== 'بدون اسم');
  }

  // Count matches with existing database
  const duplicateMatches = previewRecords.filter(item => existingRecordsMap.has(normalizeArabicText(item.name)));
  const duplicateCount = duplicateMatches.length;
  const uniqueCount = previewRecords.length - duplicateCount;

  // Check internal duplicates in current text lines
  const currentLines = (entryMode === 'specific_notary' ? notaryStreetListText : simpleRawText)
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean);
  
  const rawSet = new Set<string>();
  let internalDuplicateCount = 0;
  currentLines.forEach(l => {
    const norm = normalizeArabicText(l);
    if (rawSet.has(norm)) internalDuplicateCount++;
    else rawSet.add(norm);
  });

  const notaryExistingCount = existingCountsPerNotary.get(currentNotaryName) || 0;

  const handleSaveBulk = () => {
    if (previewRecords.length === 0) return;
    onAddBulk(previewRecords, duplicateStrategy);
    setNotaryStreetListText('');
    setSimpleRawText('');
    setExcelPasteText('');
    setSmartAutoText('');
    setCommonMetadata('');
    setAuditFeedback(null);
    onClose();
  };

  const getThemeBg = () => {
    switch (theme) {
      case 'excel': return 'bg-emerald-800 text-white';
      case 'libreoffice': return 'bg-cyan-900 text-white';
      case 'hybrid': return 'bg-gradient-to-l from-emerald-800 via-cyan-900 to-indigo-950 text-white';
      case 'modern':
      default: return 'bg-slate-900 text-white';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-gray-200 flex flex-col max-h-[96vh]">
        
        {/* ═══ Header ═══ */}
        <div className={`px-6 py-3.5 flex items-center justify-between shrink-0 ${getThemeBg()}`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-xl shadow-xs">
              <ListPlus className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                إدخال قوائم الشوارع للمأذونيات مع المعالجة الأبجدية والتدقيق التلقائي
              </h3>
              <p className="text-xs text-white/80">
                إدراج قائمة شوارع مخصصة لمأذونية محددة مع الفرز الأبجدي، تنظيف البوادئ والترقيم، والتدقيق الآلي
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-lg hover:bg-white/20 transition text-white cursor-pointer"
            title="إغلاق النافذة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ Mode Selector Tabs ═══ */}
        <div className="bg-gray-100 px-4 sm:px-6 pt-2.5 pb-0 flex flex-wrap gap-1.5 sm:gap-2 border-b border-gray-200 shrink-0">
          
          <button
            type="button"
            onClick={() => setEntryMode('specific_notary')}
            className={`px-4 py-2.5 rounded-t-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
              entryMode === 'specific_notary'
                ? 'bg-white text-emerald-900 shadow-xs border-t-2 border-emerald-600 border-x border-gray-200'
                : 'text-gray-600 hover:bg-gray-200/70'
            }`}
          >
            <Building2 className="w-4 h-4 text-emerald-700" />
            <span>1. مأذونية محددة (قائمة مخصصة + تدقيق أبجدي)</span>
          </button>

          <button
            type="button"
            onClick={() => setEntryMode('smart_auto')}
            className={`px-4 py-2.5 rounded-t-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
              entryMode === 'smart_auto'
                ? 'bg-white text-emerald-900 shadow-xs border-t-2 border-emerald-600 border-x border-gray-200'
                : 'text-gray-600 hover:bg-gray-200/70'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>2. اللصق الذكي المطور (تحليل تلقائي)</span>
          </button>

          <button
            type="button"
            onClick={() => setEntryMode('simple')}
            className={`px-4 py-2.5 rounded-t-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
              entryMode === 'simple'
                ? 'bg-white text-emerald-900 shadow-xs border-t-2 border-emerald-600 border-x border-gray-200'
                : 'text-gray-600 hover:bg-gray-200/70'
            }`}
          >
            <Layers className="w-4 h-4 text-indigo-600" />
            <span>3. إدخال أسماء مجردة سريعة</span>
          </button>

          <button
            type="button"
            onClick={() => setEntryMode('excel_columns')}
            className={`px-4 py-2.5 rounded-t-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
              entryMode === 'excel_columns'
                ? 'bg-white text-emerald-900 shadow-xs border-t-2 border-emerald-600 border-x border-gray-200'
                : 'text-gray-600 hover:bg-gray-200/70'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>4. لصق أعمدة إكسيل (Tab)</span>
          </button>
        </div>

        {/* ═══ Content Body ═══ */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-right">
          
          {/* ═══════════════════════════════════════════════════════ */}
          {/* TAB 1: SPECIFIC NOTARY ENTRY (قائمة شوارع لمأذونية محددة) */}
          {/* ═══════════════════════════════════════════════════════ */}
          {entryMode === 'specific_notary' && (
            <div className="space-y-4">
              
              {/* Instructions & Quality banner */}
              <div className="bg-emerald-50/90 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-950 flex items-start gap-2.5 leading-relaxed">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-emerald-900 block font-bold mb-0.5">
                    💡 إدخال وتدقيق قائمة شوارع مرتبطة بمأذونية محددة:
                  </strong>
                  اختر المأذونية أو جهة الاختصاص من القائمة المنسدلة، ثم ألصق قائمة أسماء الشوارع. استخدم زر <strong>«⚡ تدقيق وفحص القائمة تلقائياً»</strong> لتطبيق المعالجة الأبجدية، تنظيف أرقام الترقيم، إزالة البوادئ المتكررة، وحذف التكرار بضغطة واحدة!
                </div>
              </div>

              {/* Specification Card: Notary Selection & Dropdowns */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200 pb-2">
                  <div className="flex items-center gap-2 font-bold text-stone-900 text-xs sm:text-sm">
                    <Building2 className="w-4 h-4 text-emerald-700" />
                    <span>اختيار المأذونية والمواصفات التوثيقية الموحدة للقائمة</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 bg-emerald-100/80 px-2.5 py-0.5 rounded-lg">
                    <span>مأذونية محددة: <strong>{currentNotaryName}</strong></span>
                    <span className="text-emerald-700">({notaryExistingCount} شارع مسجل مسبقاً)</span>
                  </div>
                </div>

                {/* Primary Category & Region */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      نوع التوثيق والمأذونية <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={permissionCategory}
                      onChange={(e) => setPermissionCategory(e.target.value as any)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-gray-900 cursor-pointer"
                    >
                      <option value="مأذونية رسمية">مأذونية رسمية (النطاقات السبعة)</option>
                      <option value="مأذونية غير رسمية">مأذونية غير رسمية / مصادر مرنة</option>
                    </select>
                  </div>

                  {permissionCategory === 'مأذونية رسمية' ? (
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">
                        اختر المأذونية المحددة <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={officialRegion}
                        onChange={(e) => setOfficialRegion(e.target.value)}
                        className="w-full px-3 py-2 border border-emerald-400 rounded-lg text-xs font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-emerald-50 text-emerald-950 cursor-pointer"
                      >
                        {OFFICIAL_SEVEN_NOTARIZATIONS.map(region => {
                          const count = existingCountsPerNotary.get(region) || 0;
                          return (
                            <option key={region} value={region}>
                              {region} — ({count} {count === 1 ? 'شارع' : 'شوارع'} مسجل)
                            </option>
                          );
                        })}
                      </select>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">
                        تصنيف المصدر غير الرسمي <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={unofficialSubType}
                        onChange={(e) => setUnofficialSubType(e.target.value)}
                        className="w-full px-3 py-2 border border-amber-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500 focus:outline-none bg-amber-50 text-amber-950 cursor-pointer"
                      >
                        {DEFAULT_UNOFFICIAL_SUBTYPES.map(sub => (
                          <option key={sub} value={sub}>{sub}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      البادئة التلقائية للسطور
                    </label>
                    <select
                      value={defaultPrefix}
                      onChange={(e) => {
                        setDefaultPrefix(e.target.value);
                        if (e.target.value) setDefaultCategory(e.target.value);
                      }}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-gray-900 cursor-pointer"
                    >
                      <option value="شارع">شارع</option>
                      <option value="حارة">حارة</option>
                      <option value="زقاق">زقاق</option>
                      <option value="عطفة">عطفة</option>
                      <option value="ميدان">ميدان</option>
                      <option value="طريق">طريق</option>
                      <option value="درب">درب</option>
                      <option value="سكة">سكة</option>
                      <option value="برج">برج</option>
                      <option value="">(بدون بادئة - كما هي)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      حالة السجلات المدخلة
                    </label>
                    <select
                      value={defaultStatus}
                      onChange={(e) => setDefaultStatus(e.target.value as RecordStatus)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-gray-900 cursor-pointer"
                    >
                      <option value="نشط">نشط (معتمد)</option>
                      <option value="قيد المراجعة">قيد المراجعة والتدقيق</option>
                      <option value="تام">تام 🔒 (عنوان الحقيقة)</option>
                    </select>
                  </div>
                </div>

                {/* Subtype Structured Metadata Fields */}
                {permissionCategory === 'مأذونية غير رسمية' && (
                  <div className="bg-white p-3 rounded-xl border border-stone-200 space-y-2.5">
                    {unofficialSubType === 'مأذونية محددة / دفاتر مأذون' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">اسم المأذون الشرعي</label>
                          <input
                            type="text"
                            value={notaryName}
                            onChange={(e) => setNotaryName(e.target.value)}
                            placeholder="مثال: الشيخ / محمد عبد الله"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم الدفتر</label>
                          <input
                            type="text"
                            value={notaryBookNo}
                            onChange={(e) => setNotaryBookNo(e.target.value)}
                            placeholder="مثال: دفتر 14 زواج"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم الإشهاد / القيد</label>
                          <input
                            type="text"
                            value={notaryDeedNo}
                            onChange={(e) => setNotaryDeedNo(e.target.value)}
                            placeholder="مثال: قيد 45 لسنة 2023"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">تاريخ الإشهاد / الدفتر</label>
                          <input
                            type="text"
                            value={notaryDate}
                            onChange={(e) => setNotaryDate(e.target.value)}
                            placeholder="مثال: 2023/11/15"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}

                    {unofficialSubType === 'محضرين / إعلانات قضائية' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم المحضر / الإعلان</label>
                          <input
                            type="text"
                            value={bailiffReportNo}
                            onChange={(e) => setBailiffReportNo(e.target.value)}
                            placeholder="رقم المحضر"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">محكمة المحضرين</label>
                          <input
                            type="text"
                            value={bailiffCourt}
                            onChange={(e) => setBailiffCourt(e.target.value)}
                            placeholder="محكمة بندر دمنهور"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">اسم المحضر</label>
                          <input
                            type="text"
                            value={bailiffName}
                            onChange={(e) => setBailiffName(e.target.value)}
                            placeholder="اسم المحضر"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">تاريخ الإعلان</label>
                          <input
                            type="text"
                            value={bailiffDate}
                            onChange={(e) => setBailiffDate(e.target.value)}
                            placeholder="تاريخ الإعلان"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">الدائرة / الجدول</label>
                          <input
                            type="text"
                            value={bailiffCircuit}
                            onChange={(e) => setBailiffCircuit(e.target.value)}
                            placeholder="دائرة مدني / أسرة"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}

                    {unofficialSubType === 'شهر عقاري / توثيق / سجل عيني' && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم المحرر / المشهر</label>
                          <input
                            type="text"
                            value={registryDocNo}
                            onChange={(e) => setRegistryDocNo(e.target.value)}
                            placeholder="رقم المشهر لسنة ..."
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">مكتب / فرع التوثيق</label>
                          <input
                            type="text"
                            value={registryOffice}
                            onChange={(e) => setRegistryOffice(e.target.value)}
                            placeholder="مكتب توثيق دمنهور"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم القطعة / الحوض المساحي</label>
                          <input
                            type="text"
                            value={cadastralParcelNo}
                            onChange={(e) => setCadastralParcelNo(e.target.value)}
                            placeholder="قطعة رقم / حوض ..."
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}

                    {unofficialSubType === 'ضرائب عقارية / عوائد' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم العقار / المكلفة</label>
                          <input
                            type="text"
                            value={taxPropertyNo}
                            onChange={(e) => setTaxPropertyNo(e.target.value)}
                            placeholder="رقم العقار أو المكلفة"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">الشياخة / المأمورية</label>
                          <input
                            type="text"
                            value={taxDistrict}
                            onChange={(e) => setTaxDistrict(e.target.value)}
                            placeholder="مأمورية ضرائب دمنهور"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}

                    {unofficialSubType === 'محاكم وقضايا' && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">رقم الدعوى / القضية</label>
                          <input
                            type="text"
                            value={courtCaseNo}
                            onChange={(e) => setCourtCaseNo(e.target.value)}
                            placeholder="رقم القضية"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">السنة القضائية</label>
                          <input
                            type="text"
                            value={courtYear}
                            onChange={(e) => setCourtYear(e.target.value)}
                            placeholder="مثال: 2022"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-gray-700 mb-1">المحكمة / الدائرة</label>
                          <input
                            type="text"
                            value={courtName}
                            onChange={(e) => setCourtName(e.target.value)}
                            placeholder="محكمة دمنهور الابتدائية"
                            className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      <div>
                        <label className="block text-[11px] font-bold text-gray-700 mb-1">مأذونية مقترحة أو أقرب نطاق</label>
                        <input
                          type="text"
                          value={suggestedRegion}
                          onChange={(e) => setSuggestedRegion(e.target.value)}
                          placeholder="مثال: شبرا بحري أو سكنيدة"
                          className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-gray-700 mb-1">ملاحظات أو وصف إضافي مشترك لجميع السطور</label>
                        <input
                          type="text"
                          value={commonMetadata}
                          onChange={(e) => setCommonMetadata(e.target.value)}
                          placeholder="مثال: محيط مسجد التوبة، متفرع من ..."
                          className="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {permissionCategory === 'مأذونية رسمية' && (
                  <div>
                    <label className="block text-[11px] font-bold text-gray-700 mb-1">
                      ملاحظات أو بيان وصفي مشترك لجميع شوارع القائمة (اختياري)
                    </label>
                    <input
                      type="text"
                      value={commonMetadata}
                      onChange={(e) => setCommonMetadata(e.target.value)}
                      placeholder="مثال: قطاع دمنهور القديمة، شوارع النطاق الشمالي..."
                      className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-xs"
                    />
                  </div>
                )}
              </div>

              {/* ═══ Intelligent Processing & Automatic Audit Toolbar ═══ */}
              <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 rounded-xl p-3.5 space-y-2.5 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-100 pb-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500 fill-amber-400" />
                    <span className="text-xs font-black text-emerald-950">
                      أدوات المعالجة الأبجدية والتدقيق التلقائي للقائمة المخصصة
                    </span>
                  </div>

                  {/* 1-Click Master Audit Button */}
                  <button
                    type="button"
                    onClick={handleAutoAuditAndProcess}
                    disabled={!notaryStreetListText.trim()}
                    className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white rounded-lg text-xs font-black shadow-xs flex items-center gap-1.5 transition cursor-pointer active:scale-95"
                    title="تنظيف الأرقام والبوادئ، إزالة التكرار الداخلي، وفرز القائمة أبجدياً بضغطة واحدة"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                    <span>⚡ تدقيق وفحص القائمة تلقائياً (فرز + تنظيف + إزالة التكرار)</span>
                  </button>
                </div>

                {/* Individual Action Chips */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-bold text-gray-600 ml-1">معالجة فردية:</span>
                  
                  {/* Sort Asc */}
                  <button
                    type="button"
                    onClick={handleSortAlphabeticalAsc}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-purple-50 text-purple-900 border border-purple-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="ترتيب القائمة أبجدياً من الألف إلى الياء (أ - ي)"
                  >
                    <ArrowDownAZ className="w-3.5 h-3.5 text-purple-600" />
                    <span>فرز أبجدي (أ - ي)</span>
                  </button>

                  {/* Sort Desc */}
                  <button
                    type="button"
                    onClick={handleSortAlphabeticalDesc}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-purple-50 text-purple-900 border border-purple-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="ترتيب القائمة أبجدياً من الياء إلى الألف (ي - أ)"
                  >
                    <ArrowUpAZ className="w-3.5 h-3.5 text-purple-600" />
                    <span>فرز عكسي (ي - أ)</span>
                  </button>

                  {/* Clean Numbers */}
                  <button
                    type="button"
                    onClick={handleCleanNumbers}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-amber-50 text-amber-900 border border-amber-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="إزالة أرقام الترقيم والشرطات من بدايات السطور (مثل 1- أو 1.)"
                  >
                    <Eraser className="w-3.5 h-3.5 text-amber-600" />
                    <span>تنظيف الأرقام</span>
                  </button>

                  {/* Clean Prefixes */}
                  <button
                    type="button"
                    onClick={handleCleanPrefixes}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-blue-50 text-blue-900 border border-blue-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="إزالة البوادئ المتكررة (ش. ، ش/ ، شارع ، حارة)"
                  >
                    <Scissors className="w-3.5 h-3.5 text-blue-600" />
                    <span>تنظيف البوادئ</span>
                  </button>

                  {/* Remove Internal Duplicates */}
                  <button
                    type="button"
                    onClick={handleRemoveInternalDuplicates}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-rose-50 text-rose-900 border border-rose-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="حذف الشوارع المكررة داخل القائمة ذاتها"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>حذف التكرار الداخلي</span>
                  </button>

                  {/* Clean Empty Lines */}
                  <button
                    type="button"
                    onClick={handleCleanEmptyLines}
                    disabled={!notaryStreetListText.trim()}
                    className="px-2.5 py-1 bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 rounded-lg text-[11px] font-medium transition flex items-center gap-1 cursor-pointer shadow-2xs"
                    title="إزالة الأسطر والفراغات الفارغة"
                  >
                    <span>تنظيف الفراغات</span>
                  </button>
                </div>

                {/* Audit Feedback Banner */}
                {auditFeedback && (
                  <div className="bg-white/95 border border-emerald-300 text-emerald-900 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center justify-between gap-2 shadow-2xs">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{auditFeedback}</span>
                    </span>
                    <button 
                      type="button" 
                      onClick={() => setAuditFeedback(null)} 
                      className="text-gray-400 hover:text-gray-700"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* List Input Textarea */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-gray-800">
                    قائمة أسماء الشوارع التابعة لمأذونية ({currentNotaryName}) — (ألصق كل اسم بسطر مستقل): <span className="text-red-500">*</span>
                  </label>
                  <span className="text-[11px] text-gray-500 font-medium">
                    عدد السطور الحالية: <strong>{currentLines.length}</strong>
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={notaryStreetListText}
                  onChange={(e) => setNotaryStreetListText(e.target.value)}
                  placeholder={`عبد السلام الشاذلي\nالجمهورية\nالروضة\nسكنيدة\nالمحطة\nشجرة الدر\nالصاغة\n...`}
                  className="w-full p-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-900 text-xs sm:text-sm font-mono whitespace-pre leading-relaxed shadow-inner"
                />
              </div>

              {/* Live Audit Metrics Badge Strip */}
              {previewRecords.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 bg-stone-100/90 rounded-xl border border-stone-200 text-xs font-bold">
                  <div className="bg-white p-2 rounded-lg border border-stone-200 flex flex-col items-center justify-center text-center">
                    <span className="text-gray-500 text-[10px]">إجمالي شوارع القائمة</span>
                    <span className="text-sm font-black text-gray-900">{previewRecords.length} شارع</span>
                  </div>

                  <div className="bg-white p-2 rounded-lg border border-emerald-200 flex flex-col items-center justify-center text-center">
                    <span className="text-emerald-700 text-[10px]">شوارع جديدة تماماً</span>
                    <span className="text-sm font-black text-emerald-700">{uniqueCount} جديد</span>
                  </div>

                  <div className="bg-white p-2 rounded-lg border border-amber-200 flex flex-col items-center justify-center text-center">
                    <span className="text-amber-800 text-[10px]">موجودة مسبقاً بالنظام</span>
                    <span className="text-sm font-black text-amber-800">{duplicateCount} متطابق</span>
                  </div>

                  <div className="bg-white p-2 rounded-lg border border-indigo-200 flex flex-col items-center justify-center text-center">
                    <span className="text-indigo-800 text-[10px]">التكرار الداخلي بالأسطر</span>
                    <span className={`text-sm font-black ${internalDuplicateCount > 0 ? 'text-rose-700' : 'text-indigo-700'}`}>
                      {internalDuplicateCount} مكرر
                    </span>
                  </div>
                </div>
              )}

              {/* Duplicate Strategy Selector */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Filter className="w-4 h-4 text-slate-600" />
                  <span>طريقة معالجة وتفادي التكرار عند وجود شوارع مسجلة مسبقاً:</span>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <label className="flex items-center gap-1.5 cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-slate-200 font-semibold text-emerald-800 hover:bg-emerald-50">
                    <input
                      type="radio"
                      name="dupStrategy"
                      checked={duplicateStrategy === 'merge'}
                      onChange={() => setDuplicateStrategy('merge')}
                      className="text-emerald-600"
                    />
                    <span>دمج وتحديث الملاحظات (الموصى به)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-slate-200 font-medium text-amber-800 hover:bg-amber-50">
                    <input
                      type="radio"
                      name="dupStrategy"
                      checked={duplicateStrategy === 'skip'}
                      onChange={() => setDuplicateStrategy('skip')}
                      className="text-amber-600"
                    />
                    <span>تخطي المكرر</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-slate-200 font-medium text-gray-700 hover:bg-gray-100">
                    <input
                      type="radio"
                      name="dupStrategy"
                      checked={duplicateStrategy === 'separate'}
                      onChange={() => setDuplicateStrategy('separate')}
                      className="text-indigo-600"
                    />
                    <span>إدراج الكل كسجلات منفصلة</span>
                  </label>
                </div>
              </div>

            </div>
          )}

          {/* ═══════════════════════════════════════════════════════ */}
          {/* TAB 2: SMART AUTO-PARSER (اللصق الذكي المطور) */}
          {/* ═══════════════════════════════════════════════════════ */}
          {entryMode === 'smart_auto' && (
            <div className="space-y-4">
              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 text-xs text-amber-950 leading-relaxed space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-900">
                  <Zap className="w-4 h-4 text-amber-600" />
                  <span>⚡ ميزة اللصق الذكي المطور (Smart Auto-Parser):</span>
                </div>
                <p>
                  يمكنك نسخ قائمة نصوص من أي ملف (Word، ملاحظات، أو رسائل)، سواء كانت كل سطر باسم شارع فقط أو مصحوبة بالمأذونية أو الوصف مثل:
                </p>
                <div className="font-mono bg-white p-2 rounded-lg border border-amber-200 text-xs text-gray-800 space-y-1">
                  <p>• شارع عبد السلام الشاذلي (يقترح شبرا بحري تلقائياً)</p>
                  <p>• حارة الحوفي - شبرا بحري - خلف المحطة</p>
                  <p>• ش. طور سيناء : شبرا بحري</p>
                </div>
                <p className="text-xs text-amber-800 font-medium">
                  يقوم المحرك تلقائياً بتنظيف البوادئ (ش. أو ش/) واستخراج الملاحظات واقتراح المأذونية الصحيحة.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  ألصق القائمة هنا (سطر لكل شارع) <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={8}
                  value={smartAutoText}
                  onChange={(e) => setSmartAutoText(e.target.value)}
                  placeholder={`شارع عبد السلام الشاذلي\nحارة الصاغة - شبرا بحري\nشارع الروضة - شبرا قبلي\nش. سكنيدة (بجوار البركة)\n...`}
                  className="w-full p-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-800 text-xs font-mono whitespace-pre"
                />
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════ */}
          {/* TAB 3: SIMPLE RAW TEXT (إدخال أسماء مجردة) */}
          {/* ═══════════════════════════════════════════════════════ */}
          {entryMode === 'simple' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 leading-relaxed">
                <p className="font-bold mb-1">💡 طريقة إدخال القوائم المجردة:</p>
                ألصق أسماء الشوارع (كل اسم في سطر مستقل). سيقوم النظام بتطبيق البادئة ومأذونية النطاقات السبعة المختارة على جميع السطور دفعة واحدة وتنظيمها أبجدياً.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    البادئة والتصنيف التلقائي للسطور
                  </label>
                  <select
                    value={simplePrefix}
                    onChange={(e) => setSimplePrefix(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-gray-800"
                  >
                    <option value="شارع">شارع</option>
                    <option value="حارة">حارة</option>
                    <option value="زقاق">زقاق</option>
                    <option value="عطفة">عطفة</option>
                    <option value="برج">برج</option>
                    <option value="مسجد">مسجد</option>
                    <option value="ميدان">ميدان</option>
                    <option value="طريق">طريق</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    المأذونية المحددة
                  </label>
                  <select
                    value={simplePermission}
                    onChange={(e) => setSimplePermission(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-gray-800"
                  >
                    {OFFICIAL_SEVEN_NOTARIZATIONS.map(region => (
                      <option key={region} value={region}>{region}</option>
                    ))}
                    <option value="مأذونية غير رسمي">مأذونية غير رسمي</option>
                    <option value="حي">حي</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  الوصف أو الملاحظات المشتركة لجميع السطور (اختياري)
                </label>
                <input
                  type="text"
                  value={simpleMetadata}
                  onChange={(e) => setSimpleMetadata(e.target.value)}
                  placeholder="مثال: قطاع دمنهور الشمالي..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-gray-700">
                    قائمة الأسماء (كل سطر اسم بحد ذاته) <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleCleanNumbers}
                      className="px-2 py-0.5 bg-amber-50 text-amber-900 border border-amber-200 rounded text-[10px] font-bold cursor-pointer"
                    >
                      تنظيف الأرقام
                    </button>
                    <button
                      type="button"
                      onClick={handleSortAlphabeticalAsc}
                      className="px-2 py-0.5 bg-purple-50 text-purple-900 border border-purple-200 rounded text-[10px] font-bold cursor-pointer"
                    >
                      فرز أبجدي
                    </button>
                  </div>
                </div>
                <textarea
                  rows={7}
                  value={simpleRawText}
                  onChange={(e) => setSimpleRawText(e.target.value)}
                  placeholder={`الجمهورية\nعيسى\nالمحطة\nشجرة الدر\n...`}
                  className="w-full p-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-800 text-xs font-mono"
                />
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════ */}
          {/* TAB 4: EXCEL COLUMNS (لصق مباشر من إكسيل) */}
          {/* ═══════════════════════════════════════════════════════ */}
          {entryMode === 'excel_columns' && (
            <div className="space-y-4">
              <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-3.5 text-xs text-cyan-900 leading-relaxed space-y-1">
                <p className="font-bold">⚡ طريقة النسخ واللصق المباشر من إكسيل (أعمدة متكاملة):</p>
                <p>إذا كانت لديك جدول في Excel أو Google Sheets يحتوي على الأعمدة التالية:</p>
                <p className="font-mono bg-white px-3 py-1.5 rounded border border-cyan-200 text-xs text-gray-800">
                  [اسم الشارع] &nbsp;&lt;Tab&gt;&nbsp; [المأذونية أو المنطقة] &nbsp;&lt;Tab&gt;&nbsp; [البيان الوصفي] &nbsp;&lt;Tab&gt;&nbsp; [التصنيف]
                </p>
                <p className="text-[11px] text-cyan-800">
                  قم بتحديد الأسطر في إكسيل ثم اضغط <kbd className="bg-white px-1.5 py-0.5 rounded border shadow-xs font-mono">Ctrl + C</kbd> ثم ألصقها هنا مباشرة <kbd className="bg-white px-1.5 py-0.5 rounded border shadow-xs font-mono">Ctrl + V</kbd>.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  مربع اللصق المباشر من جدول إكسيل <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={8}
                  value={excelPasteText}
                  onChange={(e) => setExcelPasteText(e.target.value)}
                  placeholder={`شارع الجمهورية\tشبرا بحري\tرئيسي وحيوي\tشارع\nحارة عيسى\tسكنيدة\tفرعي ضيق\tحارة\nميدان المحطة\tطاموس\tميدان رئيسي\tميدان`}
                  className="w-full p-3.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-gray-800 text-xs font-mono whitespace-pre"
                />
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════ */}
          {/* PREVIEW SECTION (معاينة السجلات الجاهزة للإدراج) */}
          {/* ═══════════════════════════════════════════════════════ */}
          {previewRecords.length > 0 && (
            <div className="space-y-2.5 pt-3 border-t border-gray-200">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>معاينة السجلات الجاهزة للإدراج لمأذونية ({currentNotaryName}) — ({previewRecords.length} سجل):</span>
                </span>
                <div className="flex items-center gap-2 text-xs font-bold">
                  <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                    {uniqueCount} جديد
                  </span>
                  {duplicateCount > 0 && (
                    <span className="text-amber-800 bg-amber-50 border border-amber-300 px-2 py-0.5 rounded-md">
                      {duplicateCount} موجود مسبقاً ({duplicateStrategy === 'merge' ? 'سيتم دمج الملاحظات' : duplicateStrategy === 'skip' ? 'سيتم تخطيه' : 'سيضاف كمنفصل'})
                    </span>
                  )}
                </div>
              </div>

              {duplicateCount > 0 && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-950 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    <strong>تنبيه تكرار:</strong> {duplicateCount} من السجلات متطابقة بالاسم مع سجلات موجودة مسبقاً — بحسب الخيار المحدد ({duplicateStrategy === 'merge' ? '«دمج وتحديث الملاحظات» لن تضيع بياناتك وستدمج في السجل المعتمد' : duplicateStrategy === 'skip' ? '«تخطي المكرر»' : '«إدراج كسجل منفصل»'}).
                  </span>
                </div>
              )}

              <div className="bg-stone-50 max-h-52 overflow-y-auto p-2.5 rounded-xl border border-stone-200 text-xs space-y-1.5">
                {previewRecords.slice(0, 20).map((item, idx) => {
                  const isDup = existingRecordsMap.has(normalizeArabicText(item.name));
                  return (
                    <div key={idx} className="flex flex-wrap items-center justify-between gap-2 p-2 bg-white rounded-lg border border-stone-200 shadow-2xs">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-gray-900">{idx + 1}. {item.name}</span>
                        {isDup ? (
                          <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 border border-amber-300 rounded text-[10px] font-bold">
                            موجود مسبقاً
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded text-[10px] font-bold">
                            جديد ✓
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded font-semibold">{item.permission}</span>
                        <span className="text-gray-500 max-w-[200px] truncate" title={item.metadata}>{item.metadata || 'بدون وصف'}</span>
                        <span className="text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">{item.category}</span>
                      </div>
                    </div>
                  );
                })}
                {previewRecords.length > 20 && (
                  <p className="text-gray-500 italic text-center pt-2 text-xs font-semibold">
                    ... و {previewRecords.length - 20} سجلات أخرى متضمنة في القائمة الجاهزة للإضافة
                  </p>
                )}
              </div>
            </div>
          )}

        </div>

        {/* ═══ Footer ═══ */}
        <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <span className="text-xs font-medium text-gray-700">
            إجمالي السجلات بالقائمة: <strong className="text-emerald-700 font-bold">{previewRecords.length}</strong> شارع لمأذونية <strong className="text-stone-900">{currentNotaryName}</strong>
          </span>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-200 rounded-xl font-semibold text-xs sm:text-sm transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleSaveBulk}
              disabled={previewRecords.length === 0}
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold text-xs sm:text-sm shadow-sm transition cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>إدراج وإضافة القائمة ({previewRecords.length} شارع)</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
