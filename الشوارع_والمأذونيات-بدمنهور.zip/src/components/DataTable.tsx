import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  ArrowUpDown, 
  ArrowUp,
  ArrowDown,
  FileText, 
  Building, 
  MapPin, 
  Tag, 
  CheckSquare, 
  Square,
  MinusSquare,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Hash,
  CheckCircle2,
  Share2,
  AlertTriangle,
  Sparkles,
  Info,
  Copy,
  Check,
  MoreVertical,
  MousePointerClick,
  Layers,
  ChevronUp,
  ChevronDown,
  FileSpreadsheet,
  X,
  MessageSquarePlus,
  StickyNote,
  SlidersHorizontal,
  RotateCcw,
  Compass,
  HeartPulse,
  Activity,
  Zap,
  Wand2,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  History,
  Lock,
  Unlock,
  FileSearch,
  Highlighter,
  Palette
} from 'lucide-react';
import { RecordItem, ThemeType, FilterState } from '../types';
import { AppSettings } from '../types';
import { normalizeArabicText } from '../utils/arabicEncoding';
import { getDistrictColor } from '../utils/districtColors';
import { analyzeAllStreetSimilarities, embedSimilarityNoteIntoMetadata } from '../utils/streetSimilarity';
import { getThemeColors } from '../utils/themeConfig';
import * as XLSX from 'xlsx';

type SortColumn = 'index' | 'name' | 'permission' | 'category' | 'metadata';
type SortDirection = 'asc' | 'desc' | 'none';

export type ConditionalFormattingType = 'alert' | 'review' | null;

export interface ConditionalFormatResult {
  type: ConditionalFormattingType;
  rowBgClass: string;
  badgeText: string;
  badgeClass: string;
  borderRightClass: string;
  dotColor: string;
  keywordMatch: string;
}

/**
 * دالة التنسيق المشروط: فحص وتحديد السجلات التي تحتوي على ملاحظات 'قيد المراجعة' أو 'تنبيه'
 * لتظليلها بلون تمييز خفيف يسهل المسح البصري
 */
export function getRecordConditionalFormat(
  record: RecordItem, 
  enabled: boolean,
  alertsEnabled: boolean = true,
  reviewsEnabled: boolean = true
): ConditionalFormatResult | null {
  if (!enabled) return null;
  const metadata = (record.metadata || '').trim();

  // 1. فحص وجود كلمات التنبيه والتحذير بالملاحظات
  if (alertsEnabled) {
    const alertKeywords = ['تنبيه', 'تحذير', 'خطر', 'انتباه', 'ملاحظة هامة'];
    const matchedAlert = alertKeywords.find(kw => metadata.includes(kw));
    if (matchedAlert) {
      return {
        type: 'alert',
        rowBgClass: 'bg-amber-50/75 hover:bg-amber-100/85 text-amber-950',
        badgeText: `⚠️ ${matchedAlert}`,
        badgeClass: 'bg-amber-100 text-amber-900 border-amber-300 ring-1 ring-amber-400/40',
        borderRightClass: 'border-r-4 border-r-amber-500',
        dotColor: 'bg-amber-500',
        keywordMatch: matchedAlert
      };
    }
  }

  // 2. فحص وجود كلمات قيد المراجعة أو حالة السجل
  if (reviewsEnabled) {
    const reviewKeywords = ['قيد المراجعة', 'مراجعة', 'تدقيق', 'غير مؤكد', 'تحت الفحص', 'مشكوك'];
    const matchedReview = reviewKeywords.find(kw => metadata.includes(kw));
    if (matchedReview || record.status === 'قيد المراجعة') {
      return {
        type: 'review',
        rowBgClass: 'bg-sky-50/75 hover:bg-sky-100/85 text-sky-950',
        badgeText: `🔍 ${matchedReview || 'قيد المراجعة'}`,
        badgeClass: 'bg-sky-100 text-sky-900 border-sky-300 ring-1 ring-sky-400/40',
        borderRightClass: 'border-r-4 border-r-sky-500',
        dotColor: 'bg-sky-500',
        keywordMatch: matchedReview || 'قيد المراجعة'
      };
    }
  }

  return null;
}

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
  record: RecordItem | null;
}

interface DataTableProps {
  records: RecordItem[];
  onEdit: (record: RecordItem) => void;
  onDelete: (id: string) => void;
  onBatchDelete?: (ids: string[]) => void;
  onBatchChangePermission?: (ids: string[], permission: string) => void;
  onQuickBatchFill?: (params: {
    fillType: 'permission' | 'metadata' | 'both' | 'autoInferPermission';
    targetPermission?: string;
    targetMetadata?: string;
    onlyEmpty: boolean;
    selectedIds?: string[];
  }) => void;
  onToast?: (msg: string) => void;
  theme: ThemeType;
  settings: AppSettings;
  onOpenAudit?: (record?: RecordItem) => void;
  onViewAuditLog?: (record: RecordItem) => void;
  lastEditedId?: string | null;
  onQuickUpdateNote?: (id: string, newMetadata: string) => void;
  onEmbedSimilarityNote?: (recordId: string, noteToEmbed: string) => void;
  onEmbedAllSimilarities?: () => void;
  onUpdateSettings?: (settings: AppSettings) => void;
  onOpenSimilarModal?: (rootName?: string) => void;
  onOpenUnderReviewPage?: () => void;
  onBatchUpdateRecords?: (records: RecordItem[]) => void;
  activeDistrictFilter?: string;
  onClearDistrictFilter?: () => void;
}

export function DataTable({
  records,
  onEdit,
  onDelete,
  onBatchDelete,
  onBatchChangePermission,
  onQuickBatchFill,
  onToast,
  theme,
  settings,
  onOpenAudit,
  onViewAuditLog,
  lastEditedId,
  onQuickUpdateNote,
  onEmbedSimilarityNote,
  onEmbedAllSimilarities,
  onUpdateSettings,
  onOpenSimilarModal,
  onOpenUnderReviewPage,
  onBatchUpdateRecords,
  activeDistrictFilter,
  onClearDistrictFilter
}: DataTableProps) {
  const [filterState, setFilterState] = useState<FilterState>({
    searchQuery: '',
    searchMode: 'partial',
    permissionFilter: activeDistrictFilter || 'all',
    categoryFilter: 'all'
  });

  // Sync activeDistrictFilter if updated externally
  useEffect(() => {
    if (activeDistrictFilter !== undefined) {
      setFilterState(prev => ({
        ...prev,
        permissionFilter: activeDistrictFilter || 'all'
      }));
      setCurrentPage(1);
    }
  }, [activeDistrictFilter]);

  const [showPermissionFilterMenu, setShowPermissionFilterMenu] = useState(false);

  const [showOnlySimilar, setShowOnlySimilar] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState<number | 'all'>(() => {
    const saved = localStorage.getItem('street_data_table_page_size');
    if (saved === 'all') return 'all';
    if (saved) {
      const num = Number(saved);
      if (!isNaN(num) && num > 0) return num;
    }
    return 25;
  });
  const [jumpPageInput, setJumpPageInput] = useState<string>('');

  const handlePageSizeChange = (newSize: number | 'all') => {
    setItemsPerPage(newSize);
    localStorage.setItem('street_data_table_page_size', String(newSize));
    setCurrentPage(1);
  };

  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(jumpPageInput.trim(), 10);
    if (!isNaN(parsed) && parsed >= 1 && parsed <= totalPages) {
      setCurrentPage(parsed);
      setJumpPageInput('');
    } else {
      if (onToast) onToast(`يرجى إدخال رقم صفحة صحيح بين 1 و ${totalPages}`);
    }
  };

  // Sorting state for mouse click on headers
  const [sortColumn, setSortColumn] = useState<SortColumn>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  // Mouse Selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [lastSelectedId, setLastSelectedId] = useState<string | null>(null);

  // Context Menu state
  const [contextMenu, setContextMenu] = useState<ContextMenuState>({
    visible: false,
    x: 0,
    y: 0,
    record: null
  });

  // Unlock Permission for Locked / Ground Truth records
  const [canUnlock, setCanUnlock] = useState<boolean>(() => Boolean(settings.canUnlockRecords));

  useEffect(() => {
    if (settings.canUnlockRecords !== undefined) {
      setCanUnlock(Boolean(settings.canUnlockRecords));
    }
  }, [settings.canUnlockRecords]);

  // Batch permission modal / dropdown
  const [batchPermTarget, setBatchPermTarget] = useState<string>('');
  const [showBatchPermSelector, setShowBatchPermSelector] = useState(false);

  // Quick copied feedback
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Scroll to top visibility
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Quick Note modal state (Add Note action from right click context menu)
  const [quickNoteModal, setQuickNoteModal] = useState<{
    isOpen: boolean;
    record: RecordItem | null;
    noteText: string;
  }>({
    isOpen: false,
    record: null,
    noteText: ''
  });

  // Data Health (صحة البيانات) filter & widget state
  type HealthFilterType = 'all' | 'missingMetadata' | 'missingPermission' | 'missingBoth' | 'complete';
  const [healthFilter, setHealthFilter] = useState<HealthFilterType>('all');
  const [isHealthBarCollapsed, setIsHealthBarCollapsed] = useState(false);

  // Quick Fill (تعبئة سريعة) Modal state
  const [isQuickFillModalOpen, setIsQuickFillModalOpen] = useState(false);
  const [quickFillType, setQuickFillType] = useState<'permission' | 'metadata' | 'both' | 'autoInferPermission'>('permission');
  const [quickFillTargetPerm, setQuickFillTargetPerm] = useState('شبرا بحري');
  const [quickFillCustomPerm, setQuickFillCustomPerm] = useState('');
  const [quickFillTargetMeta, setQuickFillTargetMeta] = useState('شارع رئيسي بدمنهور');
  const [quickFillCustomMeta, setQuickFillCustomMeta] = useState('');
  const [quickFillOnlyEmpty, setQuickFillOnlyEmpty] = useState(true);
  const [quickFillScope, setQuickFillScope] = useState<'all' | 'selected'>('all');

  // Conditional Formatting State (تظليل السجلات التي تحتوي على ملاحظات 'قيد المراجعة' أو 'تنبيه' بلون تمييز خفيف)
  const [conditionalFormatting, setConditionalFormatting] = useState<boolean>(() => {
    const saved = localStorage.getItem('street_data_cond_formatting');
    if (saved !== null) return saved === 'true';
    return settings.conditionalFormatting ?? true;
  });

  const [filterConditionalOnly, setFilterConditionalOnly] = useState<'all' | 'alerts' | 'reviews' | 'any'>('all');

  const handleToggleConditionalFormatting = () => {
    const nextVal = !conditionalFormatting;
    setConditionalFormatting(nextVal);
    localStorage.setItem('street_data_cond_formatting', String(nextVal));
    if (onUpdateSettings) {
      onUpdateSettings({ ...settings, conditionalFormatting: nextVal });
    }
    if (onToast) {
      onToast(nextVal ? '✓ تم تفعيل التنسيق المشروط (تظليل ملاحظات التنبيه والمراجعة 🎨)' : 'تم إيقاف التنسيق المشروط');
    }
  };

  // إحصائيات السجلات المميزة بالتنسيق المشروط
  const condFormattingStats = useMemo(() => {
    let alertCount = 0;
    let reviewCount = 0;
    records.forEach(r => {
      const meta = (r.metadata || '').trim();
      const isAlert = /تنبيه|تحذير|خطر|انتباه|ملاحظة هامة/i.test(meta);
      const isReview = /قيد المراجعة|مراجعة|تدقيق|غير مؤكد|تحت الفحص|مشكوك/i.test(meta) || r.status === 'قيد المراجعة';
      if (isAlert) alertCount++;
      if (isReview) reviewCount++;
    });
    return { alertCount, reviewCount, total: alertCount + reviewCount };
  }, [records]);

  const contextMenuRef = useRef<HTMLDivElement>(null);
  const quickNoteInputRef = useRef<HTMLTextAreaElement>(null);

  // Close context menu on click outside or escape
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      if (contextMenuRef.current && !contextMenuRef.current.contains(e.target as Node)) {
        setContextMenu(prev => ({ ...prev, visible: false }));
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setContextMenu(prev => ({ ...prev, visible: false }));
        setShowBatchPermSelector(false);
      }
    };

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('click', handleGlobalClick);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('click', handleGlobalClick);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Pre-calculate similarity cross-references for the entire dataset
  const similarityMap = useMemo(() => {
    return analyzeAllStreetSimilarities(records);
  }, [records]);

  // Count how many records have similarities / cross-references
  const totalSimilarCount = useMemo(() => {
    let count = 0;
    similarityMap.forEach(info => {
      if (info.hasSimilarity) count++;
    });
    return count;
  }, [similarityMap]);

  // Count how many records are under review
  const underReviewRecordsCount = useMemo(() => {
    return records.filter(r => r.status === 'قيد المراجعة').length;
  }, [records]);

  // Extract unique categories and permissions with their exact counts
  const { categories, categoryCounts } = useMemo(() => {
    const counts = new Map<string, number>();
    records.forEach(r => {
      const cat = r.category || 'غير محدد';
      counts.set(cat, (counts.get(cat) || 0) + 1);
    });
    return {
      categories: Array.from(counts.keys()),
      categoryCounts: counts
    };
  }, [records]);

  const { permissions, permissionCounts } = useMemo(() => {
    const counts = new Map<string, number>();
    records.forEach(r => {
      const perm = r.permission || 'غير محدد';
      counts.set(perm, (counts.get(perm) || 0) + 1);
    });
    return {
      permissions: Array.from(counts.keys()),
      permissionCounts: counts
    };
  }, [records]);

  // Comprehensive Data Health (صحة واكتمال البيانات) metrics
  const healthStats = useMemo(() => {
    const total = records.length;
    if (total === 0) {
      return {
        total: 0,
        missingMetadataCount: 0,
        missingPermissionCount: 0,
        missingBothCount: 0,
        completeCount: 0,
        completePercent: 100,
        missingMetadataPercent: 0,
        missingPermissionPercent: 0,
        missingBothPercent: 0,
        missingAnyCount: 0,
        healthScore: 100
      };
    }

    let missingMetadataCount = 0;
    let missingPermissionCount = 0;
    let missingBothCount = 0;
    let completeCount = 0;

    records.forEach(r => {
      const noMeta = !r.metadata || !r.metadata.trim();
      const noPerm = !r.permission || !r.permission.trim() || r.permission === 'غير محدد';
      if (noMeta) missingMetadataCount++;
      if (noPerm) missingPermissionCount++;
      if (noMeta && noPerm) missingBothCount++;
      if (!noMeta && !noPerm && r.name && r.name.trim()) completeCount++;
    });

    const missingAnyCount = records.filter(r => {
      const noMeta = !r.metadata || !r.metadata.trim();
      const noPerm = !r.permission || !r.permission.trim() || r.permission === 'غير محدد';
      return noMeta || noPerm;
    }).length;

    const completePercent = Math.round((completeCount / total) * 100);
    const missingMetadataPercent = Math.round((missingMetadataCount / total) * 100);
    const missingPermissionPercent = Math.round((missingPermissionCount / total) * 100);
    const missingBothPercent = Math.round((missingBothCount / total) * 100);
    
    // Overall Health Score (0-100%): missing permission weight = 0.6, missing metadata weight = 0.4
    const penaltyPerRecord = (missingPermissionCount * 0.6 + missingMetadataCount * 0.4);
    const healthScore = Math.max(0, Math.min(100, Math.round(((total - penaltyPerRecord) / total) * 100)));

    return {
      total,
      missingMetadataCount,
      missingPermissionCount,
      missingBothCount,
      completeCount,
      completePercent,
      missingMetadataPercent,
      missingPermissionPercent,
      missingBothPercent,
      missingAnyCount,
      healthScore
    };
  }, [records]);

  // Filter and sort records
  const filteredRecords = useMemo(() => {
    let result = [...records];

    // Filter by Data Health Status
    if (healthFilter === 'missingMetadata') {
      result = result.filter(r => !r.metadata || !r.metadata.trim());
    } else if (healthFilter === 'missingPermission') {
      result = result.filter(r => !r.permission || !r.permission.trim() || r.permission === 'غير محدد');
    } else if (healthFilter === 'missingBoth') {
      result = result.filter(r => (!r.metadata || !r.metadata.trim()) && (!r.permission || !r.permission.trim() || r.permission === 'غير محدد'));
    } else if (healthFilter === 'complete') {
      result = result.filter(r => (r.metadata && r.metadata.trim()) && (r.permission && r.permission.trim() && r.permission !== 'غير محدد'));
    }

    // Filter by shared / duplicate only
    if (showOnlySimilar || filterState.similarRecordsOnly) {
      result = result.filter(r => {
        const sim = similarityMap.get(r.id);
        return sim && sim.hasSimilarity;
      });
    }

    // Filter by Truth Records (بيان تام مغلق 🔒)
    if (filterState.truthRecordsOnly) {
      result = result.filter(r => r.status === 'تام' || r.isTruthRecord || r.isLocked);
    }

    // Filter by status if specified
    if (filterState.status && filterState.status !== 'all') {
      if (filterState.status === 'تام') {
        result = result.filter(r => r.status === 'تام' || r.isTruthRecord || r.isLocked);
      } else {
        result = result.filter(r => r.status === filterState.status);
      }
    }

    // Filter by permission
    if (filterState.permissionFilter !== 'all') {
      result = result.filter(r => r.permission === filterState.permissionFilter);
    }

    // Filter by category
    if (filterState.categoryFilter !== 'all') {
      result = result.filter(r => r.category === filterState.categoryFilter);
    }

    // Filter by Conditional Formatting (تنبيه / قيد المراجعة)
    if (filterConditionalOnly === 'alerts') {
      result = result.filter(r => /تنبيه|تحذير|خطر|انتباه|ملاحظة هامة/i.test((r.metadata || '').trim()));
    } else if (filterConditionalOnly === 'reviews') {
      result = result.filter(r => /قيد المراجعة|مراجعة|تدقيق|غير مؤكد|تحت الفحص|مشكوك/i.test((r.metadata || '').trim()) || r.status === 'قيد المراجعة');
    } else if (filterConditionalOnly === 'any') {
      result = result.filter(r => {
        const meta = (r.metadata || '').trim();
        return /تنبيه|تحذير|خطر|انتباه|ملاحظة هامة/i.test(meta) || /قيد المراجعة|مراجعة|تدقيق|غير مؤكد|تحت الفحص|مشكوك/i.test(meta) || r.status === 'قيد المراجعة';
      });
    }

    // Filter by name search (partial, exact, or startsWith) with Arabic normalization
    if (filterState.searchQuery.trim()) {
      const q = normalizeArabicText(filterState.searchQuery);
      if (filterState.searchMode === 'exact') {
        result = result.filter(r => normalizeArabicText(r.name) === q);
      } else if (filterState.searchMode === 'startsWith') {
        result = result.filter(r => {
          const normName = normalizeArabicText(r.name);
          // Check if full name starts with q, or without prefix
          return normName.startsWith(q) || normName.split(' ').some(part => part.startsWith(q));
        });
      } else {
        result = result.filter(r =>
          normalizeArabicText(r.name).includes(q) ||
          normalizeArabicText(r.metadata).includes(q) ||
          normalizeArabicText(r.category).includes(q)
        );
      }
    }

    // Mouse Sorting
    if (sortDirection !== 'none') {
      result.sort((a, b) => {
        let valA = '';
        let valB = '';

        if (sortColumn === 'name') {
          valA = a.name;
          valB = b.name;
        } else if (sortColumn === 'permission') {
          valA = a.permission;
          valB = b.permission;
        } else if (sortColumn === 'category') {
          valA = a.category;
          valB = b.category;
        } else if (sortColumn === 'metadata') {
          valA = a.metadata;
          valB = b.metadata;
        }

        const comp = valA.localeCompare(valB, 'ar');
        return sortDirection === 'asc' ? comp : -comp;
      });
    }

    return result;
  }, [records, filterState, showOnlySimilar, similarityMap, sortColumn, sortDirection]);

  // Pagination logic
  const effectivePageSize = itemsPerPage === 'all' ? (filteredRecords.length || 1) : itemsPerPage;
  const totalPages = itemsPerPage === 'all' ? 1 : (Math.ceil(filteredRecords.length / effectivePageSize) || 1);

  // Clamp current page when records are deleted/filtered so the table never shows empty
  useEffect(() => {
    setCurrentPage(p => Math.min(Math.max(p, 1), totalPages));
  }, [totalPages]);

  // When a record is edited, automatically navigate to the page where it lives!
  useEffect(() => {
    if (!lastEditedId || itemsPerPage === 'all') return;
    const idx = filteredRecords.findIndex(r => r.id === lastEditedId);
    if (idx !== -1) {
      const targetPage = Math.floor(idx / itemsPerPage) + 1;
      setCurrentPage(targetPage);
    }
  }, [lastEditedId, filteredRecords, itemsPerPage]);

  // Check if edited record exists in DB but is hidden by active filter
  const isEditedRecordHiddenByFilter = useMemo(() => {
    if (!lastEditedId) return false;
    const existsInAll = records.some(r => r.id === lastEditedId);
    const existsInFiltered = filteredRecords.some(r => r.id === lastEditedId);
    return existsInAll && !existsInFiltered;
  }, [lastEditedId, records, filteredRecords]);

  const paginatedRecords = useMemo(() => {
    if (itemsPerPage === 'all') return filteredRecords;
    const start = (currentPage - 1) * itemsPerPage;
    return filteredRecords.slice(start, start + itemsPerPage);
  }, [filteredRecords, currentPage, itemsPerPage]);

  // Handle Header Sort Click
  const handleSortClick = (column: SortColumn) => {
    if (sortColumn === column) {
      if (sortDirection === 'asc') setSortDirection('desc');
      else if (sortDirection === 'desc') {
        setSortColumn('name');
        setSortDirection('asc');
      }
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // Selection handlers
  const handleSelectAllPage = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      const newSet = new Set(selectedIds);
      paginatedRecords.forEach(r => newSet.add(r.id));
      setSelectedIds(newSet);
    } else {
      const newSet = new Set(selectedIds);
      paginatedRecords.forEach(r => newSet.delete(r.id));
      setSelectedIds(newSet);
    }
  };

  const handleRowCheckboxClick = (e: React.MouseEvent, recordId: string) => {
    e.stopPropagation();
    const newSet = new Set(selectedIds);

    if (e.shiftKey && lastSelectedId) {
      const currentIndex = paginatedRecords.findIndex(r => r.id === recordId);
      const lastIndex = paginatedRecords.findIndex(r => r.id === lastSelectedId);

      if (currentIndex !== -1 && lastIndex !== -1) {
        const start = Math.min(currentIndex, lastIndex);
        const end = Math.max(currentIndex, lastIndex);
        for (let i = start; i <= end; i++) {
          newSet.add(paginatedRecords[i].id);
        }
        setSelectedIds(newSet);
        setLastSelectedId(recordId);
        return;
      }
    }

    if (newSet.has(recordId)) {
      newSet.delete(recordId);
    } else {
      newSet.add(recordId);
    }
    setSelectedIds(newSet);
    setLastSelectedId(recordId);
  };

  // Context Menu Trigger
  const handleRowContextMenu = (e: React.MouseEvent, record: RecordItem) => {
    e.preventDefault();
    e.stopPropagation();

    const mouseX = e.clientX;
    const mouseY = e.clientY;
    const menuWidth = 260;
    const menuHeight = 340;

    const clampedX = mouseX + menuWidth > window.innerWidth ? window.innerWidth - menuWidth - 10 : mouseX;
    const clampedY = mouseY + menuHeight > window.innerHeight ? window.innerHeight - menuHeight - 10 : mouseY;

    setContextMenu({
      visible: true,
      x: clampedX,
      y: clampedY,
      record
    });
  };

  // Quick Copy street name
  const handleCopyStreetName = (e: React.MouseEvent, text: string, id: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    if (onToast) onToast(`✓ تم نسخ «${text}» إلى الحافظة`);
  };

  // Copy full record details
  const handleCopyRecordDetails = (record: RecordItem) => {
    const details = `اسم الشارع: ${record.name}\nالمأذونية: ${record.permission || 'غير محدد'}\nالتصنيف: ${record.category || 'شارع'}\nالبيان الوصفي: ${record.metadata || 'لا يوجد'}`;
    navigator.clipboard.writeText(details);
    if (onToast) onToast(`✓ تم نسخ بيانات الشارع كاملة`);
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // Direct Lock / Unlock Record handler with immediate responsiveness
  const handleToggleRecordLock = (record: RecordItem) => {
    const isCurrentlyLocked = Boolean(record.status === 'تام' || record.isLocked || record.isTruthRecord);
    const updated: RecordItem = {
      ...record,
      isLocked: !isCurrentlyLocked,
      status: !isCurrentlyLocked ? 'تام' : 'نشط',
      isTruthRecord: !isCurrentlyLocked,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      lastModifiedBy: settings.reviewerName || 'المراجع'
    };

    if (onBatchUpdateRecords) {
      onBatchUpdateRecords([updated]);
    } else {
      onEdit(updated);
    }

    if (onToast) {
      onToast(
        !isCurrentlyLocked
          ? `🔒 تم اعتماد وقفل (${record.name}) كـ «بيان تام - عنوان الحقيقة»`
          : `✓ تم فك قفل (${record.name}) وأصبح متاحاً للتعديل الآن`
      );
    }
  };

  // Toggle Alert tag in record metadata via mouse
  const handleToggleAlertTag = (record: RecordItem) => {
    const currentMeta = (record.metadata || '').trim();
    let newMeta = currentMeta;
    const hasAlert = /تنبيه|تحذير|خطر|انتباه|ملاحظة هامة/i.test(currentMeta);
    if (hasAlert) {
      newMeta = currentMeta.replace(/(\[?تنبيه:?[^\]\n]*\]?|⚠️\s*تنبيه)/gi, '').trim();
      if (onToast) onToast(`✓ تم إزالة وسم التنبيه من «${record.name}»`);
    } else {
      newMeta = currentMeta ? `[تنبيه] ${currentMeta}` : '[تنبيه] ملاحظة هامة تحتاج مراجعة';
      if (onToast) onToast(`✓ تم تمييز «${record.name}» كوسم تنبيه ⚠️`);
    }
    const updated: RecordItem = {
      ...record,
      metadata: newMeta,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      lastModifiedBy: settings.reviewerName || 'المراجع'
    };
    if (onBatchUpdateRecords) {
      onBatchUpdateRecords([updated]);
    } else {
      onEdit(updated);
    }
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // Toggle Under Review tag in record metadata and status via mouse
  const handleToggleReviewTag = (record: RecordItem) => {
    const currentMeta = (record.metadata || '').trim();
    const isUnderReview = record.status === 'قيد المراجعة' || /قيد المراجعة|مراجعة|تدقيق/i.test(currentMeta);
    let newMeta = currentMeta;
    let newStatus = record.status;
    if (isUnderReview) {
      newMeta = currentMeta.replace(/(\[?قيد المراجعة:?[^\]\n]*\]?|🔍\s*قيد المراجعة)/gi, '').trim();
      newStatus = record.isLocked || record.isTruthRecord ? 'تام' : 'نشط';
      if (onToast) onToast(`✓ تم إزالة وسم قيد المراجعة من «${record.name}»`);
    } else {
      newMeta = currentMeta ? `[قيد المراجعة] ${currentMeta}` : '[قيد المراجعة] تحت الفحص الميداني';
      newStatus = 'قيد المراجعة';
      if (onToast) onToast(`✓ تم تصنيف «${record.name}» كـ «قيد المراجعة 🔍»`);
    }
    const updated: RecordItem = {
      ...record,
      metadata: newMeta,
      status: newStatus,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      lastModifiedBy: settings.reviewerName || 'المراجع'
    };
    if (onBatchUpdateRecords) {
      onBatchUpdateRecords([updated]);
    } else {
      onEdit(updated);
    }
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // Clear all conditional formatting tags from record
  const handleClearConditionalFormatting = (record: RecordItem) => {
    let newMeta = (record.metadata || '')
      .replace(/(\[?تنبيه:?[^\]\n]*\]?|⚠️\s*تنبيه)/gi, '')
      .replace(/(\[?قيد المراجعة:?[^\]\n]*\]?|🔍\s*قيد المراجعة)/gi, '')
      .trim();
    const newStatus = record.status === 'قيد المراجعة' ? 'نشط' : record.status;
    const updated: RecordItem = {
      ...record,
      metadata: newMeta,
      status: newStatus,
      lastModifiedAt: new Date().toLocaleString('ar-EG'),
      lastModifiedBy: settings.reviewerName || 'المراجع'
    };
    if (onBatchUpdateRecords) {
      onBatchUpdateRecords([updated]);
    } else {
      onEdit(updated);
    }
    if (onToast) onToast(`✓ تم إزالة كافة وسوم التمييز المشروط عن «${record.name}»`);
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // Batch Export Selected
  const handleExportSelectedExcel = () => {
    const selectedRecords = records.filter(r => selectedIds.has(r.id));
    if (selectedRecords.length === 0) return;

    const dataToExport = selectedRecords.map((r, index) => ({
      'م': index + 1,
      'اسم الشارع': r.name,
      'المأذونية / جهة الاختصاص': r.permission,
      'البيان الوصفي / الملاحظات': r.metadata,
      'نوع السجل': r.category
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    ws['!dir'] = 'rtl';
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'شوارع محددة');

    XLSX.writeFile(wb, `شوارع_محددة_${new Date().toISOString().slice(0, 10)}.xlsx`);
    if (onToast) onToast(`✓ تم تصدير (${selectedRecords.length}) سجل محدد إلى Excel`);
  };

  // Batch Copy Selected Names
  const handleCopySelectedNames = () => {
    const selectedRecords = records.filter(r => selectedIds.has(r.id));
    const names = selectedRecords.map(r => r.name).join('\n');
    navigator.clipboard.writeText(names);
    if (onToast) onToast(`✓ تم نسخ (${selectedRecords.length}) اسم شارع إلى الحافظة`);
  };

  // Batch Embed Similarities for Selected
  const handleBatchEmbedSimilarities = () => {
    if (!onEmbedSimilarityNote) return;
    let count = 0;
    selectedIds.forEach(id => {
      const sim = similarityMap.get(id);
      if (sim?.hasSimilarity && sim.suggestedNote) {
        onEmbedSimilarityNote(id, sim.suggestedNote);
        count++;
      }
    });
    if (onToast) onToast(`✓ تم تضمين ملاحظات الاشتراك لـ (${count}) سجل محدد`);
  };

  // Theme styles for table headers and accents
  const themeColors = getThemeColors(theme, settings.dynamicTheme);
  const themeStyle = {
    headerBg: `${themeColors.headerBg} ${themeColors.headerText}`,
    border: themeColors.border,
    accentHover: 'hover:bg-gray-100/60',
    badge: `${themeColors.badgeBg} ${themeColors.badgeText} ${themeColors.badgeBorder}`
  };

  const colConfig = settings.dynamicTheme?.columns || {
    index: { visible: true },
    name: { visible: true, fontWeight: 'bold' },
    permission: { visible: true },
    category: { visible: true },
    metadata: { visible: true },
    actions: { visible: true }
  };

  // Settings-driven cell styling
  const cellPad = settings.tableDensity === 'compact'
    ? 'p-2'
    : settings.tableDensity === 'relaxed'
      ? 'p-4'
      : 'p-3.5';
  const cellBorder = settings.cellBorders ? 'border border-gray-200' : 'border-l border-gray-100';

  const isAllPageSelected = paginatedRecords.length > 0 && paginatedRecords.every(r => selectedIds.has(r.id));
  const isSomePageSelected = paginatedRecords.some(r => selectedIds.has(r.id)) && !isAllPageSelected;

  const showHealthBar = settings.showDataHealthBar ?? true;
  const showQuickTags = settings.showQuickDistrictTags ?? true;

  return (
    <div className="space-y-4 relative select-none sm:select-text" dir="rtl">
      
      {/* 1. Unified Workspace Control & Search Deck (لوحة التحكم والبحث المتقدم في مساحة العمل) */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden divide-y divide-gray-100 transition-all duration-200">
        
        {/* Strip 1: Workspace Deck Header & Global Quick Actions */}
        <div className="p-3.5 sm:p-4 bg-gradient-to-l from-slate-50 via-gray-50/70 to-white flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-700 text-white rounded-xl shadow-xs">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-black text-gray-900">
                  لوحة التحكم والبحث المتقدم في مساحة العمل
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs">
                  {filteredRecords.length.toLocaleString('ar-EG')} شارع مطابق
                </span>
                <span className="text-[11px] text-gray-400 font-medium hidden md:inline">
                  (من إجمالي {records.length.toLocaleString('ar-EG')} بالمنظومة)
                </span>
              </div>
            </div>
          </div>

          {/* Quick Operations Strip */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Quick Fill Button */}
            <button
              type="button"
              onClick={() => setIsQuickFillModalOpen(true)}
              className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs font-black shadow-xs flex items-center gap-1.5 transition cursor-pointer active:scale-95"
              title="فتح نافذة التعبئة السريعة لضبط وتعبئة الحقول الفارغة دفعة واحدة"
            >
              <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
              <span>تعبئة سريعة</span>
            </button>

            {/* Data Health Toggle Chip */}
            {showHealthBar && (
              <button
                type="button"
                onClick={() => setIsHealthBarCollapsed(prev => !prev)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                  healthStats.healthScore >= 80
                    ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200'
                    : healthStats.healthScore >= 60
                      ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200'
                      : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border-rose-200'
                }`}
                title={isHealthBarCollapsed ? 'عرض تفاصيل صحة واكتمال البيانات' : 'إخفاء تفاصيل صحة واكتمال البيانات'}
              >
                <HeartPulse className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                <span>جودة البيانات: {healthStats.healthScore}%</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${!isHealthBarCollapsed ? 'rotate-180' : ''}`} />
              </button>
            )}

            {/* Conditional Formatting Toggle Button */}
            <button
              type="button"
              onClick={handleToggleConditionalFormatting}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                conditionalFormatting
                  ? 'bg-amber-50 hover:bg-amber-100 text-amber-950 border-amber-300 ring-1 ring-amber-400/30'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-600 border-gray-300'
              }`}
              title={
                conditionalFormatting
                  ? 'التنسيق المشروط مفعّل: تظليل السجلات التي تحتوي على ملاحظات «قيد المراجعة» أو «تنبيه» بلون تمييز خفيف (انقر للتعطيل)'
                  : 'التنسيق المشروط معطّل: انقر لتفعيل تظليل سجلات التنبيه والمراجعة بلون تمييز خفيف لتسهيل المسح البصري'
              }
            >
              <Highlighter className={`w-3.5 h-3.5 ${conditionalFormatting ? 'text-amber-600' : 'text-gray-500'}`} />
              <span>تنسيق مشروط {conditionalFormatting ? 'مفعّل 🎨' : 'معطّل'}</span>
              {conditionalFormatting && condFormattingStats.total > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-200 text-amber-950">
                  {condFormattingStats.total}
                </span>
              )}
            </button>

            {/* Reset Filters Button (Visible when filters are active) */}
            {(filterState.searchQuery.trim() !== '' || filterState.permissionFilter !== 'all' || filterState.categoryFilter !== 'all' || showOnlySimilar || healthFilter !== 'all' || filterConditionalOnly !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  setFilterState({
                    searchQuery: '',
                    searchMode: 'partial',
                    permissionFilter: 'all',
                    categoryFilter: 'all'
                  });
                  setShowOnlySimilar(false);
                  setHealthFilter('all');
                  setFilterConditionalOnly('all');
                  if (onClearDistrictFilter) onClearDistrictFilter();
                  setCurrentPage(1);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition cursor-pointer shadow-2xs"
                title="إعادة ضبط وتفريغ كافة الفلاتر والبحث"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة ضبط الفلاتر</span>
              </button>
            )}
          </div>
        </div>

        {/* Collapsible Health Breakdown Drawer */}
        {showHealthBar && !isHealthBarCollapsed && (
          <div className="p-3.5 sm:p-4 bg-emerald-50/30 space-y-3 animate-in fade-in duration-200 border-b border-gray-100">
            {/* Multi-segment Progress Bar */}
            <div className="space-y-1">
              <div className="h-2.5 w-full bg-gray-100 rounded-full overflow-hidden flex shadow-inner">
                {/* Complete records (Green) */}
                <div 
                  style={{ width: `${healthStats.completePercent}%` }}
                  className="bg-emerald-500 h-full transition-all duration-500 hover:opacity-90"
                  title={`سجلات مكتملة تماماً: ${healthStats.completeCount} (${healthStats.completePercent}%)`}
                />
                {/* Missing Metadata (Amber) */}
                <div 
                  style={{ width: `${healthStats.missingMetadataPercent}%` }}
                  className="bg-amber-400 h-full transition-all duration-500 hover:opacity-90"
                  title={`سجلات تفتقر لملاحظات: ${healthStats.missingMetadataCount} (${healthStats.missingMetadataPercent}%)`}
                />
                {/* Missing Permission (Rose) */}
                <div 
                  style={{ width: `${healthStats.missingPermissionPercent}%` }}
                  className="bg-rose-500 h-full transition-all duration-500 hover:opacity-90"
                  title={`سجلات تفتقر لمأذونية: ${healthStats.missingPermissionCount} (${healthStats.missingPermissionPercent}%)`}
                />
              </div>
            </div>

            {/* Interactive Filter Pills Row */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <span className="text-[11px] font-bold text-gray-500 ml-1">تصفية حسب الحالة:</span>
                
                {/* All */}
                <button
                  type="button"
                  onClick={() => {
                    setHealthFilter('all');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                    healthFilter === 'all'
                      ? 'bg-gray-800 text-white shadow-xs'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  }`}
                >
                  الكل ({healthStats.total})
                </button>

                {/* Missing Metadata */}
                <button
                  type="button"
                  onClick={() => {
                    setHealthFilter(prev => prev === 'missingMetadata' ? 'all' : 'missingMetadata');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    healthFilter === 'missingMetadata'
                      ? 'bg-amber-600 text-white shadow-xs ring-2 ring-amber-400'
                      : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>تفتقر لملاحظات: {healthStats.missingMetadataCount}</span>
                  <span className={`text-[10px] ${healthFilter === 'missingMetadata' ? 'text-amber-100' : 'text-amber-700 font-semibold'}`}>
                    ({healthStats.missingMetadataPercent}%)
                  </span>
                </button>

                {/* Missing Permission */}
                <button
                  type="button"
                  onClick={() => {
                    setHealthFilter(prev => prev === 'missingPermission' ? 'all' : 'missingPermission');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    healthFilter === 'missingPermission'
                      ? 'bg-rose-600 text-white shadow-xs ring-2 ring-rose-400'
                      : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>تفتقر لمأذونية: {healthStats.missingPermissionCount}</span>
                  <span className={`text-[10px] ${healthFilter === 'missingPermission' ? 'text-rose-100' : 'text-rose-700 font-semibold'}`}>
                    ({healthStats.missingPermissionPercent}%)
                  </span>
                </button>

                {/* Complete */}
                <button
                  type="button"
                  onClick={() => {
                    setHealthFilter(prev => prev === 'complete' ? 'all' : 'complete');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    healthFilter === 'complete'
                      ? 'bg-emerald-700 text-white shadow-xs ring-2 ring-emerald-400'
                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>مكتملة 100%: {healthStats.completeCount}</span>
                  <span className={`text-[10px] ${healthFilter === 'complete' ? 'text-emerald-100' : 'text-emerald-700 font-semibold'}`}>
                    ({healthStats.completePercent}%)
                  </span>
                </button>
              </div>

              {healthFilter !== 'all' && (
                <button
                  type="button"
                  onClick={() => {
                    setHealthFilter('all');
                    setCurrentPage(1);
                  }}
                  className="text-[11px] font-bold text-gray-500 hover:text-gray-800 flex items-center gap-1 cursor-pointer bg-white px-2 py-0.5 rounded border border-gray-200"
                >
                  <span>إلغاء تصفية صحة البيانات ✕</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Strip 2: Search & Filter Inputs Grid */}
        <div className="p-4 sm:p-5 space-y-3.5">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            
            {/* 1. Street Name / Text Search Input (5 Cols) */}
            <div className="md:col-span-5 relative">
              <label className="block text-[11px] font-bold text-gray-600 mb-1">
                البحث بالاسم أو البيان الوصفي:
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3.5 pointer-events-none text-gray-400">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  id="main-search-input"
                  type="text"
                  value={filterState.searchQuery}
                  onChange={(e) => {
                    setFilterState(prev => ({ ...prev, searchQuery: e.target.value }));
                    setCurrentPage(1);
                  }}
                  placeholder="اكتب اسم الشارع، حارة، زقاق، أو كلمة بالملاحظات..."
                  className="w-full pr-10 pl-8 py-2.5 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-xs sm:text-sm text-gray-800 font-medium"
                />
                {filterState.searchQuery && (
                  <button
                    onClick={() => {
                      setFilterState(prev => ({ ...prev, searchQuery: '' }));
                      setCurrentPage(1);
                    }}
                    className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 hover:text-gray-600 cursor-pointer"
                    title="مسح نص البحث"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* 2. Search Mode Dropdown (2 Cols) */}
            <div className="md:col-span-2">
              <label className="block text-[11px] font-bold text-gray-600 mb-1">
                طريقة المطابقة:
              </label>
              <select
                value={filterState.searchMode}
                onChange={(e) => {
                  setFilterState(prev => ({ ...prev, searchMode: e.target.value as any }));
                  setCurrentPage(1);
                }}
                className="w-full px-3 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-bold text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="partial">بحث جزئي (يحتوي)</option>
                <option value="startsWith">يبدأ بـ (بادئة)</option>
                <option value="exact">بحث كلي (مطابق)</option>
              </select>
            </div>

            {/* 3. Permission Filter Dropdown (3 Cols) */}
            <div className="md:col-span-3">
              <label className="block text-[11px] font-bold text-gray-600 mb-1 flex items-center justify-between">
                <span>فلترة حسب المأذونية:</span>
                <span className="text-[10px] text-emerald-700 font-black">
                  {filterState.permissionFilter === 'all' ? 'الكل' : filterState.permissionFilter}
                </span>
              </label>
              <select
                value={filterState.permissionFilter}
                onChange={(e) => {
                  setFilterState(prev => ({ ...prev, permissionFilter: e.target.value }));
                  setCurrentPage(1);
                }}
                className={`w-full px-3 py-2.5 border rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer transition ${
                  filterState.permissionFilter !== 'all' 
                    ? 'bg-emerald-50/90 border-emerald-400 text-emerald-950 font-black ring-1 ring-emerald-300' 
                    : 'bg-gray-50 border-gray-300 text-gray-700'
                }`}
              >
                <option value="all">📍 جميع المأذونيات ({records.length})</option>
                {permissions.map(p => {
                  const count = permissionCounts.get(p) || 0;
                  return (
                    <option key={p} value={p}>
                      {p} — ({count} {count === 1 ? 'شارع' : 'شوارع'})
                    </option>
                  );
                })}
              </select>
            </div>

            {/* 4. Category Filter Dropdown (2 Cols) */}
            <div className="md:col-span-2">
              <label className="block text-[11px] font-bold text-gray-600 mb-1 flex items-center justify-between">
                <span>نوع السجل:</span>
                <span className="text-[10px] text-indigo-700 font-black">
                  {filterState.categoryFilter === 'all' ? 'الكل' : filterState.categoryFilter}
                </span>
              </label>
              <select
                value={filterState.categoryFilter}
                onChange={(e) => {
                  setFilterState(prev => ({ ...prev, categoryFilter: e.target.value }));
                  setCurrentPage(1);
                }}
                className={`w-full px-3 py-2.5 border rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer transition ${
                  filterState.categoryFilter !== 'all' 
                    ? 'bg-indigo-50/90 border-indigo-400 text-indigo-950 font-black ring-1 ring-indigo-300' 
                    : 'bg-gray-50 border-gray-300 text-gray-700'
                }`}
              >
                <option value="all">🏷️ الأنواع ({records.length})</option>
                {categories.map(c => {
                  const count = categoryCounts.get(c) || 0;
                  return (
                    <option key={c} value={c}>
                      {c} — ({count})
                    </option>
                  );
                })}
              </select>
            </div>

          </div>

          {/* Quick Filter Tags Strip */}
          {showQuickTags && (
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-gray-100 text-xs">
              {/* Permission Quick Tags */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-gray-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-emerald-600" />
                  مأذونيات سريعة:
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setFilterState(prev => ({ ...prev, permissionFilter: 'all' }));
                    setCurrentPage(1);
                  }}
                  className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                    filterState.permissionFilter === 'all'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  }`}
                >
                  الكل
                </button>
                {['شبرا بحري', 'سكنيدة', 'طاموس', 'شبرا قبلي', 'قرطسا بحري', 'نقرها', 'قرطسا قبلي'].map((p) => {
                  const count = permissionCounts.get(p);
                  if (count === undefined) return null;
                  const isSelected = filterState.permissionFilter === p;
                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => {
                        setFilterState(prev => ({
                          ...prev,
                          permissionFilter: isSelected ? 'all' : p
                        }));
                        setCurrentPage(1);
                      }}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                        isSelected
                          ? 'bg-emerald-700 text-white shadow-xs ring-1 ring-emerald-500'
                          : 'bg-emerald-50/70 hover:bg-emerald-100 text-emerald-900 border border-emerald-200/60'
                      }`}
                    >
                      <span>{p}</span>
                      <span className={`text-[10px] ${isSelected ? 'text-emerald-200' : 'text-emerald-600 opacity-80'}`}>
                        ({count})
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Category Quick Tags */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-gray-500 flex items-center gap-1">
                  <Tag className="w-3 h-3 text-indigo-600" />
                  نوع السجل:
                </span>
                {['شارع', 'حارة', 'زقاق', 'ميدان', 'حي'].map((c) => {
                  const count = categoryCounts.get(c);
                  if (count === undefined) return null;
                  const isSelected = filterState.categoryFilter === c;
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => {
                        setFilterState(prev => ({
                          ...prev,
                          categoryFilter: isSelected ? 'all' : c
                        }));
                        setCurrentPage(1);
                      }}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                        isSelected
                          ? 'bg-indigo-700 text-white shadow-xs ring-1 ring-indigo-500'
                          : 'bg-indigo-50/70 hover:bg-indigo-100 text-indigo-900 border border-indigo-200/60'
                      }`}
                    >
                      <span>{c}</span>
                      <span className={`text-[10px] ${isSelected ? 'text-indigo-200' : 'text-indigo-600 opacity-80'}`}>
                        ({count})
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Strip 3: Dedicated Operations & Specialized Centers Band */}
        <div className="px-4 py-3 bg-gray-50/90 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* Work Centers & Analytical Hubs */}
          <div className="flex flex-wrap items-center gap-2">
            {/* 1. Similar Records Hub */}
            {onOpenSimilarModal && (
              <button
                type="button"
                onClick={() => onOpenSimilarModal()}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl font-bold transition shadow-xs cursor-pointer"
                title="فتح مركز فحص وتصنيف المتشابهات وعناوين الحقيقة المعتمدة"
              >
                <Layers className="w-3.5 h-3.5 text-amber-300" />
                <span>مركز فحص المتشابهات</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-white/20 text-white">
                  {totalSimilarCount.toLocaleString('ar-EG')}
                </span>
              </button>
            )}

            {/* 2. Under Review Center */}
            {onOpenUnderReviewPage && (
              <button
                type="button"
                onClick={onOpenUnderReviewPage}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-xl font-bold transition shadow-xs cursor-pointer"
                title="فتح مركز السجلات قيد المراجعة والتدقيق الإضافي"
              >
                <FileSearch className="w-3.5 h-3.5 text-sky-200" />
                <span>مركز قيد المراجعة</span>
                {underReviewRecordsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-white/20 text-white">
                    {underReviewRecordsCount.toLocaleString('ar-EG')}
                  </span>
                )}
              </button>
            )}

            {/* 3. Filter Similar Only Toggle */}
            <button
              type="button"
              onClick={() => {
                setShowOnlySimilar(prev => !prev);
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition shadow-xs cursor-pointer border ${
                showOnlySimilar
                  ? 'bg-blue-700 text-white border-blue-700 ring-2 ring-blue-300'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
              }`}
              title="تصفية وعرض الشوارع المشتركة والمكررة فقط في الجدول"
            >
              <Share2 className="w-3.5 h-3.5 text-current" />
              <span>عرض المشتركات والمكررات فقط</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                showOnlySimilar ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-800'
              }`}>
                {totalSimilarCount.toLocaleString('ar-EG')}
              </span>
            </button>

            {/* 4. Auto-embed Similarities */}
            {onEmbedAllSimilarities && totalSimilarCount > 0 && (
              <button
                type="button"
                onClick={onEmbedAllSimilarities}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition cursor-pointer shadow-xs"
                title="إدراج تلقائي لصيغة [مشترك مع مأذونية: ...] في خانة الملاحظات لكافة الشوارع المشتركة"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>تضمين ملاحظات الاشتراك آلياً للكل ({totalSimilarCount})</span>
              </button>
            )}

            {/* 5. Conditional Formatting Filter Quick Pills */}
            {conditionalFormatting && condFormattingStats.total > 0 && (
              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-gray-200 shadow-2xs">
                <span className="text-[11px] font-bold text-gray-500 px-1.5 flex items-center gap-1">
                  <Highlighter className="w-3 h-3 text-amber-600" />
                  <span>تصفية التنسيق:</span>
                </span>
                
                {/* All Flagged Filter */}
                <button
                  type="button"
                  onClick={() => {
                    setFilterConditionalOnly(prev => prev === 'any' ? 'all' : 'any');
                    setCurrentPage(1);
                  }}
                  className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                    filterConditionalOnly === 'any'
                      ? 'bg-amber-700 text-white shadow-xs'
                      : 'hover:bg-amber-50 text-gray-700'
                  }`}
                  title="عرض كافة السجلات المميزة بملاحظات تنبيه أو مراجعة"
                >
                  <span>الكل</span>
                  <span className="text-[10px] opacity-80">({condFormattingStats.total})</span>
                </button>

                {/* Alerts Only */}
                {condFormattingStats.alertCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setFilterConditionalOnly(prev => prev === 'alerts' ? 'all' : 'alerts');
                      setCurrentPage(1);
                    }}
                    className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                      filterConditionalOnly === 'alerts'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200'
                    }`}
                    title="تصفية السجلات التي تحتوي على تنبيهات بالملاحظات فقط"
                  >
                    <span>⚠️ تنبيه</span>
                    <span className="text-[10px] font-black">({condFormattingStats.alertCount})</span>
                  </button>
                )}

                {/* Reviews Only */}
                {condFormattingStats.reviewCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setFilterConditionalOnly(prev => prev === 'reviews' ? 'all' : 'reviews');
                      setCurrentPage(1);
                    }}
                    className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                      filterConditionalOnly === 'reviews'
                        ? 'bg-sky-600 text-white shadow-xs'
                        : 'bg-sky-50 hover:bg-sky-100 text-sky-900 border border-sky-200'
                    }`}
                    title="تصفية السجلات التي تحتوي على ملاحظات قيد المراجعة فقط"
                  >
                    <span>🔍 قيد المراجعة</span>
                    <span className="text-[10px] font-black">({condFormattingStats.reviewCount})</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Supervisor Security Control & Mouse Guide */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Supervisor Unlock Permission Toggle */}
            <button
              type="button"
              onClick={() => {
                const nextVal = !canUnlock;
                setCanUnlock(nextVal);
                if (onUpdateSettings) {
                  onUpdateSettings({ ...settings, canUnlockRecords: nextVal });
                }
                if (nextVal) {
                  onToast?.('✓ تم تفعيل صلاحية فك القفل (وضع المشرف) — أزرار التعديل والحذف متاحة الآن للسجلات التامة 🔒');
                } else {
                  onToast?.('🔒 تم إيقاف صلاحية فك القفل — أزرار التعديل والحذف محظورة لحماية عنوان الحقيقة');
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition cursor-pointer shadow-2xs border ${
                canUnlock
                  ? 'bg-amber-100 hover:bg-amber-200 text-amber-950 border-amber-300'
                  : 'bg-white hover:bg-gray-100 text-gray-700 border-gray-300'
              }`}
              title={
                canUnlock 
                  ? 'صلاحية فك القفل مفعّلة: أزرار التعديل والحذف متاحة للسجلات التامة (انقر للتعطيل وحماية السجلات)' 
                  : 'صلاحية فك القفل معطّلة: أزرار التعديل والحذف محظورة للسجلات التامة (انقر للتفعيل كمسؤول أو مشرف)'
              }
            >
              {canUnlock ? <Unlock className="w-3.5 h-3.5 text-amber-700" /> : <Lock className="w-3.5 h-3.5 text-gray-500" />}
              <span>{canUnlock ? 'وضع المشرف: فك القفل مفعل' : 'وضع المشرف: فك القفل معطل'}</span>
            </button>

            {/* Mouse Productivity Tip */}
            <span className="hidden xl:inline-flex items-center gap-1.5 text-[11px] text-gray-500 font-medium bg-white px-2.5 py-1 rounded-xl border border-gray-200 shadow-2xs">
              <MousePointerClick className="w-3.5 h-3.5 text-indigo-600" />
              <span>زر الفأرة الأيمن للقائمة • نقر مزدوج للتعديل</span>
            </span>
          </div>

        </div>

      </div>

      {/* 2. Active Notary Filter Summary & Stats Card (شريط إحصائيات المأذونية النشطة) */}
      {filterState.permissionFilter !== 'all' && (
        <div className="p-4 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/80 border-2 border-emerald-400/80 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs shadow-xs animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="p-2 bg-emerald-700 text-white rounded-xl shadow-xs">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-black text-emerald-950">
                  تصفية مأذونية نشطة: {filterState.permissionFilter}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-700 text-white shadow-xs">
                  {filteredRecords.length.toLocaleString('ar-EG')} شارع
                </span>
                <span className="text-[11px] font-bold text-emerald-800 bg-white/80 px-2 py-0.5 rounded border border-emerald-200">
                  {records.length > 0 ? Math.round((filteredRecords.length / records.length) * 100) : 0}% من إجمالي الشوارع
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-emerald-900 font-semibold flex-wrap">
                <span>توزيع الحالات:</span>
                <span className="text-emerald-800 font-bold">نشط ({filteredRecords.filter(r => r.status === 'نشط' || !r.status).length})</span>
                <span>•</span>
                <span className="text-sky-800 font-bold">قيد المراجعة ({filteredRecords.filter(r => r.status === 'قيد المراجعة').length})</span>
                <span>•</span>
                <span className="text-purple-800 font-bold">تام 🔒 ({filteredRecords.filter(r => r.status === 'تام' || r.isTruthRecord || r.isLocked).length})</span>
                <span>•</span>
                <span className="text-indigo-800 font-bold">التنظيم: أبجدي {sortDirection === 'asc' ? '(أ - ي)' : '(ي - أ)'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Alphabetical Sort Toggle */}
            <button
              type="button"
              onClick={() => {
                setSortColumn('name');
                setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
              }}
              className="px-3 py-1.5 bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-2xs transition cursor-pointer active:scale-95"
              title="تبديل الترتيب الأبجدي لشوارع هذه المأذونية"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-emerald-700" />
              <span>الترتيب الأبجدي: {sortDirection === 'asc' ? 'أ - ي' : 'ي - أ'}</span>
            </button>

            {/* Clear Notary Filter Button */}
            <button
              type="button"
              onClick={() => {
                setFilterState(prev => ({ ...prev, permissionFilter: 'all' }));
                if (onClearDistrictFilter) onClearDistrictFilter();
                setCurrentPage(1);
              }}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs transition cursor-pointer active:scale-95"
              title="إلغاء تصفية المأذونية وعرض كافة شوارع المنظومة"
            >
              <X className="w-3.5 h-3.5" />
              <span>إلغاء تصفية المأذونية (عرض الكل)</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Mouse Batch Actions Bar */}
      {selectedIds.size > 0 && (
        <div className="sticky top-4 z-40 bg-gray-900 text-white p-3.5 rounded-2xl shadow-2xl border border-gray-700 flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 bg-blue-600 text-white rounded-lg text-xs font-black flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4" />
              <span>تم تحديد ({selectedIds.size}) سجل</span>
            </span>
            <span className="text-xs text-gray-300 hidden sm:inline">
              (استخدم Shift + النقر بالماوس لتحديد نطاق كامل)
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            
            {/* Batch Change Permission */}
            {onBatchChangePermission && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowBatchPermSelector(prev => !prev)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-100 rounded-xl text-xs font-bold transition border border-gray-600 cursor-pointer"
                  title="تغيير مأذونية كافة السجلات المحددة دفعة واحدة"
                >
                  <Building className="w-3.5 h-3.5 text-blue-400" />
                  <span>تغيير المأذونية</span>
                </button>

                {showBatchPermSelector && (
                  <div className="absolute right-0 bottom-full mb-2 w-64 bg-white text-gray-900 rounded-2xl shadow-2xl border border-gray-200 p-3 z-50 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-gray-700">
                      <span>اختر المأذونية الجديدة:</span>
                      <button onClick={() => setShowBatchPermSelector(false)} className="text-gray-400 hover:text-gray-600">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <select
                      value={batchPermTarget}
                      onChange={(e) => setBatchPermTarget(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- اختر مأذونية --</option>
                      {permissions.map(p => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                    <button
                      type="button"
                      disabled={!batchPermTarget}
                      onClick={() => {
                        onBatchChangePermission(Array.from(selectedIds), batchPermTarget);
                        setShowBatchPermSelector(false);
                        setSelectedIds(new Set());
                      }}
                      className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                    >
                      تطبيق على ({selectedIds.size}) سجل
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Batch Copy Names */}
            <button
              type="button"
              onClick={handleCopySelectedNames}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-100 rounded-xl text-xs font-bold transition border border-gray-600 cursor-pointer"
              title="نسخ قائمة بأسماء الشوارع المحددة إلى الحافظة"
            >
              <Copy className="w-3.5 h-3.5 text-amber-400" />
              <span>نسخ الأسماء</span>
            </button>

            {/* Batch Export Excel */}
            <button
              type="button"
              onClick={handleExportSelectedExcel}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-100 rounded-xl text-xs font-bold transition border border-gray-600 cursor-pointer"
              title="تصدير السجلات المحددة فقط إلى ملف Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>تصدير Excel للمحدد</span>
            </button>

            {/* Batch Mark as Under Review */}
            {onBatchUpdateRecords && (
              <button
                type="button"
                onClick={() => {
                  const selected = records.filter(r => selectedIds.has(r.id));
                  const updated = selected.map(r => ({
                    ...r,
                    status: 'قيد المراجعة' as const,
                    isLocked: false
                  }));
                  onBatchUpdateRecords(updated);
                  setSelectedIds(new Set());
                  if (onToast) onToast(`✓ تم تحويل (${selected.length}) سجل محدد إلى «قيد المراجعة 🔍»`);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded-xl text-xs font-bold transition border border-sky-500 cursor-pointer shadow-xs"
                title="إحالة السجلات المحددة إلى حالة قيد المراجعة والتدقيق مع الحفاظ على كافة البيانات"
              >
                <FileSearch className="w-3.5 h-3.5 text-sky-200" />
                <span>إحالة المحدد كـ «قيد المراجعة»</span>
              </button>
            )}

            {/* Batch Delete */}
            {onBatchDelete && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`هل أنت متأكد من رغبتك في حذف (${selectedIds.size}) سجل محدد؟ يمكنك التراجع لاحقاً.`)) {
                    onBatchDelete(Array.from(selectedIds));
                    setSelectedIds(new Set());
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                title="حذف كافة السجلات المحددة"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف المحدد</span>
              </button>
            )}

            {/* Clear Selection */}
            <button
              type="button"
              onClick={() => setSelectedIds(new Set())}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg transition cursor-pointer"
              title="إلغاء التحديد"
            >
              <X className="w-4 h-4" />
            </button>

          </div>
        </div>
      )}

      {/* Alert if edited record is hidden by active filter */}
      {isEditedRecordHiddenByFilter && (
        <div className="p-3.5 bg-amber-50 border border-amber-300 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs text-amber-950 font-bold shadow-xs">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              تم حفظ السجل وتحديثه بنجاح، ولكنه لا يظهر في هذا الجدول حالياً لأن فلتر البحث أو المأذونية النشط يستبعده.
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              setFilterState({
                searchQuery: '',
                searchMode: 'partial',
                permissionFilter: 'all',
                categoryFilter: 'all'
              });
            }}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
          >
            إلغاء الفلاتر وعرض السجل المعدل فوراً
          </button>
        </div>
      )}

      {/* Results Stats & Quick Sequential Audit trigger */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-xs text-gray-500 font-medium">
        <div className="flex items-center gap-3 flex-wrap">
          <span>عرض {filteredRecords.length} من أصل {records.length} سجل</span>
          
          {/* Active Sort Indicator */}
          <span className="inline-flex items-center gap-1 text-[11px] bg-gray-200/80 text-gray-700 px-2 py-0.5 rounded-md font-semibold">
            <span>الترتيب:</span>
            <span>
              {sortColumn === 'name' ? 'اسم الشارع' : sortColumn === 'permission' ? 'المأذونية' : sortColumn === 'category' ? 'التصنيف' : 'الافتراضي'}
            </span>
            <span>({sortDirection === 'asc' ? 'أ-ي' : 'ي-أ'})</span>
          </span>

          {onOpenAudit && filteredRecords.length > 0 && (
            <button
              onClick={() => onOpenAudit(filteredRecords[0])}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
              title="بدء مراجعة وتدقيق متتالي لكافة السجلات الظاهرة مع إمكانية التعديل السلس والحفظ التلقائي"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" />
              <span>بدء التدقيق المتتالي للسجلات ({filteredRecords.length})</span>
            </button>
          )}
        </div>
        <span>الصفحة {currentPage} من {totalPages}</span>
      </div>

      {/* Data Table with Auto-Wrap Cells & Mouse Interactive Headers */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className={`${themeStyle.headerBg} text-xs sm:text-sm font-bold`}>
                
                {/* Select All Checkbox */}
                <th className="p-3.5 w-10 text-center border-l border-white/20">
                  <div className="flex items-center justify-center">
                    <input
                      type="checkbox"
                      checked={isAllPageSelected}
                      ref={input => {
                        if (input) input.indeterminate = isSomePageSelected;
                      }}
                      onChange={handleSelectAllPage}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      title="تحديد / إلغاء تحديد كافة شوارع هذه الصفحة"
                    />
                  </div>
                </th>

                {/* Index / Serial Column */}
                {colConfig.index.visible && (
                  <th 
                    onClick={() => handleSortClick('index')}
                    className="p-3.5 w-16 text-center border-l border-white/20 cursor-pointer hover:bg-white/10 transition"
                    title="الترقيم التسلسلي للسجل (انقر للترتيب بالتسلسل)"
                  >
                    <div className="flex items-center justify-center gap-1 font-bold">
                      <span>{colConfig.index.label || (settings.auditShowSerialInTable !== false ? 'التسلسل #' : 'م')}</span>
                      {sortColumn === 'index' && (
                        sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5" /> : <ArrowDown className="w-3.5 h-3.5" />
                      )}
                    </div>
                  </th>
                )}

                {/* Street Name Header */}
                {colConfig.name.visible && (
                  <th 
                    onClick={() => handleSortClick('name')}
                    className="p-3.5 border-l border-white/20 cursor-pointer hover:bg-white/10 transition group"
                    title="انقر بالماوس للترتيب الأبجدي حسب اسم الشارع"
                  >
                    <div className="flex items-center justify-between">
                      <span>اسم الشارع أو الحارة أو الزقاق</span>
                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                        {sortColumn === 'name' ? (
                          sortDirection === 'asc' ? <ArrowUp className="w-4 h-4 text-emerald-300" /> : <ArrowDown className="w-4 h-4 text-emerald-300" />
                        ) : (
                          <ArrowUpDown className="w-3.5 h-3.5 text-white/60" />
                        )}
                      </div>
                    </div>
                  </th>
                )}

                {/* Permission Header */}
                {colConfig.permission.visible && (
                  <th 
                    className="p-3.5 w-48 border-l border-white/20 relative group select-none"
                    title="المأذونية / جهة الاختصاص — انقر للترتيب أو التصفية"
                  >
                    <div className="flex items-center justify-between">
                      <div 
                        onClick={() => handleSortClick('permission')}
                        className="flex items-center gap-1 cursor-pointer flex-1 hover:text-emerald-200 transition"
                      >
                        <span>المأذونية</span>
                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                          {sortColumn === 'permission' ? (
                            sortDirection === 'asc' ? <ArrowUp className="w-4 h-4 text-emerald-300" /> : <ArrowDown className="w-4 h-4 text-emerald-300" />
                          ) : (
                            <ArrowUpDown className="w-3.5 h-3.5 text-white/60" />
                          )}
                        </div>
                      </div>

                      {/* Header Filter Icon Button */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowPermissionFilterMenu(prev => !prev);
                          }}
                          className={`p-1 rounded-lg transition cursor-pointer ${
                            filterState.permissionFilter !== 'all'
                              ? 'bg-amber-400 text-amber-950 font-black shadow-xs ring-2 ring-amber-300'
                              : 'hover:bg-white/20 text-white/80'
                          }`}
                          title={filterState.permissionFilter !== 'all' ? `مفلتر حالياً: ${filterState.permissionFilter}` : 'تصفية حسب مأذونية محددة'}
                        >
                          <Filter className="w-3.5 h-3.5" />
                        </button>

                        {showPermissionFilterMenu && (
                          <div 
                            onClick={(e) => e.stopPropagation()}
                            className="absolute left-0 top-full mt-2 w-64 bg-white text-gray-900 rounded-2xl shadow-2xl border border-gray-200 p-2.5 z-50 text-right space-y-1.5 animate-in fade-in duration-150"
                          >
                            <div className="flex items-center justify-between px-2 py-1 border-b border-gray-100 text-xs font-bold text-gray-700">
                              <span className="flex items-center gap-1">
                                <Building className="w-3.5 h-3.5 text-emerald-600" />
                                تصفية حسب المأذونية
                              </span>
                              <button 
                                onClick={() => setShowPermissionFilterMenu(false)}
                                className="text-gray-400 hover:text-gray-600 cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <div className="max-h-60 overflow-y-auto space-y-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setFilterState(prev => ({ ...prev, permissionFilter: 'all' }));
                                  if (onClearDistrictFilter) onClearDistrictFilter();
                                  setShowPermissionFilterMenu(false);
                                  setCurrentPage(1);
                                }}
                                className={`w-full text-right px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-between cursor-pointer ${
                                  filterState.permissionFilter === 'all'
                                    ? 'bg-emerald-700 text-white'
                                    : 'hover:bg-gray-100 text-gray-800'
                                }`}
                              >
                                <span>📍 عرض جميع المأذونيات</span>
                                <span className="text-[10px] opacity-80">({records.length})</span>
                              </button>

                              {permissions.map(p => {
                                const count = permissionCounts.get(p) || 0;
                                const isSelected = filterState.permissionFilter === p;
                                return (
                                  <button
                                    key={p}
                                    type="button"
                                    onClick={() => {
                                      setFilterState(prev => ({ ...prev, permissionFilter: p }));
                                      setShowPermissionFilterMenu(false);
                                      setCurrentPage(1);
                                    }}
                                    className={`w-full text-right px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-between cursor-pointer ${
                                      isSelected
                                        ? 'bg-emerald-700 text-white'
                                        : 'hover:bg-emerald-50 text-emerald-950'
                                    }`}
                                  >
                                    <span className="truncate max-w-[150px]">{p}</span>
                                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${isSelected ? 'bg-emerald-800 text-emerald-100' : 'bg-gray-100 text-gray-700'}`}>
                                      {count}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </th>
                )}

                {/* Category Header */}
                {colConfig.category.visible && (
                  <th 
                    onClick={() => handleSortClick('category')}
                    className="p-3.5 w-32 border-l border-white/20 cursor-pointer hover:bg-white/10 transition group"
                    title="انقر بالماوس للترتيب حسب نوع السجل"
                  >
                    <div className="flex items-center justify-between">
                      <span>التصنيف</span>
                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                        {sortColumn === 'category' ? (
                          sortDirection === 'asc' ? <ArrowUp className="w-4 h-4 text-emerald-300" /> : <ArrowDown className="w-4 h-4 text-emerald-300" />
                        ) : (
                          <ArrowUpDown className="w-3.5 h-3.5 text-white/60" />
                        )}
                      </div>
                    </div>
                  </th>
                )}

                {/* Metadata Header */}
                {colConfig.metadata.visible && (
                  <th 
                    onClick={() => handleSortClick('metadata')}
                    className="p-3.5 border-l border-white/20 cursor-pointer hover:bg-white/10 transition group"
                    title="انقر بالماوس للترتيب حسب الملاحظات"
                  >
                    <div className="flex items-center justify-between">
                      <span>البيانات الوصفية / الملاحظات</span>
                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                        {sortColumn === 'metadata' ? (
                          sortDirection === 'asc' ? <ArrowUp className="w-4 h-4 text-emerald-300" /> : <ArrowDown className="w-4 h-4 text-emerald-300" />
                        ) : (
                          <ArrowUpDown className="w-3.5 h-3.5 text-white/60" />
                        )}
                      </div>
                    </div>
                  </th>
                )}

                {/* Actions Header */}
                {colConfig.actions.visible && (
                  <th className="p-3.5 w-28 text-center">الإجراءات</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 text-xs sm:text-sm">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-gray-400">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <AlertCircle className="w-8 h-8 text-gray-300" />
                      <p className="font-semibold text-gray-600">لا توجد سجلات مطابقة للبحث أو الفلترة</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((record, index) => {
                  const absoluteIndex = (currentPage - 1) * itemsPerPage + index + 1;
                  const isLastEdited = record.id === lastEditedId;
                  const isSelected = selectedIds.has(record.id);
                  const zebraClass = settings.enableZebra && index % 2 === 1 ? 'bg-gray-50/70' : '';
                  const simInfo = similarityMap.get(record.id);
                  const hasNoteAlready = record.metadata && simInfo?.suggestedNote && record.metadata.includes(simInfo.suggestedNote);
                  const condFormat = getRecordConditionalFormat(
                    record, 
                    conditionalFormatting,
                    settings.conditionalFormattingAlerts !== false,
                    settings.conditionalFormattingReviews !== false
                  );

                  return (
                    <tr 
                      key={record.id} 
                      onContextMenu={(e) => {
                        if (settings.mouseRightClickMenu === false) return;
                        handleRowContextMenu(e, record);
                      }}
                      onDoubleClick={() => {
                        const dbl = settings.mouseDoubleClickAction || 'edit';
                        if (dbl === 'edit') {
                          onEdit(record);
                        } else if (dbl === 'select') {
                          handleRowCheckboxClick({ stopPropagation: () => {} } as any, record.id);
                        } else if (dbl === 'audit' && onOpenAudit) {
                          onOpenAudit(record);
                        }
                      }}
                      onAuxClick={(e) => {
                        if (e.button === 1) { // Middle click / mouse wheel button
                          e.preventDefault();
                          const mid = settings.mouseMiddleClickAction || 'select';
                          if (mid === 'select') {
                            handleRowCheckboxClick({ stopPropagation: () => {} } as any, record.id);
                          } else if (mid === 'lock') {
                            handleToggleRecordLock(record);
                          } else if (mid === 'edit') {
                            onEdit(record);
                          }
                        }
                      }}
                      className={`transition-all duration-150 cursor-default group relative ${
                        isSelected
                          ? 'bg-blue-50/90 font-medium'
                          : isLastEdited 
                            ? 'bg-emerald-50/90 ring-2 ring-emerald-500 font-bold shadow-xs' 
                            : condFormat
                              ? `${condFormat.rowBgClass} ${condFormat.borderRightClass}`
                              : `${zebraClass} ${settings.mouseHoverHighlight !== false ? themeStyle.accentHover : ''}`
                      }`}
                      title={condFormat ? `تنسيق مشروط: ${condFormat.badgeText} — انقر نقراً مزدوجاً للتعديل، أو بعجلة الماوس لتنفيذ إجراء سريع` : "انقر نقراً مزدوجاً بالماوس للتعديل، أو بزر الفأرة الأيمن للقائمة، أو بعجلة الماوس"}
                    >
                      {/* Checkbox Column */}
                      <td className={`${cellPad} text-center ${cellBorder}`} onClick={(e) => handleRowCheckboxClick(e, record.id)}>
                        <div className="flex items-center justify-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {}} // Handled by TD onClick
                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                        </div>
                      </td>

                      {/* Serial Number Column */}
                      {colConfig.index.visible && (
                        <td className={`${cellPad} text-center font-medium ${cellBorder}`}>
                          <span 
                            className="inline-flex items-center justify-center min-w-8 px-2 py-0.5 rounded-md font-mono text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200 group-hover:bg-amber-100 group-hover:text-amber-900 group-hover:border-amber-300 transition"
                            title={`الرقم التسلسلي: #${absoluteIndex}`}
                          >
                            #{absoluteIndex}
                          </span>
                        </td>
                      )}

                      {/* Street Name Column */}
                      {colConfig.name.visible && (
                        <td className={`${cellPad} ${colConfig.name.fontWeight === 'bold' ? 'font-bold' : 'font-normal'} text-gray-900 ${cellBorder} break-words max-w-sm`}>
                          <div className="flex flex-col gap-1.5">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-bold text-gray-950">{record.name}</span>
                              
                              {/* Fast Copy Button with Feedback */}
                              <button
                                type="button"
                                onClick={(e) => handleCopyStreetName(e, record.name, record.id)}
                                className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition cursor-pointer"
                                title="نسخ اسم الشارع بنقرة ماوس واحدة"
                              >
                                {copiedId === record.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>

                              {/* Ground Truth / Locked Record Badge with Click-To-Unlock */}
                              {(record.status === 'تام' || record.isTruthRecord || record.isLocked) ? (
                                <button 
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleToggleRecordLock(record);
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 hover:bg-amber-100 text-emerald-950 hover:text-amber-950 border border-emerald-300 hover:border-amber-300 shadow-2xs cursor-pointer transition active:scale-95"
                                  title="هذا البيان معتمد نهائياً وتام كـ «عنوان الحقيقة 🔒» — انقر بالماوس لفك القفل والتعديل"
                                >
                                  <Lock className="w-3 h-3 text-emerald-700" />
                                  <span>بيان تام (مغلق 🔒 - انقر لفك القفل)</span>
                                </button>
                              ) : null}
                              {record.status === 'معلّق' && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                                  معلّق
                                </span>
                              )}
                              {record.status === 'ملغي' && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-900 border border-rose-300">
                                  ملغي
                                </span>
                              )}
                              {record.status === 'قيد المراجعة' && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (onOpenUnderReviewPage) {
                                      onOpenUnderReviewPage();
                                    } else {
                                      onEdit(record);
                                    }
                                  }}
                                  className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-[10px] sm:text-[11px] font-black bg-sky-100 hover:bg-sky-200 text-sky-950 border border-sky-300 ring-1 ring-sky-400/30 shadow-2xs cursor-pointer transition group/revbadge"
                                  title="🔍 شارة مراجعة: هذا الشارع موسوم كـ «غير مؤكد • قيد المراجعة والتدقيق» بقرار إداري احترازي (انقر لفتح مركز المراجعة والاعتماد)"
                                >
                                  <span className="relative flex h-2 w-2 shrink-0">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-600"></span>
                                  </span>
                                  <FileSearch className="w-3 h-3 text-sky-700 shrink-0" />
                                  <span>غير مؤكد • قيد المراجعة</span>
                                </button>
                              )}
                              {record.similarityClassification && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-purple-800 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                                  <span>{record.similarityClassification}</span>
                                </span>
                              )}

                              {/* Conditional Formatting Alert Indicator Badge */}
                              {condFormat?.type === 'alert' && (
                                <span 
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-100 text-amber-950 border border-amber-300 ring-1 ring-amber-400/30 shadow-2xs"
                                  title={`تنسيق مشروط: ملاحظات هذا السجل تتضمن (${condFormat.keywordMatch})`}
                                >
                                  <AlertTriangle className="w-3 h-3 text-amber-700 shrink-0" />
                                  <span>{condFormat.badgeText}</span>
                                </span>
                              )}

                              {isLastEdited && (
                                <span className="px-2 py-0.5 bg-emerald-600 text-white rounded-md text-[10px] font-black shrink-0 animate-pulse shadow-xs">
                                  ✓ تم تعديله للتو
                                </span>
                              )}
                            </div>

                            {/* Similarity Badges with Quick Click Filter */}
                            {simInfo?.hasSimilarity && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {onOpenSimilarModal && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onOpenSimilarModal(record.name);
                                    }}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 rounded-md text-[10px] font-bold cursor-pointer transition"
                                    title="فتح مركز مراجعة وتصنيف المتشابهات لهذا الشارع مباشرة"
                                  >
                                    <Layers className="w-3 h-3 text-indigo-700 shrink-0" />
                                    <span>مراجعة وتصنيف المتشابهات</span>
                                  </button>
                                )}

                                {simInfo.isSharedAcrossPermissions && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setFilterState(prev => ({ ...prev, searchQuery: record.name, searchMode: 'exact' }));
                                    }}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100/90 hover:bg-blue-200 text-blue-900 border border-blue-300 rounded-md text-[10px] font-bold cursor-pointer transition"
                                    title={`هذا الشارع مشترك مع: ${(simInfo.sharedPermissions || []).join('، ')} (انقر لعرض جميع الشوارع المشتركة معه)`}
                                  >
                                    <Share2 className="w-3 h-3 text-blue-700 shrink-0" />
                                    <span>مشترك مع: {(simInfo.sharedPermissions || []).join('، ')}</span>
                                  </button>
                                )}

                                {simInfo.isDuplicateInSamePermission && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setFilterState(prev => ({ ...prev, searchQuery: record.name, searchMode: 'exact' }));
                                    }}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100/90 hover:bg-amber-200 text-amber-950 border border-amber-300 rounded-md text-[10px] font-bold cursor-pointer transition"
                                    title="تكرر اسم هذا الشارع أكثر من مرة بنفس المأذونية (انقر للبحث والمطابقة)"
                                  >
                                    <AlertTriangle className="w-3 h-3 text-amber-700 shrink-0" />
                                    <span>تكرر في نفس المأذونية</span>
                                  </button>
                                )}

                                {simInfo.hasCategoryVariant && (
                                  <span 
                                    className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-purple-100 text-purple-900 border border-purple-200 rounded text-[10px] font-semibold"
                                    title="يوجد تشابه بالاسم مع اختلاف التصنيف (مثل شارع وحارة)"
                                  >
                                    <span>تشابه مسميات</span>
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </td>
                      )}

                      {/* Permission Column with Click-To-Filter */}
                      {colConfig.permission.visible && (
                        <td className={`${cellPad} ${cellBorder}`}>
                          {(() => {
                            const district = getDistrictColor(record.permission, record.metadata, record.name);
                            const isOriginalDistrict = ['شبرا_1', 'شبرا_2', 'شبرا_3', 'قرطسا', 'نقرها أول', 'إفلاقة', 'ابو الريش'].includes(record.permission);
                            
                            return (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFilterState(prev => ({ ...prev, permissionFilter: record.permission }));
                                }}
                                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer hover:scale-105 active:scale-95 shadow-2xs ${
                                  district ? `${district.bg} ${district.text} border ${district.border}` : 'bg-gray-100 text-gray-800 border border-gray-300'
                                }`}
                                title={`انقر بالماوس لتصفية الجدول فوراً بمأذونية: ${record.permission}`}
                              >
                                {district && <span className={`w-2 h-2 rounded-full ${district.dot} shrink-0`} />}
                                <span>{record.permission || 'غير محدد'}</span>
                                {record.category === 'حي' && (
                                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-semibold ${
                                    isOriginalDistrict ? 'bg-white/70 text-gray-800' : 'bg-amber-100 text-amber-900 border border-amber-300'
                                  }`}>
                                    {isOriginalDistrict ? 'أصلي' : 'غير أصلي'}
                                  </span>
                                )}
                              </button>
                            );
                          })()}
                        </td>
                      )}

                      {/* Category Column with Click-To-Filter */}
                      {colConfig.category.visible && (
                        <td className={`${cellPad} ${cellBorder} text-gray-700 font-medium`}>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setFilterState(prev => ({ ...prev, categoryFilter: record.category }));
                            }}
                            className="px-2 py-0.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-md text-xs font-semibold cursor-pointer transition"
                            title={`انقر بالماوس لتصفية الجدول حسب تصنيف: ${record.category}`}
                          >
                            {record.category || 'شارع'}
                          </button>
                        </td>
                      )}

                      {/* Metadata / Notes Column */}
                      {colConfig.metadata.visible && (
                        <td className={`${cellPad} text-gray-600 break-words leading-relaxed`}>
                          <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {condFormat && (
                                <span 
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black shrink-0 shadow-2xs border ${condFormat.badgeClass}`}
                                  title={`تنسيق مشروط تلقائي: تم تمييز هذا السجل لاحتوائه على (${condFormat.keywordMatch})`}
                                >
                                  <span className={`w-1.5 h-1.5 rounded-full ${condFormat.dotColor} animate-pulse`} />
                                  <span>{condFormat.badgeText}</span>
                                </span>
                              )}
                              {record.metadata && (record.metadata.includes('31°') || record.metadata.includes('31.')) && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-teal-800 bg-teal-50 px-1.5 py-0.5 rounded border border-teal-200 shrink-0" title="إحداثيات جغرافية معتمدة على خرائط جوجل">
                                  <Compass className="w-3 h-3 text-teal-600" />
                                  <span>إحداثيات</span>
                                </span>
                              )}
                              <span className={condFormat ? 'font-medium text-gray-900' : ''}>{record.metadata || '-'}</span>
                            </div>
                            {simInfo?.suggestedNote && !hasNoteAlready && onEmbedSimilarityNote && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onEmbedSimilarityNote(record.id, simInfo.suggestedNote);
                                }}
                                className="self-start inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded text-[10px] font-bold transition cursor-pointer"
                                title="انقر لتضمين ملاحظة الاشتراك هذه تلقائياً في خانة الملاحظات"
                              >
                                <Sparkles className="w-3 h-3 text-emerald-600" />
                                <span>تضمين: {simInfo.suggestedNote}</span>
                              </button>
                            )}
                          </div>
                        </td>
                      )}

                      {/* Actions Column */}
                      {colConfig.actions.visible && (
                        <td className={`${cellPad} text-center`}>
                          <div className="flex items-center justify-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                            {simInfo?.suggestedNote && !hasNoteAlready && onEmbedSimilarityNote && (
                              <button
                                onClick={() => onEmbedSimilarityNote(record.id, simInfo.suggestedNote)}
                                className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition cursor-pointer"
                                title={`تضمين ملاحظة: ${simInfo.suggestedNote}`}
                              >
                                <Sparkles className="w-4 h-4" />
                              </button>
                            )}
                            <a
                              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                                record.metadata && (record.metadata.includes('31.') || record.metadata.includes('31°'))
                                  ? (record.metadata.match(/31[°\.\d\s'N]+30[°\.\d\s'E]+/i)?.[0] || (record.name + ' دمنهور'))
                                  : (record.name + ' دمنهور البحيرة')
                              )}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition cursor-pointer"
                              title={`عرض موقع «${record.name}» على خرائط جوجل`}
                              onClick={(e) => e.stopPropagation()}
                            >
                              <MapPin className="w-4 h-4" />
                            </a>
                            {onViewAuditLog && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onViewAuditLog(record);
                                }}
                                className={`p-1.5 rounded-lg transition cursor-pointer relative ${
                                  record.auditLogs && record.auditLogs.length > 0
                                    ? 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200'
                                    : 'bg-slate-50 text-slate-500 hover:bg-slate-100 hover:text-slate-800'
                                }`}
                                title={
                                  record.auditLogs && record.auditLogs.length > 0
                                    ? `سجل التعديلات والتوثيق (${record.auditLogs.length} عملية) - آخر تعديل: ${record.lastModifiedAt || ''}`
                                    : 'عرض سجل التعديلات والتوثيق القانوني'
                                }
                              >
                                <History className="w-4 h-4" />
                                {record.auditLogs && record.auditLogs.length > 0 && (
                                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-indigo-600 ring-2 ring-white"></span>
                                )}
                              </button>
                            )}
                            {/* Edit Action Button */}
                            {(() => {
                              const isLocked = Boolean(record.status === 'تام' || record.isLocked || record.isTruthRecord);

                              return (
                                <button
                                  type="button"
                                  onClick={() => onEdit(record)}
                                  className={`p-1.5 rounded-lg transition cursor-pointer ${
                                    isLocked
                                      ? 'bg-amber-100 text-amber-900 hover:bg-amber-200 border border-amber-300'
                                      : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                                  }`}
                                  title={
                                    isLocked
                                      ? 'تعديل السجل (بيان تام 🔒 - يمكنك تعديله أو فك قفله من المحرر)'
                                      : 'تعديل السجل (أو انقر نقراً مزدوجاً على الصف)'
                                  }
                                >
                                  {isLocked ? (
                                    <Lock className="w-4 h-4 text-amber-800" />
                                  ) : (
                                    <Edit3 className="w-4 h-4" />
                                  )}
                                </button>
                              );
                            })()}

                            {/* Delete Action Button */}
                            <button
                              type="button"
                              onClick={() => onDelete(record.id)}
                              className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg transition cursor-pointer"
                              title="حذف السجل"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      )}

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Comprehensive Pagination & Page Jump Footer */}
        <div className="px-4 sm:px-6 py-3.5 bg-gray-50/90 border-t border-gray-200 flex flex-col lg:flex-row items-center justify-between gap-3 text-xs">
          
          {/* Section 1: Record Counters & Summary */}
          <div className="flex items-center gap-2 flex-wrap text-gray-700 font-bold justify-center lg:justify-start">
            <span className="bg-white px-3 py-1.5 rounded-xl border border-gray-200 shadow-2xs text-gray-900">
              عرض <strong className="text-emerald-700">{paginatedRecords.length}</strong> من أصل <strong className="text-emerald-800">{filteredRecords.length.toLocaleString('ar-EG')}</strong> شارع
            </span>

            <span className="bg-white px-3 py-1.5 rounded-xl border border-gray-200 shadow-2xs text-gray-800 flex items-center gap-1.5">
              <span>الصفحة</span>
              <span className="text-emerald-700 font-black">{currentPage}</span>
              <span>من</span>
              <span className="text-gray-900 font-black">{totalPages}</span>
            </span>

            {/* Page Size Selector */}
            <div className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[11px] text-gray-500 font-medium">عرض بالصفحة:</span>
              <select
                value={itemsPerPage}
                onChange={(e) => {
                  const val = e.target.value === 'all' ? 'all' : Number(e.target.value);
                  handlePageSizeChange(val);
                }}
                className="bg-transparent font-bold text-gray-800 focus:outline-none cursor-pointer text-xs"
              >
                <option value={10}>10</option>
                <option value={15}>15</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value={250}>250</option>
                <option value={500}>500</option>
                <option value="all">الكل ({filteredRecords.length})</option>
              </select>
            </div>
          </div>

          {/* Section 2: Direct Jump To Page Input */}
          {totalPages > 1 && (
            <form onSubmit={handleJumpToPage} className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-[11px] text-gray-600 font-bold flex items-center gap-1">
                <Hash className="w-3.5 h-3.5 text-emerald-600" />
                <span>انتقال لصفحة:</span>
              </span>
              <input
                type="number"
                min={1}
                max={totalPages}
                value={jumpPageInput}
                onChange={(e) => setJumpPageInput(e.target.value)}
                placeholder={`${currentPage}`}
                className="w-14 px-2 py-0.5 text-center font-bold text-gray-900 bg-gray-50 border border-gray-300 rounded-lg text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                type="submit"
                className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
              >
                انتقال
              </button>
            </form>
          )}

          {/* Section 3: Navigation Buttons & Numbered Page Pills */}
          {totalPages > 1 && (
            <div className="flex items-center gap-1 flex-wrap justify-center">
              {/* First Page Button */}
              <button
                type="button"
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
                className="p-1.5 sm:px-2.5 sm:py-1.5 bg-white border border-gray-300 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition shadow-2xs cursor-pointer flex items-center gap-1"
                title="الصفحة الأولى (1)"
              >
                <ChevronsRight className="w-4 h-4" />
                <span className="hidden sm:inline">الأولى</span>
              </button>

              {/* Prev Page Button */}
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                disabled={currentPage === 1}
                className="p-1.5 sm:px-3 sm:py-1.5 bg-white border border-gray-300 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition shadow-2xs cursor-pointer flex items-center gap-1"
                title="الصفحة السابقة"
              >
                <ChevronRight className="w-4 h-4" />
                <span className="hidden sm:inline">السابق</span>
              </button>

              {/* Numbered Page Buttons with Sliding Window */}
              <div className="flex items-center gap-1">
                {(() => {
                  const pages: (number | 'dots')[] = [];
                  if (totalPages <= 7) {
                    for (let i = 1; i <= totalPages; i++) pages.push(i);
                  } else {
                    pages.push(1);
                    if (currentPage > 3) pages.push('dots');
                    
                    const start = Math.max(2, currentPage - 1);
                    const end = Math.min(totalPages - 1, currentPage + 1);
                    for (let i = start; i <= end; i++) {
                      if (!pages.includes(i)) pages.push(i);
                    }

                    if (currentPage < totalPages - 2) pages.push('dots');
                    if (!pages.includes(totalPages)) pages.push(totalPages);
                  }

                  return pages.map((p, idx) => {
                    if (p === 'dots') {
                      return <span key={`dots-${idx}`} className="px-1 text-gray-400 font-bold select-none">…</span>;
                    }
                    const isActive = p === currentPage;
                    return (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setCurrentPage(p)}
                        className={`min-w-[30px] h-[30px] rounded-xl text-xs font-bold transition flex items-center justify-center cursor-pointer ${
                          isActive
                            ? 'bg-emerald-700 text-white shadow-xs font-black ring-2 ring-emerald-300'
                            : 'bg-white text-gray-700 hover:bg-emerald-50 hover:text-emerald-900 border border-gray-200'
                        }`}
                      >
                        {p}
                      </button>
                    );
                  });
                })()}
              </div>

              {/* Next Page Button */}
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-1.5 sm:px-3 sm:py-1.5 bg-white border border-gray-300 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition shadow-2xs cursor-pointer flex items-center gap-1"
                title="الصفحة التالية"
              >
                <span className="hidden sm:inline">التالي</span>
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Last Page Button */}
              <button
                type="button"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
                className="p-1.5 sm:px-2.5 sm:py-1.5 bg-white border border-gray-300 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition shadow-2xs cursor-pointer flex items-center gap-1"
                title={`الصفحة الأخيرة (${totalPages})`}
              >
                <span className="hidden sm:inline">الأخيرة</span>
                <ChevronsLeft className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>

        {/* Conditional Formatting Guide & Legend Strip */}
        {conditionalFormatting && (
          <div className="px-4 py-2.5 bg-gradient-to-l from-amber-50/50 via-sky-50/40 to-slate-50 border-t border-gray-200 flex flex-wrap items-center justify-between gap-2.5 text-xs">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-[11px] font-bold text-gray-700 flex items-center gap-1.5">
                <Highlighter className="w-3.5 h-3.5 text-amber-600" />
                <span>دليل التنسيق المشروط:</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50/90 text-amber-950 border border-amber-300 border-r-4 border-r-amber-500 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                <span>🟨 تظليل كهرماني: ملاحظات تحتوي على تنبيه أو تحذير</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-sky-50/90 text-sky-950 border border-sky-300 border-r-4 border-r-sky-500 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-sky-500 shrink-0" />
                <span>🟦 تظليل سماوي: قيد المراجعة والتدقيق</span>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-gray-400 font-medium hidden md:inline">
                تمييز بصري فوري يسهل المسح السريع دون تغيير البيانات الأصلية
              </span>
              <button
                type="button"
                onClick={handleToggleConditionalFormatting}
                className="text-[11px] font-bold text-gray-500 hover:text-gray-800 underline cursor-pointer"
              >
                تعطيل التنسيق
              </button>
            </div>
          </div>
        )}

      </div>

      {/* RTL Custom Right-Click Context Menu */}
      {contextMenu.visible && contextMenu.record && (
        <div
          ref={contextMenuRef}
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          className="fixed z-50 w-64 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-gray-200 py-2 text-xs text-gray-800 font-medium animate-in fade-in zoom-in-95 duration-150 divide-y divide-gray-100"
          dir="rtl"
        >
          {/* Header Title */}
          <div className="px-3.5 py-2 font-bold text-gray-950 bg-gray-50/80 flex items-center justify-between">
            <span className="truncate max-w-[190px]">{contextMenu.record.name}</span>
            <span className="text-[10px] text-gray-500 font-normal">{contextMenu.record.category}</span>
          </div>

          {/* Quick Actions */}
          <div className="py-1">
            {/* Direct Lock / Unlock Toggle in Context Menu */}
            {contextMenu.record && (
              <button
                onClick={() => {
                  if (contextMenu.record) handleToggleRecordLock(contextMenu.record);
                  setContextMenu(prev => ({ ...prev, visible: false }));
                }}
                className="w-full text-right px-3.5 py-2 hover:bg-amber-50 hover:text-amber-950 flex items-center gap-2.5 transition cursor-pointer font-bold"
              >
                {contextMenu.record.status === 'تام' || contextMenu.record.isLocked || contextMenu.record.isTruthRecord ? (
                  <>
                    <Unlock className="w-4 h-4 text-amber-700" />
                    <span>فك قفل هذا البيان للتعديل</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-emerald-700" />
                    <span>اعتماد كـ «بيان تام 🔒» وقفل السجل</span>
                  </>
                )}
              </button>
            )}

            <button
              onClick={() => {
                if (contextMenu.record) {
                  onEdit(contextMenu.record);
                }
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-emerald-50 hover:text-emerald-900 flex items-center gap-2.5 transition cursor-pointer font-bold"
            >
              <Edit3 className="w-4 h-4 text-emerald-600" />
              <span>تعديل السجل (Edit)</span>
            </button>

            {/* Add / Edit Note Action */}
            <button
              onClick={() => {
                if (contextMenu.record) {
                  setQuickNoteModal({
                    isOpen: true,
                    record: contextMenu.record,
                    noteText: contextMenu.record.metadata || ''
                  });
                }
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-purple-50 hover:text-purple-900 flex items-center gap-2.5 transition cursor-pointer font-bold"
            >
              <MessageSquarePlus className="w-4 h-4 text-purple-600" />
              <span>إضافة / تعديل ملاحظة (Add Note)</span>
            </button>

            {onOpenAudit && (
              <button
                onClick={() => {
                  if (contextMenu.record) onOpenAudit(contextMenu.record);
                  setContextMenu(prev => ({ ...prev, visible: false }));
                }}
                className="w-full text-right px-3.5 py-2 hover:bg-amber-50 hover:text-amber-900 flex items-center gap-2.5 transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-amber-600" />
                <span>تدقيق وفحص السجل</span>
              </button>
            )}

            {contextMenu.record && (
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                  contextMenu.record.metadata && (contextMenu.record.metadata.includes('31.') || contextMenu.record.metadata.includes('31°'))
                    ? (contextMenu.record.metadata.match(/31[°\.\d\s'N]+30[°\.\d\s'E]+/i)?.[0] || (contextMenu.record.name + ' دمنهور'))
                    : (contextMenu.record.name + ' دمنهور البحيرة')
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setContextMenu(prev => ({ ...prev, visible: false }))}
                className="w-full text-right px-3.5 py-2 hover:bg-emerald-50 hover:text-emerald-900 flex items-center gap-2.5 transition cursor-pointer font-bold"
              >
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>فتح الموقع على خرائط جوجل</span>
              </a>
            )}

            {onViewAuditLog && contextMenu.record && (
              <button
                onClick={() => {
                  if (contextMenu.record) onViewAuditLog(contextMenu.record);
                  setContextMenu(prev => ({ ...prev, visible: false }));
                }}
                className="w-full text-right px-3.5 py-2 hover:bg-indigo-50 hover:text-indigo-900 flex items-center gap-2.5 transition cursor-pointer font-bold"
              >
                <History className="w-4 h-4 text-indigo-600" />
                <span>سجل التعديلات والتوثيق القانوني</span>
                {contextMenu.record.auditLogs && contextMenu.record.auditLogs.length > 0 && (
                  <span className="mr-auto px-1.5 py-0.5 rounded-full text-[10px] font-black bg-indigo-100 text-indigo-800">
                    {contextMenu.record.auditLogs.length} تعديل
                  </span>
                )}
              </button>
            )}
          </div>

          {/* Copy Actions */}
          <div className="py-1">
            <button
              onClick={() => {
                if (contextMenu.record) {
                  navigator.clipboard.writeText(contextMenu.record.name);
                  if (onToast) onToast(`✓ تم نسخ «${contextMenu.record.name}» إلى الحافظة`);
                }
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-gray-100 flex items-center gap-2.5 transition cursor-pointer"
            >
              <Copy className="w-4 h-4 text-gray-500" />
              <span>نسخ اسم الشارع (Copy Street Name)</span>
            </button>

            <button
              onClick={() => {
                if (contextMenu.record) handleCopyRecordDetails(contextMenu.record);
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-gray-100 flex items-center gap-2.5 transition cursor-pointer"
            >
              <FileText className="w-4 h-4 text-gray-500" />
              <span>نسخ كامل بيانات الشارع</span>
            </button>
          </div>

          {/* Filter Actions */}
          <div className="py-1">
            <button
              onClick={() => {
                if (contextMenu.record) {
                  setFilterState(prev => ({ ...prev, permissionFilter: contextMenu.record!.permission }));
                }
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-blue-50 hover:text-blue-900 flex items-center gap-2.5 transition cursor-pointer"
            >
              <Building className="w-4 h-4 text-blue-600" />
              <span>تصفية بمأذونية: {contextMenu.record.permission || 'غير محدد'}</span>
            </button>

            <button
              onClick={() => {
                if (contextMenu.record) {
                  setFilterState(prev => ({ ...prev, searchQuery: contextMenu.record!.name, searchMode: 'exact' }));
                }
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-indigo-50 hover:text-indigo-900 flex items-center gap-2.5 transition cursor-pointer"
            >
              <Search className="w-4 h-4 text-indigo-600" />
              <span>البحث عن هذا الشارع فقط</span>
            </button>
          </div>

          {/* Similarity & Delete */}
          <div className="py-1">
            {(() => {
              const sim = similarityMap.get(contextMenu.record.id);
              if (sim?.suggestedNote && onEmbedSimilarityNote) {
                return (
                  <button
                    onClick={() => {
                      onEmbedSimilarityNote(contextMenu.record!.id, sim.suggestedNote);
                      setContextMenu(prev => ({ ...prev, visible: false }));
                    }}
                    className="w-full text-right px-3.5 py-2 hover:bg-emerald-50 hover:text-emerald-900 flex items-center gap-2.5 transition cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>تضمين ملاحظة الاشتراك</span>
                  </button>
                );
              }
              return null;
            })()}

            <button
              onClick={() => {
                if (contextMenu.record) onDelete(contextMenu.record.id);
                setContextMenu(prev => ({ ...prev, visible: false }));
              }}
              className="w-full text-right px-3.5 py-2 hover:bg-red-50 text-red-600 flex items-center gap-2.5 transition cursor-pointer font-bold"
            >
              <Trash2 className="w-4 h-4 text-red-600" />
              <span>حذف هذا السجل (Delete)</span>
            </button>
          </div>

        </div>
      )}

      {/* Quick Note Modal (Triggered by 'Add Note' in Context Menu) */}
      {quickNoteModal.isOpen && quickNoteModal.record && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-gray-200 w-full max-w-lg overflow-hidden p-6 space-y-4 animate-in zoom-in-95 duration-200"
            dir="rtl"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-purple-100 text-purple-700 rounded-2xl">
                  <StickyNote className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900">
                    إضافة / تعديل ملاحظة الشارع
                  </h3>
                  <p className="text-xs text-gray-500 font-medium">
                    «{quickNoteModal.record.name}» • {quickNoteModal.record.permission || 'مأذونية غير محددة'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setQuickNoteModal({ isOpen: false, record: null, noteText: '' })}
                className="p-1.5 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Preset Suggested Chips */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-gray-500">صيغ واقتراحات سريعة بنقرة ماوس:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'حدود الشارع: ',
                  'يبدأ من ... وينتهي عند ...',
                  'يشمل الحارات والزقاقات المتفرعة منه',
                  'مشترك مع مأذونية: '
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setQuickNoteModal(prev => ({
                        ...prev,
                        noteText: prev.noteText ? `${prev.noteText.trim()}\n${chip}` : chip
                      }));
                      if (quickNoteInputRef.current) {
                        quickNoteInputRef.current.focus();
                      }
                    }}
                    className="px-2.5 py-1 bg-gray-100 hover:bg-purple-100 hover:text-purple-900 text-gray-700 rounded-lg text-xs font-semibold transition cursor-pointer border border-gray-200"
                  >
                    + {chip}
                  </button>
                ))}
              </div>
            </div>

            {/* Note Textarea */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700">نص الملاحظة والبيان الوصفي:</label>
              <textarea
                ref={quickNoteInputRef}
                autoFocus
                rows={4}
                value={quickNoteModal.noteText}
                onChange={(e) => setQuickNoteModal(prev => ({ ...prev, noteText: e.target.value }))}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    if (quickNoteModal.record) {
                      if (onQuickUpdateNote) {
                        onQuickUpdateNote(quickNoteModal.record.id, quickNoteModal.noteText);
                      } else {
                        onEdit({ ...quickNoteModal.record, metadata: quickNoteModal.noteText });
                      }
                      setQuickNoteModal({ isOpen: false, record: null, noteText: '' });
                    }
                  }
                }}
                placeholder="اكتب أية ملاحظات، حدود، أو توضيحات خاصة بهذا الشارع..."
                className="w-full p-3.5 bg-gray-50 border border-gray-300 rounded-2xl text-xs sm:text-sm font-medium text-gray-900 focus:bg-white focus:ring-2 focus:ring-purple-500 focus:outline-none resize-none leading-relaxed"
              />
              <span className="text-[10px] text-gray-400 block text-left">
                اضغط Ctrl + Enter للحفظ السريع
              </span>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setQuickNoteModal({ isOpen: false, record: null, noteText: '' })}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  if (quickNoteModal.record) {
                    if (onQuickUpdateNote) {
                      onQuickUpdateNote(quickNoteModal.record.id, quickNoteModal.noteText);
                    } else {
                      onEdit({ ...quickNoteModal.record, metadata: quickNoteModal.noteText });
                    }
                    setQuickNoteModal({ isOpen: false, record: null, noteText: '' });
                  }
                }}
                className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black shadow-md transition cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>حفظ الملاحظة</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Quick Fill Modal (نافذة التعبئة السريعة للحقول الفارغة) */}
      {isQuickFillModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div 
            className="bg-white rounded-3xl shadow-2xl border border-gray-200 w-full max-w-xl overflow-hidden p-6 space-y-4 animate-in zoom-in-95 duration-200"
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-gradient-to-tr from-emerald-600 to-teal-600 text-white rounded-2xl shadow-sm">
                  <Zap className="w-5 h-5 fill-amber-300 text-amber-300" />
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900">
                    أداة التعبئة والضبط السريع للبيانات
                  </h3>
                  <p className="text-xs text-gray-500 font-medium">
                    تعبئة المأذونيات والملاحظات الناقصة دفعة واحدة مع الحفاظ على السجلات السليمة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsQuickFillModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Selection Tabs */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700">اختر نوع العملية المطلوبة:</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setQuickFillType('permission')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                    quickFillType === 'permission'
                      ? 'bg-emerald-50/80 border-emerald-400 ring-2 ring-emerald-300 text-emerald-950 font-black'
                      : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                    <span>تعبئة المأذونية الفارغة</span>
                  </div>
                  <span className="text-[11px] text-gray-500 font-medium">
                    ({healthStats.missingPermissionCount} سجل بدون مأذونية)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setQuickFillType('metadata')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                    quickFillType === 'metadata'
                      ? 'bg-indigo-50/80 border-indigo-400 ring-2 ring-indigo-300 text-indigo-950 font-black'
                      : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold">
                    <StickyNote className="w-4 h-4 text-indigo-600" />
                    <span>تعبئة الملاحظات الفارغة</span>
                  </div>
                  <span className="text-[11px] text-gray-500 font-medium">
                    ({healthStats.missingMetadataCount} سجل بدون ملاحظات)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setQuickFillType('autoInferPermission')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                    quickFillType === 'autoInferPermission'
                      ? 'bg-purple-50/80 border-purple-400 ring-2 ring-purple-300 text-purple-950 font-black'
                      : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold">
                    <Wand2 className="w-4 h-4 text-purple-600" />
                    <span>استنتاج المأذونية الذكي</span>
                  </div>
                  <span className="text-[11px] text-gray-500 font-medium">
                    نسخ المأذونية من الشوارع المتطابقة تلقائياً
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setQuickFillType('both')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                    quickFillType === 'both'
                      ? 'bg-teal-50/80 border-teal-400 ring-2 ring-teal-300 text-teal-950 font-black'
                      : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold">
                    <Sparkles className="w-4 h-4 text-teal-600" />
                    <span>تعبئة شاملة (مأذونية + ملاحظات)</span>
                  </div>
                  <span className="text-[11px] text-gray-500 font-medium">
                    ضبط كلا الحقلين في خطوة واحدة
                  </span>
                </button>
              </div>
            </div>

            {/* Permission Configuration */}
            {(quickFillType === 'permission' || quickFillType === 'both') && (
              <div className="p-3.5 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-2">
                <label className="text-xs font-bold text-emerald-950 flex items-center justify-between">
                  <span>اختر المأذونية المراد تعيينها:</span>
                  <span className="text-[10px] text-emerald-700">مأذونيات دمنهور</span>
                </label>
                <div className="flex gap-2">
                  <select
                    value={quickFillTargetPerm}
                    onChange={(e) => setQuickFillTargetPerm(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-gray-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    {['شبرا بحري', 'سكنيدة', 'طاموس', 'شبرا قبلي', 'قرطسا بحري', 'نقرها', 'قرطسا قبلي', 'سيدي عمر', 'أبو الريش', 'مخصصة'].map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
                {quickFillTargetPerm === 'مخصصة' && (
                  <input
                    type="text"
                    value={quickFillCustomPerm}
                    onChange={(e) => setQuickFillCustomPerm(e.target.value)}
                    placeholder="اكتب اسم المأذونية المخصصة..."
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-gray-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                )}
              </div>
            )}

            {/* Metadata Configuration */}
            {(quickFillType === 'metadata' || quickFillType === 'both') && (
              <div className="p-3.5 bg-indigo-50/50 rounded-2xl border border-indigo-200 space-y-2">
                <label className="text-xs font-bold text-indigo-950">
                  صيغة أو نص الملاحظة المراد تعبئتها:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'شارع رئيسي بدمنهور',
                    'يقع ضمن نطاق مأذونية الشارع',
                    'يشمل الحارات والزقاقات المتفرعة'
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setQuickFillTargetMeta(preset)}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-bold border transition cursor-pointer ${
                        quickFillTargetMeta === preset
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white hover:bg-indigo-100 text-indigo-900 border-indigo-200'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={quickFillTargetMeta}
                  onChange={(e) => setQuickFillTargetMeta(e.target.value)}
                  placeholder="أدخل نص الملاحظة..."
                  className="w-full px-3 py-2 bg-white border border-indigo-300 rounded-xl text-xs font-bold text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            )}

            {/* Auto-Infer Info */}
            {quickFillType === 'autoInferPermission' && (
              <div className="p-3.5 bg-purple-50 rounded-2xl border border-purple-200 text-xs text-purple-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span>كيف يعمل الاستنتاج الذكي؟</span>
                </div>
                <p className="text-[11px] text-purple-800 leading-relaxed font-medium">
                  يقوم النظام بالبحث التلقائي عن أي شوارع أخرى لها نفس الاسم ومحددة مأذونيتها مسبقاً، ثم ينسخ المأذونية تلقائياً إلى السجلات الفارغة.
                </p>
              </div>
            )}

            {/* Scope & Safety Settings */}
            <div className="bg-gray-50 p-3.5 rounded-2xl border border-gray-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="font-bold text-gray-700">خيارات الأمان والتطبيق:</label>
                {selectedIds.size > 0 && (
                  <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    تم تحديد {selectedIds.size} سجل بالفأرة
                  </span>
                )}
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={quickFillOnlyEmpty}
                    onChange={(e) => setQuickFillOnlyEmpty(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 cursor-pointer"
                  />
                  <span className="font-bold text-gray-800">
                    تطبيق فقط على الحقول الفارغة (عدم استبدال أية بيانات مسجلة مسبقاً)
                  </span>
                </label>

                {selectedIds.size > 0 && (
                  <div className="flex items-center gap-4 pt-1">
                    <label className="flex items-center gap-1.5 cursor-pointer font-bold text-gray-700">
                      <input
                        type="radio"
                        name="quickFillScope"
                        checked={quickFillScope === 'all'}
                        onChange={() => setQuickFillScope('all')}
                        className="text-emerald-600 cursor-pointer"
                      />
                      <span>تطبيق على كافة سجلات النظام</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer font-bold text-emerald-800">
                      <input
                        type="radio"
                        name="quickFillScope"
                        checked={quickFillScope === 'selected'}
                        onChange={() => setQuickFillScope('selected')}
                        className="text-emerald-600 cursor-pointer"
                      />
                      <span>تطبيق على السجلات المحددة فقط ({selectedIds.size})</span>
                    </label>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setIsQuickFillModalOpen(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  const finalPerm = quickFillTargetPerm === 'مخصصة' ? quickFillCustomPerm.trim() : quickFillTargetPerm;
                  const finalMeta = quickFillTargetMeta.trim();

                  if (onQuickBatchFill) {
                    onQuickBatchFill({
                      fillType: quickFillType,
                      targetPermission: finalPerm,
                      targetMetadata: finalMeta,
                      onlyEmpty: quickFillOnlyEmpty,
                      selectedIds: quickFillScope === 'selected' && selectedIds.size > 0 ? Array.from(selectedIds) : undefined
                    });
                  } else if (onToast) {
                    onToast('✓ تم تنفيذ التعبئة السريعة بنجاح');
                  }
                  setIsQuickFillModalOpen(false);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>تنفيذ التعبئة والضبط الآن</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Floating Mouse Scroll-To-Top Button */}
      {showScrollTop && (
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-20 left-6 z-40 p-3 bg-gray-900/90 hover:bg-gray-900 text-white rounded-2xl shadow-2xl border border-gray-700 transition duration-200 hover:scale-110 cursor-pointer"
          title="الصعود السريع لأعلى الصفحة بالماوس"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
}
