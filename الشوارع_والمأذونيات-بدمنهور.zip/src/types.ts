export interface AuditChange {
  field: 'name' | 'permission' | 'metadata' | 'category' | 'status' | 'isLocked';
  fieldLabel: string;
  oldValue: string;
  newValue: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string; // ISO string
  formattedDate: string; // Arabic localized date
  userName: string;
  action: 'create' | 'update' | 'note_update' | 'permission_update' | 'import_update' | 'status_change';
  changes: AuditChange[];
  note?: string;
}

export interface RecordItem {
  id: string;
  name: string;
  permission: string;
  metadata: string;
  category: string;
  status?: RecordStatus;
  isLocked?: boolean;
  isTruthRecord?: boolean;
  truthRecordId?: string;
  similarityClassification?: string;
  auditLogs?: AuditLogEntry[];
  lastModifiedAt?: string;
  lastModifiedBy?: string;
}

export type ThemeType = 'excel' | 'libreoffice' | 'modern' | 'hybrid' | 'custom';

export type AccentColorType = 'emerald' | 'cyan' | 'indigo' | 'slate' | 'amber' | 'purple';

export type ViewModeType = 'normal' | 'reading' | 'mouse_edit';

export interface ColumnStyleConfig {
  visible: boolean;
  label?: string;
  align?: 'right' | 'center' | 'left';
  fontWeight?: 'normal' | 'semibold' | 'bold' | 'black';
  textColor?: string;
}

export interface DynamicThemeSettings {
  accentColor: AccentColorType;
  customHexAccent?: string;
  headerStyle: 'solid' | 'gradient' | 'minimal';
  rowStripingIntensity: 'none' | 'subtle' | 'distinct';
  hoverEffect: boolean;
  tableBorderRadius: 'sm' | 'md' | 'lg' | 'xl' | 'none';
  columns: {
    index: ColumnStyleConfig;
    name: ColumnStyleConfig;
    permission: ColumnStyleConfig;
    category: ColumnStyleConfig;
    metadata: ColumnStyleConfig;
    actions: ColumnStyleConfig;
  };
}

export interface AppSettings {
  fontFamily: string;
  fontSize: 'sm' | 'base' | 'lg' | 'xl';
  printFontSize: string;
  tableDensity: 'compact' | 'normal' | 'relaxed';
  enableZebra: boolean;
  cellBorders: boolean;
  // Work & Interaction Modes
  viewMode?: ViewModeType;
  readingModeFontSize?: 'lg' | 'xl' | '2xl';
  readingModeHighContrast?: boolean;
  mouseEditQuickTouch?: boolean;
  enableProductivitySuite?: boolean;
  enableSmartAutoCorrect?: boolean;
  enableKeyboardShortcuts?: boolean;
  // Workspace Cleanliness & Visibility Controls
  showDataHealthBar?: boolean;
  showSmartShortcutsBar?: boolean;
  showQuickDistrictTags?: boolean;
  showAuditButton?: boolean;
  showExportImportInHeader?: boolean;
  showSidebar?: boolean;
  cleanWorkspaceMode?: boolean;
  conditionalFormatting?: boolean; // التنسيق المشروط وتظليل سجلات التنبيه وقيد المراجعة بلون تمييز خفيف
  conditionalFormattingAlerts?: boolean; // تمييز وسوم التنبيه والتحذير باللون الكهرماني
  conditionalFormattingReviews?: boolean; // تمييز وسوم قيد المراجعة والتدقيق باللون السماوي
  // Mouse Ergonomics & Controls (التحكم والتفاعل بالماوس)
  mouseDoubleClickAction?: 'edit' | 'select' | 'audit' | 'none'; // سلوك النقر المزدوج بالماوس
  mouseMiddleClickAction?: 'select' | 'lock' | 'edit' | 'none'; // سلوك النقر بالزر الأوسط للفأرة / عجلة الماوس
  mouseRightClickMenu?: boolean; // تفعيل قائمة السياق الذكية بالزر الأيمن
  mouseHoverHighlight?: boolean; // تظليل الصفوف وتأثير التمرير بالماوس
  mouseShowHoverToolbar?: boolean; // إظهار شريط الإجراءات السريعة المصغر عند التمرير بالماوس
  // Auditor / Reviewer and Export Metadata
  reviewerName?: string;
  canUnlockRecords?: boolean; // هل يملك المستخدم صلاحية فك قفل السجلات التامة
  autoPrecautionUnderReview?: boolean; // وضع البيانات الجديدة أو الحالية قيد المراجعة كإجراء احترازي إداري
  userRole?: 'supervisor' | 'reviewer' | 'data_entry';
  includeTimestampsInExports?: boolean;
  lastBackupTimestamp?: string;
  // Audit Sheet & Sequential Review Settings
  auditAutoSave?: boolean;
  auditAutoSaveDelay?: number; // ms debounce (e.g. 400, 600, 1000)
  auditShowAlphabetRibbon?: boolean;
  auditShowSerialInTable?: boolean;
  auditArrowKeyNavigation?: boolean;
  auditPrefixDrawerMode?: boolean;
  // Custom Street Categories & Unofficial Classification
  customStreetCategories?: string[];
  customUnofficialSubTypes?: string[];
  suggestedOfficialNotarizations?: string[];
  // Unified Dynamic Theme Customization
  dynamicTheme: DynamicThemeSettings;
}

export interface FilterState {
  searchQuery: string;
  searchMode?: 'partial' | 'exact' | 'startsWith';
  permissionFilter?: string;
  categoryFilter?: string;
  notarization?: string | 'all';
  recordType?: RecordType | 'all';
  status?: RecordStatus | 'all';
  category?: RecordCategory | 'all';
  sharedStreetsOnly?: boolean;
  truthRecordsOnly?: boolean;
  similarRecordsOnly?: boolean;
  dateRange?: { from: string; to: string };
}

// ══════════════════════════════════════════════════════════
// 🏛️ Modular System Types (Rts Architecture Enhancements)
// ══════════════════════════════════════════════════════════

export const DEFAULT_STREET_CATEGORIES = [
  'شارع',
  'رئيسي',
  'فرعي',
  'حارة',
  'عطفة',
  'ميدان',
  'طريق',
  'زقاق',
  'درب',
  'سكة',
  'حي'
] as const;

export const DEFAULT_UNOFFICIAL_SUBTYPES = [
  'مأذونية محددة / دفاتر مأذون',
  'محضرين / إعلانات قضائية',
  'شهر عقاري / توثيق / سجل عيني',
  'خرائط مساحية وهيئة المساحة',
  'ضرائب عقارية / عوائد',
  'محاكم وقضايا',
  'داتا خاصة',
  'داتا عقود زواج',
  'داتا بطاقة رقم قومي',
  'مأذونية مقترحة',
  'أخرى (مخصص)'
] as const;

export const OFFICIAL_SEVEN_NOTARIZATIONS = [
  'شبرا بحري',
  'سكنيدة',
  'طاموس',
  'شبرا قبلي',
  'قرطسا بحري',
  'نقرها',
  'قرطسا قبلي'
] as const;

export const OFFICIAL_NOTARIZATIONS = OFFICIAL_SEVEN_NOTARIZATIONS;

export type OfficialNotarization = typeof OFFICIAL_NOTARIZATIONS[number];

export const ALL_DISTRICTS = [
  ...OFFICIAL_NOTARIZATIONS,
  'نقرها أول',
  'شبرا_1',
  'شبرا_2',
  'شبرا_3',
  'قرطسا',
  'أبو الريش',
  'إفلاقة'
] as const;

export const RECORD_TYPES = [
  'شارع',
  'حارة',
  'ميدان',
  'عطفة',
  'حي',
  'زقاق',
  'طريق',
  'محور'
] as const;

export type RecordType = typeof RECORD_TYPES[number];

export type RecordCategory = 
  | 'مأذونية رسمية' 
  | 'مأذونية غير رسمية' 
  | 'حي' 
  | 'شارع' 
  | 'تقاسيم وعقود'
  | string;

export type RecordStatus = 'نشط' | 'معلّق' | 'ملغي' | 'قيد المراجعة' | 'تام';

export interface StreetRecord {
  id: string;
  streetName: string;
  normalizedStreetName: string;
  notarization: string;
  category: RecordCategory;
  recordType: RecordType;
  description: string;
  landmarks: string;
  boundaries: string;
  nationalId?: string;
  contractDate?: string;
  gpsCoordinates?: string;
  status: RecordStatus;
  sharedNotarization?: string;
  sharedNote?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  version: number;
  auditLogs?: AuditLogEntry[];
}

export interface FieldChange {
  fieldName: string;
  fieldLabel: string;
  oldValue: string;
  newValue: string;
}

export interface UndoSnapshot {
  id: string;
  timestamp: string;
  action: string;
  description: string;
  records: StreetRecord[];
}

export type TableDensity = 'compact' | 'normal' | 'comfortable';
export type ViewMode = 'default' | 'clean' | 'reading';

export interface UserSettings {
  operatorName: string;
  theme: ThemeType | string;
  tableDensity: TableDensity;
  viewMode: ViewMode;
  fontSize: number;
  showNotes: boolean;
  showSharedBadge: boolean;
  autoSave: boolean;
  confirmDelete: boolean;
  language: 'ar' | 'en';
  shortcutsEnabled: boolean;
  exportFormat: ExportFormat;
  exportColors: boolean;
  exportBorders: boolean;
  exportHeader: boolean;
  exportFooter: boolean;
  exportRtl: boolean;
  exportWatermark: boolean;
  exportSignature: boolean;
  backupFrequency: 'daily' | 'weekly' | 'monthly' | 'never';
  encryptBackup: boolean;
  appLockEnabled: boolean;
  lastBackupDate?: string;
}

export interface DuplicateCheckResult {
  isDuplicate: boolean;
  matchedRecords: StreetRecord[];
  similarityScore: number;
  suggestedAction: 'merge' | 'replace' | 'separate';
}

export interface SimilarityResult {
  recordId: string;
  streetName: string;
  notarization: string;
  similarRecords: Array<{
    recordId: string;
    streetName: string;
    notarization: string;
    similarityScore: number;
    overlapType: 'prefix' | 'suffix' | 'contains' | 'fuzzy';
  }>;
}

export interface PrintSettings {
  notarization: string | 'all';
  fontSize: number;
  showNotes: boolean;
  showBoundaries: boolean;
  showLandmarks: boolean;
  includeHeader: boolean;
  includeFooter: boolean;
  includeAuditTrail: boolean;
}

export type ExportFormat = 'excel' | 'pdf' | 'html' | 'csv';
export type ExportScope = 'filtered' | 'all' | 'selected';

export interface AdvancedExportOptions {
  format: ExportFormat;
  scope: ExportScope;
  colors: boolean;
  borders: boolean;
  header: boolean;
  footer: boolean;
  rtl: boolean;
  autofit: boolean;
  freeze: boolean;
  altRows: boolean;
  password?: string;
  modifyPassword?: string;
  readonly: boolean;
  nocopy: boolean;
  noprint: boolean;
  watermark: boolean;
  signature: boolean;
  operator: string;
}

