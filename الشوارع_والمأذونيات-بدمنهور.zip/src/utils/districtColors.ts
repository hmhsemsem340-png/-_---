export interface DistrictColor {
  name: string;
  key: string;
  bg: string;
  text: string;
  border: string;
  dot: string;
  bar: string;
  hex: string;
}

export const OFFICIAL_DISTRICTS: DistrictColor[] = [
  { name: 'شبرا بحري', key: 'شبرا بحري', bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-300', dot: 'bg-red-600', bar: 'bg-red-600', hex: '#dc2626' },
  { name: 'سكنيدة', key: 'سكنيدة', bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300', dot: 'bg-green-600', bar: 'bg-green-600', hex: '#16a34a' },
  { name: 'طاموس', key: 'طاموس', bg: 'bg-gray-900', text: 'text-white', border: 'border-gray-900', dot: 'bg-gray-900', bar: 'bg-gray-900', hex: '#111827' },
  { name: 'شبرا قبلي', key: 'شبرا قبلي', bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-300', dot: 'bg-blue-600', bar: 'bg-blue-600', hex: '#2563eb' },
  { name: 'قرطسا بحري', key: 'قرطسا بحري', bg: 'bg-orange-100', text: 'text-orange-800', border: 'border-orange-300', dot: 'bg-orange-500', bar: 'bg-orange-500', hex: '#f97316' },
  { name: 'نقرها', key: 'نقرها', bg: 'bg-amber-100', text: 'text-amber-900', border: 'border-amber-300', dot: 'bg-amber-800', bar: 'bg-amber-800', hex: '#92400e' },
  { name: 'قرطسا قبلي', key: 'قرطسا قبلي', bg: 'bg-pink-100', text: 'text-pink-800', border: 'border-pink-300', dot: 'bg-pink-500', bar: 'bg-pink-500', hex: '#ec4899' }
];

export function getDistrictColor(permission: string, metadata = '', name = ''): DistrictColor | null {
  const haystack = `${permission || ''} ${metadata || ''} ${name || ''}`;
  for (const d of OFFICIAL_DISTRICTS) {
    if (haystack.includes(d.key)) return d;
  }
  return null;
}