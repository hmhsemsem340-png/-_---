import { RecordItem } from '../types';
import { normalizeArabicText, cleanArabicString } from './arabicEncoding';

export interface StreetSimilarityInfo {
  recordId: string;
  hasSimilarity: boolean;
  isSharedAcrossPermissions: boolean;
  isDuplicateInSamePermission: boolean;
  hasCategoryVariant: boolean;
  sharedPermissions: string[];
  samePermissionCount: number;
  matchedRecordIds: string[];
  variantNames: { name: string; permission: string; category: string }[];
  suggestedNote: string | null;
}

/**
 * Strips street prefixes like "شارع", "حارة", "زقاق", "عطفة", "ميدان", "طريق", "درب", "سكة", "حي"
 * to find root name similarities (e.g. "حارة السلام" and "شارع السلام")
 */
export function extractStreetRootName(name: string): string {
  if (!name) return '';
  let cleaned = normalizeArabicText(name);
  cleaned = cleaned.replace(/^(شارع|حارة|عطفة|زقاق|ميدان|درب|طريق|سكة|حي|منطقة|بلوك|سوق)\s+/, '');
  return cleaned.trim();
}

/**
 * Analyzes all records to find shared streets across permissions, exact name duplicates,
 * and category variations (شارع vs حارة).
 */
export function analyzeAllStreetSimilarities(records: RecordItem[]): Map<string, StreetSimilarityInfo> {
  const resultMap = new Map<string, StreetSimilarityInfo>();

  // Map 1: Exact normalized full name -> list of records
  const exactNameMap = new Map<string, RecordItem[]>();
  // Map 2: Root name (without prefix) -> list of records
  const rootNameMap = new Map<string, RecordItem[]>();

  records.forEach(r => {
    const exactNorm = normalizeArabicText(r.name);
    const rootNorm = extractStreetRootName(r.name);

    if (exactNorm) {
      const list = exactNameMap.get(exactNorm) || [];
      list.push(r);
      exactNameMap.set(exactNorm, list);
    }

    if (rootNorm && rootNorm.length >= 2) {
      const list = rootNameMap.get(rootNorm) || [];
      list.push(r);
      rootNameMap.set(rootNorm, list);
    }
  });

  records.forEach(r => {
    const exactNorm = normalizeArabicText(r.name);
    const rootNorm = extractStreetRootName(r.name);
    const currentPerm = (r.permission || '').trim();
    const currentPermNorm = normalizeArabicText(currentPerm);

    const exactMatches = (exactNameMap.get(exactNorm) || []).filter(other => other.id !== r.id);
    const rootMatches = (rootNameMap.get(rootNorm) || []).filter(other => other.id !== r.id);

    // Other permissions where this exact name appears
    const sharedPermsSet = new Set<string>();
    let samePermCount = 0;
    const matchedIds: string[] = [];

    exactMatches.forEach(other => {
      matchedIds.push(other.id);
      const otherPerm = (other.permission || '').trim();
      const otherPermNorm = normalizeArabicText(otherPerm);

      if (otherPerm && otherPermNorm !== currentPermNorm) {
        sharedPermsSet.add(otherPerm);
      } else {
        samePermCount++;
      }
    });

    const isShared = sharedPermsSet.size > 0;
    const isDupInSame = samePermCount > 0;

    // Variants (different prefix like حارة vs شارع)
    const variants: { name: string; permission: string; category: string }[] = [];
    rootMatches.forEach(other => {
      const otherExactNorm = normalizeArabicText(other.name);
      if (otherExactNorm !== exactNorm) {
        variants.push({
          name: other.name,
          permission: other.permission || 'غير محدد',
          category: other.category || 'شارع'
        });
      }
    });

    const hasVariants = variants.length > 0;
    const hasSimilarity = isShared || isDupInSame || hasVariants;

    // Build suggested note
    let suggestedNote: string | null = null;
    const noteParts: string[] = [];

    if (isShared) {
      const permsList = Array.from(sharedPermsSet).join('، ');
      noteParts.push(`[مشترك مع مأذونية أخرى: ${permsList}]`);
    }
    if (isDupInSame) {
      noteParts.push(`[تكرر في نفس المأذونية (${currentPerm || 'غير محدد'})]`);
    }
    if (hasVariants && !isShared && !isDupInSame) {
      const variantSample = variants.slice(0, 2).map(v => `${v.name} (${v.permission})`).join('، ');
      noteParts.push(`[تشابه مسميات مع: ${variantSample}]`);
    }

    if (noteParts.length > 0) {
      suggestedNote = noteParts.join(' ');
    }

    resultMap.set(r.id, {
      recordId: r.id,
      hasSimilarity,
      isSharedAcrossPermissions: isShared,
      isDuplicateInSamePermission: isDupInSame,
      hasCategoryVariant: hasVariants,
      sharedPermissions: Array.from(sharedPermsSet),
      samePermissionCount: samePermCount,
      matchedRecordIds: matchedIds,
      variantNames: variants,
      suggestedNote
    });
  });

  return resultMap;
}

/**
 * Checks similarity for a single record against the database (used in real-time forms/imports)
 */
export function checkSingleStreetSimilarity(
  name: string,
  permission: string,
  excludeId: string | undefined,
  records: RecordItem[]
): {
  isShared: boolean;
  isSamePermDup: boolean;
  sharedPermissions: string[];
  samePermMatches: RecordItem[];
  variantMatches: RecordItem[];
  suggestedNote: string;
} {
  const normName = normalizeArabicText(name);
  const rootName = extractStreetRootName(name);
  const normPerm = normalizeArabicText(permission);

  if (!normName) {
    return {
      isShared: false,
      isSamePermDup: false,
      sharedPermissions: [],
      samePermMatches: [],
      variantMatches: [],
      suggestedNote: ''
    };
  }

  const sharedPermsSet = new Set<string>();
  const samePermMatches: RecordItem[] = [];
  const variantMatches: RecordItem[] = [];

  records.forEach(r => {
    if (excludeId && r.id === excludeId) return;

    const otherNormName = normalizeArabicText(r.name);
    const otherNormPerm = normalizeArabicText(r.permission);
    const otherRootName = extractStreetRootName(r.name);

    if (otherNormName === normName) {
      if (otherNormPerm === normPerm) {
        samePermMatches.push(r);
      } else if (r.permission) {
        sharedPermsSet.add(r.permission);
      }
    } else if (rootName && otherRootName === rootName && rootName.length >= 2) {
      variantMatches.push(r);
    }
  });

  const isShared = sharedPermsSet.size > 0;
  const isSamePermDup = samePermMatches.length > 0;
  const sharedPermissions = Array.from(sharedPermsSet);

  const noteParts: string[] = [];
  if (isShared) {
    noteParts.push(`[مشترك مع مأذونية أخرى: ${sharedPermissions.join('، ')}]`);
  }
  if (isSamePermDup) {
    noteParts.push(`[تكرر في نفس المأذونية (${permission || 'غير محدد'})]`);
  }
  if (!isShared && !isSamePermDup && variantMatches.length > 0) {
    const sample = variantMatches.slice(0, 2).map(v => `${v.name} (${v.permission})`).join('، ');
    noteParts.push(`[تشابه مسميات مع: ${sample}]`);
  }

  return {
    isShared,
    isSamePermDup,
    sharedPermissions,
    samePermMatches,
    variantMatches,
    suggestedNote: noteParts.join(' ')
  };
}

/**
 * Embeds similarity / shared permission note into a record's metadata safely without duplication.
 */
export function embedSimilarityNoteIntoMetadata(currentMetadata: string, noteToEmbed: string): string {
  const meta = cleanArabicString(currentMetadata || '').trim();
  const note = noteToEmbed.trim();
  if (!note) return meta;

  // Remove existing automated tags of the same type to avoid clutter
  const cleanedExisting = meta
    .replace(/\[مشترك مع مأذونية[^\]]*\]/g, '')
    .replace(/\[تكرر في نفس المأذونية[^\]]*\]/g, '')
    .replace(/\[تشابه مسميات مع[^\]]*\]/g, '')
    .trim();

  if (!cleanedExisting) {
    return note;
  }

  return `${cleanedExisting}\n${note}`;
}

export interface SimilarityGroup {
  id: string;
  rootName: string;
  displayName: string;
  records: RecordItem[];
  truthRecord?: RecordItem;
  hasTruthRecord: boolean;
  groupType: 'duplicate_same_permission' | 'shared_permissions' | 'prefix_variant' | 'mixed';
  permissions: string[];
}

/**
 * Groups all records that share the same base/root street name or exact name
 * into clusters for review, classification, and Ground Truth management.
 */
export function groupSimilarRecords(records: RecordItem[]): SimilarityGroup[] {
  const groupsMap = new Map<string, RecordItem[]>();

  records.forEach(r => {
    const root = extractStreetRootName(r.name) || normalizeArabicText(r.name);
    if (!root || root.length < 2) return;

    const existing = groupsMap.get(root) || [];
    existing.push(r);
    groupsMap.set(root, existing);
  });

  const result: SimilarityGroup[] = [];

  groupsMap.forEach((groupRecords, root) => {
    // Only groups with 2 or more records constitute a similarity cluster
    if (groupRecords.length < 2) return;

    // Check permissions
    const permCounts = new Map<string, number>();
    const permSet = new Set<string>();
    let hasDuplicateInSame = false;

    groupRecords.forEach(r => {
      const p = (r.permission || 'غير محدد').trim();
      permSet.add(p);
      const count = (permCounts.get(p) || 0) + 1;
      permCounts.set(p, count);
      if (count > 1) {
        hasDuplicateInSame = true;
      }
    });

    const isShared = permSet.size > 1;

    // Check prefix variations
    const namesNormSet = new Set(groupRecords.map(r => normalizeArabicText(r.name)));
    const hasPrefixVariant = namesNormSet.size > 1;

    let groupType: SimilarityGroup['groupType'] = 'prefix_variant';
    if (hasDuplicateInSame && isShared) {
      groupType = 'mixed';
    } else if (hasDuplicateInSame) {
      groupType = 'duplicate_same_permission';
    } else if (isShared) {
      groupType = 'shared_permissions';
    }

    // Look for Truth Record (بيان تام معتمد)
    const truth = groupRecords.find(r => r.status === 'تام' || r.isTruthRecord || r.isLocked);

    // Sort records inside group: truth record first, then by name/permission
    const sortedRecords = [...groupRecords].sort((a, b) => {
      if (a.id === truth?.id) return -1;
      if (b.id === truth?.id) return 1;
      return a.name.localeCompare(b.name, 'ar');
    });

    result.push({
      id: `group-${root}`,
      rootName: root,
      displayName: truth?.name || sortedRecords[0]?.name || root,
      records: sortedRecords,
      truthRecord: truth,
      hasTruthRecord: Boolean(truth),
      groupType,
      permissions: Array.from(permSet)
    });
  });

  // Sort groups: duplicates in same permission first (highest priority for audit), then mixed, then shared, then prefix variants
  result.sort((a, b) => {
    const priority = (g: SimilarityGroup) => {
      if (g.groupType === 'duplicate_same_permission') return 1;
      if (g.groupType === 'mixed') return 2;
      if (g.groupType === 'shared_permissions') return 3;
      return 4;
    };
    const pDiff = priority(a) - priority(b);
    if (pDiff !== 0) return pDiff;
    return a.rootName.localeCompare(b.rootName, 'ar');
  });

  return result;
}

