import { normalizeArabicText } from './arabicEncoding';

// Landmark keywords associated with official districts in Damanhour
const DISTRICT_KEYWORDS: Record<string, string[]> = {
  'شبرا بحري': [
    'عبد السلام الشاذلي', 'طور سيناء', 'استاد دمنهور', 'صلاح سالم',
    'أرض أدمون', 'أرض الحوفي', 'المدرسة الفكرية', 'سنترال دمنهور',
    'الرحباية', 'سيدي عدس', 'داير شبرا الغربي', 'مسجد التقوى',
    'مسجد القيشي', 'شجرة الدر', 'المقريزي', 'حسين حجازي'
  ],
  'شبرا قبلي': [
    'الروضة', 'المعهد الديني', 'ترعة الشريف', 'الزخرفية',
    'طريق النصر', 'مدينة نصر', 'المرور', 'ترعة أبو قرن'
  ],
  'سكنيدة': [
    'سكنيدة', 'شارع سكنيدة', 'البركة القديمة', 'إسماعيل صدقي',
    'أحمد عرابي سكنيدة', 'تحسين الصحة', 'ابن خلدون'
  ],
  'طاموس': [
    'طاموس', 'ميدان بورسعيد', 'ترعة بني هلال', 'أبو الريش طاموس',
    'أبو هريرة طاموس', 'بابور النور', 'بيومي الوكيل'
  ],
  'قرطسا بحري': [
    'قرطسا بحري', 'إسماعيل الحبروك', 'الأقصر', 'الأنصاري',
    'البوليني', 'أبو هريرة'
  ],
  'قرطسا قبلي': [
    'قرطسا قبلي', 'أم شوشة', 'أحمد عبد العزيز'
  ],
  'نقرها': [
    'نقرها', 'البلاسي', 'الأجهوري', 'أبو عبد الله', 'أبو عساكر'
  ]
};

/**
 * Suggests an official district based on keywords in the street name or metadata
 */
export function suggestDistrictFromContext(text: string): string | null {
  if (!text) return null;
  const normalized = normalizeArabicText(text);

  for (const [district, keywords] of Object.entries(DISTRICT_KEYWORDS)) {
    for (const kw of keywords) {
      if (normalized.includes(normalizeArabicText(kw))) {
        return district;
      }
    }
  }
  return null;
}

/**
 * Automatically cleans street name input, extracts prefixes and identifies category
 */
export function cleanStreetInput(raw: string): {
  cleanName: string;
  prefix: string;
  category: string;
  suggestedPermission: string | null;
  extractedMetadata?: string;
} {
  let str = (raw || '').trim();
  let extractedMetadata = '';

  // Extract content in parentheses as potential metadata
  const bracketMatch = str.match(/\((.*?)\)/);
  if (bracketMatch) {
    extractedMetadata = bracketMatch[1].trim();
    str = str.replace(/\(.*?\)/g, ' ').trim();
  }

  // Remove common shorthand prefixes
  str = str.replace(/^(ش[\.\/:]\s*|شارع[\.\/:]\s*)/i, 'شارع ');
  str = str.replace(/^(ط[\.\/:]\s*|طريق[\.\/:]\s*)/i, 'طريق ');
  str = str.replace(/^(ح[\.\/:]\s*|حارة[\.\/:]\s*)/i, 'حارة ');
  str = str.replace(/^(ز[\.\/:]\s*|زقاق[\.\/:]\s*)/i, 'زقاق ');
  str = str.replace(/^(ع[\.\/:]\s*|عطفة[\.\/:]\s*)/i, 'عطفة ');
  str = str.replace(/^(م[\.\/:]\s*|ميدان[\.\/:]\s*)/i, 'ميدان ');

  // Standard prefixes list
  const knownPrefixes = ['شارع', 'حارة', 'عطفة', 'ميدان', 'زقاق', 'طريق', 'محور', 'حي'];
  let detectedPrefix = 'شارع';
  let cleanName = str;

  for (const p of knownPrefixes) {
    if (str.startsWith(p + ' ') || str.startsWith(p + '	')) {
      detectedPrefix = p;
      cleanName = str.substring(p.length).trim();
      break;
    }
  }

  // Determine category
  let category = 'شارع';
  if (detectedPrefix === 'حارة') category = 'حارة';
  else if (detectedPrefix === 'عطفة') category = 'عطفة';
  else if (detectedPrefix === 'زقاق') category = 'زقاق';
  else if (detectedPrefix === 'ميدان') category = 'ميدان';
  else if (detectedPrefix === 'طريق' || detectedPrefix === 'محور') category = 'طريق';
  else if (detectedPrefix === 'حي') category = 'حي';

  const fullText = `${cleanName} ${extractedMetadata}`;
  const suggestedPermission = suggestDistrictFromContext(fullText);

  return {
    cleanName,
    prefix: detectedPrefix,
    category,
    suggestedPermission,
    extractedMetadata: extractedMetadata || undefined
  };
}

/**
 * Intelligent multi-line parser for quick batch pasting
 */
export function parseSmartBatchText(rawText: string): Array<{
  name: string;
  permission: string;
  metadata: string;
  category: string;
}> {
  if (!rawText.trim()) return [];

  const lines = rawText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const results: Array<{ name: string; permission: string; metadata: string; category: string }> = [];

  for (const line of lines) {
    // 1. Check if line has tab separation (Excel copy-paste)
    if (line.includes('\t')) {
      const parts = line.split('\t').map(p => p.trim());
      const name = parts[0] || '';
      const permission = parts[1] || suggestDistrictFromContext(name) || '';
      const metadata = parts[2] || '';
      const category = parts[3] || 'شارع';
      if (name) {
        results.push({ name, permission, metadata, category });
        continue;
      }
    }

    // 2. Check if line has comma separation (CSV)
    if (line.includes(',') && !line.includes('،')) {
      const parts = line.split(',').map(p => p.trim());
      const name = parts[0] || '';
      const permission = parts[1] || suggestDistrictFromContext(name) || '';
      const metadata = parts[2] || '';
      const category = parts[3] || 'شارع';
      if (name) {
        results.push({ name, permission, metadata, category });
        continue;
      }
    }

    // 3. Check for dash or colon separation (e.g. "شارع الإسراء - شبرا بحري - بعد المدرسة الفكرية")
    const separator = line.includes(' - ') ? ' - ' : (line.includes(' : ') ? ' : ' : null);
    if (separator) {
      const parts = line.split(separator).map(p => p.trim());
      const name = parts[0] || '';
      const permission = parts[1] || suggestDistrictFromContext(name) || '';
      const metadata = parts.slice(2).join(' - ') || '';
      if (name) {
        results.push({
          name,
          permission,
          metadata,
          category: 'شارع'
        });
        continue;
      }
    }

    // 4. Fallback: single name per line with smart auto-cleaning
    const cleaned = cleanStreetInput(line);
    const fullName = cleaned.prefix && cleaned.prefix !== 'شارع'
      ? `${cleaned.prefix} ${cleaned.cleanName}`
      : cleaned.cleanName;

    results.push({
      name: fullName,
      permission: cleaned.suggestedPermission || '',
      metadata: cleaned.extractedMetadata || '',
      category: cleaned.category
    });
  }

  return results;
}
