/**
 * Web Cryptography API implementation for Encrypted Database Backups.
 * Uses AES-GCM (256-bit) with PBKDF2 (SHA-256, 100,000 iterations) and 16-byte random salt.
 */

import { RecordItem, AppSettings } from '../types';
import { getFormattedDatabaseTimestamps, FormattedDatabaseTime } from './dateTimeUtils';

export interface BackupPayload {
  version: '2.0';
  app: 'damanhour-streets-system';
  createdAt: string;
  timestamps: FormattedDatabaseTime;
  reviewerName?: string;
  recordCount: number;
  records: RecordItem[];
  settings?: Partial<AppSettings>;
  customNotes?: string;
}

export interface EncryptedBackupEnvelope {
  format: 'damanhour-encrypted-backup';
  version: '2.0';
  isEncrypted: true;
  createdAt: string;
  timestamps: FormattedDatabaseTime;
  reviewerName?: string;
  recordCount: number;
  salt: string; // Base64
  iv: string;   // Base64
  ciphertext: string; // Base64
  hint?: string;
}

export interface PlainBackupEnvelope {
  format: 'damanhour-plain-backup';
  version: '2.0';
  isEncrypted: false;
  createdAt: string;
  timestamps: FormattedDatabaseTime;
  reviewerName?: string;
  recordCount: number;
  payload: BackupPayload;
}

export type BackupEnvelope = EncryptedBackupEnvelope | PlainBackupEnvelope;

// Helper to convert ArrayBuffer to Base64
function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

// Helper to convert Base64 to Uint8Array
function base64ToBuffer(base64: string): Uint8Array {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Derives an AES-GCM key from password and salt using PBKDF2.
 */
async function deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Creates an encrypted backup envelope protected by a password.
 */
export async function createEncryptedBackup(
  payload: BackupPayload,
  password?: string,
  hint?: string
): Promise<BackupEnvelope> {
  const timestamps = payload.timestamps || getFormattedDatabaseTimestamps(payload.createdAt);

  if (!password || !password.trim()) {
    // Return plain backup envelope if no password provided
    const plainEnvelope: PlainBackupEnvelope = {
      format: 'damanhour-plain-backup',
      version: '2.0',
      isEncrypted: false,
      createdAt: payload.createdAt,
      timestamps,
      reviewerName: payload.reviewerName,
      recordCount: payload.records.length,
      payload
    };
    return plainEnvelope;
  }

  // Generate 16-byte random salt and 12-byte random IV
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  const key = await deriveKey(password, salt);
  const enc = new TextEncoder();
  const encodedPayload = enc.encode(JSON.stringify(payload));

  const ciphertextBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv
    },
    key,
    encodedPayload
  );

  const encryptedEnvelope: EncryptedBackupEnvelope = {
    format: 'damanhour-encrypted-backup',
    version: '2.0',
    isEncrypted: true,
    createdAt: payload.createdAt,
    timestamps,
    reviewerName: payload.reviewerName,
    recordCount: payload.records.length,
    salt: bufferToBase64(salt.buffer),
    iv: bufferToBase64(iv.buffer),
    ciphertext: bufferToBase64(ciphertextBuffer),
    hint: hint?.trim() || undefined
  };

  return encryptedEnvelope;
}

/**
 * Decrypts a backup envelope using password.
 */
export async function decryptBackup(
  envelope: BackupEnvelope | any,
  password?: string
): Promise<BackupPayload> {
  // If it's a legacy JSON file with direct records or snapshot
  if (Array.isArray(envelope)) {
    return {
      version: '2.0',
      app: 'damanhour-streets-system',
      createdAt: new Date().toISOString(),
      timestamps: getFormattedDatabaseTimestamps(),
      recordCount: envelope.length,
      records: envelope
    };
  }

  if (envelope.records && Array.isArray(envelope.records)) {
    return {
      version: '2.0',
      app: 'damanhour-streets-system',
      createdAt: envelope.timestamp || envelope.createdAt || new Date().toISOString(),
      timestamps: getFormattedDatabaseTimestamps(envelope.timestamp || envelope.createdAt),
      recordCount: envelope.records.length,
      records: envelope.records,
      settings: envelope.settings,
      reviewerName: envelope.reviewerName
    };
  }

  // If envelope is unencrypted plain backup
  if (envelope.format === 'damanhour-plain-backup' || envelope.isEncrypted === false) {
    return envelope.payload;
  }

  // If envelope is encrypted
  if (envelope.format === 'damanhour-encrypted-backup' || envelope.isEncrypted === true) {
    if (!password) {
      throw new Error('الملف مشفر ويتطلب كلمة مرور لفك التشفير والاستعادة');
    }

    try {
      const salt = base64ToBuffer(envelope.salt);
      const iv = base64ToBuffer(envelope.iv);
      const ciphertext = base64ToBuffer(envelope.ciphertext);

      const key = await deriveKey(password, salt);

      const decryptedBuffer = await window.crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv
        },
        key,
        ciphertext
      );

      const dec = new TextDecoder();
      const jsonStr = dec.decode(decryptedBuffer);
      const payload: BackupPayload = JSON.parse(jsonStr);
      return payload;
    } catch {
      throw new Error('كلمة المرور غير صحيحة أو تم التلاعب بملف النسخة الاحتياطية');
    }
  }

  throw new Error('صيغة ملف النسخة الاحتياطية غير مدعومة');
}
