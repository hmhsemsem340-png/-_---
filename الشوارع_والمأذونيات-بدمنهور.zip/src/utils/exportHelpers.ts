import { RecordItem, ThemeType } from '../types';
import { getThemeColors } from './themeConfig';
import { getDistrictColor } from './districtColors';
import { getFormattedDatabaseTimestamps } from './dateTimeUtils';
import { parseStreetPrefixAndName, isOfficialNotarization } from './streetSplitter';

export interface ReportOptions {
  records: RecordItem[];
  title: string;
  subtitle: string;
  footer: string;
  orientation: 'portrait' | 'landscape';
  margin: string;
  theme: ThemeType;
  zebra: boolean;
  printFontSize: string;
  fontFamily?: string;
  reviewerName?: string;
  includeTimestamps?: boolean;
  columns?: Record<string, { visible?: boolean; align?: 'right' | 'center' | 'left'; fontWeight?: 'normal' | 'semibold' | 'bold' | 'black' }>;
}

export function generateReportHtml(options: ReportOptions): string {
  const {
    records,
    title,
    subtitle,
    footer,
    orientation,
    margin,
    theme,
    zebra,
    printFontSize,
    fontFamily = "'Amiri', 'Cairo', Tahoma, Arial, serif",
    reviewerName,
    includeTimestamps = true,
    columns
  } = options;

  const colors = getThemeColors(theme);
  const zebraBg = zebra ? colors.hexZebra : '#FFFFFF';
  const zebraAlt = zebra ? colors.hexZebraAlt : '#FFFFFF';
  const timestamps = getFormattedDatabaseTimestamps();

  const getAlign = (key: string, defaultAlign: 'right' | 'center' | 'left' = 'right') => {
    return columns?.[key]?.align || defaultAlign;
  };

  const getWeight = (key: string, defaultWeight: string = 'normal') => {
    const w = columns?.[key]?.fontWeight || defaultWeight;
    if (w === 'black') return '900';
    if (w === 'bold') return 'bold';
    if (w === 'semibold') return '600';
    return 'normal';
  };

  const rows = records.map((r, index) => {
    const district = getDistrictColor(r.permission, r.metadata, r.name);
    const rowBg = index % 2 === 1 ? zebraBg : zebraAlt;
    const permColor = district ? district.hex : '#374151';
    const parsed = parseStreetPrefixAndName(r.name, r.category);
    const isOfficial = isOfficialNotarization(r.permission);

    return `<tr style="background:${rowBg}">
      <td style="border:1px solid #d1d5db;padding:6px 8px;text-align:${getAlign('index', 'center')};font-weight:${getWeight('index', 'normal')};color:#6b7280;font-size:${printFontSize}">${index + 1}</td>
      <td style="border:1px solid #d1d5db;padding:6px 8px;text-align:${getAlign('name', 'right')};font-weight:${getWeight('name', 'bold')};color:#111827;font-size:${printFontSize}">${escapeHtml(parsed.cleanName)}</td>
      <td style="border:1px solid #d1d5db;padding:6px 8px;text-align:${getAlign('permission', 'right')};color:${permColor};font-weight:${getWeight('permission', 'bold')};font-size:${printFontSize}">
        <span>${escapeHtml(r.permission || 'غير محدد')}</span>
        ${isOfficial 
          ? '<span style="font-size:9px;background:#d1fae5;color:#065f46;border:1px solid #a7f3d0;padding:2px 6px;border-radius:10px;margin-right:6px;display:inline-block;font-weight:bold;">رسمية</span>' 
          : '<span style="font-size:9px;background:#fef3c7;color:#92400e;border:1px solid #fde68a;padding:2px 6px;border-radius:10px;margin-right:6px;display:inline-block;font-weight:bold;">غير رسمية</span>'
        }
      </td>
      <td style="border:1px solid #d1d5db;padding:6px 8px;text-align:${getAlign('category', 'center')};font-weight:${getWeight('category', 'normal')};color:#374151;font-size:${printFontSize}">
        <span style="background:#f3f4f6;padding:2px 8px;border-radius:6px;font-size:10.5pt;font-weight:bold;">${escapeHtml(parsed.detectedType)}</span>
      </td>
      <td style="border:1px solid #d1d5db;padding:6px 8px;text-align:${getAlign('metadata', 'right')};font-weight:${getWeight('metadata', 'normal')};color:#4b5563;font-size:${printFontSize}">${escapeHtml(r.metadata || '-')}</td>
    </tr>`;
  }).join('\n');

  const metaHeaderBlock = includeTimestamps ? `
    <div style="display:flex; justify-content:space-between; align-items:center; background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; padding:8px 14px; margin-bottom:12px; font-size:11px; color:#374151;">
      <div>
        <strong>التاريخ الميلادي:</strong> ${timestamps.gregorianDate} &nbsp;|&nbsp;
        <strong>التاريخ الهجري:</strong> ${timestamps.hijriDate} &nbsp;|&nbsp;
        <strong>الساعة:</strong> ${timestamps.gregorianTime}
      </div>
      <div>
        <strong>المراجع المعتمد:</strong> <span style="color:${colors.hexHeader}; font-weight:bold;">${escapeHtml(reviewerName || 'مراجع السجلات المعتمد')}</span>
      </div>
    </div>
  ` : '';

  const signatureFooterBlock = reviewerName ? `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:16px; padding:10px 14px; font-size:11px; color:#4b5563;">
      <div>منظومة الشوارع والمأذونيات بدمنهور • كشف رسمي معتمد</div>
      <div style="text-align:left; border-top:1px dashed #9ca3af; padding-top:4px; min-width:180px;">
        <strong>توقيع واعتِماد المراجع:</strong> ${escapeHtml(reviewerName)}
      </div>
    </div>
  ` : '';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(title)}</title>
<style>
  @page { size: A4 ${orientation}; margin: ${margin}; }
  * { box-sizing: border-box; }
  body {
    font-family: ${fontFamily};
    direction: rtl;
    margin: 0;
    padding: 0;
    color: #1f2937;
  }
  .report-header {
    text-align: center;
    border-bottom: 3px solid ${colors.hexAccent};
    padding-bottom: 10px;
    margin-bottom: 12px;
  }
  .report-header h1 { font-size: 20px; margin: 0 0 4px; color: ${colors.hexHeader}; }
  .report-header p { margin: 0; color: #6b7280; font-size: 12px; }
  table { width: 100%; border-collapse: collapse; }
  th {
    background: ${colors.hexHeader};
    color: #ffffff;
    border: 1px solid ${colors.hexHeader};
    padding: 7px 8px;
    font-size: ${printFontSize};
    text-align: right;
  }
  td { font-size: ${printFontSize}; }
  .report-footer {
    margin-top: 14px;
    padding-top: 8px;
    border-top: 1px solid #d1d5db;
    text-align: center;
    color: #6b7280;
    font-size: 11px;
  }
  .watermark {
    position: fixed;
    top: 45%;
    left: 0;
    right: 0;
    text-align: center;
    font-size: 60px;
    color: rgba(0, 0, 0, 0.04);
    transform: rotate(-30deg);
    pointer-events: none;
    z-index: 0;
  }
</style>
</head>
<body>
  <div class="watermark">${escapeHtml(title)}</div>
  <div class="report-header">
    <h1>${escapeHtml(title)}</h1>
    <p>${escapeHtml(subtitle)}</p>
  </div>
  ${metaHeaderBlock}
  <table>
    <thead>
      <tr>
        <th style="width:40px;text-align:${getAlign('index', 'center')}">م</th>
        <th style="text-align:${getAlign('name', 'right')}">اسم الشارع</th>
        <th style="width:145px;text-align:${getAlign('permission', 'right')}">المأذونية / جهة الاختصاص</th>
        <th style="width:90px;text-align:${getAlign('category', 'center')}">النوع</th>
        <th style="text-align:${getAlign('metadata', 'right')}">البيانات الوصفية والملاحظات</th>
      </tr>
    </thead>
    <tbody>
${rows}
    </tbody>
  </table>
  ${signatureFooterBlock}
  <div class="report-footer">${escapeHtml(footer)}</div>
</body>
</html>`;
}

export function exportToProtectedPdf(options: ReportOptions): void {
  const html = generateReportHtml(options);
  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) {
    alert('يرجى السماح بالنوافذ المنبثقة لتصدير التقرير PDF.');
    return;
  }
  win.document.open();
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => {
    win.print();
  }, 400);
}

function escapeHtml(str: string): string {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}