import { OFFICIAL_DISTRICTS } from './districtColors';

export interface ParsedStreet {
  cleanName: string;
  detectedType: string;
  hasPrefix: boolean;
  prefix?: string;
}

// قائمة البادئات الشائعة للشوارع والحارات والأزقة
export const DEFAULT_STREET_PREFIXES: string[] = [
  'شارع',
  'حارة',
  'زقاق',
  'عطفة',
  'درب',
  'ميدان',
  'طريق',
  'سكة',
  'مدق',
  'كفر',
  'عزبة',
  'مساكن',
  'بلوك',
  'حوش',
  'حي',
  'محور',
  'تقسيم',
  'منطقة'
];

const CUSTOM_PREFIXES_STORAGE_KEY = 'custom_street_prefixes';

/**
 * استرجاع قائمة البادئات المخصصة المضافة من قبل المستخدم من التخزين المحلي
 */
export function getCustomPrefixes(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CUSTOM_PREFIXES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/**
 * استرجاع جميع البادئات المتاحة (الافتراضية + المخصصة)
 */
export function getAllAvailablePrefixes(): string[] {
  const custom = getCustomPrefixes();
  const set = new Set([...DEFAULT_STREET_PREFIXES, ...custom]);
  return Array.from(set);
}

/**
 * إضافة بادئة مخصصة جديدة وحفظها
 */
export function addCustomPrefix(prefix: string): string[] {
  const clean = prefix.trim();
  if (!clean) return getAllAvailablePrefixes();
  const current = getCustomPrefixes();
  if (!current.includes(clean) && !DEFAULT_STREET_PREFIXES.includes(clean)) {
    const updated = [...current, clean];
    try {
      localStorage.setItem(CUSTOM_PREFIXES_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save custom prefix:', e);
    }
  }
  return getAllAvailablePrefixes();
}

/**
 * حذف بادئة مخصصة
 */
export function removeCustomPrefix(prefix: string): string[] {
  const clean = prefix.trim();
  const current = getCustomPrefixes();
  const updated = current.filter(p => p !== clean);
  try {
    localStorage.setItem(CUSTOM_PREFIXES_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to remove custom prefix:', e);
  }
  return getAllAvailablePrefixes();
}

/**
 * إعادة ضبط البادئات إلى الوضع القياسي
 */
export function resetCustomPrefixes(): string[] {
  try {
    localStorage.removeItem(CUSTOM_PREFIXES_STORAGE_KEY);
  } catch (e) {
    console.error('Failed to reset prefixes:', e);
  }
  return [...DEFAULT_STREET_PREFIXES];
}

// بناء التعبير النمطي للتعرف على البادئات في بداية الاسم
function buildPrefixRegex(): RegExp {
  const all = getAllAvailablePrefixes();
  return new RegExp(`^(${all.join('|')})\\s+(.+)$`, 'i');
}

/**
 * دالة برمجية ذكية لفصل اسم الشارع عن نوعه وتطهيره من البادئات
 * @param rawName الاسم الخام المخزن (مثل: "شارع الجمهورية" أو "حارة الصاغة")
 * @param fallbackType النوع الاحتياطي في حال عدم وجود بادئة
 */
export function parseStreetPrefixAndName(rawName?: string, fallbackType?: string): ParsedStreet {
  if (!rawName || typeof rawName !== 'string') {
    return {
      cleanName: '',
      detectedType: fallbackType && fallbackType.trim() ? fallbackType.trim() : 'شارع',
      hasPrefix: false
    };
  }

  const trimmed = rawName.trim();

  // فحص الاختصارات الشائعة مثل ش/ أو ش. أو ح/ أو ز/
  const abbrevMatch = trimmed.match(/^(ش|ح|ز)[\/.\s\-]+(.+)$/);
  if (abbrevMatch) {
    const letter = abbrevMatch[1];
    const rest = abbrevMatch[2].trim();
    const type = letter === 'ح' ? 'حارة' : letter === 'ز' ? 'زقاق' : 'شارع';
    return {
      cleanName: rest,
      detectedType: type,
      hasPrefix: true,
      prefix: letter
    };
  }

  // فحص الكلمات الصريحة مثل "شارع النصر"
  const match = trimmed.match(buildPrefixRegex());
  if (match) {
    return {
      cleanName: match[2].trim(),
      detectedType: match[1].trim(),
      hasPrefix: true,
      prefix: match[1].trim()
    };
  }

  // في حال لم تبدأ ببادئة صريحة، نستخدم الاسم كاملاً والنوع الحالي أو الافتراضي
  return {
    cleanName: trimmed,
    detectedType: fallbackType && fallbackType.trim() ? fallbackType.trim() : 'شارع',
    hasPrefix: false
  };
}

/**
 * قائمة المأذونيات السبع الأساسية الرسمية المعتمدة
 */
export const OFFICIAL_7_NOTARIZATIONS = [
  'شبرا بحري',
  'سكنيدة',
  'طاموس',
  'شبرا قبلي',
  'قرطسا بحري',
  'نقرها',
  'قرطسا قبلي'
];

/**
 * فحص ما إذا كانت المأذونية تنتمي إلى قائمة المأذونيات السبع الرسمية
 */
export function isOfficialNotarization(permission?: string | null): boolean {
  if (!permission || typeof permission !== 'string') return false;
  const p = permission.trim();
  
  // مطابقة مباشرة مع أسماء المأذونيات السبعة أو الـ OFFICIAL_DISTRICTS
  return OFFICIAL_7_NOTARIZATIONS.some(official => 
    p === official || 
    p.includes(official) || 
    official.includes(p)
  ) || OFFICIAL_DISTRICTS.some(d => 
    p === d.name || 
    p.includes(d.name)
  );
}

/**
 * استخراج حالة السجل التوثيقية:
 * مكتمل: مأذونية رسمية معتمدة من السبع الأساسية
 * غير مكتمل: مأذونية غير رسمية أو خارج النطاق الرسمي
 */
export function getRecordDocumentationStatus(permission?: string | null): 'completed' | 'incomplete' {
  return isOfficialNotarization(permission) ? 'completed' : 'incomplete';
}
