import { SYSTEM_FEATURES_MARKDOWN } from '../data/systemFeaturesMarkdown';

export function downloadSystemFeaturesMarkdown() {
  const blob = new Blob([SYSTEM_FEATURES_MARKDOWN], { type: 'text/markdown;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'دليل_مميزات_منظومة_دمنهور_الرقمية.md';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
