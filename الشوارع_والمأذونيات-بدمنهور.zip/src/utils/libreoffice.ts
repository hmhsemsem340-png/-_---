/**
 * Client-side helpers for the LibreOffice bridge server (server.js).
 * All calls degrade gracefully when the bridge server is not running.
 */

export interface LibreOfficeStatus {
  installed: boolean;
  version?: string;
  path?: string;
  error?: string;
}

export async function getLibreOfficeStatus(): Promise<LibreOfficeStatus | null> {
  try {
    const res = await fetch('/api/libreoffice/status');
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function convertWithLibreOffice(
  file: File,
  target: string
): Promise<Blob | null> {
  try {
    const data = await fileToBase64(file);
    const res = await fetch('/api/libreoffice/convert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: file.name, data, target })
    });
    if (!res.ok) return null;
    return await res.blob();
  } catch {
    return null;
  }
}

export async function openInLibreOffice(file: File): Promise<boolean> {
  try {
    const data = await fileToBase64(file);
    const res = await fetch('/api/libreoffice/open', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: file.name, data })
    });
    return res.ok;
  } catch {
    return false;
  }
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1] || '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}