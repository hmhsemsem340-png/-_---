import { ThemeType, AccentColorType, DynamicThemeSettings, AppSettings } from '../types';

export interface ThemeColors {
  name: string;
  headerBg: string;
  headerText: string;
  accentBg: string;
  accentText: string;
  zebraBg: string;
  zebraText: string;
  border: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  hexHeader: string;
  hexAccent: string;
  hexZebra: string;
  hexZebraAlt: string;
  hexText: string;
}

export const ACCENT_PALETTES: Record<AccentColorType, ThemeColors> = {
  emerald: {
    name: 'أخضر زمردي كلاسيكي (Excel)',
    headerBg: 'bg-emerald-800',
    headerText: 'text-white',
    accentBg: 'bg-emerald-600',
    accentText: 'text-emerald-900',
    zebraBg: 'bg-emerald-50/70',
    zebraText: 'text-gray-900',
    border: 'border-emerald-200',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-emerald-800',
    badgeBorder: 'border-emerald-300',
    hexHeader: '#065F46',
    hexAccent: '#059669',
    hexZebra: '#F0FDF4',
    hexZebraAlt: '#FFFFFF',
    hexText: '#111827'
  },
  cyan: {
    name: 'سماوي هادئ (LibreOffice Calc)',
    headerBg: 'bg-cyan-900',
    headerText: 'text-white',
    accentBg: 'bg-cyan-600',
    accentText: 'text-cyan-950',
    zebraBg: 'bg-cyan-50/70',
    zebraText: 'text-gray-900',
    border: 'border-cyan-200',
    badgeBg: 'bg-cyan-100',
    badgeText: 'text-cyan-900',
    badgeBorder: 'border-cyan-300',
    hexHeader: '#164E63',
    hexAccent: '#0891B2',
    hexZebra: '#ECFEFF',
    hexZebraAlt: '#FFFFFF',
    hexText: '#111827'
  },
  indigo: {
    name: 'كحلي عصري (Modern Indigo)',
    headerBg: 'bg-indigo-900',
    headerText: 'text-white',
    accentBg: 'bg-indigo-600',
    accentText: 'text-indigo-950',
    zebraBg: 'bg-indigo-50/70',
    zebraText: 'text-gray-900',
    border: 'border-indigo-200',
    badgeBg: 'bg-indigo-100',
    badgeText: 'text-indigo-900',
    badgeBorder: 'border-indigo-300',
    hexHeader: '#312E81',
    hexAccent: '#4F46E5',
    hexZebra: '#EEF2FF',
    hexZebraAlt: '#FFFFFF',
    hexText: '#111827'
  },
  slate: {
    name: 'رمادي فولاذي نقي (Clean Slate)',
    headerBg: 'bg-slate-900',
    headerText: 'text-white',
    accentBg: 'bg-slate-700',
    accentText: 'text-slate-950',
    zebraBg: 'bg-slate-50',
    zebraText: 'text-gray-900',
    border: 'border-slate-200',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-800',
    badgeBorder: 'border-slate-300',
    hexHeader: '#0F172A',
    hexAccent: '#334155',
    hexZebra: '#F8FAFC',
    hexZebraAlt: '#FFFFFF',
    hexText: '#0F172A'
  },
  amber: {
    name: 'ذهبي كلاسيكي (Executive Amber)',
    headerBg: 'bg-amber-900',
    headerText: 'text-white',
    accentBg: 'bg-amber-600',
    accentText: 'text-amber-950',
    zebraBg: 'bg-amber-50/70',
    zebraText: 'text-gray-900',
    border: 'border-amber-200',
    badgeBg: 'bg-amber-100',
    badgeText: 'text-amber-900',
    badgeBorder: 'border-amber-300',
    hexHeader: '#78350F',
    hexAccent: '#D97706',
    hexZebra: '#FFFBEB',
    hexZebraAlt: '#FFFFFF',
    hexText: '#111827'
  },
  purple: {
    name: 'بنفسجي ملكي (Royal Purple)',
    headerBg: 'bg-purple-900',
    headerText: 'text-white',
    accentBg: 'bg-purple-600',
    accentText: 'text-purple-950',
    zebraBg: 'bg-purple-50/70',
    zebraText: 'text-gray-900',
    border: 'border-purple-200',
    badgeBg: 'bg-purple-100',
    badgeText: 'text-purple-900',
    badgeBorder: 'border-purple-300',
    hexHeader: '#581C87',
    hexAccent: '#9333EA',
    hexZebra: '#FAF5FF',
    hexZebraAlt: '#FFFFFF',
    hexText: '#111827'
  }
};

export const DEFAULT_DYNAMIC_THEME: DynamicThemeSettings = {
  accentColor: 'emerald',
  headerStyle: 'solid',
  rowStripingIntensity: 'subtle',
  hoverEffect: true,
  tableBorderRadius: 'lg',
  columns: {
    index: { visible: true, label: 'م', align: 'center', fontWeight: 'normal' },
    name: { visible: true, label: 'اسم الشارع / الحارة', align: 'right', fontWeight: 'bold' },
    permission: { visible: true, label: 'المأذونية / جهة الاختصاص', align: 'right', fontWeight: 'bold' },
    category: { visible: true, label: 'النوع', align: 'center', fontWeight: 'normal' },
    metadata: { visible: true, label: 'البيان الوصفي والملاحظات', align: 'right', fontWeight: 'normal' },
    actions: { visible: true, label: 'الإجراءات', align: 'center', fontWeight: 'normal' }
  }
};

export const THEME_CONFIGS: Record<ThemeType, ThemeColors> = {
  excel: ACCENT_PALETTES.emerald,
  libreoffice: ACCENT_PALETTES.cyan,
  modern: ACCENT_PALETTES.indigo,
  custom: ACCENT_PALETTES.emerald,
  hybrid: {
    name: 'هجين موسّع (أخضر + سماوي + كحلي)',
    headerBg: 'bg-gradient-to-l from-emerald-800 via-cyan-900 to-indigo-950',
    headerText: 'text-white',
    accentBg: 'bg-gradient-to-l from-emerald-600 via-cyan-600 to-indigo-600',
    accentText: 'text-emerald-950',
    zebraBg: 'bg-gradient-to-l from-emerald-50/50 via-cyan-50/40 to-indigo-50/40',
    zebraText: 'text-gray-900',
    border: 'border-emerald-200',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-gray-900',
    badgeBorder: 'border-emerald-300',
    hexHeader: '#065F46',
    hexAccent: '#0E7490',
    hexZebra: '#F0FDF4',
    hexZebraAlt: '#F8FAFC',
    hexText: '#111827'
  }
};

export function getThemeColors(theme: ThemeType, dynamicTheme?: DynamicThemeSettings): ThemeColors {
  if (dynamicTheme && dynamicTheme.accentColor && ACCENT_PALETTES[dynamicTheme.accentColor]) {
    return ACCENT_PALETTES[dynamicTheme.accentColor];
  }
  return THEME_CONFIGS[theme] || THEME_CONFIGS.excel;
}
