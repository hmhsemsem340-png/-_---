/**
 * Date and Time utilities supporting both Gregorian and Hijri calendars in Arabic.
 */

export interface FormattedDatabaseTime {
  iso: string;
  gregorianDate: string;
  gregorianTime: string;
  gregorianFull: string;
  hijriDate: string;
  hijriTime: string;
  hijriFull: string;
  combinedBadge: string;
  timestampHeader: string;
}

const ARABIC_GREGORIAN_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

/**
 * Formats a Date or timestamp into comprehensive Arabic Gregorian and Hijri strings.
 */
export function getFormattedDatabaseTimestamps(inputDate?: Date | string | number): FormattedDatabaseTime {
  const d = inputDate ? new Date(inputDate) : new Date();
  const validDate = isNaN(d.getTime()) ? new Date() : d;

  // Gregorian formatting
  const day = validDate.getDate();
  const monthName = ARABIC_GREGORIAN_MONTHS[validDate.getMonth()];
  const year = validDate.getFullYear();
  
  let hours = validDate.getHours();
  const minutes = validDate.getMinutes().toString().padStart(2, '0');
  const seconds = validDate.getSeconds().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'م' : 'ص';
  hours = hours % 12 || 12;
  const gregorianTime = `${hours}:${minutes}:${seconds} ${ampm}`;
  const gregorianDate = `${day} ${monthName} ${year}م`;
  const gregorianFull = `${gregorianDate} - ${gregorianTime}`;

  // Hijri formatting using Intl API with fallback
  let hijriDate = '';
  try {
    const hijriFormatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    hijriDate = hijriFormatter.format(validDate);
    // Ensure 'هـ' suffix if not present
    if (!hijriDate.includes('هـ')) {
      hijriDate = `${hijriDate} هـ`;
    }
  } catch {
    // Fallback Islamic calendar calculation
    try {
      const fallbackFormatter = new Intl.DateTimeFormat('ar-TN-u-ca-islamic', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
      hijriDate = `${fallbackFormatter.format(validDate)} هـ`;
    } catch {
      hijriDate = 'التاريخ الهجري غير متاح';
    }
  }

  const hijriTime = gregorianTime;
  const hijriFull = `${hijriDate} - ${hijriTime}`;

  const combinedBadge = `${gregorianDate} | ${hijriDate} (${gregorianTime})`;
  const timestampHeader = `بتاريخ: ${gregorianDate} الموافق ${hijriDate} • الساعة: ${gregorianTime}`;

  return {
    iso: validDate.toISOString(),
    gregorianDate,
    gregorianTime,
    gregorianFull,
    hijriDate,
    hijriTime,
    hijriFull,
    combinedBadge,
    timestampHeader
  };
}

/**
 * Returns current timestamp formatted specifically for backup and export file names
 */
export function getExportFileTimestamp(): string {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}
