// ============================================================
// 🔤 أدوات معالجة وتطبيع النصوص العربية والأرقام
// ============================================================

export class ArabicUtils {
  /**
   * تطبيع النص للبحث والمقارنة الفائقة
   */
  static normalizeArabic(text: string): string {
    return this.normalizeForSearch(text);
  }

  /**
   * تطبيع النص للبحث والمقارنة الفائقة
   * يتجاهل التشكيل، يوحد الهمزات والألف اللينة والتاء المربوطة
   */
  static normalizeForSearch(text: string): string {
    if (!text) return '';
    
    return text
      .toLowerCase()
      // إزالة التشكيل
      .replace(/[\u064B-\u065F\u0670]/g, '')
      // إزالة التطويل (الكشيدة)
      .replace(/\u0640/g, '')
      // توحيد الهمزات
      .replace(/[أإآ]/g, 'ا')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      // توحيد الألف اللينة
      .replace(/ى/g, 'ي')
      // توحيد التاء المربوطة والهاء
      .replace(/ة/g, 'ه')
      // إزالة أل التعريف في بداية الكلمات للبحث
      .replace(/(^|\s)ال/g, '$1')
      // إزالة علامات الترقيم والأقواس
      .replace(/[،,.;:\-_\(\)\[\]"'/\\#@!]/g, ' ')
      // تقليص المسافات المتعددة
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * تطبيع خفيف يحافظ على بنية الكلمات مع توحيد الهمزات والتطويل
   */
  static normalizeFull(text: string): string {
    if (!text) return '';
    return text
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/\u0640/g, '')
      .replace(/[أإآ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * استخراج الإحداثيات الجغرافية (خط الطول ودائرة العرض)
   * يدعم صيغ مختلفة: 31.0345°N, 30.4682°E أو 31.0345, 30.4682
   */
  static extractCoordinates(text: string): { lat: number; lng: number } | null {
    if (!text) return null;

    // نمط درجات مع اتجاه N/E
    const degreeMatch = text.match(/([0-9]+\.?[0-9]*)\s*°?\s*[Nn]\s*[,،\s]+\s*([0-9]+\.?[0-9]*)\s*°?\s*[Ee]/);
    if (degreeMatch) {
      return {
        lat: parseFloat(degreeMatch[1]),
        lng: parseFloat(degreeMatch[2])
      };
    }

    // نمط عشري عادي
    const decimalMatch = text.match(/([0-9]{2}\.[0-9]+)\s*[,،\s]+\s*([0-9]{2}\.[0-9]+)/);
    if (decimalMatch) {
      const lat = parseFloat(decimalMatch[1]);
      const lng = parseFloat(decimalMatch[2]);
      // التحقق من أن الإحداثيات تقع في النطاق الجغرافي المعقول لدمنهور/مصر
      if (lat >= 22 && lat <= 32 && lng >= 24 && lng <= 37) {
        return { lat, lng };
      }
    }

    return null;
  }

  /**
   * استخراج المحافظة وتاريخ الميلاد من الرقم القومي المصري (14 رقماً)
   */
  static parseNationalId(id: string): { governorate?: string; birthDate?: string; isValid: boolean } {
    const cleaned = (id || '').replace(/\D/g, '');
    if (cleaned.length !== 14) return { isValid: false };

    const centuryCode = cleaned[0];
    const yearPart = cleaned.slice(1, 3);
    const monthPart = cleaned.slice(3, 5);
    const dayPart = cleaned.slice(5, 7);
    const govCode = cleaned.slice(7, 9);

    const century = centuryCode === '2' ? '19' : centuryCode === '3' ? '20' : '';
    const birthDate = century ? `${dayPart}/${monthPart}/${century}${yearPart}` : undefined;

    const governorates: Record<string, string> = {
      '01': 'القاهرة', '02': 'الإسكندرية', '03': 'بورسعيد', '04': 'السويس',
      '11': 'دمياط', '12': 'الدقهلية', '13': 'الشرقية', '14': 'القليوبية',
      '15': 'كفر الشيخ', '16': 'الغربية', '17': 'المنوفية', '18': 'البحيرة',
      '19': 'الإسماعيلية', '21': 'الجيزة', '22': 'بني سويف', '23': 'الفيوم',
      '24': 'المنيا', '25': 'أسيوط', '26': 'سوهاج', '27': 'قنا',
      '28': 'أسوان', '29': 'الأقصر', '31': 'البحر الأحمر', '32': 'الوادي الجديد',
      '33': 'مطروح', '34': 'شمال سيناء', '35': 'جنوب سيناء', '88': 'خارج الجمهورية'
    };

    return {
      isValid: true,
      governorate: governorates[govCode] || 'غير محدد',
      birthDate
    };
  }

  /**
   * تنسيق التاريخ العربي بدقة
   */
  static formatDateArabic(dateInput: string | Date | undefined): string {
    if (!dateInput) return '-';
    try {
      const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return String(dateInput);
      return d.toLocaleDateString('ar-EG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return String(dateInput);
    }
  }

  /**
   * تطبيع البيانات الوصفية والملاحظات للمقارنة المتساوية
   * يزيل الوسوم الهيكلية وعلامات الترقيم ويوحد النص العربي
   */
  static normalizeMetadata(meta?: string): string {
    if (!meta) return '';
    let cleaned = meta
      .replace(/\[نوع غير رسمي:\s*[^\]]+\]/gi, '')
      .replace(/\[مأذونية مقترحة:\s*[^\]]+\]/gi, '')
      .replace(/\[دمج وتحديث\]:\s*/gi, '')
      .replace(/\[دمج مأذونية\]:\s*/gi, '')
      .replace(/\[إضافة\]:\s*/gi, '')
      .replace(/\[إضافة جديدة\]:\s*/gi, '')
      .replace(/\[تحديث\]:\s*/gi, '')
      .replace(/\[مشترك بين مأذونيتي:[^\]]+\]/gi, '')
      .replace(/\[مرتبط بعنوان الحقيقة المعتمد:[^\]]+\]/gi, '')
      .replace(/\[معتمد نهائي[^\]]*\]/gi, '')
      .replace(/التعريف:[^|\n-]+/gi, '')
      .replace(/رقم العقد:[^|\n-]+/gi, '')
      .replace(/التاريخ:[^|\n-]+/gi, '')
      .replace(/الرقم القومي(\s*المرجع)?:[^|\n-]+/gi, '')
      .replace(/نوع الخرائط:[^|\n-]+/gi, '')
      .replace(/اسم المأذون:[^|\n-]+/gi, '')
      .replace(/رقم الدفتر:[^|\n-]+/gi, '')
      .replace(/رقم الإشهاد:[^|\n-]+/gi, '');

    cleaned = cleaned.replace(/[-|_/\\,،.:;()\[\]{}«»"']/g, ' ');
    return this.normalizeForSearch(cleaned).replace(/\s+/g, ' ').trim();
  }

  /**
   * فحص تساوي وتطابق البيانات الوصفية وفق معايير المحتوى الدلالي
   */
  static areMetadataEqual(meta1?: string, meta2?: string): boolean {
    const norm1 = this.normalizeMetadata(meta1);
    const norm2 = this.normalizeMetadata(meta2);
    if (!norm1 && !norm2) return true;
    if (!norm1 || !norm2) return false;
    if (norm1 === norm2) return true;
    // مطابقة التضمين للبيانات المتماثلة في المعنى
    if (norm1.includes(norm2) || norm2.includes(norm1)) {
      const minLen = Math.min(norm1.length, norm2.length);
      const maxLen = Math.max(norm1.length, norm2.length);
      if (minLen > 0 && minLen / maxLen >= 0.8) return true;
    }
    return false;
  }

  /**
   * تنظيف وتطهير النص من البوادئ والوسوم الاصطناعية المكررة
   */
  static cleanNoteArtifacts(text: string): string {
    if (!text) return '';
    let cleaned = text.trim();
    cleaned = cleaned
      .replace(/^\[دمج وتحديث\]:\s*/gi, '')
      .replace(/^\[دمج مأذونية\]:\s*/gi, '')
      .replace(/^\[إضافة\]:\s*/gi, '')
      .replace(/^\[إضافة جديدة\]:\s*/gi, '')
      .replace(/^\[تحديث\]:\s*/gi, '')
      .replace(/^\[بيان إضافي\]:\s*/gi, '')
      .replace(/^[-•*]\s*/, '')
      .trim();
    return cleaned;
  }

  /**
   * دمج الملاحظات والبيانات الوصفية بذكاء فائق وتفادي تكرار العبارات
   * يقوم بتنظيف وتجريد الوسوم الاصطناعية، وفصل الجمل والأسطر، 
   * وتطبيق المطابقة الدلالية العربية لمنع تكرار أي عبارة أو جزء منها.
   */
  static smartMergeNotes(note1?: string, note2?: string, crossReferenceTag?: string): string {
    const raw1 = (note1 || '').trim();
    const raw2 = (note2 || '').trim();

    if (!raw1 && !raw2) return '';
    if (!raw1) return this.cleanNoteArtifacts(raw2);
    if (!raw2) return this.cleanNoteArtifacts(raw1);

    // إذا كان النصان متطابقين دلالياً، نكتفي بالأحدث / الأنظف
    if (this.areMetadataEqual(raw1, raw2)) {
      return this.cleanNoteArtifacts(raw2 || raw1);
    }

    // تفكيك النصين إلى أسطر وعبارات منفصلة
    const splitClauses = (text: string): string[] => {
      return text
        .split(/[\n\r]+/)
        .map(line => line.trim())
        .filter(Boolean);
    };

    const clauses1 = splitClauses(raw1);
    const clauses2 = splitClauses(raw2);
    const allClauses = [...clauses1, ...clauses2];

    const resultClauses: string[] = [];

    for (const rawClause of allClauses) {
      const cleanClause = this.cleanNoteArtifacts(rawClause);
      if (!cleanClause) continue;

      const norm = this.normalizeMetadata(cleanClause);
      if (!norm) {
        // إذا كان سطراً هيكلياً مثل وسم خاص
        if (!resultClauses.includes(cleanClause)) {
          resultClauses.push(cleanClause);
        }
        continue;
      }

      // فحص إذا كان السطر مكرراً أو موجوداً بالفعل أو متضمناً في أحد الأسطر السابقة
      let isDuplicateOrSubsumed = false;
      for (let i = 0; i < resultClauses.length; i++) {
        const existingNorm = this.normalizeMetadata(resultClauses[i]);
        if (existingNorm === norm) {
          isDuplicateOrSubsumed = true;
          // إذا كان السطر الجديد يحتوي على تفاصيل أكثر أو نص أحدث، نحدثه
          if (cleanClause.length > resultClauses[i].length) {
            resultClauses[i] = cleanClause;
          }
          break;
        }
        // إذا كان السطر الجديد متضمناً بالكامل داخل سطر سابق
        if (existingNorm.includes(norm) && norm.length >= 4) {
          isDuplicateOrSubsumed = true;
          break;
        }
        // إذا كان السطر السابق متضمناً بالكامل داخل السطر الجديد، نقوم بتحديث السطر السابق بالأكمل
        if (norm.includes(existingNorm) && existingNorm.length >= 4) {
          resultClauses[i] = cleanClause;
          isDuplicateOrSubsumed = true;
          break;
        }
      }

      if (!isDuplicateOrSubsumed) {
        resultClauses.push(cleanClause);
      }
    }

    if (crossReferenceTag && crossReferenceTag.trim()) {
      const cleanTag = crossReferenceTag.trim();
      const normTag = this.normalizeMetadata(cleanTag);
      const hasTag = resultClauses.some(c => this.normalizeMetadata(c).includes(normTag));
      if (!hasTag) {
        resultClauses.push(cleanTag);
      }
    }

    return resultClauses.join('\n');
  }
}
