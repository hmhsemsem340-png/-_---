/**
 * Arabic Text Encoding & Normalization Utilities
 * Supports UTF-8, Windows-1256 (Arabic Windows Excel default), ISO-8859-6,
 * Mojibake repair (e.g. Ø´Ø§Ø±Ø¹ -> شارع), and preservation of all Arabic symbols & numerals.
 */

// Regular expressions for Arabic detection
export const ARABIC_CHAR_REGEX = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
export const ARABIC_MOJIBAKE_REGEX = /[\u00C0-\u00FF][\u0080-\u00FF]/;

/**
 * Repairs Arabic text that was corrupted due to UTF-8 bytes being read as Latin-1/Windows-1252,
 * or Windows-1256 bytes being read as Windows-1252/Latin-1.
 * Examples:
 * "Ø´Ø§Ø±Ø¹" -> "شارع"
 * "©â( Ø'Ø±Ø±±Ø" -> genuine Arabic street names
 */
export function fixArabicMojibake(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // If text doesn't contain high-ASCII or typical mojibake characters, return original
  if (!/[\u0080-\u00FF]/.test(text)) {
    return text;
  }

  const arabicInitialCount = (text.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;

  try {
    const bytes = new Uint8Array([...text].map(char => char.charCodeAt(0) & 0xff));
    
    // Test UTF-8
    let utf8Decoded = '';
    try {
      utf8Decoded = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    } catch {
      // ignore
    }
    const utf8ArabicCount = (utf8Decoded.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;

    // Test Windows-1256 (for Arabic bytes decoded as Windows-1252/Latin-1)
    let win1256Decoded = '';
    try {
      win1256Decoded = new TextDecoder('windows-1256', { fatal: false }).decode(bytes);
    } catch {
      // ignore
    }
    const win1256ArabicCount = (win1256Decoded.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;

    // Compare which decoder produced superior genuine Arabic
    if (win1256ArabicCount > arabicInitialCount && win1256ArabicCount >= utf8ArabicCount) {
      return win1256Decoded.trim();
    }
    if (utf8ArabicCount > arabicInitialCount && !utf8Decoded.includes('\uFFFD')) {
      return utf8Decoded.trim();
    }
  } catch {
    // If decoding fails, return original
  }

  return text;
}



/**
 * Normalizes and cleans Arabic text while strictly preserving:
 * - Arabic letters & Alef variants
 * - Arabic diacritics / Tashkeel
 * - Arabic punctuation (، ؛ ؟) and standard punctuation ( ( ) [ ] - / . : " )
 * - Arabic Eastern numerals (٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩) and standard numerals (0-9)
 * - Removes invisible control characters (BOM, zero-width spaces, RTL/LTR marks)
 */
export function cleanArabicString(val: any): string {
  if (val === null || val === undefined) return '';
  let str = String(val);

  // 1. Remove BOM and invisible directional characters
  str = str.replace(/[\uFEFF\u200B-\u200D\u200E\u200F\u00AD]/g, '');

  // 2. Replace non-breaking spaces with standard space
  str = str.replace(/[\u00A0\u1680\u180e\u2000-\u200a\u202f\u205f\u3000]/g, ' ');

  // 3. Fix mojibake if detected
  str = fixArabicMojibake(str);

  // 4. Collapse multiple consecutive spaces/tabs (preserve intentional newlines)
  str = str.replace(/[ \t]+/g, ' ').trim();

  return str;
}

/**
 * Normalizes Arabic text for consistent search & duplicate detection:
 * - Collapses alef variants (إ أ آ ا) to ا
 * - Collapses taa marbuta (ة) to ه
 * - Collapses alef maqsura (ى) to ي
 * - Strips tashkeel / diacritics
 * - Collapses whitespace
 */
export function normalizeArabicText(str: string): string {
  if (!str) return '';
  return str
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ');
}

export type SupportedEncoding = 'auto' | 'utf-8' | 'windows-1256' | 'iso-8859-6';

/**
 * Detects whether a buffer is UTF-8 or Windows-1256 based on Arabic character presence,
 * and decodes it to a clean string.
 */
export function decodeTextBuffer(
  buffer: ArrayBuffer,
  encoding: SupportedEncoding = 'auto'
): { text: string; usedEncoding: string; arabicRatio: number } {
  const bytes = new Uint8Array(buffer);

  // Check for UTF-8 BOM (EF BB BF)
  const hasUtf8Bom = bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf;

  if (encoding === 'utf-8' || (encoding === 'auto' && hasUtf8Bom)) {
    const text = new TextDecoder('utf-8').decode(buffer);
    const arabicCount = (text.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;
    return {
      text,
      usedEncoding: 'UTF-8',
      arabicRatio: text.length > 0 ? arabicCount / text.length : 0
    };
  }

  if (encoding === 'windows-1256') {
    const text = new TextDecoder('windows-1256').decode(buffer);
    const arabicCount = (text.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;
    return {
      text,
      usedEncoding: 'Windows-1256 (عربي إكسيل)',
      arabicRatio: text.length > 0 ? arabicCount / text.length : 0
    };
  }

  if (encoding === 'iso-8859-6') {
    try {
      const text = new TextDecoder('iso-8859-6').decode(buffer);
      const arabicCount = (text.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;
      return {
        text,
        usedEncoding: 'ISO-8859-6',
        arabicRatio: text.length > 0 ? arabicCount / text.length : 0
      };
    } catch {
      // Fallback
    }
  }

  // AUTO-DETECTION: Compare UTF-8 and Windows-1256
  let utf8Decoded = '';
  let utf8ArabicCount = 0;
  let utf8HasErrors = false;

  try {
    utf8Decoded = new TextDecoder('utf-8', { fatal: false }).decode(buffer);
    // If it contains Unicode replacement characters, it has invalid UTF-8 bytes
    if (utf8Decoded.includes('\uFFFD')) {
      utf8HasErrors = true;
    }
    utf8ArabicCount = (utf8Decoded.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;
  } catch {
    utf8HasErrors = true;
  }

  let win1256Decoded = '';
  let win1256ArabicCount = 0;

  try {
    win1256Decoded = new TextDecoder('windows-1256', { fatal: false }).decode(buffer);
    win1256ArabicCount = (win1256Decoded.match(new RegExp(ARABIC_CHAR_REGEX, 'g')) || []).length;
  } catch {
    // ignore
  }

  // Decision logic:
  // If UTF-8 has errors and Windows-1256 has Arabic characters, prefer Windows-1256
  if ((utf8HasErrors || utf8ArabicCount === 0) && win1256ArabicCount > 0) {
    return {
      text: win1256Decoded,
      usedEncoding: 'Windows-1256 (عربي إكسيل ويندوز)',
      arabicRatio: win1256ArabicCount / Math.max(1, win1256Decoded.length)
    };
  }

  // If Windows-1256 has significantly more Arabic characters than UTF-8
  if (win1256ArabicCount > utf8ArabicCount * 1.5 && win1256ArabicCount > 5) {
    return {
      text: win1256Decoded,
      usedEncoding: 'Windows-1256 (عربي إكسيل ويندوز)',
      arabicRatio: win1256ArabicCount / Math.max(1, win1256Decoded.length)
    };
  }

  // Default to UTF-8
  return {
    text: utf8Decoded || win1256Decoded,
    usedEncoding: 'UTF-8',
    arabicRatio: utf8ArabicCount / Math.max(1, utf8Decoded.length)
  };
}

/**
 * Smart column detection score for Street Name in Arabic
 */
export function scoreStreetNameColumn(headerText: string, sampleValues: string[]): number {
  const h = headerText.trim().toLowerCase();
  let score = 0;

  // Exact or strong matches
  if (h.includes('اسم الشارع') || h.includes('اسم_الشارع') || h.includes('اسم الشارع / الحارة')) score += 100;
  if (h.includes('الشارع') || h.includes('الشوارع') || h.includes('الشارع أو الحارة')) score += 80;
  if (h.includes('اسم الحارة') || h.includes('الحارة') || h.includes('الحارات')) score += 75;
  if (h.includes('اسم') && !h.includes('مأذون') && !h.includes('جهة') && !h.includes('مستخدم')) score += 50;
  if (h.includes('street') || h.includes('street_name') || h.includes('name')) score += 60;
  if (h.includes('العنوان') || h.includes('الموقع') || h.includes('البيان')) score += 40;

  // Penalize ID, Serial, Date, or Permission columns
  if (h.includes('م') || h.includes('رقم') || h.includes('id') || h.includes('مسلسل') || h.includes('كود')) score -= 50;
  if (h.includes('مأذونية') || h.includes('تاريخ') || h.includes('ملاحظات') || h.includes('تصنيف')) score -= 40;

  // Check sample values
  let arabicSampleCount = 0;
  let textSampleCount = 0;
  for (const val of sampleValues.slice(0, 10)) {
    if (!val) continue;
    if (ARABIC_CHAR_REGEX.test(val)) arabicSampleCount++;
    // If it starts with common street words
    if (/^(شارع|حارة|زقاق|ميدان|درب|طريق|عطفة|سكة)/.test(val.trim())) {
      score += 25;
    }
    // If it's purely a number (like 1, 2, 3), penalize
    if (/^\d+$/.test(val.trim())) {
      score -= 20;
    } else {
      textSampleCount++;
    }
  }

  score += arabicSampleCount * 5;
  if (textSampleCount > 0) score += 10;

  return score;
}

/**
 * Score permission / district column
 */
export function scorePermissionColumn(headerText: string, sampleValues: string[]): number {
  const h = headerText.trim().toLowerCase();
  let score = 0;

  if (h.includes('مأذونية') || h.includes('المأذونية') || h.includes('جهة الاختصاص')) score += 100;
  if (h.includes('التبعية') || h.includes('الحي') || h.includes('المنطقة') || h.includes('القطاع')) score += 70;
  if (h.includes('permission') || h.includes('district')) score += 60;

  for (const val of sampleValues.slice(0, 10)) {
    if (!val) continue;
    if (/(شبرا|إفلاقة|قرطسا|نقرها|الريش|سكنيدة|طاموس)/.test(val)) {
      score += 30;
    }
  }

  return score;
}

/**
 * Score metadata / notes column
 */
export function scoreMetadataColumn(headerText: string, sampleValues: string[] = []): number {
  const h = headerText.trim().toLowerCase();
  let score = 0;

  if (h.includes('بيانات وصفية') || h.includes('الوصفية') || h.includes('بيانات_وصفية') || h.includes('بيان وصفي')) score += 100;
  if (h.includes('ملاحظات') || h.includes('الوصف') || h.includes('تفاصيل') || h.includes('حدود') || h.includes('البيان')) score += 80;
  if (h.includes('توصيف') || h.includes('معلومات') || h.includes('metadata') || h.includes('notes') || h.includes('description')) score += 60;

  // Check sample values for descriptive content (long texts, landmarks, directions)
  for (const val of sampleValues.slice(0, 10)) {
    if (!val) continue;
    const trimmed = val.trim();
    if (trimmed.length > 20) score += 15;
    if (/(يمتد|تقاطع|بجوار|خلف|أمام|شمال|جنوب|شرق|غرب|منطقة|أرقام|فردي|زوجي|حتى)/.test(trimmed)) {
      score += 20;
    }
  }

  return score;
}

/**
 * Score category column
 */
export function scoreCategoryColumn(headerText: string, sampleValues: string[]): number {
  const h = headerText.trim().toLowerCase();
  let score = 0;

  if (h.includes('تصنيف') || h.includes('التصنيف') || h.includes('النوع') || h.includes('نوع الشارع')) score += 100;
  if (h.includes('category') || h.includes('type')) score += 60;

  for (const val of sampleValues.slice(0, 10)) {
    if (!val) continue;
    if (['شارع', 'حارة', 'زقاق', 'ميدان', 'درب', 'طريق', 'عطفة'].includes(val.trim())) {
      score += 25;
    }
  }

  return score;
}
