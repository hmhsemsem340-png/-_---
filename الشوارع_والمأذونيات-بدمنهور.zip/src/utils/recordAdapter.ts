import { RecordItem, StreetRecord } from '../types';

/**
 * محوّل البيانات المزدوج (Bidirectional Adapter)
 * يضمن التوافق الكامل بين RecordItem و StreetRecord دون فقدان أي بيانات
 */
export function recordItemToStreetRecord(item: RecordItem): StreetRecord {
  return {
    id: item.id,
    streetName: item.name,
    normalizedStreetName: item.name,
    notarization: item.permission || 'غير محدد',
    category: item.category || 'مأذونية رسمية',
    recordType: 'شارع',
    description: item.metadata || '',
    landmarks: '',
    boundaries: '',
    status: 'نشط',
    createdAt: item.lastModifiedAt || new Date().toISOString(),
    updatedAt: item.lastModifiedAt || new Date().toISOString(),
    createdBy: item.lastModifiedBy || 'الموثق',
    updatedBy: item.lastModifiedBy || 'الموثق',
    version: 1,
    auditLogs: item.auditLogs
  };
}

export function streetRecordToRecordItem(record: StreetRecord): RecordItem {
  const metadataParts: string[] = [];
  if (record.description) metadataParts.push(record.description);
  if (record.landmarks) metadataParts.push(`المعالم: ${record.landmarks}`);
  if (record.boundaries) metadataParts.push(`الحدود: ${record.boundaries}`);
  if (record.gpsCoordinates) metadataParts.push(`إحداثيات: ${record.gpsCoordinates}`);
  if (record.sharedNote) metadataParts.push(record.sharedNote);

  return {
    id: record.id,
    name: record.streetName,
    permission: record.notarization,
    metadata: metadataParts.join('؛ '),
    category: record.category || 'شارع',
    auditLogs: record.auditLogs,
    lastModifiedAt: record.updatedAt,
    lastModifiedBy: record.updatedBy
  };
}
