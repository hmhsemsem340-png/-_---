// ============================================================
// 📤 منظومة الاستيراد والتصدير المتقدم ونظام الحماية الشامل
// Advanced Export & Comprehensive Security Engine
// (SpreadsheetML XML Excel/Calc, Protected PDF, HTML, CSV, Backup)
// ============================================================

import * as XLSX from 'xlsx';
import { 
  StreetRecord, 
  AuditLogEntry, 
  UserSettings, 
  RecordCategory, 
  RecordType, 
  RecordStatus, 
  AdvancedExportOptions 
} from '../types';
import { ArabicUtils } from './arabicUtils';
import { MojibakeEngine } from './mojibakeEngine';
import { parseStreetPrefixAndName, isOfficialNotarization } from './streetSplitter';

export const OFFICIAL_NOTARIZATIONS = [
  { name: 'شبرا بحري', class: 'n1', color: '#2e7d32', bg: '#e8f5e9' },
  { name: 'سكنيدة', class: 'n2', color: '#1565c0', bg: '#e3f2fd' },
  { name: 'طاموس', class: 'n3', color: '#e65100', bg: '#fff3e0' },
  { name: 'شبرا قبلي', class: 'n4', color: '#c62828', bg: '#fce4ec' },
  { name: 'قرطسا بحري', class: 'n5', color: '#6a1b9a', bg: '#f3e5f5' },
  { name: 'نقرها', class: 'n6', color: '#00695c', bg: '#e0f2f1' },
  { name: 'قرطسا قبلي', class: 'n7', color: '#f57f17', bg: '#fff8e1' }
];

export class ExportEngine {
  /**
   * 🚀 التصدير المتقدم الشامل وفق الخيارات والحماية
   */
  static exportAdvanced(records: StreetRecord[], options: AdvancedExportOptions): void {
    switch (options.format) {
      case 'excel':
        this.exportSpreadsheetML(records, options);
        break;
      case 'pdf':
        this.exportToPDF(records, options);
        break;
      case 'html':
        this.exportToHTML(records, options);
        break;
      case 'csv':
        this.exportToCSV(records, `شوارع_دمنهور_${this.getDateStamp()}`);
        break;
      default:
        this.exportSpreadsheetML(records, options);
    }
  }

  /**
   * 📊 تصدير Excel / Calc احترافي متوافق 100% مع SpreadsheetML XML
   * يدعم LibreOffice Calc, Excel, Google Sheets, WPS, Numbers
   */
  static exportSpreadsheetML(data: StreetRecord[], options: AdvancedExportOptions): void {
    const operatorName = options.operator || 'أ/ حسام الدين الخولي';
    const exportDate = new Date().toLocaleString('ar-EG');
    const pwdOpen = options.password || '';
    const pwdModify = options.modifyPassword || '';

    // تعريف الأنماط المتقدمة والألوان
    let styles = `
    <Styles>
      <Style ss:ID="Default" ss:Name="Normal">
        <Alignment ss:Vertical="Center" ss:WrapText="1"/>
        <Font ss:FontName="Cairo" ss:Size="10"/>
      </Style>
      <Style ss:ID="Header">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="12" ss:Bold="1" ss:Color="#FFFFFF"/>
        <Interior ss:Color="#2c5f2d" ss:Pattern="Solid"/>
        <Borders>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#1a3d1b"/>
          <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#4a8c4b"/>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#4a8c4b"/>
        </Borders>
      </Style>
      <Style ss:ID="Title">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="16" ss:Bold="1" ss:Color="#2c5f2d"/>
      </Style>
      <Style ss:ID="Subtitle">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="12" ss:Bold="1" ss:Color="#444444"/>
      </Style>
      <Style ss:ID="Info">
        <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10" ss:Color="#555555"/>
      </Style>
      <Style ss:ID="Footer">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="9" ss:Italic="1" ss:Color="#666666"/>
        <Borders>
          <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#2c5f2d"/>
        </Borders>
      </Style>
      <Style ss:ID="CellNormal">
        <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10"/>
        <Borders>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
      <Style ss:ID="CellCenter">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10"/>
        <Borders>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
    `;

    // أنماط المأذونيات الملونة
    OFFICIAL_NOTARIZATIONS.forEach((n, idx) => {
      styles += `
      <Style ss:ID="Notarization${idx}">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10" ss:Bold="1" ss:Color="${n.color}"/>
        <Interior ss:Color="${n.bg}" ss:Pattern="Solid"/>
        <Borders>
          <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="${n.color}"/>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="${n.color}"/>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
      `;
    });

    // أنماط الحالات
    const statusStyles: Record<string, { color: string; bg: string }> = {
      'تام': { color: '#064e3b', bg: '#a7f3d0' },
      'نشط': { color: '#155724', bg: '#d4edda' },
      'معلّق': { color: '#856404', bg: '#fff3cd' },
      'قيد المراجعة': { color: '#0c5460', bg: '#d1ecf1' },
      'ملغي': { color: '#721c24', bg: '#f8d7da' }
    };

    Object.entries(statusStyles).forEach(([status, colors], idx) => {
      styles += `
      <Style ss:ID="Status${idx}">
        <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10" ss:Bold="1" ss:Color="${colors.color}"/>
        <Interior ss:Color="${colors.bg}" ss:Pattern="Solid"/>
        <Borders>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
      `;
    });

    // أنماط الصفوف البديلة والمشتركة
    styles += `
      <Style ss:ID="AltRow">
        <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10"/>
        <Interior ss:Color="#FAFAFA" ss:Pattern="Solid"/>
        <Borders>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
      <Style ss:ID="SharedRow">
        <Alignment ss:Horizontal="Right" ss:Vertical="Center"/>
        <Font ss:FontName="Cairo" ss:Size="10" ss:Bold="1"/>
        <Borders>
          <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="3" ss:Color="#f39c12"/>
          <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E0E0E0"/>
        </Borders>
      </Style>
    </Styles>
    `;

    // بناء صفوف البيانات
    let rows = '';

    // الترويسة الرسمية
    if (options.header) {
      rows += `
      <Row ss:Height="32">
        <Cell ss:MergeAcross="9" ss:StyleID="Title"><Data ss:Type="String">جمهورية مصر العربية</Data></Cell>
      </Row>
      <Row ss:Height="26">
        <Cell ss:MergeAcross="9" ss:StyleID="Subtitle"><Data ss:Type="String">محافظة البحيرة — بندر دمنهور</Data></Cell>
      </Row>
      <Row ss:Height="26">
        <Cell ss:MergeAcross="9" ss:StyleID="Subtitle"><Data ss:Type="String">منظومة التوثيق الرقمي للشوارع والمأذونيات</Data></Cell>
      </Row>
      <Row ss:Height="22"><Cell ss:Index="10" ss:StyleID="Info"><Data ss:Type="String">تاريخ الاستخراج: ${exportDate}</Data></Cell></Row>
      <Row ss:Height="22"><Cell ss:Index="10" ss:StyleID="Info"><Data ss:Type="String">الموثق المسؤول: ${operatorName}</Data></Cell></Row>
      <Row ss:Height="22"><Cell ss:Index="10" ss:StyleID="Info"><Data ss:Type="String">عدد السجلات: ${data.length}</Data></Cell></Row>
      <Row ss:Height="12"><Cell ss:Index="1"></Cell></Row>
      `;
    }

    // رأس الجدول
    const headers = ['م', 'اسم الشارع', 'المأذونية', 'النوع', 'الوصف', 'المعالم', 'الحدود', 'الحالة', 'المأذونية المشتركة', 'ملاحظة الاشتراك'];
    rows += '<Row ss:Height="28">';
    headers.forEach((h) => {
      rows += `<Cell ss:StyleID="Header"><Data ss:Type="String">${h}</Data></Cell>`;
    });
    rows += '</Row>';

    // كتابة بيانات السجلات
    data.forEach((r, idx) => {
      const parsed = parseStreetPrefixAndName(r.streetName, r.recordType);
      const notarization = OFFICIAL_NOTARIZATIONS.find((n) => n.name === r.notarization);
      const nIdx = notarization ? OFFICIAL_NOTARIZATIONS.indexOf(notarization) : -1;
      const statusIdx = Object.keys(statusStyles).indexOf(r.status);
      const rowStyle = options.altRows && idx % 2 === 1 ? 'AltRow' : 'CellNormal';

      rows += `<Row ss:Height="24" ss:StyleID="${r.sharedNotarization ? 'SharedRow' : rowStyle}">`;
      rows += `<Cell ss:StyleID="CellCenter"><Data ss:Type="Number">${idx + 1}</Data></Cell>`;
      rows += `<Cell><Data ss:Type="String">${this.escapeXml(parsed.cleanName)}</Data></Cell>`;
      rows += `<Cell ss:StyleID="${options.colors && nIdx >= 0 ? `Notarization${nIdx}` : 'CellCenter'}"><Data ss:Type="String">${this.escapeXml(r.notarization)}</Data></Cell>`;
      rows += `<Cell ss:StyleID="CellCenter"><Data ss:Type="String">${this.escapeXml(parsed.detectedType)}</Data></Cell>`;
      rows += `<Cell><Data ss:Type="String">${this.escapeXml(r.description || '')}</Data></Cell>`;
      rows += `<Cell><Data ss:Type="String">${this.escapeXml(r.landmarks || '')}</Data></Cell>`;
      rows += `<Cell><Data ss:Type="String">${this.escapeXml(r.boundaries || '')}</Data></Cell>`;
      rows += `<Cell ss:StyleID="${options.colors && statusIdx >= 0 ? `Status${statusIdx}` : 'CellCenter'}"><Data ss:Type="String">${this.escapeXml(r.status)}</Data></Cell>`;
      rows += `<Cell ss:StyleID="CellCenter"><Data ss:Type="String">${this.escapeXml(r.sharedNotarization || '')}</Data></Cell>`;
      rows += `<Cell><Data ss:Type="String">${this.escapeXml(r.sharedNote || '')}</Data></Cell>`;
      rows += '</Row>';
    });

    // التذييل والتوقيعات
    if (options.footer) {
      rows += `<Row ss:Height="14"><Cell ss:Index="1"></Cell></Row>`;
      rows += `<Row ss:Height="28">
        <Cell ss:MergeAcross="4" ss:StyleID="Footer"><Data ss:Type="String">توقيع الموثق: ${operatorName}</Data></Cell>
        <Cell ss:MergeAcross="4" ss:StyleID="Footer"><Data ss:Type="String">تاريخ الاعتماد: ${exportDate}</Data></Cell>
      </Row>`;
      if (options.watermark) {
        rows += `<Row ss:Height="22">
          <Cell ss:MergeAcross="9" ss:StyleID="Footer"><Data ss:Type="String">⚠️ هذا المستند محمي ومُصدَر من منظومة التوثيق الرقمي — أي تعديل يُعد باطلاً</Data></Cell>
        </Row>`;
      }
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>${this.escapeXml(operatorName)}</Author>
  <Created>${new Date().toISOString()}</Created>
  <Title>شوارع ومأذونيات دمنهور</Title>
  <Subject>منظومة التوثيق الرقمي</Subject>
 </DocumentProperties>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>8500</WindowHeight>
  <WindowWidth>14000</WindowWidth>
  ${options.rtl ? '<ActiveSheetDirection>RightToLeft</ActiveSheetDirection>' : ''}
 </ExcelWorkbook>
 ${styles}
 <Worksheet ss:Name="شوارع دمنهور">
  <Table ss:DefaultRowHeight="22" ss:DefaultColWidth="110">
   <Column ss:Width="45"/>
   <Column ss:Width="220"/>
   <Column ss:Width="130"/>
   <Column ss:Width="90"/>
   <Column ss:Width="260"/>
   <Column ss:Width="220"/>
   <Column ss:Width="220"/>
   <Column ss:Width="100"/>
   <Column ss:Width="130"/>
   <Column ss:Width="260"/>
   ${rows}
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   ${options.freeze ? '<FreezePanes/><FrozenNoSplit/><SplitHorizontal>1</SplitHorizontal><TopRowBottomPane>1</TopRowBottomPane>' : ''}
   ${options.rtl ? '<DisplayRightToLeft/>' : ''}
   <Protect>${options.readonly ? '1' : '0'}</Protect>
   ${pwdOpen ? `<Password>${this.escapeXml(pwdOpen)}</Password>` : ''}
   <ProtectObjects>${options.readonly ? '1' : '0'}</ProtectObjects>
   <ProtectScenarios>${options.readonly ? '1' : '0'}</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>
</Workbook>`;

    this.downloadBlob(xml, `شوارع_دمنهور_${this.getDateStamp()}.xls`, 'application/vnd.ms-excel');
  }

  /**
   * 📄 تصدير PDF محمي مع ترويسة رسمية وعلامة مائية وتوقيعات
   */
  static exportToPDF(data: StreetRecord[], options: AdvancedExportOptions): void {
    const operatorName = options.operator || 'أ/ حسام الدين الخولي';
    const exportDate = new Date().toLocaleString('ar-EG');

    let html = `<!DOCTYPE html>
<html dir="${options.rtl ? 'rtl' : 'ltr'}" lang="ar">
<head>
<meta charset="UTF-8">
<title>شوارع ومأذونيات دمنهور - ${exportDate}</title>
<style>
  @page { size: A4 landscape; margin: 1.2cm; }
  * { box-sizing: border-box; }
  body {
    font-family: 'Cairo', 'Segoe UI', 'Traditional Arabic', Arial, sans-serif;
    font-size: 11pt;
    direction: rtl;
    color: #111;
    line-height: 1.5;
    margin: 0;
    padding: 20px;
  }
  .header {
    text-align: center;
    border-bottom: 3px double #2c5f2d;
    padding-bottom: 12px;
    margin-bottom: 16px;
  }
  .header h1 { color: #2c5f2d; font-size: 19pt; margin: 4px 0; }
  .header h2 { font-size: 13pt; margin: 3px 0; color: #444; }
  .header h3 { font-size: 11pt; margin: 3px 0; color: #666; }
  .info-bar {
    display: flex;
    justify-content: space-between;
    margin-bottom: 14px;
    font-size: 10pt;
    color: #444;
    padding: 8px 14px;
    background: #f5f7f5;
    border: 1px solid #dce4dc;
    border-radius: 6px;
  }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; }
  th {
    background: #2c5f2d;
    color: white;
    padding: 10px 8px;
    font-size: 10pt;
    font-weight: bold;
    text-align: right;
    border: 1px solid #1a3d1b;
  }
  td {
    padding: 8px;
    border: 1px solid #ddd;
    font-size: 9.5pt;
    vertical-align: middle;
  }
  tr:nth-child(even) { background: ${options.altRows ? '#f9f9f9' : '#fff'}; }
  .notarization-tag {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 9pt;
    font-weight: bold;
  }
  .status-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 9pt;
    font-weight: bold;
  }
  .footer {
    margin-top: 25px;
    border-top: 2px solid #2c5f2d;
    padding-top: 15px;
    display: flex;
    justify-content: space-between;
    font-size: 10pt;
    page-break-inside: avoid;
  }
  .signature-box { text-align: center; width: 30%; }
  .signature-line { border-top: 1px solid #333; margin-top: 40px; padding-top: 5px; font-weight: bold; }
  .watermark {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 60pt;
    color: rgba(44, 95, 45, 0.08);
    font-weight: bold;
    pointer-events: none;
    z-index: 0;
    white-space: nowrap;
  }
  @media print {
    body { padding: 0; }
    .no-print { display: none; }
  }
</style>
</head>
<body>
${options.watermark ? `<div class="watermark">${this.escapeHtml(operatorName)}</div>` : ''}

${options.header ? `
<div class="header">
  <h1>جمهورية مصر العربية</h1>
  <h2>محافظة البحيرة — بندر دمنهور</h2>
  <h3>منظومة التوثيق الرقمي للشوارع والمأذونيات</h3>
</div>
` : ''}

<div class="info-bar">
  <span>📅 تاريخ الاستخراج: ${exportDate}</span>
  <span>👤 الموثق: ${this.escapeHtml(operatorName)}</span>
  <span>📊 عدد السجلات: ${data.length}</span>
</div>

<table>
  <thead>
    <tr>
      <th style="width:35px; text-align:center">م</th>
      <th>اسم الشارع</th>
      <th style="width:120px; text-align:center">المأذونية</th>
      <th style="width:70px; text-align:center">النوع</th>
      <th>الوصف</th>
      <th>المعالم</th>
      <th>الحدود</th>
      <th style="width:85px; text-align:center">الحالة</th>
    </tr>
  </thead>
  <tbody>`;

    data.forEach((r, idx) => {
      const notarization = OFFICIAL_NOTARIZATIONS.find((n) => n.name === r.notarization);
      const nColor = notarization ? notarization.color : '#333';
      const nBg = notarization ? notarization.bg : '#eee';
      const statusColors: Record<string, { color: string; bg: string }> = {
        'تام': { color: '#064e3b', bg: '#a7f3d0' },
        'نشط': { color: '#155724', bg: '#d4edda' },
        'معلّق': { color: '#856404', bg: '#fff3cd' },
        'قيد المراجعة': { color: '#0c5460', bg: '#d1ecf1' },
        'ملغي': { color: '#721c24', bg: '#f8d7da' }
      };
      const sColors = statusColors[r.status] || { color: '#333', bg: '#eee' };
      const parsed = parseStreetPrefixAndName(r.streetName, r.recordType);
      const isOfficial = isOfficialNotarization(r.notarization);
      const officialBadge = isOfficial 
        ? '<span style="display:inline-block;padding:2px 6px;background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;border-radius:10px;font-size:9px;font-weight:bold;margin-right:4px;">رسمية</span>'
        : '<span style="display:inline-block;padding:2px 6px;background:#fff3e0;color:#e65100;border:1px solid #ffcc80;border-radius:10px;font-size:9px;font-weight:bold;margin-right:4px;">غير رسمية</span>';

      html += `
    <tr style="${r.sharedNotarization ? 'border-right: 4px solid #f39c12;' : ''}">
      <td style="text-align:center">${idx + 1}</td>
      <td><strong>${this.escapeHtml(parsed.cleanName)}</strong>${r.sharedNotarization ? ' 🔗' : ''}</td>
      <td style="text-align:center"><span class="notarization-tag" style="background:${nBg};color:${nColor}">${this.escapeHtml(r.notarization)}</span> ${officialBadge}</td>
      <td style="text-align:center">${this.escapeHtml(parsed.detectedType)}</td>
      <td>${this.escapeHtml(r.description || '-')}</td>
      <td>${this.escapeHtml(r.landmarks || '-')}</td>
      <td>${this.escapeHtml(r.boundaries || '-')}</td>
      <td style="text-align:center"><span class="status-badge" style="background:${sColors.bg};color:${sColors.color}">${this.escapeHtml(r.status)}</span></td>
    </tr>`;
    });

    html += `
  </tbody>
</table>

${options.footer ? `
<div class="footer">
  <div class="signature-box">
    <p>توقيع الموثق</p>
    <div class="signature-line">${this.escapeHtml(operatorName)}</div>
  </div>
  <div class="signature-box">
    <p>توقيع المراجع</p>
    <div class="signature-line"></div>
  </div>
  <div class="signature-box">
    <p>خاتم شعار الجمهورية</p>
    <div class="signature-line"></div>
  </div>
</div>
<p style="text-align:center; margin-top:15px; font-size:9pt; color:#666;">
  ${options.signature ? `✅ تم التصدير بواسطة: ${this.escapeHtml(operatorName)} | ${exportDate} | ` : ''}
  ${options.watermark ? '⚠️ هذا المستند محمي — أي تعديل يُعد باطلاً' : ''}
</p>
` : ''}

${options.nocopy ? `<script>document.addEventListener('copy', function(e){ e.preventDefault(); }); document.addEventListener('cut', function(e){ e.preventDefault(); });<\/script>` : ''}
${options.noprint ? `<style>@media print { body { display: none !important; } }</style>` : ''}

</body>
</html>`;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('يرجى السماح بالنوافذ المنبثقة لإتمام عملية تصدير/طباعة PDF');
      return;
    }
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.onload = () => {
      setTimeout(() => printWindow.print(), 500);
    };
  }

  /**
   * 🌐 تصدير صفحة HTML كاملة التنسيق مع الحماية
   */
  static exportToHTML(data: StreetRecord[], options: AdvancedExportOptions): void {
    const operatorName = options.operator || 'أ/ حسام الدين الخولي';
    const exportDate = new Date().toLocaleString('ar-EG');

    let html = `<!DOCTYPE html>
<html dir="${options.rtl ? 'rtl' : 'ltr'}" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>شوارع ومأذونيات دمنهور — ${exportDate}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Cairo', 'Segoe UI', 'Traditional Arabic', Arial, sans-serif;
    font-size: 14px;
    direction: rtl;
    background: linear-gradient(135deg, #f5f7f5 0%, #e8f5e9 100%);
    color: #2c3e50;
    line-height: 1.6;
    padding: 24px;
    min-height: 100vh;
  }
  .container { max-width: 1400px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden; }
  .header {
    background: linear-gradient(135deg, #2c5f2d, #4a8c4b);
    color: white;
    padding: 28px;
    text-align: center;
  }
  .header h1 { font-size: 26px; margin-bottom: 6px; font-weight: bold; }
  .header h2 { font-size: 17px; opacity: 0.92; margin-bottom: 4px; }
  .header h3 { font-size: 14px; opacity: 0.85; }
  .info-bar {
    display: flex;
    justify-content: space-around;
    padding: 14px 24px;
    background: #e8f5e9;
    border-bottom: 1px solid #dce4dc;
    flex-wrap: wrap;
    gap: 15px;
  }
  .info-item { text-align: center; }
  .info-item .label { font-size: 11px; color: #7f8c8d; display: block; }
  .info-item .value { font-size: 15px; font-weight: bold; color: #2c5f2d; }
  .table-wrapper { padding: 20px; overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; background: white; }
  thead { position: sticky; top: 0; z-index: 10; }
  th {
    background: #2c5f2d;
    color: white;
    padding: 12px 10px;
    font-size: 13px;
    font-weight: 600;
    text-align: right;
    border-left: 1px solid rgba(255,255,255,0.15);
    white-space: nowrap;
  }
  th:last-child { border-left: none; }
  td {
    padding: 11px 10px;
    border-bottom: 1px solid #dce4dc;
    font-size: 13px;
    vertical-align: middle;
  }
  tbody tr:hover { background: #f0f7f0; }
  ${options.altRows ? 'tbody tr:nth-child(even) { background: #fafafa; }' : ''}
  .notarization-tag {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
  }
  .status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
  }
  .shared-street { border-right: 4px solid #f39c12 !important; }
  .street-name { font-weight: 600; color: #2c3e50; }
  .footer {
    background: #1a3d1b;
    color: rgba(255,255,255,0.9);
    padding: 24px;
    text-align: center;
  }
  .footer .signatures {
    display: flex;
    justify-content: space-around;
    margin: 20px 0;
    flex-wrap: wrap;
    gap: 20px;
  }
  .signature-box { text-align: center; min-width: 180px; }
  .signature-line { border-top: 1px solid rgba(255,255,255,0.3); margin-top: 40px; padding-top: 6px; font-size: 13px; font-weight: bold; }
  .watermark {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 70px;
    color: rgba(44, 95, 45, 0.05);
    font-weight: bold;
    pointer-events: none;
    z-index: 0;
    white-space: nowrap;
  }
  .security-notice {
    background: #fff3cd;
    border: 1px solid #ffeeba;
    color: #856404;
    padding: 10px;
    text-align: center;
    font-size: 12px;
    border-radius: 6px;
    margin: 15px 24px;
  }
</style>
</head>
<body>
${options.watermark ? `<div class="watermark">${this.escapeHtml(operatorName)}</div>` : ''}

<div class="container">
  ${options.header ? `
  <div class="header">
    <h1>🏛️ جمهورية مصر العربية</h1>
    <h2>محافظة البحيرة — بندر دمنهور</h2>
    <h3>منظومة التوثيق الرقمي للشوارع والمأذونيات</h3>
  </div>
  ` : ''}

  <div class="info-bar">
    <div class="info-item"><span class="label">تاريخ الاستخراج</span><span class="value">${exportDate}</span></div>
    <div class="info-item"><span class="label">الموثق</span><span class="value">${this.escapeHtml(operatorName)}</span></div>
    <div class="info-item"><span class="label">عدد السجلات</span><span class="value">${data.length}</span></div>
    <div class="info-item"><span class="label">الحماية</span><span class="value">${options.readonly ? 'محمي (قراءة فقط)' : 'عادي'}</span></div>
  </div>

  ${options.readonly || options.nocopy ? `
  <div class="security-notice">
    ⚠️ هذا المستند محمي — ${options.readonly ? 'ممنوع التعديل' : ''} ${options.nocopy ? 'ممنوع النسخ واللصق' : ''} — أي تغيير يُعد باطلاً قانونياً
  </div>
  ` : ''}

  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th style="width:40px; text-align:center">م</th>
          <th>اسم الشارع</th>
          <th style="width:120px; text-align:center">المأذونية</th>
          <th style="width:80px; text-align:center">النوع</th>
          <th>الوصف</th>
          <th>المعالم</th>
          <th>الحدود</th>
          <th style="width:90px; text-align:center">الحالة</th>
          <th style="width:120px; text-align:center">مشترك مع</th>
        </tr>
      </thead>
      <tbody>`;

    data.forEach((r, idx) => {
      const notarization = OFFICIAL_NOTARIZATIONS.find((n) => n.name === r.notarization);
      const nColor = notarization ? notarization.color : '#333';
      const nBg = notarization ? notarization.bg : '#eee';
      const statusColors: Record<string, { color: string; bg: string }> = {
        'تام': { color: '#064e3b', bg: '#a7f3d0' },
        'نشط': { color: '#155724', bg: '#d4edda' },
        'معلّق': { color: '#856404', bg: '#fff3cd' },
        'قيد المراجعة': { color: '#0c5460', bg: '#d1ecf1' },
        'ملغي': { color: '#721c24', bg: '#f8d7da' }
      };
      const sColors = statusColors[r.status] || { color: '#333', bg: '#eee' };
      const parsed = parseStreetPrefixAndName(r.streetName, r.recordType);
      const isOfficial = isOfficialNotarization(r.notarization);
      const officialBadge = isOfficial 
        ? '<span style="display:inline-block;padding:2px 6px;background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;border-radius:10px;font-size:9px;font-weight:bold;margin-right:4px;">رسمية</span>'
        : '<span style="display:inline-block;padding:2px 6px;background:#fff3e0;color:#e65100;border:1px solid #ffcc80;border-radius:10px;font-size:9px;font-weight:bold;margin-right:4px;">غير رسمية</span>';

      html += `
        <tr class="${r.sharedNotarization ? 'shared-street' : ''}">
          <td style="text-align:center; font-weight:bold">${idx + 1}</td>
          <td class="street-name">${this.escapeHtml(parsed.cleanName)}${r.sharedNotarization ? ' 🔗' : ''}</td>
          <td style="text-align:center"><span class="notarization-tag" style="background:${nBg};color:${nColor}">${this.escapeHtml(r.notarization)}</span> ${officialBadge}</td>
          <td style="text-align:center">${this.escapeHtml(parsed.detectedType)}</td>
          <td>${this.escapeHtml(r.description || '-')}</td>
          <td>${this.escapeHtml(r.landmarks || '-')}</td>
          <td>${this.escapeHtml(r.boundaries || '-')}</td>
          <td style="text-align:center"><span class="status-badge" style="background:${sColors.bg};color:${sColors.color}">${this.escapeHtml(r.status)}</span></td>
          <td style="text-align:center; font-size:11px">${this.escapeHtml(r.sharedNotarization || '-')}</td>
        </tr>`;
    });

    html += `
      </tbody>
    </table>
  </div>

  ${options.footer ? `
  <div class="footer">
    <div class="signatures">
      <div class="signature-box">
        <p>توقيع الموثق</p>
        <div class="signature-line">${this.escapeHtml(operatorName)}</div>
      </div>
      <div class="signature-box">
        <p>توقيع المراجع</p>
        <div class="signature-line"></div>
      </div>
      <div class="signature-box">
        <p>خاتم شعار الجمهورية</p>
        <div class="signature-line"></div>
      </div>
    </div>
    <p style="font-size:12px;opacity:0.85;margin-top:12px">
      ${options.signature ? `✅ تم التصدير بواسطة: ${this.escapeHtml(operatorName)} | ${exportDate} | ` : ''}
      ${options.watermark ? '⚠️ هذا المستند محمي ومُصدَر من منظومة التوثيق الرقمي — أي تعديل يُعد باطلاً' : ''}
    </p>
  </div>
  ` : ''}
</div>

${options.nocopy ? `<script>document.addEventListener('copy', function(e){ e.preventDefault(); alert('النسخ ممنوع في هذا المستند المحمي'); }); document.addEventListener('cut', function(e){ e.preventDefault(); }); document.addEventListener('contextmenu', function(e){ e.preventDefault(); });<\/script>` : ''}
${options.readonly ? `<script>document.addEventListener('keydown', function(e){ if (e.ctrlKey && (e.key === 'c' || e.key === 'x' || e.key === 'v')) { e.preventDefault(); alert('هذا المستند للقراءة فقط'); } });<\/script>` : ''}

</body>
</html>`;

    this.downloadBlob(html, `شوارع_دمنهور_${this.getDateStamp()}.html`, 'text/html;charset=utf-8');
  }

  /**
   * التصدير الاحترافي إلى Excel (.xlsx) عبر XLSX
   */
  static exportToExcel(
    records: StreetRecord[],
    filename: string = 'شوارع_ومأذونيات_دمنهور'
  ): void {
    const rows = records.map((r, index) => {
      const parsed = parseStreetPrefixAndName(r.streetName, r.recordType);
      return {
        'م': index + 1,
        'اسم الشارع': parsed.cleanName,
        'جهة المأذونية': r.notarization,
        'التصنيف القانوني': r.category,
        'النوع': parsed.detectedType,
        'الوصف وتفاصيل العقود': r.description || '',
        'المعالم المميزة': r.landmarks || '',
        'الحدود الجغرافية': r.boundaries || '',
        'المأذونية المشتركة': r.sharedNotarization || '',
        'ملاحظات الاشتراك المكاني': r.sharedNote || '',
        'الإحداثيات الجغرافية (GPS)': r.gpsCoordinates || '',
        'الرقم القومي للموثق': r.nationalId || '',
        'تاريخ العقد / السند': r.contractDate || '',
        'الحالة': r.status,
        'تاريخ القيد': ArabicUtils.formatDateArabic(r.createdAt),
        'آخر تعديل': ArabicUtils.formatDateArabic(r.updatedAt),
        'الموثق': r.updatedBy || r.createdBy,
        'الإصدار': r.version
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);

    if (!worksheet['!views']) worksheet['!views'] = [];
    worksheet['!views'].push({ RTL: true });

    worksheet['!cols'] = [
      { wch: 6 },
      { wch: 32 },
      { wch: 18 },
      { wch: 18 },
      { wch: 12 },
      { wch: 45 },
      { wch: 32 },
      { wch: 35 },
      { wch: 18 },
      { wch: 45 },
      { wch: 22 },
      { wch: 18 },
      { wch: 15 },
      { wch: 10 },
      { wch: 20 },
      { wch: 20 },
      { wch: 16 },
      { wch: 8 }
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'شوارع دمنهور');

    const dateStr = this.getDateStamp();
    XLSX.writeFile(workbook, `${filename}_${dateStr}.xlsx`);
  }

  /**
   * التصدير إلى CSV مع إضافة BOM لضمان عدم تشويه الحروف العربية
   */
  static exportToCSV(records: StreetRecord[], filename: string = 'شوارع_دمنهور'): void {
    const BOM = '\uFEFF';
    const headers = [
      'م',
      'اسم الشارع',
      'المأذونية',
      'التصنيف',
      'النوع',
      'الوصف',
      'المعالم',
      'الحدود',
      'المأذونية المشتركة',
      'ملاحظة الاشتراك',
      'الإحداثيات GPS',
      'الرقم القومي',
      'تاريخ العقد',
      'الحالة',
      'تاريخ القيد',
      'آخر تعديل'
    ];

    const csvRows = records.map((r, i) => {
      const parsed = parseStreetPrefixAndName(r.streetName, r.recordType);
      return [
        i + 1,
        this.escapeCsv(parsed.cleanName),
        this.escapeCsv(r.notarization),
        this.escapeCsv(r.category),
        this.escapeCsv(parsed.detectedType),
        this.escapeCsv(r.description || ''),
        this.escapeCsv(r.landmarks || ''),
        this.escapeCsv(r.boundaries || ''),
        this.escapeCsv(r.sharedNotarization || ''),
        this.escapeCsv(r.sharedNote || ''),
        this.escapeCsv(r.gpsCoordinates || ''),
        this.escapeCsv(r.nationalId || ''),
        this.escapeCsv(r.contractDate || ''),
        this.escapeCsv(r.status),
        this.escapeCsv(ArabicUtils.formatDateArabic(r.createdAt)),
        this.escapeCsv(ArabicUtils.formatDateArabic(r.updatedAt))
      ];
    });

    const csvContent = BOM + [headers.join(','), ...csvRows.map((row) => row.join(','))].join('\n');
    this.downloadBlob(csvContent, `${filename}.csv`, 'text/csv;charset=utf-8;');
  }

  /**
   * تصدير النسخة الاحتياطية الشاملة (JSON)
   */
  static exportFullBackup(
    records: StreetRecord[],
    auditLog: AuditLogEntry[],
    settings: UserSettings
  ): void {
    const backupData = {
      system: 'Digital Documentation System for Streets and Notarizations in Damanhour',
      exportDate: new Date().toISOString(),
      version: '2.0.0',
      totalRecords: records.length,
      settings,
      records,
      auditLog
    };

    const jsonString = JSON.stringify(backupData, null, 2);
    const dateStr = this.getDateStamp();
    this.downloadBlob(jsonString, `نسخة_احتياطية_شوارع_دمنهور_${dateStr}.json`, 'application/json');
  }

  /**
   * استيراد البيانات من ملفات (Excel, CSV, JSON)
   */
  static async importFile(
    file: File,
    operatorName: string = 'الموثق'
  ): Promise<{
    records: StreetRecord[];
    backupAuditLog?: AuditLogEntry[];
    backupSettings?: UserSettings;
    repairedCount: number;
    totalImported: number;
  }> {
    const extension = file.name.split('.').pop()?.toLowerCase();
    let importedRawRecords: any[] = [];
    let backupAuditLog: AuditLogEntry[] | undefined;
    let backupSettings: UserSettings | undefined;

    if (extension === 'json') {
      const text = await file.text();
      const parsed = JSON.parse(text);

      if (Array.isArray(parsed)) {
        importedRawRecords = parsed;
      } else if (parsed && Array.isArray(parsed.records)) {
        importedRawRecords = parsed.records;
        backupAuditLog = parsed.auditLog;
        backupSettings = parsed.settings;
      } else if (parsed && Array.isArray(parsed.data)) {
        importedRawRecords = parsed.data;
      } else {
        throw new Error('صيغة ملف النسخة الاحتياطية JSON غير مطابقة للمواصفات.');
      }
    } else if (extension === 'xlsx' || extension === 'xls' || extension === 'csv') {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      importedRawRecords = XLSX.utils.sheet_to_json(worksheet);
    } else {
      throw new Error(`امتداد الملف غير مدعوم (.${extension}). يرجى رفع ملف Excel أو CSV أو JSON.`);
    }

    let repairedCount = 0;
    const now = new Date().toISOString();

    const normalizedRecords: StreetRecord[] = importedRawRecords.map((item, idx) => {
      let rawName = String(
        item['اسم الشارع / التقسيم'] || 
        item['اسم الشارع'] || 
        item['الشارع'] || 
        item['streetName'] || 
        item['name'] || 
        ''
      ).trim();

      if (MojibakeEngine.isMojibake(rawName)) {
        rawName = MojibakeEngine.fullRepair(rawName);
        repairedCount++;
      }

      let rawNotarization = String(
        item['جهة المأذونية'] || 
        item['المأذونية'] || 
        item['notarization'] || 
        item['permission'] || 
        'شبرا بحري'
      ).trim();

      if (MojibakeEngine.isMojibake(rawNotarization)) {
        rawNotarization = MojibakeEngine.fullRepair(rawNotarization);
      }

      const rawDescription = String(
        item['الوصف وتفاصيل العقود'] || 
        item['الوصف'] || 
        item['description'] || 
        item['metadata'] || 
        ''
      ).trim();

      const rawLandmarks = String(
        item['المعالم المميزة'] || 
        item['المعالم'] || 
        item['landmarks'] || 
        ''
      ).trim();

      const rawBoundaries = String(
        item['الحدود الجغرافية'] || 
        item['الحدود'] || 
        item['boundaries'] || 
        ''
      ).trim();

      const category: RecordCategory = (item['التصنيف القانوني'] || item['التصنيف'] || item['category'] || 'مأذونية رسمية') as RecordCategory;
      const recordType: RecordType = (item['نوع السجل'] || item['النوع'] || item['recordType'] || 'شارع') as RecordType;
      const status: RecordStatus = (item['الحالة'] || item['status'] || 'نشط') as RecordStatus;

      return {
        id: item.id || `street_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 7)}`,
        streetName: rawName || `شارع غير مسمى ${idx + 1}`,
        normalizedStreetName: ArabicUtils.normalizeForSearch(rawName),
        notarization: rawNotarization,
        category,
        recordType,
        description: rawDescription,
        landmarks: rawLandmarks,
        boundaries: rawBoundaries,
        nationalId: item.nationalId || item['الرقم القومي'] || '',
        contractDate: item.contractDate || item['تاريخ العقد'] || '',
        gpsCoordinates: item.gpsCoordinates || item['الإحداثيات'] || item['الإحداثيات الجغرافية (GPS)'] || '',
        status,
        sharedNotarization: item.sharedNotarization || item['المأذونية المشتركة'],
        sharedNote: item.sharedNote || item['ملاحظة الاشتراك'] || item['ملاحظات الاشتراك المكاني'],
        createdAt: item.createdAt || item['تاريخ القيد'] || now,
        updatedAt: item.updatedAt || item['آخر تعديل'] || now,
        createdBy: item.createdBy || operatorName,
        updatedBy: item.updatedBy || operatorName,
        version: Number(item.version || 1)
      };
    });

    return {
      records: normalizedRecords,
      backupAuditLog,
      backupSettings,
      repairedCount,
      totalImported: normalizedRecords.length
    };
  }

  private static escapeXml(str: any): string {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  private static escapeHtml(str: any): string {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  private static escapeCsv(value: any): string {
    const str = String(value || '');
    if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }

  private static getDateStamp(): string {
    return new Date().toISOString().split('T')[0];
  }

  private static downloadBlob(content: string, filename: string, mimeType: string): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
