import { RecordItem, AuditLogEntry, AuditChange } from '../types';

export const STORAGE_KEY_AUDIT_USER = 'audit_user_name';
export const DEFAULT_AUDITOR_NAME = 'الأستاذ/ حسام الدين الخولي';

export function getAuditUserName(fallback: string = DEFAULT_AUDITOR_NAME): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_AUDIT_USER);
    if (saved && saved.trim()) {
      return saved.trim();
    }
  } catch (err) {
    console.error('Error reading audit user from localStorage:', err);
  }
  return fallback;
}

export function setAuditUserName(name: string): void {
  try {
    if (name && name.trim()) {
      localStorage.setItem(STORAGE_KEY_AUDIT_USER, name.trim());
    }
  } catch (err) {
    console.error('Error saving audit user to localStorage:', err);
  }
}

export function formatAuditDate(date: Date = new Date()): string {
  try {
    return date.toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  } catch {
    return date.toLocaleString();
  }
}

export function createAuditLogEntry(
  oldRecord: RecordItem | undefined | null,
  newValues: Omit<RecordItem, 'id'>,
  userName?: string,
  customAction?: AuditLogEntry['action'],
  customNote?: string
): AuditLogEntry | null {
  const author = userName?.trim() || getAuditUserName();
  const now = new Date();
  const formattedDate = formatAuditDate(now);
  const changes: AuditChange[] = [];

  if (!oldRecord) {
    // New Record Creation
    changes.push({
      field: 'name',
      fieldLabel: 'اسم الشارع',
      oldValue: '— (سجل جديد)',
      newValue: newValues.name
    });
    changes.push({
      field: 'permission',
      fieldLabel: 'المأذونية',
      oldValue: '—',
      newValue: newValues.permission
    });
    if (newValues.metadata?.trim()) {
      changes.push({
        field: 'metadata',
        fieldLabel: 'الملاحظات والحدود',
        oldValue: '—',
        newValue: newValues.metadata.trim()
      });
    }
    if (newValues.category?.trim()) {
      changes.push({
        field: 'category',
        fieldLabel: 'التصنيف',
        oldValue: '—',
        newValue: newValues.category.trim()
      });
    }

    return {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: now.toISOString(),
      formattedDate,
      userName: author,
      action: 'create',
      changes,
      note: customNote || 'إنشاء وقيد الشارع لأول مرة في المنظومة'
    };
  }

  // Compare each field between old and new
  if (oldRecord.name.trim() !== newValues.name.trim()) {
    changes.push({
      field: 'name',
      fieldLabel: 'اسم الشارع',
      oldValue: oldRecord.name.trim(),
      newValue: newValues.name.trim()
    });
  }

  if (oldRecord.permission.trim() !== newValues.permission.trim()) {
    changes.push({
      field: 'permission',
      fieldLabel: 'المأذونية المختصة',
      oldValue: oldRecord.permission.trim(),
      newValue: newValues.permission.trim()
    });
  }

  const oldMeta = (oldRecord.metadata || '').trim();
  const newMeta = (newValues.metadata || '').trim();
  if (oldMeta !== newMeta) {
    changes.push({
      field: 'metadata',
      fieldLabel: 'الملاحظات والحدود والتوثيق',
      oldValue: oldMeta || 'لا توجد ملاحظات سابقة',
      newValue: newMeta || 'تم إفراغ الملاحظات'
    });
  }

  const oldCat = (oldRecord.category || '').trim();
  const newCat = (newValues.category || '').trim();
  if (oldCat !== newCat) {
    changes.push({
      field: 'category',
      fieldLabel: 'التصنيف الجغرافي / الإداري',
      oldValue: oldCat || 'غير محدد',
      newValue: newCat || 'غير محدد'
    });
  }

  // If no fields changed and no custom note provided, don't create empty log
  if (changes.length === 0 && !customNote) {
    return null;
  }

  let action: AuditLogEntry['action'] = customAction || 'update';
  if (!customAction) {
    if (changes.length === 1 && changes[0].field === 'metadata') {
      action = 'note_update';
    } else if (changes.length === 1 && changes[0].field === 'permission') {
      action = 'permission_update';
    }
  }

  return {
    id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: now.toISOString(),
    formattedDate,
    userName: author,
    action,
    changes,
    note: customNote
  };
}

export function applyAuditLog(
  record: RecordItem,
  entry: AuditLogEntry
): RecordItem {
  const existingLogs = record.auditLogs || [];
  return {
    ...record,
    lastModifiedAt: entry.formattedDate,
    lastModifiedBy: entry.userName,
    auditLogs: [entry, ...existingLogs]
  };
}
