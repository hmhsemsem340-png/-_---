<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# 🏛️ منظومة الشوارع والمأذونيات بدمنهور

منظومة التوثيق الرقمي للشوارع والمأذونيات بمحافظة البحيرة (بندر دمنهور).
- **مالك ومطور المنظومة:** الأستاذ / حسام الدين الخولي
- **الدليل الشامل لكافة المميزات والإمكانيات الفائقة:** يرجى مراجعة ملف [`SYSTEM_FEATURES.md`](./SYSTEM_FEATURES.md).

## التشغيل محلياً (Run Locally)

1. تثبيت الحزم:
   `npm install`
2. تشغيل خادم التطوير:
   `npm run dev`

