import * as XLSX from 'xlsx';
import { readFileSync } from 'fs';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/';
const files = ['سكنيدة.ods','شبرا بحري.ods','شبرا قبلي.ods','قرطسا بحري.ods','قرطسا قبلي.ods','نقرها.ods','شبرا 1.ods','شبرا 2.ods','شبرا 3.ods'];

for (const f of files) {
  try {
    const wb = XLSX.read(readFileSync(dir + f), { type: 'buffer' });
    const sheets = wb.SheetNames;
    let total = 0;
    const sheetInfo = [];
    for (const sn of sheets) {
      const ws = wb.Sheets[sn];
      const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      const nonEmpty = rows.filter(r => r.some(c => String(c).trim() !== ''));
      sheetInfo.push({ sheet: sn, rows: nonEmpty.length });
      total += nonEmpty.length;
    }
    console.log(`=== ${f} ===`);
    console.log(`  sheets: ${sheets.join(', ')}`);
    console.log(`  total rows: ${total}`);
    for (const si of sheetInfo) console.log(`    - ${si.sheet}: ${si.rows} rows`);
  } catch (e) {
    console.log(`=== ${f} === ERROR: ${e.message}`);
  }
}