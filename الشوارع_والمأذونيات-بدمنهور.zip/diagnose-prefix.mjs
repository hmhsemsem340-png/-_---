import { readFileSync } from 'fs';

const dataFile = './src/data/initialData.ts';
const src = readFileSync(dataFile, 'utf8');
const records = [];
const re = /\{\s*id:\s*'([^']+)'\s*,\s*name:\s*'([^']*)'\s*,\s*permission:\s*'([^']*)'\s*,\s*metadata:\s*'([^']*)'\s*,\s*category:\s*'([^']*)'\s*\}/g;
let m;
while ((m = re.exec(src)) !== null) {
  records.push({ id: m[1], name: m[2], permission: m[3], metadata: m[4], category: m[5] });
}

const prefixes = ['ترعة', 'ميدان', 'كوبري', 'حارة', 'زقاق', 'عطفة', 'شارع', 'طريق', 'محور'];
for (const p of prefixes) {
  const matches = records.filter(r => r.name.startsWith(p + ' ') || r.name.startsWith(p + '.'));
  console.log(`\n=== "${p}" prefix: ${matches.length} records ===`);
  for (const r of matches.slice(0, 15)) {
    console.log(`  id=${r.id} name="${r.name}" perm=${r.permission} meta="${r.metadata}"`);
  }
}

const dupNames = {};
for (const r of records) {
  const key = r.name + '|' + r.permission;
  dupNames[key] = (dupNames[key] || 0) + 1;
}
console.log('\n=== DUPLICATES (same name+permission) ===');
for (const [k, v] of Object.entries(dupNames)) {
  if (v > 1) console.log(`  ${k}: ${v} copies`);
}