import { readFileSync, writeFileSync } from 'fs';
import { execSync } from 'child_process';

const dataFile = './src/data/initialData.ts';
const src = readFileSync(dataFile, 'utf8');
const records = [];
const re = /\{\s*id:\s*'([^']+)'\s*,\s*name:\s*'([^']*)'\s*,\s*permission:\s*'([^']*)'\s*,\s*metadata:\s*'([^']*)'\s*,\s*category:\s*'([^']*)'\s*\}/g;
let m;
while ((m = re.exec(src)) !== null) {
  records.push({ id: m[1], name: m[2], permission: m[3], metadata: m[4], category: m[5] });
}

const DISTRICT_HEX = {
  'شبرا بحري': '#dc2626',
  'سكنيدة': '#16a34a',
  'طاموس': '#111827',
  'شبرا قبلي': '#2563eb',
  'قرطسا بحري': '#f97316',
  'نقرها': '#92400e',
  'قرطسا قبلي': '#ec4899',
};

function districtHex(permission, metadata, name) {
  const haystack = `${permission || ''} ${metadata || ''} ${name || ''}`;
  for (const [k, v] of Object.entries(DISTRICT_HEX)) {
    if (haystack.includes(k)) return v;
  }
  return '#374151';
}

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const rows = records.map((r, i) => {
  const bg = i % 2 === 1 ? '#ECFDF5' : '#F0FDFA';
  const pc = districtHex(r.permission, r.metadata, r.name);
  return `<tr style="background:${bg}">
    <td style="border:1px solid #d1d5db;padding:5px 7px;text-align:center;color:#6b7280;font-size:9px">${i + 1}</td>
    <td style="border:1px solid #d1d5db;padding:5px 7px;font-weight:bold;color:#111827;font-size:9px">${esc(r.name)}</td>
    <td style="border:1px solid #d1d5db;padding:5px 7px;color:${pc};font-weight:bold;font-size:9px">${esc(r.permission || 'غير محدد')}</td>
    <td style="border:1px solid #d1d5db;padding:5px 7px;color:#374151;font-size:9px">${esc(r.category || 'شارع')}</td>
    <td style="border:1px solid #d1d5db;padding:5px 7px;color:#4b5563;font-size:9px">${esc(r.metadata || '-')}</td>
  </tr>`;
}).join('\n');

const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تقرير شوارع دمنهور</title>
<style>
  @page { size: A4 landscape; margin: 8mm; }
  * { box-sizing: border-box; }
  body {
    font-family: 'Amiri', 'Cairo', Tahoma, Arial, serif;
    direction: rtl;
    margin: 0;
    padding: 0;
    color: #1f2937;
  }
  .report-header {
    text-align: center;
    border-bottom: 3px solid #0E7490;
    padding-bottom: 8px;
    margin-bottom: 10px;
  }
  .report-header h1 { font-size: 18px; margin: 0 0 4px; color: #065F46; }
  .report-header p { margin: 0; color: #6b7280; font-size: 11px; }
  table { width: 100%; border-collapse: collapse; }
  th {
    background: #065F46;
    color: #ffffff;
    border: 1px solid #065F46;
    padding: 6px 7px;
    font-size: 10px;
    text-align: right;
  }
  td { font-size: 9px; }
  .report-footer {
    margin-top: 12px;
    padding-top: 6px;
    border-top: 1px solid #d1d5db;
    text-align: center;
    color: #6b7280;
    font-size: 10px;
  }
</style>
</head>
<body>
  <div class="report-header">
    <h1>تقرير شوارع دمنهور الشامل</h1>
    <p>القاعدة الأساسية النهائية — ${records.length} شارع — 12 سبتمبر 2026</p>
  </div>
  <table>
    <thead>
      <tr>
        <th style="width:30px">م</th>
        <th>اسم الشارع أو الحارة أو الزقاق</th>
        <th style="width:110px">المأذونية</th>
        <th style="width:90px">التصنيف</th>
        <th>البيانات الوصفية</th>
      </tr>
    </thead>
    <tbody>
${rows}
    </tbody>
  </table>
  <div class="report-footer">منظومة إدارة وتغذية البيانات المتقدمة — شوارع دمنهور 2025</div>
</body>
</html>`;

writeFileSync('/tmp/opencode/report.html', html, 'utf8');
console.log('HTML written:', records.length, 'records');

execSync('soffice --headless --convert-to pdf --outdir /tmp/opencode /tmp/opencode/report.html', { stdio: 'inherit' });
console.log('PDF generated');