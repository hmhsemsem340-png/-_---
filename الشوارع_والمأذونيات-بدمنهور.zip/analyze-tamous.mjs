import XLSX from 'xlsx';

const wb = XLSX.readFile('/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/طاموس.ods');
console.log('Sheets:', wb.SheetNames);

for (const name of wb.SheetNames) {
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  console.log(`\n=== Sheet: ${name} | rows: ${rows.length} ===`);
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    console.log(JSON.stringify(rows[i]));
  }
}