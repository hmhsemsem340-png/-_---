import * as XLSX from 'xlsx';
import { readFileSync } from 'fs';
import { execSync } from 'child_process';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';
const tamousDir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/';
const dataFile = './src/data/initialData.ts';

function splitPrefix(s) {
  let t = String(s).trim();
  let prefix = '';
  const m = t.match(/^(شارع|طريق|محور|حارة|زقاق|عطفة|ش\.|ش)\s+/i);
  if (m) {
    prefix = m[1] === 'ش' || m[1] === 'ش.' ? 'شارع' : m[1];
    t = t.slice(m[0].length);
  }
  return { name: t, prefix };
}

function normStreet(s) {
  const { name } = splitPrefix(s);
  let t = name;
  t = t.replace(/\([^)]*\)/g, ' ');
  t = t.replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  t = t.replace(/[^\u0600-\u06FF\s]/g, ' ');
  t = t.replace(/\s+/g, ' ').trim();
  return t;
}

function extractOds(file) {
  const wb = XLSX.read(readFileSync(file), { type: 'buffer' });
  const names = [];
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    for (const r of rows) {
      const cell = String(r[0] || '').trim();
      if (cell && !/^\d+$/.test(cell)) {
        names.push(cell);
      }
    }
  }
  return names;
}

function extractOdtStreets(file) {
  execSync(`unzip -o -q "${file}" content.xml -d /tmp/opencode/odt_x`);
  const content = readFileSync('/tmp/opencode/odt_x/content.xml', 'utf8');
  const texts = content.match(/<text:p[^>]*>(.*?)<\/text:p>/g) || [];
  const lines = [];
  for (const t of texts) {
    let s = t.replace(/<[^>]+>/g, '');
    s = s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    s = s.trim();
    if (s) lines.push(s);
  }
  const start = lines.findIndex(l => l.includes('الشوارع والطرق'));
  const end = lines.findIndex(l => l.includes('المعالم والمنشآت'));
  const section = lines.slice(start + 1, end);
  const names = [];
  let prevWasNumber = false;
  for (const l of section) {
    if (/^\d+$/.test(l)) {
      prevWasNumber = true;
      continue;
    }
    if (/^[أ-هـ]\./.test(l) || /^\d+\./.test(l)) {
      prevWasNumber = false;
      continue;
    }
    if (prevWasNumber) {
      names.push(l);
      prevWasNumber = false;
    }
  }
  return names;
}

const official = {
  'سكنيدة': extractOds(dir + 'سكنيدة.ods'),
  'شبرا بحري': extractOds(dir + 'شبرا بحري.ods'),
  'شبرا قبلي': extractOdtStreets(dir + 'شبرا قبلي.odt'),
  'قرطسا بحري': extractOds(dir + 'قرطسا بحري.ods'),
  'قرطسا قبلي': extractOds(dir + 'قرطسا قبلي.ods'),
  'نقرها': extractOds(dir + 'نقرها.ods'),
  'طاموس': extractOds(tamousDir + 'طاموس.ods'),
};

const officialNorm = {};
for (const [perm, names] of Object.entries(official)) {
  officialNorm[perm] = new Set(names.map(normStreet));
}

const src = readFileSync(dataFile, 'utf8');
const records = [];
const re = /\{\s*id:\s*'([^']+)'\s*,\s*name:\s*'([^']*)'\s*,\s*permission:\s*'([^']*)'\s*,\s*metadata:\s*'([^']*)'\s*,\s*category:\s*'([^']*)'\s*\}/g;
let m;
while ((m = re.exec(src)) !== null) {
  records.push({ id: m[1], name: m[2], permission: m[3], metadata: m[4], category: m[5] });
}

const SIX = ['سكنيدة', 'شبرا بحري', 'شبرا قبلي', 'قرطسا بحري', 'قرطسا قبلي', 'نقرها'];
const ALL = [...SIX, 'طاموس'];

console.log(`Total records: ${records.length}\n`);

let errors = 0;

for (const r of records) {
  const n = normStreet(r.name);
  const matches = ALL.filter(p => officialNorm[p] && officialNorm[p].has(n));

  if (SIX.includes(r.permission)) {
    if (matches.length === 0) {
      console.log(`ERROR: ${r.permission} record not in any official file: "${r.name}"`);
      errors++;
    } else if (matches.length === 1 && matches[0] !== r.permission) {
      console.log(`ERROR: ${r.permission} record matches only ${matches[0]}: "${r.name}"`);
      errors++;
    }
  }

  if (r.permission === 'مأذونية غير رسمي') {
    if (matches.length === 1) {
      console.log(`ERROR: unofficial record matches only ${matches[0]}: "${r.name}"`);
      errors++;
    }
  }
}

const baseNames = new Set(records.map(r => normStreet(r.name)));
for (const [perm, set] of Object.entries(officialNorm)) {
  if (!SIX.includes(perm)) continue;
  for (const n of set) {
    if (!baseNames.has(n)) {
      console.log(`ERROR: official ${perm} name missing from base: "${n}"`);
      errors++;
    }
  }
}

console.log(errors === 0 ? 'ALL CHECKS PASSED' : `${errors} ERRORS FOUND`);