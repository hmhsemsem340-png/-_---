import * as XLSX from 'xlsx';
import { readFileSync } from 'fs';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';
const files = ['سكنيدة.ods','شبرا بحري.ods','قرطسا بحري.ods','قرطسا قبلي.ods','نقرها.ods'];

for (const f of files) {
  try {
    const wb = XLSX.read(readFileSync(dir + f), { type: 'buffer' });
    console.log(`\n=== ${f} ===`);
    for (const sn of wb.SheetNames) {
      const ws = wb.Sheets[sn];
      const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      const nonEmpty = rows.filter(r => r.some(c => String(c).trim() !== ''));
      console.log(`  Sheet "${sn}": ${nonEmpty.length} rows`);
      console.log(`  First 5 rows:`);
      for (const r of nonEmpty.slice(0, 5)) {
        console.log(`    ${JSON.stringify(r)}`);
      }
    }
  } catch (e) {
    console.log(`\n=== ${f} === ERROR: ${e.message}`);
  }
}