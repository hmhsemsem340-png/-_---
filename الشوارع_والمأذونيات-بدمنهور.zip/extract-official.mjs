import * as XLSX from 'xlsx';
import { readFileSync } from 'fs';
import { execSync } from 'child_process';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';

function norm(s) {
  return String(s).trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[^\u0600-\u06FF\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractOds(file) {
  const wb = XLSX.read(readFileSync(dir + file), { type: 'buffer' });
  const names = [];
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    for (const r of rows) {
      const cell = String(r[0] || '').trim();
      if (cell && !/^\d+$/.test(cell)) {
        names.push(cell);
      }
    }
  }
  return names;
}

function extractOdtStreets(file) {
  execSync(`unzip -o -q "${dir}${file}" content.xml -d /tmp/opencode/odt_x`);
  const content = readFileSync('/tmp/opencode/odt_x/content.xml', 'utf8');
  const texts = content.match(/<text:p[^>]*>(.*?)<\/text:p>/g) || [];
  const lines = [];
  for (const t of texts) {
    let s = t.replace(/<[^>]+>/g, '');
    s = s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    s = s.trim();
    if (s) lines.push(s);
  }
  // Section 1: الشوارع والطرق (from "1. الشوارع والطرق" to "2. المعالم والمنشآت")
  const start = lines.findIndex(l => l.includes('الشوارع والطرق'));
  const end = lines.findIndex(l => l.includes('المعالم والمنشآت'));
  const section = lines.slice(start + 1, end);
  const names = [];
  let prevWasNumber = false;
  for (const l of section) {
    if (/^\d+$/.test(l)) {
      prevWasNumber = true;
      continue;
    }
    if (/^[أ-هـ]\./.test(l) || /^\d+\./.test(l)) {
      prevWasNumber = false;
      continue;
    }
    if (prevWasNumber) {
      names.push(l);
      prevWasNumber = false;
    }
  }
  return names;
}

const official = {
  'سكنيدة': extractOds('سكنيدة.ods'),
  'شبرا بحري': extractOds('شبرا بحري.ods'),
  'شبرا قبلي': extractOdtStreets('شبرا قبلي.odt'),
  'قرطسا بحري': extractOds('قرطسا بحري.ods'),
  'قرطسا قبلي': extractOds('قرطسا قبلي.ods'),
  'نقرها': extractOds('نقرها.ods'),
};

for (const [perm, names] of Object.entries(official)) {
  console.log(`\n=== ${perm}: ${names.length} official streets ===`);
  console.log(JSON.stringify(names, null, 0));
}