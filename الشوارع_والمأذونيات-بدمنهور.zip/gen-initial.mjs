import XLSX from 'xlsx';
import { writeFileSync } from 'fs';

const wb = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const ws = wb.Sheets['البيانات المنظمة'];
const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

const records = [];
for (let i = 1; i < rows.length; i++) {
  const r = rows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const permission = r[1] ? String(r[1]).trim() : '';
  const metadata = r[2] ? String(r[2]).trim() : '';
  const category = r[3] ? String(r[3]).trim() : 'شارع';
  records.push({
    id: String(i),
    name,
    permission,
    metadata,
    category
  });
}

const lines = records.map(r => {
  const esc = (s) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  return `  { id: '${r.id}', name: '${esc(r.name)}', permission: '${esc(r.permission)}', metadata: '${esc(r.metadata)}', category: '${esc(r.category)}' },`;
});

const content = `import { RecordItem } from '../types';

export const INITIAL_RECORDS: RecordItem[] = [
${lines.join('\n')}
];
`;

writeFileSync('/home/sam2/Music/الشوارع_والمأذونيات/src/data/initialData.ts', content, 'utf-8');
console.log('Wrote initialData.ts with', records.length, 'records');
console.log('File size:', (content.length / 1024).toFixed(1), 'KB');