import XLSX from 'xlsx';

function normalize(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ');
}

const wbT = XLSX.readFile('/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/طاموس.ods');
const wsT = wbT.Sheets[wbT.SheetNames[0]];
const tRows = XLSX.utils.sheet_to_json(wsT, { header: 1 });

const tamous = [];
for (let i = 1; i < tRows.length; i++) {
  const r = tRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  tamous.push({ name, norm: normalize(name) });
}

console.log('Official طاموس streets:', tamous.length);

const wbBase = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const wsBase = wbBase.Sheets['البيانات المنظمة'];
const baseRows = XLSX.utils.sheet_to_json(wsBase, { header: 1 });

const baseRecords = [];
for (let i = 1; i < baseRows.length; i++) {
  const r = baseRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  baseRecords.push({
    name,
    permission: r[1] ? String(r[1]).trim() : '',
    metadata: r[2] ? String(r[2]).trim() : '',
    category: r[3] ? String(r[3]).trim() : 'شارع',
    norm: normalize(name)
  });
}

const tamousNorm = new Set(tamous.map(t => t.norm));

// Streets currently classified as طاموس in base
const baseTamous = baseRecords.filter(r => r.permission === 'طاموس');
console.log('Base streets with permission=طاموس:', baseTamous.length);

// Of those, which are in the official file?
const tamousInOfficial = baseTamous.filter(r => tamousNorm.has(r.norm));
const tamousNotInOfficial = baseTamous.filter(r => !tamousNorm.has(r.norm));
console.log('  In official file (keep as طاموس):', tamousInOfficial.length);
console.log('  NOT in official file (should become غير رسمي):', tamousNotInOfficial.length);

// Official streets NOT in base at all
const baseNorm = new Set(baseRecords.map(r => r.norm));
const officialNotInBase = tamous.filter(t => !baseNorm.has(t.norm));
console.log('\nOfficial طاموس streets NOT in base:', officialNotInBase.length);
officialNotInBase.forEach(t => console.log(`  [${t.name}]`));

// Official streets in base but with different permission
const officialInBaseOther = tamous.filter(t => {
  const matches = baseRecords.filter(r => r.norm === t.norm);
  return matches.length > 0 && matches.every(r => r.permission !== 'طاموس');
});
console.log('\nOfficial طاموس streets in base with DIFFERENT permission:', officialInBaseOther.length);
officialInBaseOther.forEach(t => {
  const matches = baseRecords.filter(r => r.norm === t.norm);
  matches.forEach(m => console.log(`  [${t.name}] base perm=${m.permission} cat=${m.category}`));
});

console.log('\n=== Streets to reclassify (currently طاموس but NOT official) ===');
tamousNotInOfficial.forEach(r => console.log(`  [${r.name}] cat=${r.category}`));