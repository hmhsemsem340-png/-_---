import * as XLSX from 'xlsx';
import { readFileSync } from 'fs';
import { execSync } from 'child_process';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';

function norm(s) {
  return String(s).trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[^\u0600-\u06FF\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractOds(file) {
  const wb = XLSX.read(readFileSync(dir + file), { type: 'buffer' });
  const names = [];
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    for (const r of rows) {
      const cell = String(r[0] || '').trim();
      if (cell && !/^\d+$/.test(cell)) {
        names.push(cell);
      }
    }
  }
  return names;
}

function extractOdt(file) {
  execSync(`unzip -o -q "${dir}${file}" content.xml -d /tmp/opencode/odt_x`);
  const content = readFileSync('/tmp/opencode/odt_x/content.xml', 'utf8');
  const texts = content.match(/<text:p[^>]*>(.*?)<\/text:p>/g) || [];
  const lines = [];
  for (const t of texts) {
    let s = t.replace(/<[^>]+>/g, '');
    s = s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    s = s.trim();
    if (s) lines.push(s);
  }
  return lines;
}

const results = {};

// ODS files
for (const f of ['سكنيدة.ods', 'شبرا بحري.ods', 'قرطسا بحري.ods', 'قرطسا قبلي.ods', 'نقرها.ods']) {
  const names = extractOds(f);
  results[f] = names;
  console.log(`\n=== ${f}: ${names.length} names ===`);
  console.log('First 10:', JSON.stringify(names.slice(0, 10), null, 0));
}

// ODT file
const odtLines = extractOdt('شبرا قبلي.odt');
console.log(`\n=== شبرا قبلي.odt: ${odtLines.length} lines ===`);
console.log('All lines:');
odtLines.forEach((l, i) => console.log(`${i}: ${l}`));