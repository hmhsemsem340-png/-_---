import * as XLSX from 'xlsx';
import { readFileSync, writeFileSync } from 'fs';
import { execSync } from 'child_process';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';
const tamousDir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/';
const dataFile = './src/data/initialData.ts';

function splitPrefix(s) {
  let t = String(s).trim();
  let prefix = '';
  const m = t.match(/^(شارع|طريق|محور|حارة|زقاق|عطفة|ش\.|ش)\s+/i);
  if (m) {
    prefix = m[1] === 'ش' || m[1] === 'ش.' ? 'شارع' : m[1];
    t = t.slice(m[0].length);
  }
  return { name: t, prefix };
}

function normStreet(s) {
  const { name } = splitPrefix(s);
  let t = name;
  t = t.replace(/\([^)]*\)/g, ' ');
  t = t.replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
  t = t.replace(/[^\u0600-\u06FF\s]/g, ' ');
  t = t.replace(/\s+/g, ' ').trim();
  return t;
}

function extractOds(file) {
  const wb = XLSX.read(readFileSync(file), { type: 'buffer' });
  const names = [];
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    for (const r of rows) {
      const cell = String(r[0] || '').trim();
      if (cell && !/^\d+$/.test(cell)) {
        names.push(cell);
      }
    }
  }
  return names;
}

function extractOdtStreets(file) {
  execSync(`unzip -o -q "${file}" content.xml -d /tmp/opencode/odt_x`);
  const content = readFileSync('/tmp/opencode/odt_x/content.xml', 'utf8');
  const texts = content.match(/<text:p[^>]*>(.*?)<\/text:p>/g) || [];
  const lines = [];
  for (const t of texts) {
    let s = t.replace(/<[^>]+>/g, '');
    s = s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    s = s.trim();
    if (s) lines.push(s);
  }
  const start = lines.findIndex(l => l.includes('الشوارع والطرق'));
  const end = lines.findIndex(l => l.includes('المعالم والمنشآت'));
  const section = lines.slice(start + 1, end);
  const names = [];
  let prevWasNumber = false;
  for (const l of section) {
    if (/^\d+$/.test(l)) {
      prevWasNumber = true;
      continue;
    }
    if (/^[أ-هـ]\./.test(l) || /^\d+\./.test(l)) {
      prevWasNumber = false;
      continue;
    }
    if (prevWasNumber) {
      names.push(l);
      prevWasNumber = false;
    }
  }
  return names;
}

const official = {
  'سكنيدة': extractOds(dir + 'سكنيدة.ods'),
  'شبرا بحري': extractOds(dir + 'شبرا بحري.ods'),
  'شبرا قبلي': extractOdtStreets(dir + 'شبرا قبلي.odt'),
  'قرطسا بحري': extractOds(dir + 'قرطسا بحري.ods'),
  'قرطسا قبلي': extractOds(dir + 'قرطسا قبلي.ods'),
  'نقرها': extractOds(dir + 'نقرها.ods'),
  'طاموس': extractOds(tamousDir + 'طاموس.ods'),
};

const officialNorm = {};
for (const [perm, names] of Object.entries(official)) {
  officialNorm[perm] = new Set(names.map(normStreet));
}

const src = readFileSync(dataFile, 'utf8');
const records = [];
const re = /\{\s*id:\s*'([^']+)'\s*,\s*name:\s*'([^']*)'\s*,\s*permission:\s*'([^']*)'\s*,\s*metadata:\s*'([^']*)'\s*,\s*category:\s*'([^']*)'\s*\}/g;
let m;
while ((m = re.exec(src)) !== null) {
  records.push({ id: m[1], name: m[2], permission: m[3], metadata: m[4], category: m[5] });
}

const SIX = ['سكنيدة', 'شبرا بحري', 'شبرا قبلي', 'قرطسا بحري', 'قرطسا قبلي', 'نقرها'];
const ALL = [...SIX, 'طاموس'];

let reclassified = 0;
let updatedToOfficial = 0;
let addedNew = 0;
let keptAmbiguous = 0;
const addedNames = [];
const reclassifiedNames = [];

for (const r of records) {
  const n = normStreet(r.name);
  const matches = ALL.filter(p => officialNorm[p] && officialNorm[p].has(n));

  if (matches.length === 0) {
    if (SIX.includes(r.permission)) {
      r.permission = 'مأذونية غير رسمي';
      r.category = 'مأذونية غير رسمي';
      reclassified++;
      reclassifiedNames.push(r.name);
    }
    continue;
  }

  if (matches.length === 1) {
    const target = matches[0];
    if (r.permission !== target) {
      r.permission = target;
      r.category = 'مأذونية رسمية';
      updatedToOfficial++;
    } else if (r.category !== 'مأذونية رسمية') {
      r.category = 'مأذونية رسمية';
    }
  } else {
    keptAmbiguous++;
  }
}

const baseNames = new Set(records.map(r => normStreet(r.name)));
for (const [perm, set] of Object.entries(officialNorm)) {
  if (!SIX.includes(perm)) continue;
  for (const n of set) {
    if (!baseNames.has(n)) {
      const original = official[perm].find(o => normStreet(o) === n);
      const { name, prefix } = splitPrefix(original || n);
      records.push({
        id: String(records.length + 1),
        name,
        permission: perm,
        metadata: prefix ? prefix : '',
        category: 'مأذونية رسمية',
      });
      baseNames.add(n);
      addedNew++;
      addedNames.push({ name, permission: perm, prefix });
    }
  }
}

const lines = records.map(r =>
  `  { id: '${r.id}', name: '${r.name.replace(/'/g, "\\'")}', permission: '${r.permission}', metadata: '${r.metadata.replace(/'/g, "\\'")}', category: '${r.category}' },`
);
const output = `import { RecordItem } from '../types';\n\nexport const INITIAL_RECORDS: RecordItem[] = [\n${lines.join('\n')}\n];\n`;
writeFileSync(dataFile, output);

const finalCounts = {};
for (const p of ALL) {
  finalCounts[p] = records.filter(r => r.permission === p).length;
}
finalCounts['مأذونية غير رسمي'] = records.filter(r => r.permission === 'مأذونية غير رسمي').length;
finalCounts['غير محدد'] = records.filter(r => r.permission === 'غير محدد').length;

console.log('=== UPDATE SUMMARY ===');
console.log(`Total records: ${records.length}`);
console.log(`Reclassified to مأذونية غير رسمي: ${reclassified}`);
console.log(`Updated to official: ${updatedToOfficial}`);
console.log(`Added new: ${addedNew}`);
console.log(`Kept ambiguous (shared names): ${keptAmbiguous}`);
console.log('\nFinal counts:');
console.log(JSON.stringify(finalCounts, null, 2));
console.log('\nAdded names:');
for (const a of addedNames) console.log(`  - ${a.name} (${a.permission})${a.prefix ? ' [prefix: ' + a.prefix + ']' : ''}`);
console.log('\nReclassified names (first 30):');
for (const n of reclassifiedNames.slice(0, 30)) console.log(`  - ${n}`);