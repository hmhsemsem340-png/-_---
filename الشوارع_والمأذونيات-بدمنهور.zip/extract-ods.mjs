import XLSX from 'xlsx';
import { writeFileSync } from 'fs';

const wb = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const ws = wb.Sheets['البيانات المنظمة'];
const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

const records = [];
const seen = new Set();
let skipped = 0;

for (let i = 1; i < rows.length; i++) {
  const r = rows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) { skipped++; continue; }

  const permission = r[1] ? String(r[1]).trim() : '';
  const metadata = r[2] ? String(r[2]).trim() : '';
  const category = r[3] ? String(r[3]).trim() : 'شارع';

  records.push({
    id: `imp_${i}_${Date.now().toString(36)}`,
    name,
    permission,
    metadata,
    category
  });
}

const backup = {
  version: '2.0',
  exportDate: new Date().toISOString(),
  source: 'شوارع_دمنهور_النهائي.ods',
  records,
  settings: {
    fontFamily: 'Tahoma, Arial, sans-serif',
    fontSize: 'base',
    printFontSize: '11pt',
    tableDensity: 'normal',
    enableZebra: true,
    cellBorders: true
  }
};

const outPath = '/home/sam2/Music/الشوارع_والمأذونيات/street_records_backup.json';
writeFileSync(outPath, JSON.stringify(backup, null, 2), 'utf-8');

console.log('Total records:', records.length);
console.log('Skipped (empty name):', skipped);
console.log('Output:', outPath);

const permCount = {};
records.forEach(r => {
  const p = r.permission || '(فارغ)';
  permCount[p] = (permCount[p] || 0) + 1;
});
console.log('\n--- Permission distribution ---');
Object.entries(permCount).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log(`  ${v}x ${k}`));

const catCount = {};
records.forEach(r => {
  const c = r.category || '(فارغ)';
  catCount[c] = (catCount[c] || 0) + 1;
});
console.log('\n--- Category distribution ---');
Object.entries(catCount).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log(`  ${v}x ${k}`));

console.log('\n--- Sample records ---');
records.slice(0, 5).forEach(r => console.log(JSON.stringify(r)));