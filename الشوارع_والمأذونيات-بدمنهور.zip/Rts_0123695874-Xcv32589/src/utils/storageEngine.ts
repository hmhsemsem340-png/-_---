// ============================================================
// 🗄️ محرك التخزين المحلي والذاكرة وحصانة البيانات
// LocalStorage & Multi-Tier Undo Storage Engine (Air-Gapped)
// ============================================================

import { StreetRecord, AuditLogEntry, UserSettings, UndoSnapshot, FieldChange } from '../types';
import { INITIAL_DAMANHOUR_STREETS } from '../data/initialData';

const STORAGE_KEYS = {
  RECORDS: 'street_data_records_v2',
  AUDIT_LOG: 'street_data_audit_v2',
  SETTINGS: 'street_data_settings_v2',
  UNDO_STACK: 'street_data_undo_v2',
};

const MAX_UNDO_DEPTH = 15;

const DEFAULT_SETTINGS: UserSettings = {
  operatorName: 'الأستاذ / حسام الدين الخولي',
  theme: 'excel-green',
  tableDensity: 'normal',
  viewMode: 'default',
  fontSize: 14,
  showNotes: true,
  showSharedBadge: true,
  autoSave: true,
  confirmDelete: true,
  language: 'ar',
  shortcutsEnabled: true,
  exportFormat: 'excel',
  exportColors: true,
  exportBorders: true,
  exportHeader: true,
  exportFooter: true,
  exportRtl: true,
  exportWatermark: true,
  exportSignature: true,
  backupFrequency: 'daily',
  encryptBackup: true,
  appLockEnabled: false
};

export class StorageEngine {
  /**
   * تحميل السجلات من LocalStorage أو التهيئة بالبيانات الأولية
   */
  static loadRecords(): StreetRecord[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.RECORDS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('خطأ في قراءة السجلات من الذاكرة المحلية:', e);
    }

    // تهيئة أولية
    this.saveRecordsDirect(INITIAL_DAMANHOUR_STREETS);
    return INITIAL_DAMANHOUR_STREETS;
  }

  /**
   * حفظ السجلات المباشر دون عمل لقطة تراجع
   */
  static saveRecordsDirect(records: StreetRecord[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(records));
    } catch (e) {
      console.error('فشل حفظ السجلات في LocalStorage:', e);
    }
  }

  /**
   * حفظ السجلات مع أخذ لقطة تراجع (Snapshot) متعددة المراحل حتى 15 لقطة
   */
  static saveRecordsWithUndo(
    currentRecords: StreetRecord[],
    newRecords: StreetRecord[],
    action: string,
    description: string
  ): void {
    // أخذ لقطة من الحالة الحالية قبل التعديل
    this.pushUndoSnapshot({
      id: `undo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      action,
      description,
      records: currentRecords
    });

    // حفظ البيانات الجديدة
    this.saveRecordsDirect(newRecords);
  }

  /**
   * إضافة لقطة تراجع للـ Stack
   */
  static pushUndoSnapshot(snapshot: UndoSnapshot): void {
    try {
      const stack = this.loadUndoStack();
      stack.push(snapshot);
      // الحفاظ على سقف 15 لقطة متتالية
      while (stack.length > MAX_UNDO_DEPTH) {
        stack.shift();
      }
      localStorage.setItem(STORAGE_KEYS.UNDO_STACK, JSON.stringify(stack));
    } catch (e) {
      console.error('فشل حفظ لقطة التراجع:', e);
    }
  }

  /**
   * استرجاع وتفريغ آخر لقطة تراجع
   */
  static popUndoSnapshot(): UndoSnapshot | null {
    try {
      const stack = this.loadUndoStack();
      if (stack.length === 0) return null;
      const lastSnapshot = stack.pop();
      localStorage.setItem(STORAGE_KEYS.UNDO_STACK, JSON.stringify(stack));
      return lastSnapshot || null;
    } catch (e) {
      console.error('فشل استعادة لقطة التراجع:', e);
      return null;
    }
  }

  static loadUndoStack(): UndoSnapshot[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.UNDO_STACK);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  static getUndoCount(): number {
    return this.loadUndoStack().length;
  }

  // ═══ إدارة سجل التعديلات (Audit Log) ═══

  static loadAuditLog(): AuditLogEntry[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOG);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  static addAuditEntry(entry: AuditLogEntry): void {
    try {
      const log = this.loadAuditLog();
      log.unshift(entry); // وضع الأحدث أولاً
      // الاحتفاظ بآخر 1000 عملية تدقيق
      if (log.length > 1000) log.length = 1000;
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOG, JSON.stringify(log));
    } catch (e) {
      console.error('فشل تسجيل حركة التعديل:', e);
    }
  }

  static logChange(
    recordId: string,
    recordName: string,
    action: AuditLogEntry['action'],
    changes: FieldChange[],
    notes: string,
    operatorName: string
  ): void {
    const entry: AuditLogEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      recordId,
      recordName,
      timestamp: new Date().toISOString(),
      action,
      operatorName,
      changes,
      notes
    };
    this.addAuditEntry(entry);
  }

  // ═══ الإعدادات ═══

  static loadSettings(): UserSettings {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (raw) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
      }
    } catch {}
    return DEFAULT_SETTINGS;
  }

  static saveSettings(settings: UserSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('فشل حفظ الإعدادات:', e);
    }
  }

  /**
   * حفظ أو تعديل سجل واحد مع توثيق التدقيق ولقطة التراجع
   */
  static saveRecord(recordData: Partial<StreetRecord>, operatorName: string): StreetRecord[] {
    const currentRecords = this.loadRecords();
    let updatedRecords: StreetRecord[];
    const now = new Date().toISOString();

    if (recordData.id) {
      // تعديل سجل قائم
      const existing = currentRecords.find(r => r.id === recordData.id);
      const version = (existing?.version || 1) + 1;
      
      const updatedItem: StreetRecord = {
        id: recordData.id,
        streetName: recordData.streetName || existing?.streetName || '',
        normalizedStreetName: recordData.streetName ? recordData.streetName.toLowerCase() : existing?.normalizedStreetName || '',
        notarization: recordData.notarization || existing?.notarization || 'شبرا بحري',
        category: recordData.category || existing?.category || 'مأذونية رسمية',
        recordType: recordData.recordType || existing?.recordType || 'شارع',
        description: recordData.description !== undefined ? recordData.description : existing?.description || '',
        landmarks: recordData.landmarks !== undefined ? recordData.landmarks : existing?.landmarks || '',
        boundaries: recordData.boundaries !== undefined ? recordData.boundaries : existing?.boundaries || '',
        nationalId: recordData.nationalId !== undefined ? recordData.nationalId : existing?.nationalId || '',
        contractDate: recordData.contractDate !== undefined ? recordData.contractDate : existing?.contractDate || '',
        gpsCoordinates: recordData.gpsCoordinates !== undefined ? recordData.gpsCoordinates : existing?.gpsCoordinates || '',
        status: recordData.status || existing?.status || 'نشط',
        sharedNotarization: recordData.sharedNotarization,
        sharedNote: recordData.sharedNote,
        version,
        createdAt: existing?.createdAt || now,
        createdBy: existing?.createdBy || operatorName,
        updatedAt: now,
        updatedBy: operatorName
      };

      updatedRecords = currentRecords.map(r => r.id === recordData.id ? updatedItem : r);

      this.logChange(
        updatedItem.id,
        updatedItem.streetName,
        'تعديل',
        [{ fieldName: 'all', fieldLabel: 'تحديث بيانات الشارع', oldValue: existing?.streetName || '', newValue: updatedItem.streetName }],
        `تعديل بيانات شارع ${updatedItem.streetName} بواسطة ${operatorName}`,
        operatorName
      );

      this.saveRecordsWithUndo(currentRecords, updatedRecords, 'تعديل سجل', `تعديل شارع: ${updatedItem.streetName}`);
    } else {
      // إنشاء سجل جديد
      const newId = `street_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const newItem: StreetRecord = {
        id: newId,
        streetName: recordData.streetName || '',
        normalizedStreetName: recordData.streetName ? recordData.streetName.toLowerCase() : '',
        notarization: recordData.notarization || 'شبرا بحري',
        category: recordData.category || 'مأذونية رسمية',
        recordType: recordData.recordType || 'شارع',
        description: recordData.description || '',
        landmarks: recordData.landmarks || '',
        boundaries: recordData.boundaries || '',
        nationalId: recordData.nationalId || '',
        contractDate: recordData.contractDate || '',
        gpsCoordinates: recordData.gpsCoordinates || '',
        status: recordData.status || 'نشط',
        sharedNotarization: recordData.sharedNotarization,
        sharedNote: recordData.sharedNote,
        version: 1,
        createdAt: now,
        createdBy: operatorName,
        updatedAt: now,
        updatedBy: operatorName
      };

      updatedRecords = [newItem, ...currentRecords];

      this.logChange(
        newItem.id,
        newItem.streetName,
        'إنشاء',
        [{ fieldName: 'streetName', fieldLabel: 'اسم الشارع', oldValue: '', newValue: newItem.streetName }],
        `إضافة شارع جديد: ${newItem.streetName} بجهة مأذونية ${newItem.notarization}`,
        operatorName
      );

      this.saveRecordsWithUndo(currentRecords, updatedRecords, 'إضافة سجل', `إضافة شارع: ${newItem.streetName}`);
    }

    return updatedRecords;
  }

  /**
   * حذف سجل مع أخذ لقطة تراجع وتسجيل التدقيق
   */
  static deleteRecord(id: string, operatorName: string): StreetRecord[] {
    const currentRecords = this.loadRecords();
    const target = currentRecords.find(r => r.id === id);
    const updatedRecords = currentRecords.filter(r => r.id !== id);

    if (target) {
      this.logChange(
        target.id,
        target.streetName,
        'حذف',
        [{ fieldName: 'status', fieldLabel: 'الحالة', oldValue: 'نشط', newValue: 'محذوف' }],
        `حذف شارع ${target.streetName} من مأذونية ${target.notarization}`,
        operatorName
      );
    }

    this.saveRecordsWithUndo(currentRecords, updatedRecords, 'حذف سجل', `حذف شارع: ${target?.streetName || id}`);
    return updatedRecords;
  }

  /**
   * حفظ مجموعة سجلات مباشرة مع لقطة تراجع
   */
  static saveRecordsDirectly(newRecords: StreetRecord[], action: string, operatorName: string): void {
    const currentRecords = this.loadRecords();
    this.saveRecordsWithUndo(currentRecords, newRecords, action, `${action} بواسطة ${operatorName}`);
  }

  /**
   * استرجاع لقطة التراجع
   */
  static undo(): StreetRecord[] | null {
    const snapshot = this.popUndoSnapshot();
    if (!snapshot) return null;
    this.saveRecordsDirect(snapshot.records);
    return snapshot.records;
  }

  /**
   * استعادة قاعدة البيانات الأولية المعتمدة
   */
  static resetToInitial(operatorName: string): StreetRecord[] {
    const currentRecords = this.loadRecords();
    this.resetToDefault(currentRecords);
    this.logChange(
      'system',
      'قاعدة البيانات المعتمدة',
      'ترميم',
      [],
      `استعادة قاعدة البيانات المعتمدة الأصلية (2943 شارع ومأذونية)`,
      operatorName
    );
    return INITIAL_DAMANHOUR_STREETS;
  }

  /**
   * إعادة ضبط وتعيين قاعدة البيانات للوضع الافتراضي
   */
  static resetToDefault(currentRecords: StreetRecord[]): void {
    this.saveRecordsWithUndo(
      currentRecords,
      INITIAL_DAMANHOUR_STREETS,
      'إعادة تعيين',
      'إعادة ضبط المنظومة للبيانات المعتمدة الأصلية'
    );
  }
}
