// ============================================================
// 🔧 محرك كشف وترميم النصوص العربية التالفة (Mojibake Engine)
// Reconstruction of Corrupted Windows-1256 / UTF-8 Encoded Data
// ============================================================

import { ArabicUtils } from './arabicUtils';

/**
 * خريطة بايتات Windows-1256 إلى اليونيكود العربي
 */
const WIN1256_BYTE_MAP: Record<number, string> = {
  0xC0: '\u0640', // تطويل
  0xC1: '\u0621', // همزة
  0xC2: '\u0622', // آ
  0xC3: '\u0623', // أ
  0xC4: '\u0624', // ؤ
  0xC5: '\u0625', // إ
  0xC6: '\u0626', // ئ
  0xC7: '\u0627', // ا
  0xC8: '\u0628', // ب
  0xC9: '\u0629', // ة
  0xCA: '\u062A', // ت
  0xCB: '\u062B', // ث
  0xCC: '\u062C', // ج
  0xCD: '\u062D', // ح
  0xCE: '\u062E', // خ
  0xCF: '\u062F', // د
  0xD0: '\u0630', // ذ
  0xD1: '\u0631', // ر
  0xD2: '\u0632', // ز
  0xD3: '\u0633', // س
  0xD4: '\u0634', // ش
  0xD5: '\u0635', // ص
  0xD6: '\u0636', // ض
  0xD7: '\u0637', // ط
  0xD8: '\u0638', // ظ
  0xD9: '\u0639', // ع
  0xDA: '\u063A', // غ
  0xE0: '\u0640', // تطويل
  0xE1: '\u0641', // ف
  0xE2: '\u0642', // ق
  0xE3: '\u0643', // ك
  0xE4: '\u0644', // ل
  0xE5: '\u0645', // م
  0xE6: '\u0646', // ن
  0xE7: '\u0647', // هـ
  0xE8: '\u0648', // و
  0xE9: '\u0649', // ى
  0xEA: '\u064A', // ي
  0xEB: '\u064B', // تنوين فتح
  0xEC: '\u064C', // تنوين ضم
  0xED: '\u064D', // تنوين كسر
  0xEE: '\u064E', // فتحة
  0xEF: '\u064F', // ضمة
  0xF0: '\u0650', // كسرة
  0xF1: '\u0651', // شدة
  0xF2: '\u0652', // سكون
};

/**
 * خريطة استبدال الأنماط الشائعة للموجيباكي العربي في ملفات ويندوز وإكسيل القديمة
 */
const COMMON_MOJIBAKE_REPLACEMENTS: Array<[RegExp, string]> = [
  [/ÔÇÑÚ/g, 'شارع'],
  [/ãÃÐæäíÉ/g, 'مأذونية'],
  [/ÔÈÑÇ/g, 'شبرا'],
  [/ÈÍÑí/g, 'بحري'],
  [/ÞÈáí/g, 'قبلي'],
  [/ÓßäíÏÉ/g, 'سكنيدة'],
  [/ØÇãæÓ/g, 'طاموس'],
  [/ÞÑØÓÇ/g, 'قرطسا'],
  [/äÞÑåÇ/g, 'نقرها'],
  [/ÇáÌãåæÑíÉ/g, 'الجمهورية'],
  [/ÇáÌíÔ/g, 'الجيش'],
  [/ÕáÇÍ ÇáÏíä/g, 'صلاح الدين'],
  [/ÚÑÇÈí/g, 'عرابي'],
  [/ÍÇÑÉ/g, 'حارة'],
  [/ãíÏÇä/g, 'ميدان'],
  [/ÚØÝÉ/g, 'عطفة'],
  [/ÒÞÇÞ/g, 'زقاق'],
  [/ØÑíÞ/g, 'طريق'],
  [/Íí/g, 'حي'],
  [/ÃÈæ ÇáÑíÔ/g, 'أبو الريش'],
  [/ÅÝáÇÞÉ/g, 'إفلاقة'],
  [/ÏãäåæÑ/g, 'دمنهور'],
  [/ÇáÈÍíÑÉ/g, 'البحيرة']
];

/**
 * قاموس المعالم وشوارع دمنهور للتحقق والترميم السياقي
 */
export const DAMANHOUR_LEXICON = [
  'دمنهور', 'البحيرة', 'شبرا بحري', 'شبرا قبلي', 'سكنيدة', 'طاموس',
  'قرطسا بحري', 'قرطسا قبلي', 'نقرها', 'نقرها أول', 'أبو الريش', 'إفلاقة',
  'الجمهورية', 'عبد السلام الشاذلي', 'الجيش', 'أحمد عرابي', 'صلاح الدين',
  'الكورنيش', 'المحطة', 'الساعة', 'مستشفى دمنهور التعليمي', 'الصاغة',
  'الأوبرا', 'حوض زهران', 'تقسيم المعلمين', 'موقف دمنهور', 'شارع', 'حارة',
  'عطفة', 'ميدان', 'زقاق', 'طريق', 'محور'
];

export class MojibakeEngine {
  /**
   * ترميم النص التالف
   */
  static repairMojibake(text: string): string {
    return this.fullRepair(text);
  }

  /**
   * كشف ما إذا كان النص يحتوي على تلف بايتي (Mojibake)
   */
  static isMojibake(text: string): boolean {
    if (!text || typeof text !== 'string') return false;

    // علامات محددة للأحرف اللاتينية الممتدة الناتجة عن Windows-1256
    const mojibakeIndicators = [
      /ÔÇ/i, /ãÃ/i, /ÈÍ/i, /ÞÈ/i, /ÃÈ/i, /Çá/i,
      /[\u00C0-\u00FF]{3,}/, // سلسلة متصلة من الأحرف اللاتينية الموسعة
      /Ã[\u0080-\u00BF]/,   // تسلسل UTF-8 double-encoded
      /\u00E2\u0080/,
      /Ø[§©ª«®¯±²³´µ¶·¸¹º»¼½¾¿]/,
      /Ù[¡¢£¤¥¦§¨©ª«¬®¯°±²³´µ]/
    ];

    for (const pattern of mojibakeIndicators) {
      if (pattern.test(text)) return true;
    }

    // فحص النسبة: إذا كان النص يحتوي على الكثير من الحروف اللاتينية الغريبة دون أن يكون نصاً إنجليزياً معتاداً
    const latinExtended = (text.match(/[\u00C0-\u00FF]/g) || []).length;
    if (latinExtended >= 3 && latinExtended / text.length > 0.25) {
      return true;
    }

    return false;
  }

  /**
   * الطبقة الأولى: الفحص البايتي العكسي المباشر
   */
  static reverseByteMapping(text: string): string {
    if (!text) return '';

    // التحقق من استبدال الأنماط الشائعة أولاً
    let cleaned = text;
    for (const [pattern, replacement] of COMMON_MOJIBAKE_REPLACEMENTS) {
      cleaned = cleaned.replace(pattern, replacement);
    }

    // إذا ما زال هناك بايتات تالفة، نحول كل كود بايت إلى الحرف العربي المطابق
    let result = '';
    for (let i = 0; i < cleaned.length; i++) {
      const code = cleaned.charCodeAt(i);
      if (WIN1256_BYTE_MAP[code]) {
        result += WIN1256_BYTE_MAP[code];
      } else if (code >= 0xC0 && code <= 0xFF && WIN1256_BYTE_MAP[code]) {
        result += WIN1256_BYTE_MAP[code];
      } else {
        result += cleaned[i];
      }
    }

    return result;
  }

  /**
   * الطبقة الثانية والثالثة: الترميم الكامل ثلاثي الطبقات
   */
  static fullRepair(text: string): string {
    if (!text) return '';
    if (!this.isMojibake(text)) {
      return text.trim();
    }

    // الطبقة 1: فك البايتات العكسية والأنماط
    let repaired = this.reverseByteMapping(text);

    // الطبقة 2: مطابقة قاموس دمنهور السياقي وتصحيح الكلمات
    for (const term of DAMANHOUR_LEXICON) {
      const normalizedTerm = ArabicUtils.normalizeForSearch(term);
      const normalizedRepaired = ArabicUtils.normalizeForSearch(repaired);
      if (normalizedRepaired === normalizedTerm) {
        repaired = term;
        break;
      }
    }

    // الطبقة 3: توحيد الحروف العربية والتخلص من التشويه
    repaired = repaired
      .replace(/[\u00C0-\u00FF]/g, '') // إزالة أي شوائب متبقية
      .replace(/\s+/g, ' ')
      .trim();

    return repaired || text;
  }

  /**
   * فحص مصفوفة من النصوص وإعطاء تقرير تحليلي دقيق
   */
  static analyzeBatch(texts: string[]): {
    total: number;
    corruptedCount: number;
    repairedCount: number;
    samples: Array<{ original: string; repaired: string }>;
  } {
    let corruptedCount = 0;
    const samples: Array<{ original: string; repaired: string }> = [];

    for (const t of texts) {
      if (this.isMojibake(t)) {
        corruptedCount++;
        const repaired = this.fullRepair(t);
        if (samples.length < 8) {
          samples.push({ original: t, repaired });
        }
      }
    }

    return {
      total: texts.length,
      corruptedCount,
      repairedCount: corruptedCount,
      samples
    };
  }
}
