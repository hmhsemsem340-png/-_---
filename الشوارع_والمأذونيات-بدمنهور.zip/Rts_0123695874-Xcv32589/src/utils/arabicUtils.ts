// ============================================================
// 🔤 أدوات معالجة وتطبيع النصوص العربية والأرقام
// ============================================================

export class ArabicUtils {
  /**
   * تطبيع النص للبحث والمقارنة الفائقة
   */
  static normalizeArabic(text: string): string {
    return this.normalizeForSearch(text);
  }

  /**
   * تطبيع النص للبحث والمقارنة الفائقة
   * يتجاهل التشكيل، يوحد الهمزات والألف اللينة والتاء المربوطة
   */
  static normalizeForSearch(text: string): string {
    if (!text) return '';
    
    return text
      .toLowerCase()
      // إزالة التشكيل
      .replace(/[\u064B-\u065F\u0670]/g, '')
      // إزالة التطويل (الكشيدة)
      .replace(/\u0640/g, '')
      // توحيد الهمزات
      .replace(/[أإآ]/g, 'ا')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      // توحيد الألف اللينة
      .replace(/ى/g, 'ي')
      // توحيد التاء المربوطة والهاء
      .replace(/ة/g, 'ه')
      // إزالة أل التعريف في بداية الكلمات للبحث
      .replace(/(^|\s)ال/g, '$1')
      // إزالة علامات الترقيم والأقواس
      .replace(/[،,.;:\-_\(\)\[\]"'/\\#@!]/g, ' ')
      // تقليص المسافات المتعددة
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * تطبيع خفيف يحافظ على بنية الكلمات مع توحيد الهمزات والتطويل
   */
  static normalizeFull(text: string): string {
    if (!text) return '';
    return text
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/\u0640/g, '')
      .replace(/[أإآ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * استخراج الإحداثيات الجغرافية (خط الطول ودائرة العرض)
   * يدعم صيغ مختلفة: 31.0345°N, 30.4682°E أو 31.0345, 30.4682
   */
  static extractCoordinates(text: string): { lat: number; lng: number } | null {
    if (!text) return null;

    // نمط درجات مع اتجاه N/E
    const degreeMatch = text.match(/([0-9]+\.?[0-9]*)\s*°?\s*[Nn]\s*[,،\s]+\s*([0-9]+\.?[0-9]*)\s*°?\s*[Ee]/);
    if (degreeMatch) {
      return {
        lat: parseFloat(degreeMatch[1]),
        lng: parseFloat(degreeMatch[2])
      };
    }

    // نمط عشري عادي
    const decimalMatch = text.match(/([0-9]{2}\.[0-9]+)\s*[,،\s]+\s*([0-9]{2}\.[0-9]+)/);
    if (decimalMatch) {
      const lat = parseFloat(decimalMatch[1]);
      const lng = parseFloat(decimalMatch[2]);
      // التحقق من أن الإحداثيات تقع في النطاق الجغرافي المعقول لدمنهور/مصر
      if (lat >= 22 && lat <= 32 && lng >= 24 && lng <= 37) {
        return { lat, lng };
      }
    }

    return null;
  }

  /**
   * استخراج المحافظة وتاريخ الميلاد من الرقم القومي المصري (14 رقماً)
   */
  static parseNationalId(id: string): { governorate?: string; birthDate?: string; isValid: boolean } {
    const cleaned = (id || '').replace(/\D/g, '');
    if (cleaned.length !== 14) return { isValid: false };

    const centuryCode = cleaned[0];
    const yearPart = cleaned.slice(1, 3);
    const monthPart = cleaned.slice(3, 5);
    const dayPart = cleaned.slice(5, 7);
    const govCode = cleaned.slice(7, 9);

    const century = centuryCode === '2' ? '19' : centuryCode === '3' ? '20' : '';
    const birthDate = century ? `${dayPart}/${monthPart}/${century}${yearPart}` : undefined;

    const governorates: Record<string, string> = {
      '01': 'القاهرة', '02': 'الإسكندرية', '03': 'بورسعيد', '04': 'السويس',
      '11': 'دمياط', '12': 'الدقهلية', '13': 'الشرقية', '14': 'القليوبية',
      '15': 'كفر الشيخ', '16': 'الغربية', '17': 'المنوفية', '18': 'البحيرة',
      '19': 'الإسماعيلية', '21': 'الجيزة', '22': 'بني سويف', '23': 'الفيوم',
      '24': 'المنيا', '25': 'أسيوط', '26': 'سوهاج', '27': 'قنا',
      '28': 'أسوان', '29': 'الأقصر', '31': 'البحر الأحمر', '32': 'الوادي الجديد',
      '33': 'مطروح', '34': 'شمال سيناء', '35': 'جنوب سيناء', '88': 'خارج الجمهورية'
    };

    return {
      isValid: true,
      governorate: governorates[govCode] || 'غير محدد',
      birthDate
    };
  }

  /**
   * تنسيق التاريخ العربي بدقة
   */
  static formatDateArabic(dateInput: string | Date | undefined): string {
    if (!dateInput) return '-';
    try {
      const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return String(dateInput);
      return d.toLocaleDateString('ar-EG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return String(dateInput);
    }
  }
}
