// ============================================================
// 🗺️ محرك الذكاء الجغرافي وكشف تشابه الشوارع المشتركة
// Street Similarity & Jurisdiction Overlap Engine
// ============================================================

import { StreetRecord, SimilarityResult } from '../types';
import { ArabicUtils } from './arabicUtils';

export class SimilarityEngine {
  /**
   * كشف الشوارع المشتركة بصيغة مبسطة
   */
  static findSharedStreets(records: StreetRecord[]): Array<{
    record: StreetRecord;
    overlapWithRecord: StreetRecord;
    overlapWithNotarization: string;
    similarityScore: number;
  }> {
    const overlaps = this.analyzeOverlap(records);
    const list: Array<{
      record: StreetRecord;
      overlapWithRecord: StreetRecord;
      overlapWithNotarization: string;
      similarityScore: number;
    }> = [];

    const recordMap = new Map<string, StreetRecord>();
    records.forEach(r => recordMap.set(r.id, r));

    for (const ov of overlaps) {
      const rec = recordMap.get(ov.recordId);
      if (rec && ov.similarRecords.length > 0) {
        const top = ov.similarRecords[0];
        const otherRec = recordMap.get(top.recordId);
        if (otherRec) {
          list.push({
            record: rec,
            overlapWithRecord: otherRec,
            overlapWithNotarization: top.notarization,
            similarityScore: top.similarityScore
          });
        }
      }
    }

    return list;
  }

  /**
   * حساب مسافة ليفنشتاين (Levenshtein Distance) بين سلسلتين
   */
  static levenshteinDistance(a: string, b: string): number {
    const s1 = ArabicUtils.normalizeForSearch(a);
    const s2 = ArabicUtils.normalizeForSearch(b);

    if (s1 === s2) return 0;
    if (s1.length === 0) return s2.length;
    if (s2.length === 0) return s1.length;

    const matrix: number[][] = [];
    for (let i = 0; i <= s2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= s1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= s2.length; i++) {
      for (let j = 1; j <= s1.length; j++) {
        if (s2.charAt(i - 1) === s1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1, // استبدال
            matrix[i][j - 1] + 1,     // إدراج
            matrix[i - 1][j] + 1      // حذف
          );
        }
      }
    }

    return matrix[s2.length][s1.length];
  }

  /**
   * حساب نسبة التشابه بين اسمين (0.0 إلى 1.0)
   */
  static calculateSimilarity(name1: string, name2: string): number {
    const n1 = ArabicUtils.normalizeForSearch(name1);
    const n2 = ArabicUtils.normalizeForSearch(name2);

    if (!n1 || !n2) return 0;
    if (n1 === n2) return 1.0;

    // تطابق احتواء مباشر
    if (n1.includes(n2) || n2.includes(n1)) {
      const minLen = Math.min(n1.length, n2.length);
      const maxLen = Math.max(n1.length, n2.length);
      return Math.max(0.85, minLen / maxLen);
    }

    // تقاطع الكلمات
    const words1 = n1.split(' ').filter(w => w.length > 1);
    const words2 = n2.split(' ').filter(w => w.length > 1);
    const commonWords = words1.filter(w => words2.includes(w));

    if (commonWords.length > 0) {
      const jaccard = (commonWords.length * 2) / (words1.length + words2.length);
      if (jaccard >= 0.5) return jaccard;
    }

    // مسافة ليفنشتاين
    const maxLen = Math.max(n1.length, n2.length);
    const distance = this.levenshteinDistance(n1, n2);
    const levScore = 1 - distance / maxLen;

    return Math.max(0, levScore);
  }

  /**
   * تحديد نوع التداخل المكاني
   */
  private static detectOverlapType(name1: string, name2: string): 'prefix' | 'suffix' | 'contains' | 'fuzzy' {
    const n1 = ArabicUtils.normalizeForSearch(name1);
    const n2 = ArabicUtils.normalizeForSearch(name2);

    if (n1.startsWith(n2) || n2.startsWith(n1)) return 'prefix';
    if (n1.endsWith(n2) || n2.endsWith(n1)) return 'suffix';
    if (n1.includes(n2) || n2.includes(n1)) return 'contains';
    return 'fuzzy';
  }

  /**
   * تحديد الجهة التقريبية من حدود الشارع
   */
  private static detectDirection(boundaries: string): string {
    const b = boundaries || '';
    if (b.includes('شرق') || b.includes('شرقي')) return 'الشرقية';
    if (b.includes('غرب') || b.includes('غربي')) return 'الغربية';
    if (b.includes('شمال') || b.includes('شمالي')) return 'الشمالية';
    if (b.includes('جنوب') || b.includes('جنوبي')) return 'الجنوبية';
    return 'المشتركة';
  }

  /**
   * تحليل الشوارع المشتركة عبر المنظومة كاملة
   */
  static analyzeOverlap(records: StreetRecord[]): SimilarityResult[] {
    const results: SimilarityResult[] = [];

    for (let i = 0; i < records.length; i++) {
      const record = records[i];
      const similarRecords: SimilarityResult['similarRecords'] = [];

      for (let j = 0; j < records.length; j++) {
        if (i === j) continue;
        const other = records[j];

        // التدقيق في الشوارع التي تقع في مأذونيات مختلفة فقط
        if (record.notarization === other.notarization) continue;

        const score = this.calculateSimilarity(record.streetName, other.streetName);
        if (score >= 0.70) {
          similarRecords.push({
            recordId: other.id,
            streetName: other.streetName,
            notarization: other.notarization,
            similarityScore: Math.round(score * 100) / 100,
            overlapType: this.detectOverlapType(record.streetName, other.streetName)
          });
        }
      }

      if (similarRecords.length > 0) {
        similarRecords.sort((a, b) => b.similarityScore - a.similarityScore);
        results.push({
          recordId: record.id,
          streetName: record.streetName,
          notarization: record.notarization,
          similarRecords
        });
      }
    }

    return results;
  }

  /**
   * تطبيق التضمين التلقائي لملاحظات الاشتراك عبر كامل المنظومة
   */
  static autoAnnotateSharedStreets(records: StreetRecord[]): {
    updatedRecords: StreetRecord[];
    annotatedCount: number;
  } {
    const overlaps = this.analyzeOverlap(records);
    const overlapMap = new Map<string, SimilarityResult>();
    for (const ov of overlaps) {
      overlapMap.set(ov.recordId, ov);
    }

    let count = 0;
    const updatedRecords = records.map(record => {
      const overlap = overlapMap.get(record.id);
      if (overlap && overlap.similarRecords.length > 0) {
        const topMatch = overlap.similarRecords[0];
        const sharedNotarizations = [...new Set(overlap.similarRecords.map(s => s.notarization))];
        const direction = this.detectDirection(record.boundaries);
        const autoNote = `[تنبيه اشتراك مكاني: هذا الشارع مشترك مع مأذونية (${sharedNotarizations.join(' و ')}) في مقاطعه ${direction}]`;

        const existingNotes = record.sharedNote || '';
        const alreadyAnnotated = existingNotes.includes('تنبيه اشتراك مكاني');

        if (!alreadyAnnotated || record.sharedNotarization !== topMatch.notarization) {
          count++;
          return {
            ...record,
            sharedNotarization: topMatch.notarization,
            sharedNote: alreadyAnnotated ? existingNotes : `${existingNotes ? existingNotes + ' - ' : ''}${autoNote}`.trim(),
            updatedAt: new Date().toISOString()
          };
        }
      }
      return record;
    });

    return { updatedRecords, annotatedCount: count };
  }
}
