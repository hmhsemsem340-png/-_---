// ============================================================
// 🔤 محرك الفرز الأبجدي العربي الدقيق (Strict Arabic Collation)
// وفق قواعد المعاجم والتوثيق القانوني
// ============================================================

import { ArabicUtils } from './arabicUtils';

/** ترتيب الحروف العربية المعجمي */
const ARABIC_ALPHABET = 'أبتثجحخدذرزسشصضطظعغفقكلمنهوي';

const CHAR_ORDER_MAP: Map<string, number> = new Map();
for (let i = 0; i < ARABIC_ALPHABET.length; i++) {
  CHAR_ORDER_MAP.set(ARABIC_ALPHABET[i], i);
}

export class CollationEngine {
  /**
   * مقارنة كلمتين عربيتين وفق الترتيب الأبجدي الدقيق
   */
  static compareArabic(a: string, b: string): number {
    const cleanA = ArabicUtils.normalizeForSearch(a || '');
    const cleanB = ArabicUtils.normalizeForSearch(b || '');

    if (cleanA === cleanB) return 0;

    const minLen = Math.min(cleanA.length, cleanB.length);
    for (let i = 0; i < minLen; i++) {
      const charA = cleanA[i];
      const charB = cleanB[i];

      if (charA === charB) continue;

      const orderA = CHAR_ORDER_MAP.has(charA) ? CHAR_ORDER_MAP.get(charA)! : 999;
      const orderB = CHAR_ORDER_MAP.has(charB) ? CHAR_ORDER_MAP.get(charB)! : 999;

      if (orderA !== orderB) {
        return orderA - orderB;
      }
      return charA.localeCompare(charB, 'ar');
    }

    return cleanA.length - cleanB.length;
  }

  /**
   * فرز مصفوفة سجلات وفق حقل معين
   */
  static sortRecords<T>(records: T[], key: keyof T, direction: 'asc' | 'desc' = 'asc'): T[] {
    const sorted = [...records].sort((itemA, itemB) => {
      const valA = String(itemA[key] || '');
      const valB = String(itemB[key] || '');
      return this.compareArabic(valA, valB);
    });

    return direction === 'desc' ? sorted.reverse() : sorted;
  }
}
