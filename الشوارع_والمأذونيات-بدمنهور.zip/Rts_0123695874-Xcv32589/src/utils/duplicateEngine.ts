// ============================================================
// 🚫 نظام إدارة وحظر التكرار الذكي
// Smart Duplicate Prevention & Dispute Resolution
// ============================================================

import { StreetRecord, DuplicateCheckResult, FieldChange } from '../types';
import { ArabicUtils } from './arabicUtils';
import { SimilarityEngine } from './similarityEngine';

export class DuplicateEngine {
  /**
   * كشف لحظي استباقي عند كتابة اسم الشارع
   */
  static checkDuplicate(
    streetName: string,
    notarization: string,
    existingRecords: StreetRecord[],
    currentRecordId?: string
  ): DuplicateCheckResult {
    if (!streetName || streetName.trim().length < 2) {
      return {
        isDuplicate: false,
        matchedRecords: [],
        similarityScore: 0,
        suggestedAction: 'separate'
      };
    }

    const matchedRecords: StreetRecord[] = [];
    let highestScore = 0;

    for (const record of existingRecords) {
      if (currentRecordId && record.id === currentRecordId) continue;

      const score = SimilarityEngine.calculateSimilarity(streetName, record.streetName);

      // زيادة الوزن إذا كانا في نفس المأذونية
      const sameNotarization = record.notarization === notarization;
      const adjustedScore = sameNotarization ? score : score * 0.9;

      if (adjustedScore >= 0.78) {
        matchedRecords.push(record);
        if (adjustedScore > highestScore) {
          highestScore = adjustedScore;
        }
      }
    }

    matchedRecords.sort((a, b) => {
      const scoreA = SimilarityEngine.calculateSimilarity(streetName, a.streetName);
      const scoreB = SimilarityEngine.calculateSimilarity(streetName, b.streetName);
      return scoreB - scoreA;
    });

    const isDuplicate = matchedRecords.length > 0 && highestScore >= 0.82;
    let suggestedAction: 'merge' | 'replace' | 'separate' = 'separate';

    if (isDuplicate) {
      if (highestScore >= 0.95) {
        suggestedAction = 'replace';
      } else {
        suggestedAction = 'merge';
      }
    }

    return {
      isDuplicate,
      matchedRecords,
      similarityScore: Math.round(highestScore * 100) / 100,
      suggestedAction
    };
  }

  /**
   * دمج سجل مكرر
   */
  static mergeDuplicate(existing: StreetRecord, incoming: Partial<StreetRecord>): Partial<StreetRecord> {
    const { mergedRecord } = this.mergeRecords(existing, incoming, 'الموثق');
    return mergedRecord;
  }

  /**
   * خيار 1: دمج الملاحظات والمعالم مع السجل الأصلي
   */
  static mergeRecords(
    existing: StreetRecord,
    incoming: Partial<StreetRecord>,
    operatorName: string
  ): { mergedRecord: StreetRecord; changes: FieldChange[] } {
    const changes: FieldChange[] = [];

    // دمج المعالم
    let newLandmarks = existing.landmarks || '';
    if (incoming.landmarks && !newLandmarks.includes(incoming.landmarks)) {
      newLandmarks = newLandmarks ? `${newLandmarks}، ${incoming.landmarks}` : incoming.landmarks;
      changes.push({
        fieldName: 'landmarks',
        fieldLabel: 'المعالم المميزة',
        oldValue: existing.landmarks || '(فارغ)',
        newValue: newLandmarks
      });
    }

    // دمج الحدود
    let newBoundaries = existing.boundaries || '';
    if (incoming.boundaries && !newBoundaries.includes(incoming.boundaries)) {
      newBoundaries = newBoundaries ? `${newBoundaries} | ${incoming.boundaries}` : incoming.boundaries;
      changes.push({
        fieldName: 'boundaries',
        fieldLabel: 'الحدود',
        oldValue: existing.boundaries || '(فارغ)',
        newValue: newBoundaries
      });
    }

    // دمج الوصف
    let newDesc = existing.description || '';
    if (incoming.description && !newDesc.includes(incoming.description)) {
      newDesc = newDesc ? `${newDesc} [إضافة مدمجة: ${incoming.description}]` : incoming.description;
      changes.push({
        fieldName: 'description',
        fieldLabel: 'الوصف والبيان',
        oldValue: existing.description || '(فارغ)',
        newValue: newDesc
      });
    }

    // دمج الإحداثيات إذا لم تكن موجودة
    let newGps = existing.gpsCoordinates;
    if (!newGps && incoming.gpsCoordinates) {
      newGps = incoming.gpsCoordinates;
      changes.push({
        fieldName: 'gpsCoordinates',
        fieldLabel: 'الإحداثيات الجغرافية',
        oldValue: '(فارغ)',
        newValue: newGps
      });
    }

    const mergedRecord: StreetRecord = {
      ...existing,
      landmarks: newLandmarks,
      boundaries: newBoundaries,
      description: newDesc,
      gpsCoordinates: newGps,
      updatedAt: new Date().toISOString(),
      updatedBy: operatorName,
      version: existing.version + 1
    };

    return { mergedRecord, changes };
  }

  /**
   * خيار 2: استبدال وتحديث السجل الأصلي مع حساب الفروقات لسجل التدقيق
   */
  static replaceRecord(
    existing: StreetRecord,
    incoming: Partial<StreetRecord>,
    operatorName: string
  ): { replacedRecord: StreetRecord; changes: FieldChange[] } {
    const changes: FieldChange[] = [];

    const fieldLabels: Record<string, string> = {
      streetName: 'اسم الشارع',
      notarization: 'المأذونية',
      category: 'التصنيف',
      recordType: 'نوع السجل',
      description: 'الوصف',
      landmarks: 'المعالم',
      boundaries: 'الحدود',
      nationalId: 'الرقم القومي',
      contractDate: 'تاريخ العقد',
      gpsCoordinates: 'الإحداثيات',
      status: 'الحالة'
    };

    for (const [key, label] of Object.entries(fieldLabels)) {
      const oldVal = String((existing as any)[key] || '');
      const newVal = String((incoming as any)[key] !== undefined ? (incoming as any)[key] : (existing as any)[key] || '');

      if (oldVal !== newVal) {
        changes.push({
          fieldName: key,
          fieldLabel: label,
          oldValue: oldVal || '(فارغ)',
          newValue: newVal || '(فارغ)'
        });
      }
    }

    const replacedRecord: StreetRecord = {
      ...existing,
      ...incoming,
      id: existing.id,
      normalizedStreetName: ArabicUtils.normalizeForSearch(incoming.streetName || existing.streetName),
      createdAt: existing.createdAt,
      createdBy: existing.createdBy,
      updatedAt: new Date().toISOString(),
      updatedBy: operatorName,
      version: existing.version + 1
    };

    return { replacedRecord, changes };
  }
}
