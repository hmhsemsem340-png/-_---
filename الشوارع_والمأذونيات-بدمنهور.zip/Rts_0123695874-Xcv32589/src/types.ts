// ============================================================
// 🏛️ منظومة التوثيق الرقمي للشوارع والمأذونيات بدمنهور
// تعريفات الأنواع والواجهات (TypeScript Definitions)
// ============================================================

/** المأذونيات الرسمية السبع لبندر دمنهور */
export const OFFICIAL_NOTARIZATIONS = [
  'شبرا بحري',
  'سكنيدة',
  'طاموس',
  'شبرا قبلي',
  'قرطسا بحري',
  'نقرها',
  'قرطسا قبلي'
] as const;

export type OfficialNotarization = typeof OFFICIAL_NOTARIZATIONS[number];

/** قائمة كافة الأحياء والمناطق المعتمدة في قاعدة البيانات */
export const ALL_DISTRICTS = [
  ...OFFICIAL_NOTARIZATIONS,
  'نقرها أول',
  'شبرا_1',
  'شبرا_2',
  'شبرا_3',
  'قرطسا',
  'أبو الريش',
  'إفلاقة'
] as const;

/** أنواع السجلات الجغرافية */
export const RECORD_TYPES = [
  'شارع',
  'حارة',
  'ميدان',
  'عطفة',
  'حي',
  'زقاق',
  'طريق',
  'محور'
] as const;

export type RecordType = typeof RECORD_TYPES[number];

/** تصنيف السجل القانوني */
export type RecordCategory = 
  | 'مأذونية رسمية' 
  | 'مأذونية غير رسمية' 
  | 'حي' 
  | 'شارع' 
  | 'تقاسيم وعقود';

/** حالة السجل */
export type RecordStatus = 'نشط' | 'معلّق' | 'ملغي' | 'قيد المراجعة';

/** سجل الشارع الأساسي */
export interface StreetRecord {
  id: string;
  streetName: string;
  normalizedStreetName: string;
  notarization: string;
  category: RecordCategory;
  recordType: RecordType;
  description: string;
  landmarks: string;
  boundaries: string;
  nationalId?: string;
  contractDate?: string;
  gpsCoordinates?: string;
  status: RecordStatus;
  sharedNotarization?: string;
  sharedNote?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  version: number;
}

/** تغيير في حقل معين */
export interface FieldChange {
  fieldName: string;
  fieldLabel: string;
  oldValue: string;
  newValue: string;
}

/** سجل التعديل (Audit Log Entry) */
export interface AuditLogEntry {
  id: string;
  recordId: string;
  recordName: string;
  timestamp: string;
  action: 'إنشاء' | 'تعديل' | 'حذف' | 'استيراد' | 'استعادة' | 'دمج' | 'ترميم';
  operatorName: string;
  changes: FieldChange[];
  notes: string;
}

/** لقطة التراجع (Undo Snapshot) */
export interface UndoSnapshot {
  id: string;
  timestamp: string;
  action: string;
  description: string;
  records: StreetRecord[];
}

/** أنواع الثيمات */
export type ThemeType = 
  | 'excel-green' 
  | 'classic-blue' 
  | 'dark-mode' 
  | 'dynamic';

/** كثافة الجدول */
export type TableDensity = 'compact' | 'normal' | 'comfortable';

/** وضع العرض */
export type ViewMode = 'default' | 'clean' | 'reading';

/** إعدادات المستخدم الشاملة */
export interface UserSettings {
  operatorName: string;
  theme: ThemeType;
  tableDensity: TableDensity;
  viewMode: ViewMode;
  fontSize: number;
  showNotes: boolean;
  showSharedBadge: boolean;
  autoSave: boolean;
  confirmDelete: boolean;
  language: 'ar' | 'en';
  shortcutsEnabled: boolean;
  exportFormat: ExportFormat;
  exportColors: boolean;
  exportBorders: boolean;
  exportHeader: boolean;
  exportFooter: boolean;
  exportRtl: boolean;
  exportWatermark: boolean;
  exportSignature: boolean;
  backupFrequency: 'daily' | 'weekly' | 'monthly' | 'never';
  encryptBackup: boolean;
  appLockEnabled: boolean;
  lastBackupDate?: string;
}

/** حالة التصفية */
export interface FilterState {
  notarization: string | 'all';
  recordType: RecordType | 'all';
  status: RecordStatus | 'all';
  category: RecordCategory | 'all';
  sharedStreetsOnly: boolean;
  dateRange?: { from: string; to: string };
}

/** نتيجة كشف التكرار */
export interface DuplicateCheckResult {
  isDuplicate: boolean;
  matchedRecords: StreetRecord[];
  similarityScore: number;
  suggestedAction: 'merge' | 'replace' | 'separate';
}

/** نتيجة كشف التشابه الجغرافي */
export interface SimilarityResult {
  recordId: string;
  streetName: string;
  notarization: string;
  similarRecords: Array<{
    recordId: string;
    streetName: string;
    notarization: string;
    similarityScore: number;
    overlapType: 'prefix' | 'suffix' | 'contains' | 'fuzzy';
  }>;
}

/** إعدادات الطباعة الرسمية */
export interface PrintSettings {
  notarization: string | 'all';
  fontSize: number;
  showNotes: boolean;
  showBoundaries: boolean;
  showLandmarks: boolean;
  includeHeader: boolean;
  includeFooter: boolean;
  includeAuditTrail: boolean;
}

/** صيغ التصدير المتقدمة */
export type ExportFormat = 'excel' | 'pdf' | 'html' | 'csv';

/** نطاق التصدير */
export type ExportScope = 'filtered' | 'all' | 'selected';

/** خيارات التصدير المتقدم ونظام الحماية الشامل */
export interface AdvancedExportOptions {
  format: ExportFormat;
  scope: ExportScope;
  colors: boolean;
  borders: boolean;
  header: boolean;
  footer: boolean;
  rtl: boolean;
  autofit: boolean;
  freeze: boolean;
  altRows: boolean;
  password?: string;
  modifyPassword?: string;
  readonly: boolean;
  nocopy: boolean;
  noprint: boolean;
  watermark: boolean;
  signature: boolean;
  operator: string;
}

