// ============================================================
// 🏷️ شريط وسوم المأذونيات السريعة الملونة
// Quick Notarization Filter Tags with Real-Time Counts
// ============================================================

import React from 'react';
import { OFFICIAL_NOTARIZATIONS } from '../types';

interface NotarizationTagsProps {
  selectedNotarization: string;
  onSelect: (notarization: string) => void;
  counts: Record<string, number>;
  totalCount: number;
}

export const NOTARIZATION_COLOR_CONFIG: Record<string, { bg: string; text: string; border: string; activeBg: string }> = {
  'شبرا بحري': {
    bg: 'bg-rose-50',
    text: 'text-rose-900',
    border: 'border-rose-200',
    activeBg: 'bg-rose-700 text-white border-rose-700'
  },
  'سكنيدة': {
    bg: 'bg-emerald-50',
    text: 'text-emerald-900',
    border: 'border-emerald-200',
    activeBg: 'bg-emerald-700 text-white border-emerald-700'
  },
  'طاموس': {
    bg: 'bg-amber-50',
    text: 'text-amber-900',
    border: 'border-amber-200',
    activeBg: 'bg-amber-700 text-white border-amber-700'
  },
  'شبرا قبلي': {
    bg: 'bg-orange-50',
    text: 'text-orange-900',
    border: 'border-orange-200',
    activeBg: 'bg-orange-700 text-white border-orange-700'
  },
  'قرطسا بحري': {
    bg: 'bg-purple-50',
    text: 'text-purple-900',
    border: 'border-purple-200',
    activeBg: 'bg-purple-700 text-white border-purple-700'
  },
  'نقرها': {
    bg: 'bg-teal-50',
    text: 'text-teal-900',
    border: 'border-teal-200',
    activeBg: 'bg-teal-700 text-white border-teal-700'
  },
  'قرطسا قبلي': {
    bg: 'bg-blue-50',
    text: 'text-blue-900',
    border: 'border-blue-200',
    activeBg: 'bg-blue-700 text-white border-blue-700'
  },
  'أبو الريش': {
    bg: 'bg-indigo-50',
    text: 'text-indigo-900',
    border: 'border-indigo-200',
    activeBg: 'bg-indigo-700 text-white border-indigo-700'
  },
  'إفلاقة': {
    bg: 'bg-violet-50',
    text: 'text-violet-900',
    border: 'border-violet-200',
    activeBg: 'bg-violet-700 text-white border-violet-700'
  }
};

export const NotarizationTags: React.FC<NotarizationTagsProps> = ({
  selectedNotarization,
  onSelect,
  counts,
  totalCount
}) => {
  const extraDistricts = ['أبو الريش', 'إفلاقة'];

  return (
    <div className="bg-stone-50/80 border-b border-stone-200/90 px-4 py-2 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
      <span className="text-[11px] font-bold text-stone-500 whitespace-nowrap pl-1">
        المأذونيات:
      </span>

      {/* الكل */}
      <button
        onClick={() => onSelect('all')}
        className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 border whitespace-nowrap shrink-0 shadow-2xs ${
          selectedNotarization === 'all'
            ? 'bg-stone-900 text-white border-stone-900 shadow-sm'
            : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-100'
        }`}
      >
        <span>كافة المأذونيات</span>
        <span
          className={`px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${
            selectedNotarization === 'all' ? 'bg-stone-800 text-stone-200' : 'bg-stone-100 text-stone-600'
          }`}
        >
          {totalCount}
        </span>
      </button>

      {/* المأذونيات السبع الرسمية */}
      {OFFICIAL_NOTARIZATIONS.map((name) => {
        const count = counts[name] || 0;
        const config = NOTARIZATION_COLOR_CONFIG[name] || {
          bg: 'bg-stone-50',
          text: 'text-stone-800',
          border: 'border-stone-300',
          activeBg: 'bg-stone-800 text-white border-stone-800'
        };
        const isActive = selectedNotarization === name;

        return (
          <button
            key={name}
            onClick={() => onSelect(name)}
            className={`px-2.5 py-1 rounded-full text-xs font-semibold transition flex items-center gap-1.5 border whitespace-nowrap shrink-0 shadow-2xs ${
              isActive
                ? config.activeBg
                : `${config.bg} ${config.text} ${config.border} hover:opacity-85`
            }`}
          >
            <span>{name}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                isActive ? 'bg-black/25 text-white' : 'bg-white/80 text-stone-700'
              }`}
            >
              {count}
            </span>
          </button>
        );
      })}

      <div className="w-px h-5 bg-stone-300 shrink-0 mx-1"></div>

      {/* أحياء إضافية */}
      {extraDistricts.map((name) => {
        const count = counts[name] || 0;
        const config = NOTARIZATION_COLOR_CONFIG[name] || {
          bg: 'bg-stone-50',
          text: 'text-stone-800',
          border: 'border-stone-300',
          activeBg: 'bg-stone-800 text-white border-stone-800'
        };
        const isActive = selectedNotarization === name;

        return (
          <button
            key={name}
            onClick={() => onSelect(name)}
            className={`px-2.5 py-1 rounded-full text-xs font-medium transition flex items-center gap-1.5 border whitespace-nowrap shrink-0 ${
              isActive
                ? config.activeBg
                : `${config.bg} ${config.text} ${config.border} hover:opacity-85`
            }`}
          >
            <span>{name}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                isActive ? 'bg-black/25 text-white' : 'bg-white/80 text-stone-700'
              }`}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
};
