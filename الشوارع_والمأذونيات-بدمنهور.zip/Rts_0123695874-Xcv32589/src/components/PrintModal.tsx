// ============================================================
// 🖨️ نافذة إعداد وطباعة التقارير والكشوف الرسمية
// Official Printing Configuration & Report Generator
// ============================================================

import React, { useState } from 'react';
import { StreetRecord, UserSettings, OFFICIAL_NOTARIZATIONS, ALL_DISTRICTS } from '../types';
import { ArabicUtils } from '../utils/arabicUtils';
import { Printer, X, FileText, CheckSquare, Settings2 } from 'lucide-react';

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: StreetRecord[];
  settings: UserSettings;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  records,
  settings
}) => {
  const [targetNotarization, setTargetNotarization] = useState<string>('all');
  const [orientation, setOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [fontSize, setFontSize] = useState<'9pt' | '10pt' | '11pt' | '12pt'>('10pt');
  const [includeDescription, setIncludeDescription] = useState(true);
  const [includeLandmarks, setIncludeLandmarks] = useState(true);
  const [includeBoundaries, setIncludeBoundaries] = useState(true);
  const [includeSignatures, setIncludeSignatures] = useState(true);
  const [includeHeader, setIncludeHeader] = useState(true);
  const [colorStyle, setColorStyle] = useState<'colored' | 'mono'>('colored');

  if (!isOpen) return null;

  // السجلات المصفاة للطباعة
  const printRecords = targetNotarization === 'all'
    ? records
    : records.filter((r) => r.notarization === targetNotarization);

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('يرجى السماح بالنوافذ المنبثقة للطباعة.');
      return;
    }

    const notarizationTitle = targetNotarization === 'all'
      ? 'كافة مأذونيات وأحياء بندر دمنهور'
      : `مأذونية / حي: ${targetNotarization}`;

    const nowArabic = ArabicUtils.formatDateArabic(new Date());

    let rowsHtml = '';
    printRecords.forEach((r, i) => {
      rowsHtml += `
        <tr style="${i % 2 === 0 ? 'background-color: #ffffff;' : 'background-color: #f9fafb;'}">
          <td style="text-align: center; border: 1px solid #94a3b8; padding: 4px; font-weight: bold; width: 35px;">${i + 1}</td>
          <td style="border: 1px solid #94a3b8; padding: 4px 6px; font-weight: bold; color: #0f172a;">
            ${r.streetName}
            ${r.sharedNotarization ? `<div style="font-size: 8pt; color: #b45309; font-weight: bold;">[مشترك: ${r.sharedNotarization}]</div>` : ''}
          </td>
          <td style="border: 1px solid #94a3b8; padding: 4px; text-align: center; font-weight: bold; width: 100px;">
            ${r.notarization}
          </td>
          <td style="border: 1px solid #94a3b8; padding: 4px; text-align: center; width: 65px; font-size: 8pt;">
            ${r.recordType}
          </td>
          ${includeDescription ? `<td style="border: 1px solid #94a3b8; padding: 4px 6px; font-size: 8.5pt;">${r.description || '-'}</td>` : ''}
          ${includeLandmarks ? `<td style="border: 1px solid #94a3b8; padding: 4px 6px; font-size: 8.5pt;">${r.landmarks || '-'}</td>` : ''}
          ${includeBoundaries ? `<td style="border: 1px solid #94a3b8; padding: 4px 6px; font-size: 8.5pt;">${r.boundaries || '-'}</td>` : ''}
          <td style="border: 1px solid #94a3b8; padding: 4px; text-align: center; width: 55px; font-size: 8pt;">
            ${r.status}
          </td>
        </tr>
      `;
    });

    const printableDocument = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>كشف رسمي - ${notarizationTitle}</title>
        <style>
          @page {
            size: A4 ${orientation};
            margin: 10mm;
          }
          body {
            font-family: 'Cairo', 'Amiri', 'Traditional Arabic', serif;
            direction: rtl;
            color: #000;
            margin: 0;
            padding: 0;
            font-size: ${fontSize};
            line-height: 1.35;
          }
          .page-header {
            text-align: center;
            border-bottom: 2px solid ${colorStyle === 'colored' ? '#065f46' : '#000000'};
            padding-bottom: 8px;
            margin-bottom: 12px;
          }
          .page-header h1 {
            margin: 0 0 4px;
            font-size: 16pt;
            color: ${colorStyle === 'colored' ? '#064e3b' : '#000000'};
            font-weight: bold;
          }
          .page-header h2 {
            margin: 0 0 4px;
            font-size: 12pt;
            color: #1e293b;
          }
          .page-header .meta-bar {
            display: flex;
            justify-content: space-between;
            font-size: 9pt;
            font-weight: bold;
            color: #334155;
            margin-top: 6px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: ${fontSize};
          }
          thead th {
            background-color: ${colorStyle === 'colored' ? '#064e3b' : '#e2e8f0'};
            color: ${colorStyle === 'colored' ? '#ffffff' : '#000000'};
            border: 1px solid #475569;
            padding: 6px 4px;
            font-weight: bold;
            text-align: center;
          }
          .signatures-container {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
            page-break-inside: avoid;
            font-size: 9.5pt;
          }
          .signature-box {
            width: 28%;
            text-align: center;
          }
          .signature-line {
            border-top: 1px dotted #000;
            margin-top: 45px;
            padding-top: 4px;
          }
        </style>
      </head>
      <body>
        ${includeHeader ? `
          <div class="page-header">
            <h2>جمهورية مصر العربية — محافظة البحيرة — بندر دمنهور</h2>
            <h1>كشف حصر واعتماد الشوارع والمأذونيات الرسمية</h1>
            <div class="meta-bar">
              <span>نطاق الكشف: <strong>${notarizationTitle}</strong></span>
              <span>عدد السجلات: <strong>${printRecords.length} شارع/تقسيم</strong></span>
              <span>الموثق المعتمد: <strong>${settings.operatorName}</strong></span>
              <span>تاريخ الطباعة: <strong>${nowArabic}</strong></span>
            </div>
          </div>
        ` : ''}

        <table>
          <thead>
            <tr>
              <th style="width: 35px;">م</th>
              <th>اسم الشارع / الحارة / التقسيم</th>
              <th style="width: 100px;">المأذونية</th>
              <th style="width: 65px;">النوع</th>
              ${includeDescription ? '<th>الوصف والبيان</th>' : ''}
              ${includeLandmarks ? '<th>المعالم المميزة</th>' : ''}
              ${includeBoundaries ? '<th>الحدود الجغرافية</th>' : ''}
              <th style="width: 55px;">الحالة</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        ${includeSignatures ? `
          <div class="signatures-container">
            <div class="signature-box">
              <strong>القائم بالحصر والتوثيق الرقمي</strong>
              <p style="margin: 4px 0 0; color: #334155;">${settings.operatorName}</p>
              <div class="signature-line">التوقيع: ............................</div>
            </div>
            <div class="signature-box">
              <strong>مأذون الناحية / الموثق الشرعي</strong>
              <div class="signature-line">التوقيع: ............................</div>
            </div>
            <div class="signature-box">
              <strong>خاتم شعار المنظومة والاعتماد</strong>
              <div class="signature-line">بصمة الخاتم الرسمي</div>
            </div>
          </div>
        ` : ''}
      </body>
      </html>
    `;

    printWindow.document.write(printableDocument);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-2xl overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                إعداد وطباعة كشف تقرير رسمي للمأذونيات
              </h2>
              <p className="text-xs text-stone-400">
                توليد وطباعة الكشوف المعتمدة وفق المعايير القضائية والإدارية
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ الإعدادات والخيارات ═══ */}
        <div className="p-5 space-y-4">
          {/* نطاق المأذونية */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              نطاق المأذونية المراد طباعتها:
            </label>
            <select
              value={targetNotarization}
              onChange={(e) => setTargetNotarization(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-md text-xs text-stone-900 font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="all">كافة المأذونيات والأحياء ({records.length} سجل)</option>
              <optgroup label="المأذونيات السبع الرسمية">
                {OFFICIAL_NOTARIZATIONS.map((name) => {
                  const count = records.filter((r) => r.notarization === name).length;
                  return (
                    <option key={name} value={name}>
                      {name} ({count} سجل)
                    </option>
                  );
                })}
              </optgroup>
              <optgroup label="أحياء وتفرعات أخرى">
                {ALL_DISTRICTS.filter((d) => !OFFICIAL_NOTARIZATIONS.includes(d as any)).map((name) => {
                  const count = records.filter((r) => r.notarization === name).length;
                  return (
                    <option key={name} value={name}>
                      {name} ({count} سجل)
                    </option>
                  );
                })}
              </optgroup>
            </select>
          </div>

          {/* التخطيط واتجاه الصفحة وحجم الخط */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                اتجاه الصفحة (A4)
              </label>
              <select
                value={orientation}
                onChange={(e) => setOrientation(e.target.value as 'landscape' | 'portrait')}
                className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded text-xs text-stone-800"
              >
                <option value="landscape">أفقي (Landscape - موصى به)</option>
                <option value="portrait">رأسي (Portrait)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                حجم خط الطباعة
              </label>
              <select
                value={fontSize}
                onChange={(e) => setFontSize(e.target.value as any)}
                className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded text-xs text-stone-800"
              >
                <option value="9pt">9pt (مضغوط لكثرة البيانات)</option>
                <option value="10pt">10pt (مثالي ومتوازن)</option>
                <option value="11pt">11pt (واضح ومريح)</option>
                <option value="12pt">12pt (مكبر)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                نمط الألوان
              </label>
              <select
                value={colorStyle}
                onChange={(e) => setColorStyle(e.target.value as any)}
                className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded text-xs text-stone-800"
              >
                <option value="colored">أخضر إكسيل رسمي</option>
                <option value="mono">أبيض وأسود (اقتصادي)</option>
              </select>
            </div>
          </div>

          {/* تضمين الحقول والأقسام */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-3.5 space-y-2.5">
            <span className="text-xs font-bold text-stone-800 block">
              الحقول والأقسام المضمنة في التقرير المطبوع:
            </span>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeHeader}
                  onChange={(e) => setIncludeHeader(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>الترويسة السيادية وبيانات الموثق</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeSignatures}
                  onChange={(e) => setIncludeSignatures(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>مربعات التوقيعات وخاتم الاعتماد</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeDescription}
                  onChange={(e) => setIncludeDescription(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>عمود الوصف والبيان التفصيلي</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeLandmarks}
                  onChange={(e) => setIncludeLandmarks(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>عمود المعالم المميزة</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeBoundaries}
                  onChange={(e) => setIncludeBoundaries(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>عمود الحدود الجغرافية</span>
              </label>
            </div>
          </div>
        </div>

        {/* ═══ أزرار الإجراءات ═══ */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex items-center justify-between">
          <span className="text-xs text-stone-500">
            عدد السجلات المستهدفة بالطباعة: <strong>{printRecords.length}</strong> سجل
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-white hover:bg-stone-200 text-stone-700 border border-stone-300 rounded-md text-xs font-semibold transition"
            >
              إلغاء
            </button>

            <button
              onClick={handlePrint}
              className="px-5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>بدء الطباعة الآن</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
