// ============================================================
// 📤 نافذة التصدير المتقدم ونظام الحماية الشامل
// Advanced Export Modal with Security & Protection Features
// ============================================================

import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  Globe, 
  Printer, 
  ShieldCheck, 
  Lock, 
  EyeOff, 
  Copy, 
  Droplet, 
  PenTool, 
  Check, 
  Sparkles
} from 'lucide-react';
import { 
  StreetRecord, 
  UserSettings, 
  ExportFormat, 
  ExportScope, 
  AdvancedExportOptions 
} from '../types';

interface AdvancedExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  filteredRecords: StreetRecord[];
  allRecords: StreetRecord[];
  selectedCount: number;
  settings: UserSettings;
  onExecuteExport: (options: AdvancedExportOptions) => void;
}

export const AdvancedExportModal: React.FC<AdvancedExportModalProps> = ({
  isOpen,
  onClose,
  filteredRecords,
  allRecords,
  selectedCount,
  settings,
  onExecuteExport
}) => {
  const [format, setFormat] = useState<ExportFormat>('excel');
  const [scope, setScope] = useState<ExportScope>('filtered');

  // خيارات التنسيق
  const [colors, setColors] = useState(true);
  const [borders, setBorders] = useState(true);
  const [header, setHeader] = useState(true);
  const [footer, setFooter] = useState(true);
  const [rtl, setRtl] = useState(true);
  const [autofit, setAutofit] = useState(true);
  const [freeze, setFreeze] = useState(true);
  const [altRows, setAltRows] = useState(true);

  // خيارات الحماية والأمان
  const [enablePassword, setEnablePassword] = useState(false);
  const [password, setPassword] = useState('');
  const [modifyPassword, setModifyPassword] = useState('');
  const [readonly, setReadonly] = useState(false);
  const [nocopy, setNocopy] = useState(false);
  const [noprint, setNoprint] = useState(false);
  const [watermark, setWatermark] = useState(true);
  const [signature, setSignature] = useState(true);

  if (!isOpen) return null;

  const getRecordCountForScope = () => {
    if (scope === 'filtered') return filteredRecords.length;
    if (scope === 'selected') return selectedCount;
    return allRecords.length;
  };

  const handleExport = () => {
    const options: AdvancedExportOptions = {
      format,
      scope,
      colors,
      borders,
      header,
      footer,
      rtl,
      autofit,
      freeze,
      altRows,
      password: enablePassword ? password : '',
      modifyPassword: enablePassword ? modifyPassword : '',
      readonly,
      nocopy,
      noprint,
      watermark,
      signature,
      operator: settings.operatorName || 'أ/ حسام الدين الخولي'
    };

    onExecuteExport(options);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
      dir="rtl"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-stone-200 w-full max-w-2xl overflow-hidden my-6">
        {/* الترويسة */}
        <div className="bg-emerald-800 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-900">
          <div className="flex items-center gap-2.5">
            <Download className="w-5 h-5 text-emerald-300" />
            <div>
              <h3 className="font-bold text-base">📤 نظام التصدير المتقدم والحماية الشاملة</h3>
              <p className="text-xs text-emerald-200/90 mt-0.5">
                تصدير مهني معتمد متوافق مع Excel و LibreOffice و Google Sheets
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-700/50 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 max-h-[78vh] overflow-y-auto space-y-6 text-stone-800 text-sm">
          {/* 1️⃣ اختيار الصيغة */}
          <div>
            <label className="font-bold text-stone-900 mb-2.5 flex items-center gap-2 text-xs uppercase tracking-wider text-emerald-900">
              <Sparkles className="w-4 h-4 text-emerald-700" />
              <span>1. اختر صيغة التصدير المستهدفة</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {/* Excel */}
              <button
                type="button"
                onClick={() => setFormat('excel')}
                className={`p-3.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
                  format === 'excel'
                    ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 shadow-xs ring-2 ring-emerald-600/20'
                    : 'border-stone-200 hover:border-emerald-300 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <FileSpreadsheet className="w-6 h-6 text-emerald-700" />
                <span className="font-bold text-xs">Excel / Calc</span>
                <span className="text-[10px] text-stone-500 line-clamp-1">XLS XML المعتمد</span>
              </button>

              {/* PDF */}
              <button
                type="button"
                onClick={() => setFormat('pdf')}
                className={`p-3.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
                  format === 'pdf'
                    ? 'border-rose-600 bg-rose-50/80 text-rose-950 shadow-xs ring-2 ring-rose-600/20'
                    : 'border-stone-200 hover:border-rose-300 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <Printer className="w-6 h-6 text-rose-700" />
                <span className="font-bold text-xs">PDF للطباعة</span>
                <span className="text-[10px] text-stone-500 line-clamp-1">كشف رسمي محمي</span>
              </button>

              {/* HTML */}
              <button
                type="button"
                onClick={() => setFormat('html')}
                className={`p-3.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
                  format === 'html'
                    ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 shadow-xs ring-2 ring-indigo-600/20'
                    : 'border-stone-200 hover:border-indigo-300 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <Globe className="w-6 h-6 text-indigo-700" />
                <span className="font-bold text-xs">HTML ويب</span>
                <span className="text-[10px] text-stone-500 line-clamp-1">صفحة ويب متكاملة</span>
              </button>

              {/* CSV */}
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`p-3.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1.5 ${
                  format === 'csv'
                    ? 'border-amber-600 bg-amber-50/80 text-amber-950 shadow-xs ring-2 ring-amber-600/20'
                    : 'border-stone-200 hover:border-amber-300 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <FileText className="w-6 h-6 text-amber-700" />
                <span className="font-bold text-xs">CSV</span>
                <span className="text-[10px] text-stone-500 line-clamp-1">بيانات UTF-8 BOM</span>
              </button>
            </div>
          </div>

          {/* 2️⃣ نطاق التصدير */}
          <div>
            <label className="font-bold text-stone-900 mb-2 block text-xs uppercase tracking-wider text-emerald-900">
              2. نطاق البيانات المحددة
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <label
                className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition ${
                  scope === 'filtered'
                    ? 'border-emerald-600 bg-emerald-50/60 text-emerald-950 font-bold'
                    : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="export-scope"
                  value="filtered"
                  checked={scope === 'filtered'}
                  onChange={() => setScope('filtered')}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span className="text-xs">المعروضة حالياً ({filteredRecords.length})</span>
              </label>

              <label
                className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition ${
                  scope === 'all'
                    ? 'border-emerald-600 bg-emerald-50/60 text-emerald-950 font-bold'
                    : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="export-scope"
                  value="all"
                  checked={scope === 'all'}
                  onChange={() => setScope('all')}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span className="text-xs">جميع السجلات ({allRecords.length})</span>
              </label>

              <label
                className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition ${
                  scope === 'selected'
                    ? 'border-emerald-600 bg-emerald-50/60 text-emerald-950 font-bold'
                    : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                } ${selectedCount === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <input
                  type="radio"
                  name="export-scope"
                  value="selected"
                  checked={scope === 'selected'}
                  disabled={selectedCount === 0}
                  onChange={() => setScope('selected')}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span className="text-xs">المحددة فقط ({selectedCount})</span>
              </label>
            </div>
          </div>

          {/* 3️⃣ خيارات التنسيق الاحترافي */}
          <div className="bg-stone-50 p-4 rounded-xl border border-stone-200">
            <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider text-emerald-900 mb-3">
              3. خيارات التنسيق والطباعة
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={colors}
                  onChange={(e) => setColors(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>✅ تلوين الخلايا حسب المأذونية (7 ألوان) والحالات</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={borders}
                  onChange={(e) => setBorders(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>✅ رسم الحدود والخطوط الفاصلة</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={header}
                  onChange={(e) => setHeader(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>✅ ترويسة رسمية (جمهورية مصر العربية)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={footer}
                  onChange={(e) => setFooter(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>✅ تذييل بالتوقيعات واعتماد الموثق</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={rtl}
                  onChange={(e) => setRtl(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>✅ اتجاه عربي كامل من اليمين لليسار (RTL)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={freeze}
                  onChange={(e) => setFreeze(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>❄️ تثبيت صف الرأس عند التمرير (Freeze Panes)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={altRows}
                  onChange={(e) => setAltRows(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>🦓 تلوين الصفوف بالتناوب (Zebra striping)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={autofit}
                  onChange={(e) => setAutofit(e.target.checked)}
                  className="accent-emerald-700 w-4 h-4"
                />
                <span>📐 احتواء تلقائي متناسق لعرض الأعمدة</span>
              </label>
            </div>
          </div>

          {/* 4️⃣ نظام الحماية والأمان الشامل */}
          <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200">
            <h4 className="font-bold text-amber-950 text-xs uppercase tracking-wider flex items-center gap-1.5 mb-3">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span>4. نظام الحماية والأمان المعتمد</span>
            </h4>

            <div className="space-y-3">
              {/* كلمة المرور */}
              <div>
                <label className="flex items-center gap-2 text-xs font-bold text-amber-950 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enablePassword}
                    onChange={(e) => setEnablePassword(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <Lock className="w-3.5 h-3.5 text-amber-700" />
                  <span>تفعيل الحماية بكلمة مرور (Excel / Calc)</span>
                </label>

                {enablePassword && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2.5 pr-6 animate-fadeIn">
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        🔐 كلمة مرور الفتح (Read Password)
                      </label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="اتركها فارغة لفتح حر"
                        className="w-full px-3 py-1.5 rounded-lg border border-amber-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        🔒 كلمة مرور التعديل (Modify Password)
                      </label>
                      <input
                        type="password"
                        value={modifyPassword}
                        onChange={(e) => setModifyPassword(e.target.value)}
                        placeholder="لمنع التعديل على البيانات"
                        className="w-full px-3 py-1.5 rounded-lg border border-amber-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={readonly}
                    onChange={(e) => setReadonly(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <span>📖 وضع القراءة فقط (منع التعديل نهائياً)</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={nocopy}
                    onChange={(e) => setNocopy(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <span>🚫 منع النسخ واللصق (No-Copy Protection)</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={noprint}
                    onChange={(e) => setNoprint(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <span>🖨️ منع الطباعة غير المصرح بها</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={watermark}
                    onChange={(e) => setWatermark(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <Droplet className="w-3.5 h-3.5 text-blue-600" />
                  <span>💧 علامة مائية باسم الموثق</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={signature}
                    onChange={(e) => setSignature(e.target.checked)}
                    className="accent-amber-700 w-4 h-4"
                  />
                  <PenTool className="w-3.5 h-3.5 text-emerald-700" />
                  <span>✍️ توقيع رقمي مع التاريخ والموثق</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* أزرار الإجراء */}
        <div className="bg-stone-100 px-6 py-4 border-t border-stone-200 flex items-center justify-between gap-3">
          <div className="text-xs text-stone-600 font-semibold">
            عدد السجلات المستهدفة: <strong className="text-emerald-800">{getRecordCountForScope()} سجل</strong>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-stone-200 text-stone-700 border border-stone-300 rounded-xl text-xs font-bold transition"
            >
              إلغاء
            </button>
            <button
              onClick={handleExport}
              className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-md hover:shadow-lg"
            >
              <Download className="w-4 h-4" />
              <span>تنفيذ التصدير</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
