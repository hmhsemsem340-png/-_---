// ============================================================
// 📊 جدول البيانات الرئيسي فائق السرعة
// High-Performance Data Table with Geolocation, Audit & Row Selection
// ============================================================

import React from 'react';
import { StreetRecord, TableDensity, ViewMode } from '../types';
import { NOTARIZATION_COLOR_CONFIG } from './NotarizationTags';
import { 
  Edit3, 
  MapPin, 
  History, 
  Trash2, 
  Link2, 
  Compass, 
  Calendar, 
  CreditCard
} from 'lucide-react';

interface DataTableProps {
  records: StreetRecord[];
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onToggleSelectAll: () => void;
  onEdit: (record: StreetRecord) => void;
  onDelete: (id: string) => void;
  onOpenAudit: (record: StreetRecord) => void;
  density: TableDensity;
  viewMode: ViewMode;
  showSharedBadge?: boolean;
  fontSize?: number;
}

export const DataTable: React.FC<DataTableProps> = ({
  records,
  selectedIds,
  onToggleSelect,
  onToggleSelectAll,
  onEdit,
  onDelete,
  onOpenAudit,
  density,
  viewMode,
  showSharedBadge = true,
  fontSize
}) => {
  const isAllSelected = records.length > 0 && records.every((r) => selectedIds.has(r.id));

  // فتح خرائط جوجل للشارع في دمنهور
  const handleOpenGoogleMaps = (record: StreetRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    let query = `${record.streetName}، دمنهور، محافظة البحيرة، مصر`;
    if (record.gpsCoordinates) {
      const match = record.gpsCoordinates.match(/([0-9]+\.?[0-9]*)\s*°?\s*[Nn]?\s*[,،\s]+\s*([0-9]+\.?[0-9]*)\s*°?\s*[Ee]?/);
      if (match) {
        query = `${match[1]},${match[2]}`;
      }
    }
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // كثافة الصفوف
  const paddingClass = 
    density === 'compact' ? 'py-1.5 px-2 text-xs' :
    density === 'comfortable' ? 'py-3.5 px-3.5 text-sm' :
    'py-2 px-2.5 text-xs';

  const rowHeightClass =
    density === 'compact' ? 'h-9' :
    density === 'comfortable' ? 'h-16' :
    'h-12';

  const textSizeClass =
    viewMode === 'reading' ? 'text-base font-medium' : 'text-xs';

  return (
    <div className="flex-1 overflow-auto bg-white border border-stone-200">
      <table className="w-full text-right border-collapse select-text">
        {/* ═══ رؤوس الأعمدة ═══ */}
        <thead className="bg-stone-900 text-white sticky top-0 z-10 shadow-xs text-xs select-none">
          <tr>
            <th className="w-10 text-center py-2.5 px-1 border-b border-stone-800">
              <input
                type="checkbox"
                checked={isAllSelected}
                onChange={onToggleSelectAll}
                className="w-3.5 h-3.5 text-emerald-600 rounded border-stone-700 cursor-pointer"
                title="تحديد كل السجلات المعروضة"
              />
            </th>
            <th className="w-12 text-center py-2.5 px-1 font-bold border-b border-stone-800">
              م
            </th>
            <th className="py-2.5 px-3 font-bold border-b border-stone-800 min-w-[220px]">
              اسم الشارع / التقسيم
            </th>
            <th className="py-2.5 px-3 font-bold border-b border-stone-800 min-w-[130px]">
              المأذونية
            </th>
            <th className="py-2.5 px-2.5 font-bold border-b border-stone-800 min-w-[90px]">
              النوع
            </th>
            <th className="py-2.5 px-3 font-bold border-b border-stone-800 min-w-[240px]">
              الوصف والبيان
            </th>
            <th className="py-2.5 px-3 font-bold border-b border-stone-800 min-w-[180px]">
              المعالم المميزة
            </th>
            <th className="py-2.5 px-3 font-bold border-b border-stone-800 min-w-[180px]">
              الحدود الجغرافية
            </th>
            <th className="py-2.5 px-2 text-center font-bold border-b border-stone-800 min-w-[70px]">
              الحالة
            </th>
            <th className="w-32 text-center py-2.5 px-2 font-bold border-b border-stone-800">
              الإجراءات
            </th>
          </tr>
        </thead>

        {/* ═══ صفوف البيانات ═══ */}
        <tbody className={`divide-y divide-stone-200 ${textSizeClass}`}>
          {records.length === 0 ? (
            <tr>
              <td colSpan={10} className="py-16 text-center text-stone-400 bg-stone-50">
                <div className="flex flex-col items-center justify-center gap-2">
                  <Compass className="w-12 h-12 text-stone-300 stroke-[1.5]" />
                  <p className="text-base font-semibold text-stone-600">لا توجد شوارع أو سجلات مطابقة للبحث أو التصفية</p>
                  <p className="text-xs text-stone-400">يمكنك تعديل كلمات البحث، إزالة وسوم التصفية، أو إضافة شارع جديد</p>
                </div>
              </td>
            </tr>
          ) : (
            records.map((record, index) => {
              const isSelected = selectedIds.has(record.id);
              const colorConfig = NOTARIZATION_COLOR_CONFIG[record.notarization] || {
                bg: 'bg-stone-100',
                text: 'text-stone-800',
                border: 'border-stone-300'
              };

              return (
                <tr
                  key={record.id}
                  onDoubleClick={() => onEdit(record)}
                  className={`transition-colors cursor-pointer group ${rowHeightClass} ${
                    isSelected
                      ? 'bg-emerald-50/80 hover:bg-emerald-100/70'
                      : index % 2 === 0
                      ? 'bg-white hover:bg-stone-50/90'
                      : 'bg-stone-50/40 hover:bg-stone-100/80'
                  } ${record.sharedNotarization ? 'border-r-4 border-r-amber-500' : ''}`}
                  title="انقر نقراً مزدوجاً لفتح التعديل المباشر"
                >
                  {/* Checkbox */}
                  <td className="text-center py-1 px-1" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => onToggleSelect(record.id)}
                      className="w-3.5 h-3.5 text-emerald-600 rounded border-stone-300 cursor-pointer"
                    />
                  </td>

                  {/* مسلسل */}
                  <td className="text-center text-stone-400 font-mono text-[11px] select-none">
                    {index + 1}
                  </td>

                  {/* اسم الشارع */}
                  <td className={`${paddingClass} font-semibold text-stone-900`}>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-stone-900 group-hover:text-emerald-700 transition">
                        {record.streetName}
                      </span>
                      {record.sharedNotarization && showSharedBadge && (
                        <span
                          className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs"
                          title={record.sharedNote || `مشترك مع مأذونية ${record.sharedNotarization}`}
                        >
                          <Link2 className="w-2.5 h-2.5 text-amber-700" />
                          <span>مشترك ({record.sharedNotarization})</span>
                        </span>
                      )}
                      {record.version > 1 && (
                        <span className="text-[10px] text-stone-400 font-normal">
                          (إصدار {record.version})
                        </span>
                      )}
                    </div>
                  </td>

                  {/* المأذونية */}
                  <td className={paddingClass}>
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border shadow-2xs ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}
                    >
                      {record.notarization}
                    </span>
                  </td>

                  {/* نوع السجل */}
                  <td className={paddingClass}>
                    <span className="text-stone-600 bg-stone-100 border border-stone-200 px-2 py-0.5 rounded text-[11px]">
                      {record.recordType}
                    </span>
                  </td>

                  {/* الوصف والبيان */}
                  <td className={`${paddingClass} text-stone-600 max-w-[260px] truncate`} title={record.description}>
                    <div className="flex items-center gap-1">
                      <span className="truncate">{record.description || '-'}</span>
                      {record.contractDate && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] text-stone-400 shrink-0" title={`تاريخ العقد: ${record.contractDate}`}>
                          <Calendar className="w-3 h-3 text-stone-400" />
                        </span>
                      )}
                      {record.nationalId && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] text-stone-400 shrink-0" title={`الرقم القومي: ${record.nationalId}`}>
                          <CreditCard className="w-3 h-3 text-stone-400" />
                        </span>
                      )}
                    </div>
                  </td>

                  {/* المعالم المميزة */}
                  <td className={`${paddingClass} text-stone-700 max-w-[180px] truncate`} title={record.landmarks}>
                    {record.landmarks || '-'}
                  </td>

                  {/* الحدود الجغرافية */}
                  <td className={`${paddingClass} text-stone-700 max-w-[180px] truncate`} title={record.boundaries}>
                    {record.boundaries || '-'}
                  </td>

                  {/* الحالة */}
                  <td className="text-center py-1 px-1">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        record.status === 'نشط'
                          ? 'bg-emerald-100 text-emerald-800'
                          : record.status === 'معلّق'
                          ? 'bg-amber-100 text-amber-800'
                          : record.status === 'قيد المراجعة'
                          ? 'bg-sky-100 text-sky-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>

                  {/* الإجراءات */}
                  <td className="text-center py-1 px-1" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-center gap-1">
                      {/* تعديل */}
                      <button
                        onClick={() => onEdit(record)}
                        className="p-1.5 text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 rounded transition"
                        title="تعديل بيانات الشارع (نقر مزدوج على الصف)"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {/* خريطة جوجل */}
                      <button
                        onClick={(e) => handleOpenGoogleMaps(record, e)}
                        className="p-1.5 text-stone-600 hover:text-sky-700 hover:bg-sky-50 rounded transition"
                        title="معاينة الموقع الدقيق على خرائط جوجل في دمنهور"
                      >
                        <MapPin className="w-3.5 h-3.5" />
                      </button>

                      {/* سجل التعديلات والشهادة */}
                      <button
                        onClick={() => onOpenAudit(record)}
                        className="p-1.5 text-stone-600 hover:text-purple-700 hover:bg-purple-50 rounded transition"
                        title="عرض سجل التعديلات وطباعة شهادة التدقيق القانونية"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>

                      {/* حذف */}
                      <button
                        onClick={() => onDelete(record.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                        title="حذف السجل (مع حفظ لقطة تراجع)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};
