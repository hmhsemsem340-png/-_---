// ============================================================
// 📝 نافذة إضافة وتعديل السجلات مع الفحص الاستباقي للتكرار
// Record Entry & Edit Modal with Proactive Duplicate Warning
// ============================================================

import React, { useState, useEffect, useMemo } from 'react';
import { 
  StreetRecord, 
  OFFICIAL_NOTARIZATIONS, 
  ALL_DISTRICTS, 
  RECORD_TYPES, 
  RecordCategory, 
  RecordType, 
  RecordStatus 
} from '../types';
import { DuplicateEngine } from '../utils/duplicateEngine';
import { ArabicUtils } from '../utils/arabicUtils';
import { 
  X, 
  Save, 
  AlertTriangle, 
  ArrowRight, 
  ArrowLeft, 
  MapPin, 
  ExternalLink,
  Layers,
  FileCheck
} from 'lucide-react';

interface RecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordToEdit?: StreetRecord | null;
  onSave: (recordData: Partial<StreetRecord>, isSequentialNext?: boolean) => void;
  allRecords: StreetRecord[];
  currentIndex?: number;
  totalCount?: number;
  onNavigateNext?: () => void;
  onNavigatePrev?: () => void;
}

export const RecordModal: React.FC<RecordModalProps> = ({
  isOpen,
  onClose,
  recordToEdit,
  onSave,
  allRecords,
  currentIndex,
  totalCount,
  onNavigateNext,
  onNavigatePrev
}) => {
  const isEditing = !!recordToEdit;

  // حالة حقول النموذج
  const [streetName, setStreetName] = useState('');
  const [notarization, setNotarization] = useState<string>('شبرا بحري');
  const [category, setCategory] = useState<RecordCategory>('مأذونية رسمية');
  const [recordType, setRecordType] = useState<RecordType>('شارع');
  const [description, setDescription] = useState('');
  const [landmarks, setLandmarks] = useState('');
  const [boundaries, setBoundaries] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [contractDate, setContractDate] = useState('');
  const [gpsCoordinates, setGpsCoordinates] = useState('');
  const [status, setStatus] = useState<RecordStatus>('نشط');
  const [sharedNotarization, setSharedNotarization] = useState('');
  const [sharedNote, setSharedNote] = useState('');

  // تعبئة البيانات عند فتح المودال أو تغيير السجل
  useEffect(() => {
    if (recordToEdit) {
      setStreetName(recordToEdit.streetName || '');
      setNotarization(recordToEdit.notarization || 'شبرا بحري');
      setCategory(recordToEdit.category || 'مأذونية رسمية');
      setRecordType(recordToEdit.recordType || 'شارع');
      setDescription(recordToEdit.description || '');
      setLandmarks(recordToEdit.landmarks || '');
      setBoundaries(recordToEdit.boundaries || '');
      setNationalId(recordToEdit.nationalId || '');
      setContractDate(recordToEdit.contractDate || '');
      setGpsCoordinates(recordToEdit.gpsCoordinates || '');
      setStatus(recordToEdit.status || 'نشط');
      setSharedNotarization(recordToEdit.sharedNotarization || '');
      setSharedNote(recordToEdit.sharedNote || '');
    } else {
      setStreetName('');
      setNotarization('شبرا بحري');
      setCategory('مأذونية رسمية');
      setRecordType('شارع');
      setDescription('');
      setLandmarks('');
      setBoundaries('');
      setNationalId('');
      setContractDate('');
      setGpsCoordinates('');
      setStatus('نشط');
      setSharedNotarization('');
      setSharedNote('');
    }
  }, [recordToEdit, isOpen]);

  // الكشف اللحظي الاستباقي عن التكرار أثناء الكتابة
  const duplicateCheck = useMemo(() => {
    if (!streetName || streetName.trim().length < 2) return null;
    return DuplicateEngine.checkDuplicate(
      streetName,
      notarization,
      allRecords,
      recordToEdit?.id
    );
  }, [streetName, notarization, allRecords, recordToEdit]);

  // استخراج المحافظة وتاريخ الميلاد تلقائياً من الرقم القومي
  const nationalIdInfo = useMemo(() => {
    return ArabicUtils.parseNationalId(nationalId);
  }, [nationalId]);

  if (!isOpen) return null;

  const handleSubmit = (e?: React.FormEvent, isSequentialNext: boolean = false) => {
    if (e) e.preventDefault();
    if (!streetName.trim()) {
      alert('يرجى إدخال اسم الشارع أولاً.');
      return;
    }

    const payload: Partial<StreetRecord> = {
      streetName: streetName.trim(),
      notarization,
      category,
      recordType,
      description: description.trim(),
      landmarks: landmarks.trim(),
      boundaries: boundaries.trim(),
      nationalId: nationalId.trim(),
      contractDate: contractDate.trim(),
      gpsCoordinates: gpsCoordinates.trim(),
      status,
      sharedNotarization: sharedNotarization.trim() || undefined,
      sharedNote: sharedNote.trim() || undefined
    };

    onSave(payload, isSequentialNext);
  };

  // فتح معاينة إحداثيات دمنهور على جوجل
  const handlePreviewMap = () => {
    const query = gpsCoordinates || `${streetName || 'دمنهور'}، البحيرة، مصر`;
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ ترويسة النافذة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white font-bold">
              {isEditing ? '✏️' : '➕'}
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                {isEditing ? `تعديل سجل: ${recordToEdit.streetName}` : 'إضافة شارع / تقسيم مكاني جديد'}
              </h2>
              {currentIndex !== undefined && totalCount !== undefined && (
                <span className="text-xs text-stone-400 font-mono">
                  وضع التدقيق المتتالي — سجل {currentIndex + 1} من {totalCount}
                </span>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition"
            title="إغلاق (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ متن النموذج القابل للتمرير ═══ */}
        <form onSubmit={(e) => handleSubmit(e, false)} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* تنبيه التكرار الاستباقي اللحظي */}
          {duplicateCheck && duplicateCheck.isDuplicate && (
            <div className="bg-amber-50 border-r-4 border-amber-500 p-3.5 rounded-md shadow-xs flex items-start gap-3 text-amber-900">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <p className="font-bold text-amber-950">
                  ⚠️ تنبيه: تم رصد شارع مشابه مسجل بالفعل (نسبة التطابق: {(duplicateCheck.similarityScore * 100).toFixed(0)}%)
                </p>
                <p className="mt-1 text-amber-800">
                  السجل المطابق: <strong>{duplicateCheck.matchedRecords[0]?.streetName}</strong> بجهة مأذونية{' '}
                  <span className="underline font-semibold">{duplicateCheck.matchedRecords[0]?.notarization}</span>.
                </p>
                <p className="text-[11px] text-amber-700 mt-1">
                  عند النقر على "حفظ"، ستظهر لك نافذة فض النزاع الذكية لدمج المعالم، استبدال السجل الأصلي، أو الحفظ المنفصل.
                </p>
              </div>
            </div>
          )}

          {/* ═══ القسم 1: بيانات الشارع الأساسية ═══ */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-3.5">
            <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-2">
              <Layers className="w-4 h-4 text-emerald-700" />
              <span>1. البيانات الأساسية والتصنيف القانوني</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* اسم الشارع */}
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  اسم الشارع / الحارة / التقسيم <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={streetName}
                  onChange={(e) => setStreetName(e.target.value)}
                  placeholder="مثال: شارع عبد السلام الشاذلي، حارة الصاغة..."
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-semibold"
                />
              </div>

              {/* المأذونية */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  جهة المأذونية (الحي التابع) <span className="text-rose-600">*</span>
                </label>
                <select
                  value={notarization}
                  onChange={(e) => setNotarization(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <optgroup label="المأذونيات السبع الرسمية">
                    {OFFICIAL_NOTARIZATIONS.map((name) => (
                      <option key={name} value={name}>
                        {name} (رسمي)
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="أحياء وتفرعات أخرى">
                    {ALL_DISTRICTS.filter((d) => !OFFICIAL_NOTARIZATIONS.includes(d as any)).map((name) => (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* نوع السجل */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  نوع السجل الجغرافي
                </label>
                <select
                  value={recordType}
                  onChange={(e) => setRecordType(e.target.value as RecordType)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  {RECORD_TYPES.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              {/* التصنيف القانوني */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  التصنيف القانوني
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as RecordCategory)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="مأذونية رسمية">مأذونية رسمية</option>
                  <option value="مأذونية غير رسمية">مأذونية غير رسمية</option>
                  <option value="تقاسيم وعقود">تقاسيم وعقود</option>
                  <option value="حي">حي</option>
                  <option value="شارع">شارع</option>
                </select>
              </div>

              {/* الحالة */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  حالة السجل
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as RecordStatus)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="نشط">نشط</option>
                  <option value="معلّق">معلّق</option>
                  <option value="قيد المراجعة">قيد المراجعة</option>
                  <option value="ملغي">ملغي</option>
                </select>
              </div>
            </div>
          </div>

          {/* ═══ القسم 2: المعالم الجغرافية والحدود المكانية ═══ */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-3.5">
            <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-2">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>2. المعالم الجغرافية والحدود المكانية</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* المعالم المميزة */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  المعالم المميزة (مساجد، مدارس، منشآت)
                </label>
                <input
                  type="text"
                  value={landmarks}
                  onChange={(e) => setLandmarks(e.target.value)}
                  placeholder="مثال: مسجد سيدي عمر، مجمع المحاكم، بنك مصر..."
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* الحدود الجغرافية */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  الحدود الجغرافية (من ... إلى ...)
                </label>
                <input
                  type="text"
                  value={boundaries}
                  onChange={(e) => setBoundaries(e.target.value)}
                  placeholder="مثال: يمتد من ميدان الساعة حتى كوبري إفلاقة..."
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* الإحداثيات الجغرافية GPS */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-800">
                    الإحداثيات الجغرافية (GPS)
                  </label>
                  <button
                    type="button"
                    onClick={handlePreviewMap}
                    className="text-[11px] text-sky-600 hover:text-sky-700 flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>معاينة في خرائط دمنهور</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={gpsCoordinates}
                  onChange={(e) => setGpsCoordinates(e.target.value)}
                  placeholder="مثال: 31.0378°N, 30.4688°E"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600 text-left"
                  dir="ltr"
                />
              </div>

              {/* المأذونية المشتركة (إن وجدت) */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  المأذونية المشتركة (في حال تداخل الشارع)
                </label>
                <select
                  value={sharedNotarization}
                  onChange={(e) => setSharedNotarization(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="">(غير مشترك - يتبع مأذونية واحدة فقط)</option>
                  {ALL_DISTRICTS.map((name) => (
                    <option key={name} value={name}>
                      مشترك مع: {name}
                    </option>
                  ))}
                </select>
              </div>

              {/* ملاحظات الاشتراك */}
              {sharedNotarization && (
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-amber-900 mb-1">
                    بيان الاشتراك والتداخل المكاني
                  </label>
                  <input
                    type="text"
                    value={sharedNote}
                    onChange={(e) => setSharedNote(e.target.value)}
                    placeholder="مثال: [تنبيه اشتراك مكاني: هذا الشارع مشترك مع مأذونية (سكنيدة) في مقاطعه الشرقية]"
                    className="w-full px-3 py-2 bg-amber-50 border border-amber-300 rounded-md text-xs text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              )}
            </div>
          </div>

          {/* ═══ القسم 3: بيانات التوثيق والعقود والملاحظات ═══ */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-3.5">
            <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5 border-b border-stone-200 pb-2">
              <FileCheck className="w-4 h-4 text-emerald-700" />
              <span>3. بيانات التوثيق، العقود المسجلة، والأوصاف</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* الرقم القومي */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  الرقم القومي للموثق / صاحب الشأن (اختياري)
                </label>
                <input
                  type="text"
                  maxLength={14}
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="14 رقماً"
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600 text-left"
                  dir="ltr"
                />
                {nationalIdInfo.isValid && (
                  <p className="text-[11px] text-emerald-700 mt-1">
                    ✓ المحافظة: {nationalIdInfo.governorate} | الميلاد: {nationalIdInfo.birthDate}
                  </p>
                )}
              </div>

              {/* تاريخ العقد */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  تاريخ العقد / السند المسجل (اختياري)
                </label>
                <input
                  type="date"
                  value={contractDate}
                  onChange={(e) => setContractDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* الوصف والبيان التفصيلي */}
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  الوصف التفصيلي، الأحواض الزراعية، وتفاصيل الأوصاف
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="سجل أية تفاصيل خاصة بالأحواض، العقود المسجلة بالشهر العقاري، أو التقاسيم المعتمدة..."
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 resize-y"
                ></textarea>
              </div>
            </div>
          </div>
        </form>

        {/* ═══ تذييل أزرار الإجراءات والتدقيق المتتالي ═══ */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* أزرار التنقل بين السجلات في وضع التدقيق المتتالي */}
          <div className="flex items-center gap-1.5">
            {onNavigatePrev && (
              <button
                type="button"
                onClick={onNavigatePrev}
                className="px-2.5 py-1.5 bg-white hover:bg-stone-50 border border-stone-300 rounded-md text-xs font-semibold text-stone-700 flex items-center gap-1 transition"
                title="السابق (Alt + P)"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>السابق</span>
                <kbd className="hidden sm:inline-block text-[10px] text-stone-400">Alt+P</kbd>
              </button>
            )}

            {onNavigateNext && (
              <button
                type="button"
                onClick={onNavigateNext}
                className="px-2.5 py-1.5 bg-white hover:bg-stone-50 border border-stone-300 rounded-md text-xs font-semibold text-stone-700 flex items-center gap-1 transition"
                title="التالي (Alt + N)"
              >
                <span>التالي</span>
                <ArrowLeft className="w-3.5 h-3.5" />
                <kbd className="hidden sm:inline-block text-[10px] text-stone-400">Alt+N</kbd>
              </button>
            )}
          </div>

          {/* أزرار الحفظ والإلغاء */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 bg-white hover:bg-stone-200 text-stone-700 border border-stone-300 rounded-md text-xs font-semibold transition"
            >
              إلغاء
            </button>

            {onNavigateNext && (
              <button
                type="button"
                onClick={() => handleSubmit(undefined, true)}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-md text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                title="حفظ السجل الحالي والانتقال التلقائي للشارع التالي (Ctrl + Enter)"
              >
                <Save className="w-4 h-4" />
                <span>حفظ والتالي</span>
                <kbd className="hidden md:inline-block px-1 py-0.2 text-[10px] bg-emerald-800 rounded text-emerald-200">
                  Ctrl+Enter
                </kbd>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleSubmit(undefined, false)}
              className="px-4 py-1.5 bg-stone-900 hover:bg-black text-white rounded-md text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
            >
              <Save className="w-4 h-4" />
              <span>{isEditing ? 'حفظ التعديلات' : 'إضافة السجل'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
