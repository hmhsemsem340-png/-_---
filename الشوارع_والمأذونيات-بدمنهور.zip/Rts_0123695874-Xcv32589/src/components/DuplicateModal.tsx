// ============================================================
// ⚠️ نافذة فض النزاع وحظر التكرار الذكي
// Duplicate Prevention & Dispute Resolution Modal (3 Smart Options)
// ============================================================

import React from 'react';
import { StreetRecord, DuplicateCheckResult } from '../types';
import { AlertTriangle, GitMerge, RefreshCw, CopyPlus, X } from 'lucide-react';

interface DuplicateModalProps {
  isOpen: boolean;
  onClose: () => void;
  incomingRecord: Partial<StreetRecord>;
  duplicateResult: DuplicateCheckResult;
  onResolve: (action: 'merge' | 'replace' | 'separate') => void;
}

export const DuplicateModal: React.FC<DuplicateModalProps> = ({
  isOpen,
  onClose,
  incomingRecord,
  duplicateResult,
  onResolve
}) => {
  if (!isOpen) return null;

  const existing = duplicateResult.matchedRecords[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-2xl overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-amber-600 text-white px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-100" />
            <h2 className="text-base font-bold font-['Cairo'] text-white">
              تنبيه تكرار: فض النزاع وتوثيق الشارع المشابه
            </h2>
          </div>
          <button onClick={onClose} className="text-amber-100 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg text-xs text-amber-900">
            <p className="font-bold">
              تم اكتشاف تطابق بنسبة {(duplicateResult.similarityScore * 100).toFixed(0)}% مع سجل مسجل مسبقاً في المنظومة.
            </p>
            <p className="mt-1 text-amber-800">
              يرجى اختيار الإجراء القانوني الأنسب لفض هذا التداخل دون فقدان أو تشويه البيانات السابقة:
            </p>
          </div>

          {/* ═══ جدول المقارنة بين السجل الحالي والجديد ═══ */}
          <div className="border border-stone-200 rounded-lg overflow-hidden text-xs">
            <table className="w-full text-right divide-y divide-stone-200">
              <thead className="bg-stone-100 text-stone-700 font-bold">
                <tr>
                  <th className="p-2.5 w-1/4">الحقل</th>
                  <th className="p-2.5 w-3/8 text-stone-900 bg-stone-50 border-r border-stone-200">
                    السجل الأصلي في المنظومة
                  </th>
                  <th className="p-2.5 w-3/8 text-emerald-900 bg-emerald-50/50 border-r border-stone-200">
                    البيانات الجديدة المدخلة
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 bg-white">
                <tr>
                  <td className="p-2 font-semibold text-stone-600">اسم الشارع</td>
                  <td className="p-2 bg-stone-50 border-r border-stone-200 font-bold text-stone-900">
                    {existing?.streetName}
                  </td>
                  <td className="p-2 bg-emerald-50/30 border-r border-stone-200 font-bold text-emerald-800">
                    {incomingRecord.streetName}
                  </td>
                </tr>
                <tr>
                  <td className="p-2 font-semibold text-stone-600">جهة المأذونية</td>
                  <td className="p-2 bg-stone-50 border-r border-stone-200">
                    {existing?.notarization}
                  </td>
                  <td className="p-2 bg-emerald-50/30 border-r border-stone-200">
                    {incomingRecord.notarization}
                  </td>
                </tr>
                <tr>
                  <td className="p-2 font-semibold text-stone-600">المعالم</td>
                  <td className="p-2 bg-stone-50 border-r border-stone-200">
                    {existing?.landmarks || '-'}
                  </td>
                  <td className="p-2 bg-emerald-50/30 border-r border-stone-200">
                    {incomingRecord.landmarks || '-'}
                  </td>
                </tr>
                <tr>
                  <td className="p-2 font-semibold text-stone-600">الحدود</td>
                  <td className="p-2 bg-stone-50 border-r border-stone-200">
                    {existing?.boundaries || '-'}
                  </td>
                  <td className="p-2 bg-emerald-50/30 border-r border-stone-200">
                    {incomingRecord.boundaries || '-'}
                  </td>
                </tr>
                <tr>
                  <td className="p-2 font-semibold text-stone-600">الوصف</td>
                  <td className="p-2 bg-stone-50 border-r border-stone-200 text-stone-500">
                    {existing?.description || '-'}
                  </td>
                  <td className="p-2 bg-emerald-50/30 border-r border-stone-200 text-stone-600">
                    {incomingRecord.description || '-'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ═══ الخيارات الثلاثة لفض النزاع ═══ */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
            {/* خيار 1: دمج */}
            <button
              onClick={() => onResolve('merge')}
              className="p-3 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg text-right transition flex flex-col justify-between group shadow-xs"
            >
              <div>
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs mb-1">
                  <GitMerge className="w-4 h-4 text-indigo-600 group-hover:scale-110 transition" />
                  <span>1. دمج الملاحظات والمعالم</span>
                </div>
                <p className="text-[11px] text-indigo-700 leading-relaxed">
                  الحفاظ على السجل الأصلي مع ضم المعالم والحدود والأوصاف الجديدة له وتوثيق العملية.
                </p>
              </div>
              <span className="text-[10px] font-bold text-indigo-900 bg-indigo-200/60 px-2 py-0.5 rounded mt-2.5 inline-block text-center">
                موصى به (دمج متكامل)
              </span>
            </button>

            {/* خيار 2: استبدال */}
            <button
              onClick={() => onResolve('replace')}
              className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg text-right transition flex flex-col justify-between group shadow-xs"
            >
              <div>
                <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs mb-1">
                  <RefreshCw className="w-4 h-4 text-amber-600 group-hover:rotate-45 transition" />
                  <span>2. استبدال وتحديث السجل الأصلي</span>
                </div>
                <p className="text-[11px] text-amber-700 leading-relaxed">
                  تحديث بيانات السجل الأصلي كلياً وتسجيل كافة الفروقات السابقة والجديدة في سجل التدقيق.
                </p>
              </div>
              <span className="text-[10px] font-bold text-amber-900 bg-amber-200/60 px-2 py-0.5 rounded mt-2.5 inline-block text-center">
                تحديث شامل
              </span>
            </button>

            {/* خيار 3: حفظ منفصل */}
            <button
              onClick={() => onResolve('separate')}
              className="p-3 bg-stone-50 hover:bg-stone-100 border border-stone-300 rounded-lg text-right transition flex flex-col justify-between group shadow-xs"
            >
              <div>
                <div className="flex items-center gap-1.5 text-stone-900 font-bold text-xs mb-1">
                  <CopyPlus className="w-4 h-4 text-stone-600 group-hover:scale-110 transition" />
                  <span>3. الحفظ كإدخال مكرر منفصل</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  إذا كان هناك مسوغ قانوني (مثلاً وجود شارعين بنفس الاسم في حيين مختلفين بدمنهور).
                </p>
              </div>
              <span className="text-[10px] font-bold text-stone-700 bg-stone-200 px-2 py-0.5 rounded mt-2.5 inline-block text-center">
                حفظ كشارع مستقل
              </span>
            </button>
          </div>
        </div>

        {/* التذييل */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white hover:bg-stone-200 text-stone-700 border border-stone-300 rounded-md text-xs font-semibold transition"
          >
            إلغاء العملية بالكامل
          </button>
        </div>
      </div>
    </div>
  );
};
