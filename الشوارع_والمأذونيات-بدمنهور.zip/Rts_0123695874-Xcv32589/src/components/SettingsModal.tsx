// ============================================================
// ⚙️ لوحة التحكم والإعدادات الشاملة المنظمة بالتبويبات
// Comprehensive Control Panel & Settings Modal with 7 Tabbed Panels
// ============================================================

import React, { useState, useRef } from 'react';
import { 
  UserSettings, 
  ThemeType, 
  TableDensity, 
  ViewMode, 
  ExportFormat,
  StreetRecord,
  AuditLogEntry
} from '../types';
import { 
  Settings, 
  Palette, 
  FileSpreadsheet, 
  Shield, 
  Database, 
  Keyboard, 
  Info, 
  X, 
  Check, 
  Trash2, 
  RotateCcw, 
  Download, 
  Upload, 
  Lock, 
  ShieldCheck, 
  User, 
  Languages, 
  Save, 
  Layers, 
  Type, 
  Eye, 
  Sparkles,
  Printer,
  FileText,
  Globe
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (newSettings: UserSettings) => void;
  allRecords: StreetRecord[];
  auditLog: AuditLogEntry[];
  onExportFullBackup: () => void;
  onImportBackupFile: (file: File) => void;
  onResetAllData: () => void;
  onResetSettingsToDefault: () => void;
}

type TabType = 'general' | 'display' | 'export' | 'security' | 'backup' | 'shortcuts' | 'about';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  allRecords,
  auditLog,
  onExportFullBackup,
  onImportBackupFile,
  onResetAllData,
  onResetSettingsToDefault
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('general');
  const [formSettings, setFormSettings] = useState<UserSettings>({ ...settings });
  const backupFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleUpdate = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    setFormSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onSaveSettings(formSettings);
    onClose();
  };

  const handleBackupFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportBackupFile(file);
      e.target.value = '';
    }
  };

  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'general', label: 'عام', icon: <Settings className="w-4 h-4" /> },
    { id: 'display', label: 'العرض', icon: <Palette className="w-4 h-4" /> },
    { id: 'export', label: 'التصدير', icon: <FileSpreadsheet className="w-4 h-4" /> },
    { id: 'security', label: 'الأمان', icon: <Shield className="w-4 h-4" /> },
    { id: 'backup', label: 'النسخ', icon: <Database className="w-4 h-4" /> },
    { id: 'shortcuts', label: 'الاختصارات', icon: <Keyboard className="w-4 h-4" /> },
    { id: 'about', label: 'حول', icon: <Info className="w-4 h-4" /> },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-stone-900 w-full max-w-4xl rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[90vh] text-stone-900 dark:text-stone-100"
        dir="rtl"
      >
        {/* ═══ ترويسة لوحة التحكم ═══ */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white flex justify-between items-center shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-xs">
              <Settings className="w-6 h-6 text-emerald-200 animate-spin-slow" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-['Cairo'] flex items-center gap-2">
                لوحة التحكم والإعدادات الشاملة
              </h2>
              <p className="text-xs text-emerald-100">
                تخصيص الواجهة، الموثق، معايير التصدير، الأمان، وإدارة النسخ الاحتياطي
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition"
            title="إغلاق (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ شريط التبويبات ═══ */}
        <div className="flex overflow-x-auto bg-stone-100 dark:bg-stone-950 border-b border-stone-200 dark:border-stone-800 px-4 pt-2 gap-1 scrollbar-thin">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap border-t border-x ${
                  isActive
                    ? 'bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 border-stone-200 dark:border-stone-800 shadow-xs'
                    : 'border-transparent text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 hover:bg-stone-200/50 dark:hover:bg-stone-800/50'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* ═══ جسم المحتوى بحسب التبويب ═══ */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-stone-50/50 dark:bg-stone-900/50">
          
          {/* ════════ 1️⃣ تبويب عام ════════ */}
          {activeTab === 'general' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* بيانات الموثق */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <User className="w-4 h-4" />
                  <span>معلومات الموثق المعتمد</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      اسم الموثق / المشرف المسؤول
                    </label>
                    <p className="text-[11px] text-stone-500 dark:text-stone-400 mb-2">
                      يظهر رسمياً في شهادات التدقيق، تذييل التقارير، والعلامة المائية.
                    </p>
                    <input
                      type="text"
                      value={formSettings.operatorName}
                      onChange={(e) => handleUpdate('operatorName', e.target.value)}
                      placeholder="مثال: الأستاذ / حسام الدين الخولي"
                      className="w-full px-3.5 py-2 text-sm bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      لغة المنظومة والتقارير
                    </label>
                    <p className="text-[11px] text-stone-500 dark:text-stone-400 mb-2">
                      الواجهة الرسمية المعتمدة لمحاكم وشوارع دمنهور.
                    </p>
                    <select
                      value={formSettings.language}
                      onChange={(e) => handleUpdate('language', e.target.value as 'ar' | 'en')}
                      className="w-full px-3.5 py-2 text-sm bg-stone-50 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    >
                      <option value="ar">العربية (جمهورية مصر العربية - دمنهور)</option>
                      <option value="en">English (Localization Support)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* السلوك العام للواجهة */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <Settings className="w-4 h-4" />
                  <span>السلوك العام والتنبيهات</span>
                </h3>

                <div className="space-y-3.5">
                  {/* الحفظ التلقائي */}
                  <div className="flex items-center justify-between p-3 bg-stone-50 dark:bg-stone-900/60 rounded-lg border border-stone-200/60 dark:border-stone-800">
                    <div>
                      <span className="text-xs font-bold block text-stone-800 dark:text-stone-200">
                        الحفظ التلقائي الفوري (Auto Save)
                      </span>
                      <span className="text-[11px] text-stone-500 dark:text-stone-400">
                        حفظ أي تعديل مباشرة في ذاكرة المتصفح المحلية مع لقطة تراجع فورية.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formSettings.autoSave}
                        onChange={(e) => handleUpdate('autoSave', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>

                  {/* تأكيد الحذف */}
                  <div className="flex items-center justify-between p-3 bg-stone-50 dark:bg-stone-900/60 rounded-lg border border-stone-200/60 dark:border-stone-800">
                    <div>
                      <span className="text-xs font-bold block text-stone-800 dark:text-stone-200">
                        طلب تأكيد قبل الحذف (Confirm Delete)
                      </span>
                      <span className="text-[11px] text-stone-500 dark:text-stone-400">
                        إظهار نافذة تأكيد لمنع الحذف العرضي للسجلات الفردية أو الجماعية.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formSettings.confirmDelete}
                        onChange={(e) => handleUpdate('confirmDelete', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>

                  {/* إظهار شارة الاشتراك */}
                  <div className="flex items-center justify-between p-3 bg-stone-50 dark:bg-stone-900/60 rounded-lg border border-stone-200/60 dark:border-stone-800">
                    <div>
                      <span className="text-xs font-bold block text-stone-800 dark:text-stone-200">
                        إظهار شارة الاشتراك المكاني 🔗 (Shared Badge)
                      </span>
                      <span className="text-[11px] text-stone-500 dark:text-stone-400">
                        تمييز الشوارع المتداخلة جغرافياً بين أكثر من مأذونية بشارة برتقالية وأيقونة وصلة.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formSettings.showSharedBadge}
                        onChange={(e) => handleUpdate('showSharedBadge', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════════ 2️⃣ تبويب العرض ════════ */}
          {activeTab === 'display' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* الثيمات الأربعة مع المعاينة */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <Palette className="w-4 h-4" />
                  <span>ثيم ومظهر المنظومة (4 ثيمات معتمدة)</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5">
                  {/* أخضر إكسيل */}
                  <div
                    onClick={() => handleUpdate('theme', 'excel-green')}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      formSettings.theme === 'excel-green'
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 shadow-md ring-2 ring-emerald-500/20'
                        : 'border-stone-200 dark:border-stone-700 hover:border-emerald-300 bg-white dark:bg-stone-800'
                    }`}
                  >
                    <div className="h-10 rounded-lg bg-gradient-to-r from-emerald-800 to-emerald-600 mb-2 flex items-center justify-center text-white font-bold text-xs">
                      إكسيل
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">أخضر إكسيل</span>
                      {formSettings.theme === 'excel-green' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 mt-1">
                      المظهر المكتبي الكلاسيكي
                    </p>
                  </div>

                  {/* أزرق إداري */}
                  <div
                    onClick={() => handleUpdate('theme', 'classic-blue')}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      formSettings.theme === 'classic-blue'
                        ? 'border-sky-600 bg-sky-50/50 dark:bg-sky-950/30 shadow-md ring-2 ring-sky-500/20'
                        : 'border-stone-200 dark:border-stone-700 hover:border-sky-300 bg-white dark:bg-stone-800'
                    }`}
                  >
                    <div className="h-10 rounded-lg bg-gradient-to-r from-sky-800 to-sky-600 mb-2 flex items-center justify-center text-white font-bold text-xs">
                      أزرق
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">أزرق إداري</span>
                      {formSettings.theme === 'classic-blue' && <Check className="w-4 h-4 text-sky-600" />}
                    </div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 mt-1">
                      الطابع القضائي الرسمي
                    </p>
                  </div>

                  {/* وضع داكن */}
                  <div
                    onClick={() => handleUpdate('theme', 'dark-mode')}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      formSettings.theme === 'dark-mode'
                        ? 'border-stone-400 bg-stone-900 shadow-md ring-2 ring-stone-400/20'
                        : 'border-stone-200 dark:border-stone-700 hover:border-stone-500 bg-white dark:bg-stone-800'
                    }`}
                  >
                    <div className="h-10 rounded-lg bg-gradient-to-r from-stone-900 to-stone-800 mb-2 flex items-center justify-center text-amber-300 font-bold text-xs border border-stone-700">
                      داكن
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">وضع داكن</span>
                      {formSettings.theme === 'dark-mode' && <Check className="w-4 h-4 text-amber-400" />}
                    </div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 mt-1">
                      مريح للعين والإضاءة الخافتة
                    </p>
                  </div>

                  {/* بنفسجي تفاعلي */}
                  <div
                    onClick={() => handleUpdate('theme', 'dynamic')}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                      formSettings.theme === 'dynamic'
                        ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/30 shadow-md ring-2 ring-purple-500/20'
                        : 'border-stone-200 dark:border-stone-700 hover:border-purple-300 bg-white dark:bg-stone-800'
                    }`}
                  >
                    <div className="h-10 rounded-lg bg-gradient-to-r from-purple-800 to-purple-600 mb-2 flex items-center justify-center text-white font-bold text-xs">
                      تفاعلي
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">بنفسجي تفاعلي</span>
                      {formSettings.theme === 'dynamic' && <Check className="w-4 h-4 text-purple-600" />}
                    </div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 mt-1">
                      تصميم عصري وحيوي
                    </p>
                  </div>
                </div>
              </div>

              {/* كثافة الجدول وحجم الخط */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* كثافة الجدول */}
                <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-3">
                  <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    <span>كثافة جدول البيانات</span>
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => handleUpdate('tableDensity', 'compact')}
                      className={`p-3 rounded-lg border text-center transition ${
                        formSettings.tableDensity === 'compact'
                          ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-750'
                      }`}
                    >
                      <div className="text-base mb-1">📋</div>
                      <div className="text-xs">مضغوط</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdate('tableDensity', 'normal')}
                      className={`p-3 rounded-lg border text-center transition ${
                        formSettings.tableDensity === 'normal'
                          ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-750'
                      }`}
                    >
                      <div className="text-base mb-1">📄</div>
                      <div className="text-xs">عادي</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdate('tableDensity', 'comfortable')}
                      className={`p-3 rounded-lg border text-center transition ${
                        formSettings.tableDensity === 'comfortable'
                          ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-750'
                      }`}
                    >
                      <div className="text-base mb-1">📖</div>
                      <div className="text-xs">مريح</div>
                    </button>
                  </div>
                </div>

                {/* حجم الخط */}
                <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-3">
                  <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <Type className="w-4 h-4" />
                    <span>حجم خط الواجهة الأساسي</span>
                  </h3>
                  <div className="flex items-center justify-between p-3 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-700">
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleUpdate('fontSize', Math.max(10, formSettings.fontSize - 1))}
                        className="w-8 h-8 rounded-lg bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 font-bold text-sm hover:bg-stone-100 flex items-center justify-center shadow-xs"
                      >
                        -
                      </button>
                      <span className="text-base font-bold text-emerald-700 dark:text-emerald-400 min-w-[50px] text-center">
                        {formSettings.fontSize} px
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdate('fontSize', Math.min(20, formSettings.fontSize + 1))}
                        className="w-8 h-8 rounded-lg bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 font-bold text-sm hover:bg-stone-100 flex items-center justify-center shadow-xs"
                      >
                        +
                      </button>
                    </div>
                    <span className="text-xs text-stone-500 dark:text-stone-400">
                      (المدى: 10px إلى 20px)
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════════ 3️⃣ تبويب التصدير ════════ */}
          {activeTab === 'export' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* الصيغة الافتراضية */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>صيغة التصدير الافتراضية</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { id: 'excel', label: 'Excel / Calc', icon: <FileSpreadsheet className="w-5 h-5 text-emerald-600" /> },
                    { id: 'pdf', label: 'PDF رسمي', icon: <Printer className="w-5 h-5 text-rose-600" /> },
                    { id: 'html', label: 'HTML ويب', icon: <Globe className="w-5 h-5 text-indigo-600" /> },
                    { id: 'csv', label: 'CSV مجرد', icon: <FileText className="w-5 h-5 text-amber-600" /> },
                  ].map((fmt) => (
                    <div
                      key={fmt.id}
                      onClick={() => handleUpdate('exportFormat', fmt.id as ExportFormat)}
                      className={`p-3 rounded-xl border-2 cursor-pointer transition text-center ${
                        formSettings.exportFormat === fmt.id
                          ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold shadow-xs'
                          : 'border-stone-200 dark:border-stone-700 hover:border-emerald-300 bg-white dark:bg-stone-800'
                      }`}
                    >
                      <div className="flex justify-center mb-1.5">{fmt.icon}</div>
                      <div className="text-xs">{fmt.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* خيارات التنسيق والحماية المضمنة في التصدير */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <Sparkles className="w-4 h-4" />
                  <span>خيارات التنسيق والحماية المعتمدة بالتصدير</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {[
                    { key: 'exportColors', label: 'تلوين الخلايا (7 ألوان للمأذونيات)', desc: 'تمييز بصري للمأذونيات والحالات' },
                    { key: 'exportBorders', label: 'إظهار الحدود وشبكة الجداول', desc: 'تسطير الخلايا بنسق رسمي' },
                    { key: 'exportHeader', label: 'الترويسة الرسمية للجمهورية', desc: 'جمهورية مصر العربية — محافظة البحيرة' },
                    { key: 'exportFooter', label: 'التذييل بالتوقيع والاعتماد', desc: 'خانات التوقيع وخاتم الجهة' },
                    { key: 'exportRtl', label: 'اتجاه المستند من اليمين لليسار (RTL)', desc: 'محاذاة كاملة للغة العربية' },
                    { key: 'exportWatermark', label: 'العلامة المائية باسم الموثق', desc: 'طباعة اسم الموثق بخلفية المستند' },
                    { key: 'exportSignature', label: 'التوقيع الرقمي والتاريخ الدقيق', desc: 'تضمين بصمة التوقيع والوقت' },
                  ].map((item) => (
                    <div
                      key={item.key}
                      className="flex items-center justify-between p-3 bg-stone-50 dark:bg-stone-900/60 rounded-lg border border-stone-200/60 dark:border-stone-800"
                    >
                      <div>
                        <span className="text-xs font-bold block text-stone-800 dark:text-stone-200">
                          {item.label}
                        </span>
                        <span className="text-[10px] text-stone-500 dark:text-stone-400">
                          {item.desc}
                        </span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!formSettings[item.key as keyof UserSettings]}
                          onChange={(e) => handleUpdate(item.key as keyof UserSettings, e.target.checked as any)}
                          className="sr-only peer"
                        />
                        <div className="w-10 h-5 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ════════ 4️⃣ تبويب الأمان ════════ */}
          {activeTab === 'security' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* حماية وتشفير البيانات */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <ShieldCheck className="w-4 h-4" />
                  <span>حصانة وتشفير البيانات المحلية (Air-Gapped)</span>
                </h3>

                <div className="space-y-3.5">
                  <div className="flex items-center justify-between p-3.5 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-lg border border-emerald-200 dark:border-emerald-800">
                    <div>
                      <span className="text-xs font-bold block text-emerald-900 dark:text-emerald-300">
                        تشفير وتوثيق النسخ الاحتياطية (AES-256 Checksums)
                      </span>
                      <span className="text-[11px] text-emerald-700 dark:text-emerald-400">
                        تضمين بصمة رقمية وتشفير كامل للنسخ المصدرة للتحقق من عدم التلاعب.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formSettings.encryptBackup}
                        onChange={(e) => handleUpdate('encryptBackup', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between p-3.5 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-700">
                    <div>
                      <span className="text-xs font-bold block text-stone-800 dark:text-stone-200">
                        قفل المنظومة بكلمة مرور الجلسة
                      </span>
                      <span className="text-[11px] text-stone-500 dark:text-stone-400">
                        طلب كلمة مرور عند فتح المنظومة لحماية سرية القيود والسجلات.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formSettings.appLockEnabled}
                        onChange={(e) => handleUpdate('appLockEnabled', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* إدارة ومسح البيانات */}
              <div className="bg-rose-50/50 dark:bg-rose-950/20 p-5 rounded-xl border border-rose-200 dark:border-rose-900/50 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-rose-800 dark:text-rose-400 flex items-center gap-2 pb-2 border-b border-rose-200 dark:border-rose-900/50">
                  <Trash2 className="w-4 h-4" />
                  <span>منطقة العمليات الحساسة وإعادة التعيين</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div className="p-3.5 bg-white dark:bg-stone-800 rounded-lg border border-rose-200 dark:border-rose-900/50 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-stone-800 dark:text-stone-200">إعادة تعيين الإعدادات</h4>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
                        استعادة الإعدادات الافتراضية الأصلية دون التأثير على قاعدة بيانات الشوارع.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('هل ترغب في إعادة جميع الإعدادات للوضع الافتراضي؟')) {
                          onResetSettingsToDefault();
                          onClose();
                        }
                      }}
                      className="mt-3 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/40 text-amber-900 dark:text-amber-300 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>إعادة ضبط الإعدادات</span>
                    </button>
                  </div>

                  <div className="p-3.5 bg-white dark:bg-stone-800 rounded-lg border border-rose-200 dark:border-rose-900/50 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-rose-700 dark:text-rose-400">استعادة قاعدة البيانات المعتمدة</h4>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
                        استرجاع كافة سجلات مأذونيات دمنهور الرسمية (2943 شارع) وحفظ لقطة تراجع.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('تحذير: هل أنت متأكد من استعادة قاعدة البيانات المعتمدة الأصلية (2943 شارع ومأذونية)؟ سيتم أخذ لقطة تراجع.')) {
                          onResetAllData();
                          onClose();
                        }
                      }}
                      className="mt-3 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Database className="w-3.5 h-3.5" />
                      <span>استعادة السجلات المعتمدة</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════════ 5️⃣ تبويب النسخ الاحتياطي ════════ */}
          {activeTab === 'backup' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* التكرار التلقائي للنسخ */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <Database className="w-4 h-4" />
                  <span>جدولة النسخ الاحتياطي التلقائي</span>
                </h3>

                <div className="flex items-center justify-between p-3.5 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-700">
                  <div>
                    <label className="text-xs font-bold block text-stone-800 dark:text-stone-200 mb-0.5">
                      تكرار التذكير بالنسخ الاحتياطي
                    </label>
                    <span className="text-[11px] text-stone-500 dark:text-stone-400">
                      تنبيه آلي للموثق لتصدير نسخة أمان دورية.
                    </span>
                  </div>
                  <select
                    value={formSettings.backupFrequency}
                    onChange={(e) => handleUpdate('backupFrequency', e.target.value as any)}
                    className="px-3.5 py-1.5 text-xs bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 rounded-lg font-bold text-emerald-800 dark:text-emerald-300 focus:outline-none"
                  >
                    <option value="daily">يومياً (موصى به)</option>
                    <option value="weekly">أسبوعياً</option>
                    <option value="monthly">شهرياً</option>
                    <option value="never">إيقاف التنبيه</option>
                  </select>
                </div>
              </div>

              {/* التصدير والاستيراد المباشر */}
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-700">
                  <Download className="w-4 h-4" />
                  <span>تصدير واستيراد النسخة الاحتياطية الشاملة</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* تصدير نسخة */}
                  <div className="p-4 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-xl border border-emerald-200 dark:border-emerald-800 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs mb-1">
                        <Download className="w-4 h-4" />
                        <span>تصدير ملف أمان JSON كامل</span>
                      </div>
                      <p className="text-[11px] text-stone-600 dark:text-stone-400">
                        يشمل كافة السجلات ({allRecords.length.toLocaleString('ar-EG')} شارع)، سجل التعديلات التدقيقي ({auditLog.length} قيد)، والإعدادات المخصصة.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={onExportFullBackup}
                      className="mt-4 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 shadow-sm"
                    >
                      <Download className="w-4 h-4" />
                      <span>تصدير النسخة الاحتياطية الآن</span>
                    </button>
                  </div>

                  {/* استيراد نسخة */}
                  <div className="p-4 bg-sky-50/60 dark:bg-sky-950/20 rounded-xl border border-sky-200 dark:border-sky-800 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-sky-800 dark:text-sky-300 font-bold text-xs mb-1">
                        <Upload className="w-4 h-4" />
                        <span>استيراد واستعادة من ملف</span>
                      </div>
                      <p className="text-[11px] text-stone-600 dark:text-stone-400">
                        استرجاع أو دمج نسخة احتياطية من ملف JSON مع فك الترميز العربي التلقائي وحفظ لقطة تراجع فورية.
                      </p>
                    </div>
                    <input
                      type="file"
                      ref={backupFileInputRef}
                      onChange={handleBackupFileChange}
                      accept=".json"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => backupFileInputRef.current?.click()}
                      className="mt-4 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 shadow-sm"
                    >
                      <Upload className="w-4 h-4" />
                      <span>اختيار ملف JSON للاستعادة</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════════ 6️⃣ تبويب الاختصارات ════════ */}
          {activeTab === 'shortcuts' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="bg-white dark:bg-stone-800/80 p-5 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-700">
                  <h3 className="text-sm font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <Keyboard className="w-4 h-4" />
                    <span>اختصارات لوحة المفاتيح والإنتاجية السريعة</span>
                  </h3>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-stone-700 dark:text-stone-300">
                    <input
                      type="checkbox"
                      checked={formSettings.shortcutsEnabled}
                      onChange={(e) => handleUpdate('shortcutsEnabled', e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                    />
                    <span>تفعيل اختصارات لوحة المفاتيح</span>
                  </label>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-stone-100 dark:bg-stone-900 text-stone-700 dark:text-stone-300">
                        <th className="p-2.5 rounded-r-lg">الاختصار</th>
                        <th className="p-2.5">الوظيفة الإجرائية</th>
                        <th className="p-2.5 rounded-l-lg">نطاق الاستخدام</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 dark:divide-stone-700/60">
                      {[
                        { key: 'Ctrl + N', action: 'إضافة شارع أو حارة جديدة', scope: 'عام' },
                        { key: 'Ctrl + Z', action: 'التراجع الفوري عن آخر عملية (Undo)', scope: 'عام (حتى 15 مرحلة)' },
                        { key: 'Ctrl + F', action: 'التركيز الفوري على حقل البحث الشامل', scope: 'عام' },
                        { key: 'Ctrl + P', action: 'توليد وطباعة تقرير رسمي PDF', scope: 'عام' },
                        { key: 'Ctrl + E', action: 'تصدير سريع لجدول Excel / Calc', scope: 'عام' },
                        { key: 'F1', action: 'فتح دليل الاختصارات والمساعدة', scope: 'عام' },
                        { key: 'Alt + S', action: 'فتح نافذة الإحصائيات والرسوم البيانية', scope: 'عام' },
                        { key: 'Delete', action: 'حذف السجلات المحددة مع حفظ لقطة تراجع', scope: 'عند تحديد سجلات' },
                        { key: 'نقر مزدوج', action: 'فتح نموذج تعديل بيانات الشارع', scope: 'على أي صف في الجدول' },
                        { key: 'Esc', action: 'إغلاق أي نافذة منبثقة نشطة', scope: 'النوافذ' },
                      ].map((sc, i) => (
                        <tr key={i} className="hover:bg-stone-50 dark:hover:bg-stone-750">
                          <td className="p-2.5 font-mono font-bold text-emerald-700 dark:text-emerald-400">
                            <kbd className="px-2 py-1 bg-stone-100 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded text-[11px] shadow-2xs">
                              {sc.key}
                            </kbd>
                          </td>
                          <td className="p-2.5 font-semibold text-stone-800 dark:text-stone-200">
                            {sc.action}
                          </td>
                          <td className="p-2.5 text-stone-500 dark:text-stone-400">
                            {sc.scope}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ════════ 7️⃣ تبويب حول ════════ */}
          {activeTab === 'about' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="bg-white dark:bg-stone-800/80 p-6 rounded-xl border border-stone-200 dark:border-stone-700 shadow-xs text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-800 to-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-900/30">
                  <span className="text-3xl">🏛️</span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 font-['Cairo']">
                    منظومة التوثيق الرقمي للشوارع والمأذونيات بدمنهور
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                    جمهورية مصر العربية — محافظة البحيرة — بندر دمنهور
                  </p>
                  <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                    الإصدار المعتمد 3.0 — سبتمبر 2026
                  </p>
                </div>

                <div className="p-3.5 bg-stone-50 dark:bg-stone-900 rounded-lg border border-stone-200 dark:border-stone-700 text-xs text-stone-700 dark:text-stone-300 max-w-lg mx-auto">
                  <p>
                    <strong>المالك والمطور:</strong> الأستاذ / حسام الدين الخولي
                  </p>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
                    منظومة قضائية ومكتبية متكاملة تعمل محلياً بالكامل (Offline-First) دون الحاجة لأي اتصال خارجي.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                  <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/30 rounded-lg border border-emerald-200 dark:border-emerald-800/60 text-center">
                    <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block">2,943 شارع</span>
                    <span className="text-[10px] text-stone-500">قاعدة البيانات المعتمدة</span>
                  </div>
                  <div className="p-2.5 bg-sky-50 dark:bg-sky-950/30 rounded-lg border border-sky-200 dark:border-sky-800/60 text-center">
                    <span className="text-xs font-bold text-sky-800 dark:text-sky-300 block">7 مأذونيات</span>
                    <span className="text-[10px] text-stone-500">نطاق التغطية الجغرافية</span>
                  </div>
                  <div className="p-2.5 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800/60 text-center">
                    <span className="text-xs font-bold text-purple-800 dark:text-purple-300 block">4 صيغ تصدير</span>
                    <span className="text-[10px] text-stone-500">Excel, PDF, HTML, CSV</span>
                  </div>
                  <div className="p-2.5 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800/60 text-center">
                    <span className="text-xs font-bold text-amber-800 dark:text-amber-300 block">15 لقطة تراجع</span>
                    <span className="text-[10px] text-stone-500">حصانة وتراجع فوري</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* ═══ أزرار الإجراءات السفلية ═══ */}
        <div className="px-6 py-4 bg-stone-100 dark:bg-stone-950 border-t border-stone-200 dark:border-stone-800 flex justify-between items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 rounded-lg text-xs font-bold transition"
          >
            إلغاء
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSave}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-2 shadow-md hover:shadow-lg active:scale-98"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
