// ============================================================
// ⚡ شريط الإنتاجية العائم السريع
// Floating Quick Action Productivity Bar with Counter & Shortcuts
// ============================================================

import React from 'react';
import { Plus, RotateCcw, BarChart3, HelpCircle, Trash2, Layers } from 'lucide-react';

interface FloatingProductivityBarProps {
  undoCount: number;
  onUndo: () => void;
  onAddNew: () => void;
  onOpenStats: () => void;
  onOpenHelp: () => void;
  selectedCount: number;
  onBulkDelete: () => void;
  filteredCount?: number;
  totalCount?: number;
}

export const FloatingProductivityBar: React.FC<FloatingProductivityBarProps> = ({
  undoCount,
  onUndo,
  onAddNew,
  onOpenStats,
  onOpenHelp,
  selectedCount,
  onBulkDelete,
  filteredCount = 0,
  totalCount = 0
}) => {
  return (
    <aside aria-label="شريط الإجراءات السريعة" className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 bg-stone-900/95 text-white backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-2xl border border-stone-700/80 flex items-center gap-2.5 text-xs select-none transition-all duration-200">
      {/* التراجع السريع */}
      <button
        onClick={onUndo}
        disabled={undoCount === 0}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full font-semibold transition ${
          undoCount > 0
            ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40'
            : 'text-stone-500 cursor-not-allowed opacity-50'
        }`}
        title="تراجع عن آخر عملية (Ctrl + Z)"
      >
        <RotateCcw className="w-3.5 h-3.5" />
        <span>تراجع</span>
        {undoCount > 0 && (
          <span className="w-4 h-4 rounded-full bg-amber-500 text-stone-950 text-[10px] font-bold flex items-center justify-center">
            {undoCount}
          </span>
        )}
      </button>

      <div className="w-px h-4 bg-stone-700"></div>

      {/* إضافة شارع */}
      <button
        onClick={onAddNew}
        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full font-bold transition shadow-sm"
        title="إضافة شارع جديد (Ctrl + N)"
      >
        <Plus className="w-3.5 h-3.5 stroke-[3]" />
        <span>شارع جديد</span>
      </button>

      {/* إجراءات التحديد المتعدد إن وجدت */}
      {selectedCount > 0 && (
        <>
          <div className="w-px h-4 bg-stone-700"></div>
          <button
            onClick={onBulkDelete}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-full font-bold transition shadow-sm animate-fadeIn"
            title="حذف المحدد (Delete)"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>حذف ({selectedCount})</span>
          </button>
        </>
      )}

      {/* عداد السجلات العائم */}
      {totalCount > 0 && (
        <>
          <div className="w-px h-4 bg-stone-700"></div>
          <div
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-800 text-stone-300 font-mono text-[11px] border border-stone-700/60"
            title={`المعروض: ${filteredCount} من إجمالي ${totalCount} سجل`}
          >
            <Layers className="w-3 h-3 text-emerald-400" />
            <span>{filteredCount.toLocaleString('ar-EG')} / {totalCount.toLocaleString('ar-EG')}</span>
          </div>
        </>
      )}

      <div className="w-px h-4 bg-stone-700"></div>

      {/* إحصائيات */}
      <button
        onClick={onOpenStats}
        className="p-1.5 text-stone-300 hover:text-white rounded-full hover:bg-stone-800 transition"
        title="الإحصائيات (Alt + S)"
      >
        <BarChart3 className="w-4 h-4" />
      </button>

      {/* مساعدة واختصارات */}
      <button
        onClick={onOpenHelp}
        className="p-1.5 text-stone-300 hover:text-amber-400 rounded-full hover:bg-stone-800 transition"
        title="دليل الاختصارات (F1)"
      >
        <HelpCircle className="w-4 h-4" />
      </button>
    </aside>
  );
};
