// ============================================================
// ❓ دليل تشغيل المنظومة واختصارات لوحة المفاتيح
// System Operation Guide & Keyboard Shortcuts Directory (F1)
// ============================================================

import React from 'react';
import { HelpCircle, X, Keyboard, ShieldCheck, Compass, FileCheck } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'F1', desc: 'فتح دليل تشغيل المنظومة واختصارات لوحة المفاتيح' },
    { key: 'Ctrl + N', desc: 'إضافة شارع / تقسيم مكاني جديد فوراً' },
    { key: 'Ctrl + Z', desc: 'التراجع الفوري عن آخر عملية (يدعم 15 لقطة زمنية متتالية)' },
    { key: 'Ctrl + F', desc: 'التركيز المباشر على حقل البحث الفوري الشامل' },
    { key: 'Ctrl + P', desc: 'فتح نافذة إعداد وطباعة الكشف والتقرير الرسمي المعتمد' },
    { key: 'Alt + S', desc: 'فتح لوحة الإحصائيات والتحليلات الجغرافية الشاملة' },
    { key: 'Ctrl + Enter', desc: 'حفظ السجل الحالي والانتقال التلقائي للشارع التالي (وضع التدقيق)' },
    { key: 'Alt + P', desc: 'الانتقال إلى السجل السابق أثناء تحرير وتدقيق الشوارع' },
    { key: 'Alt + N', desc: 'الانتقال إلى السجل التالي أثناء تحرير وتدقيق الشوارع' },
    { key: 'نقر مزدوج (Double Click)', desc: 'فتح نافذة التعديل السريع لأي صف في الجدول مباشرة' },
    { key: 'Esc', desc: 'إغلاق أية نافذة منبثقة نشطة والعودة لمساحة العمل' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-2xl overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                دليل تشغيل المنظومة واختصارات لوحة المفاتيح
              </h2>
              <p className="text-xs text-stone-400">
                منظومة التوثيق الرقمي للشوارع والمأذونيات — بندر دمنهور
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ المحتوى ═══ */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* جدول اختصارات لوحة المفاتيح */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-stone-900 flex items-center gap-1.5 border-b border-stone-200 pb-2">
              <Keyboard className="w-4 h-4 text-emerald-700" />
              <span>دليل اختصارات لوحة المفاتيح للإنتاجية العالية</span>
            </h3>

            <div className="border border-stone-200 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-right divide-y divide-stone-200">
                <thead className="bg-stone-100 text-stone-700 font-bold">
                  <tr>
                    <th className="p-2.5 w-1/3">المفتاح / الاختصار</th>
                    <th className="p-2.5 w-2/3">الوظيفة والإجراء الفوري</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 bg-white">
                  {shortcuts.map((sc, i) => (
                    <tr key={i} className="hover:bg-stone-50 transition">
                      <td className="p-2 font-mono font-bold text-stone-900">
                        <kbd className="px-2 py-0.5 bg-stone-100 border border-stone-300 rounded text-xs shadow-2xs">
                          {sc.key}
                        </kbd>
                      </td>
                      <td className="p-2 text-stone-700 leading-relaxed">{sc.desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* الحصانة والأمان */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-3.5 space-y-2 text-xs text-stone-700">
            <h4 className="font-bold text-stone-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>الحصانة الأمنية والتخزين المحلي المعتزل (Air-Gapped)</span>
            </h4>
            <p className="leading-relaxed text-[11px] text-stone-600">
              تعمل المنظومة بنظام التخزين المحلي الآمن بنسبة 100% داخل المتصفح دون إرسال بيانات الشوارع أو أرقام العقود لأي خوادم خارجية. يُنصح دائماً بالضغط على زر <strong>"نسخة احتياطية"</strong> في شريط الأدوات لحفظ ملف JSON على جهازك كأرشيف دائم.
            </p>
          </div>
        </div>

        {/* التذييل */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex justify-between items-center text-xs text-stone-500">
          <span>المالك والمطور: <strong>أ / حسام الدين الخولي</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-md text-xs font-semibold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
