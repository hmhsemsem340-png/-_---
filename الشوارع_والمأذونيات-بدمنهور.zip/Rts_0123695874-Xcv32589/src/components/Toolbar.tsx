// ============================================================
// 🛠️ شريط الأدوات والعمليات الرئيسي المنظم والمبسط
// Streamlined Main Toolbar
// ============================================================

import React from 'react';
import { 
  PlusCircle, 
  RotateCcw, 
  Trash2, 
  Sparkles, 
  Compass, 
  Wrench, 
  History, 
  Printer
} from 'lucide-react';

interface ToolbarProps {
  onAddNew: () => void;
  onUndo: () => void;
  undoCount: number;
  selectedCount: number;
  onBulkDelete: () => void;
  onAutoAnnotateOverlaps: () => void;
  onOpenMojibakeScanner: () => void;
  onOpenAdvancedExport: () => void;
  onOpenPrint: () => void;
  onOpenAuditLog: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  onAddNew,
  onUndo,
  undoCount,
  selectedCount,
  onBulkDelete,
  onAutoAnnotateOverlaps,
  onOpenMojibakeScanner,
  onOpenAdvancedExport,
  onOpenPrint,
  onOpenAuditLog
}) => {
  return (
    <div className="bg-stone-100 dark:bg-stone-900 border-b border-stone-200 dark:border-stone-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-xs">
      {/* ═══ مجموعة عمليات السجلات الأساسية ═══ */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={onAddNew}
          className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
          title="إضافة شارع أو حارة جديدة (Ctrl + N)"
        >
          <PlusCircle className="w-4 h-4" />
          <span>إضافة شارع جديد</span>
          <kbd className="hidden md:inline-block px-1 py-0.2 text-[10px] bg-emerald-800/80 rounded text-emerald-200 mr-1">
            Ctrl+N
          </kbd>
        </button>

        <button
          onClick={onUndo}
          disabled={undoCount === 0}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border ${
            undoCount > 0
              ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300 shadow-xs dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
              : 'bg-stone-100 text-stone-400 border-stone-200 dark:bg-stone-850 dark:text-stone-600 dark:border-stone-800 cursor-not-allowed opacity-60'
          }`}
          title="التراجع عن آخر عملية (Ctrl + Z)"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>تراجع</span>
          {undoCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-amber-600 text-white text-[10px] font-bold flex items-center justify-center">
              {undoCount}
            </span>
          )}
        </button>

        {selectedCount > 0 && (
          <button
            onClick={onBulkDelete}
            className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-300 dark:border-rose-800 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 animate-pulse"
            title="حذف السجلات المحددة مع حفظ لقطة تراجع (Delete)"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
            <span>حذف المحدد ({selectedCount})</span>
          </button>
        )}
      </div>

      {/* ═══ مجموعة الإجراءات والذكاء الجغرافي ═══ */}
      <div className="flex flex-wrap items-center gap-2">
        {/* زر التصدير الشامل */}
        <button
          onClick={onOpenAdvancedExport}
          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
          title="فتح نافذة التصدير المتقدم مع خيارات التنسيق والحماية"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
          <span>📤 تصدير متقدم</span>
        </button>

        {/* اشتراكات مكانية */}
        <button
          onClick={onAutoAnnotateOverlaps}
          className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow-xs"
          title="فحص المنظومة وكشف الشوارع المشتركة وتوثيقها"
        >
          <Compass className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
          <span>🔗 اشتراكات</span>
        </button>

        {/* ترميم التشفير */}
        <button
          onClick={onOpenMojibakeScanner}
          className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow-xs"
          title="فحص وترميم تشفير النصوص العربية التالفة (Mojibake)"
        >
          <Wrench className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>ترميم التشفير</span>
        </button>

        {/* سجل التعديلات */}
        <button
          onClick={onOpenAuditLog}
          className="px-3 py-1.5 bg-stone-50 hover:bg-stone-200/70 text-stone-800 dark:bg-stone-800 dark:text-stone-200 border border-stone-300 dark:border-stone-700 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow-xs"
          title="استعراض سجل التعديلات والتوثيق القانوني"
        >
          <History className="w-3.5 h-3.5 text-stone-600 dark:text-stone-400" />
          <span>سجل التعديلات</span>
        </button>

        {/* طباعة كشف رسمي */}
        <button
          onClick={onOpenPrint}
          className="px-3 py-1.5 bg-stone-800 hover:bg-stone-900 active:bg-black text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
          title="توليد وطباعة كشف تقرير رسمي معتمد للمأذونيات (Ctrl + P)"
        >
          <Printer className="w-3.5 h-3.5" />
          <span>طباعة كشف</span>
          <kbd className="hidden lg:inline-block px-1 py-0.2 text-[10px] bg-stone-700 rounded text-stone-300 mr-1">
            Ctrl+P
          </kbd>
        </button>
      </div>
    </div>
  );
};
