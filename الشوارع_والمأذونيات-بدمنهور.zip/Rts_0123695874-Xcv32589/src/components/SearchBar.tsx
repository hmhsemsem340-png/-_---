// ============================================================
// 🔍 شريط البحث الذكي فائق السرعة والتصفية متعددة الأبعاد
// Instant Omni-Search & Multi-Dimensional Filtering Bar
// ============================================================

import React from 'react';
import { FilterState, RECORD_TYPES, RecordType, RecordCategory, RecordStatus } from '../types';
import { Search, X, SlidersHorizontal, ArrowUpDown, Link2 } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  filter: FilterState;
  onFilterChange: (newFilter: Partial<FilterState>) => void;
  sortField: string;
  sortDirection: 'asc' | 'desc';
  onSortChange: (field: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  onSearchChange,
  filter,
  onFilterChange,
  sortField,
  sortDirection,
  onSortChange
}) => {
  return (
    <div className="bg-white border-b border-stone-200 px-4 py-3 flex flex-wrap items-center gap-3">
      {/* ═══ حقل البحث الفوري الشامل ═══ */}
      <div className="relative flex-1 min-w-[280px]">
        <Search className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          id="omni-search-input"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="بحث فوري في أسماء الشوارع، المعالم، الحدود، أو أرقام العقود... (Ctrl + F)"
          className="w-full pr-9 pl-8 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs md:text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 transition"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 p-0.5 text-stone-400 hover:text-stone-600 rounded-full hover:bg-stone-200"
            title="مسح حقل البحث"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* ═══ قوائم التصفية المنسدلة ═══ */}
      <div className="flex flex-wrap items-center gap-2">
        {/* نوع السجل */}
        <div className="flex items-center gap-1.5 text-xs text-stone-600">
          <SlidersHorizontal className="w-3.5 h-3.5 text-stone-400" />
          <select
            value={filter.recordType}
            onChange={(e) => onFilterChange({ recordType: e.target.value as RecordType | 'all' })}
            className="bg-stone-50 border border-stone-300 rounded-md px-2 py-1.5 text-xs text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-600"
          >
            <option value="all">كل الأنواع الجغرافية</option>
            {RECORD_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* التصنيف القانوني */}
        <select
          value={filter.category}
          onChange={(e) => onFilterChange({ category: e.target.value as RecordCategory | 'all' })}
          className="bg-stone-50 border border-stone-300 rounded-md px-2 py-1.5 text-xs text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-600"
        >
          <option value="all">كافة التصنيفات</option>
          <option value="مأذونية رسمية">مأذونية رسمية</option>
          <option value="مأذونية غير رسمية">مأذونية غير رسمية</option>
          <option value="تقاسيم وعقود">تقاسيم وعقود</option>
          <option value="حي">حي</option>
          <option value="شارع">شارع</option>
        </select>

        {/* حالة السجل */}
        <select
          value={filter.status}
          onChange={(e) => onFilterChange({ status: e.target.value as RecordStatus | 'all' })}
          className="bg-stone-50 border border-stone-300 rounded-md px-2 py-1.5 text-xs text-stone-800 focus:outline-none focus:ring-1 focus:ring-emerald-600"
        >
          <option value="all">كل الحالات</option>
          <option value="نشط">نشط</option>
          <option value="معلّق">معلّق</option>
          <option value="قيد المراجعة">قيد المراجعة</option>
          <option value="ملغي">ملغي</option>
        </select>

        {/* زر التصفية للشوارع المشتركة */}
        <label
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border text-xs font-semibold cursor-pointer transition select-none ${
            filter.sharedStreetsOnly
              ? 'bg-amber-100 text-amber-900 border-amber-400'
              : 'bg-stone-50 text-stone-600 border-stone-300 hover:bg-stone-100'
          }`}
          title="عرض الشوارع التي يقع جزء منها في مأذونية وجزء في مأذونية أخرى فقط"
        >
          <input
            type="checkbox"
            checked={filter.sharedStreetsOnly}
            onChange={(e) => onFilterChange({ sharedStreetsOnly: e.target.checked })}
            className="w-3.5 h-3.5 text-amber-600 rounded border-stone-300 focus:ring-amber-500"
          />
          <Link2 className="w-3.5 h-3.5 text-amber-600" />
          <span>المشتركة مكانياً</span>
        </label>

        {/* الفرز السريع */}
        <div className="flex items-center gap-1 bg-stone-50 border border-stone-300 rounded-md px-2 py-1 text-xs">
          <ArrowUpDown className="w-3 h-3 text-stone-400" />
          <span className="text-stone-500 text-[11px]">فرز:</span>
          <button
            onClick={() => onSortChange('streetName')}
            className={`px-1.5 py-0.5 rounded text-xs font-medium transition ${
              sortField === 'streetName' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-200'
            }`}
            title="فرز أبجدي بالاسم"
          >
            الاسم {sortField === 'streetName' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
          </button>
          <button
            onClick={() => onSortChange('notarization')}
            className={`px-1.5 py-0.5 rounded text-xs font-medium transition ${
              sortField === 'notarization' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-200'
            }`}
            title="فرز بالمأذونية"
          >
            المأذونية {sortField === 'notarization' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
          </button>
          <button
            onClick={() => onSortChange('updatedAt')}
            className={`px-1.5 py-0.5 rounded text-xs font-medium transition ${
              sortField === 'updatedAt' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-200'
            }`}
            title="فرز بتاريخ التعديل"
          >
            التاريخ {sortField === 'updatedAt' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
          </button>
        </div>
      </div>
    </div>
  );
};
