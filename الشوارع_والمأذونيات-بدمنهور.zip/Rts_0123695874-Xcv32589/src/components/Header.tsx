// ============================================================
// 🏛️ الترويسة الرسمية المبسطة لمنظومة التوثيق الرقمي
// Streamlined Official Header with Control Panel / Settings Trigger
// ============================================================

import React from 'react';
import { UserSettings } from '../types';
import { 
  Building2, 
  Settings, 
  HelpCircle, 
  BarChart3, 
  ShieldCheck,
  UserCheck
} from 'lucide-react';

interface HeaderProps {
  settings: UserSettings;
  onOpenSettings: () => void;
  totalRecordsCount: number;
  filteredCount: number;
  sharedCount: number;
  undoCount: number;
  onOpenHelp: () => void;
  onOpenStats: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onOpenSettings,
  totalRecordsCount,
  filteredCount,
  sharedCount,
  undoCount,
  onOpenHelp,
  onOpenStats
}) => {
  return (
    <header className="bg-stone-900 text-stone-100 border-b border-stone-800 shadow-md">
      {/* ═══ الشريط العلوي السيادي والاعتمادات ═══ */}
      <div className="bg-stone-950 px-4 py-1.5 border-b border-stone-800/80 flex flex-wrap justify-between items-center text-xs text-stone-400">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            جمهورية مصر العربية — محافظة البحيرة — بندر دمنهور
          </span>
          <span className="text-stone-600 hidden sm:inline">|</span>
          <span className="hidden sm:inline">المرجع الرقمي القضائي للشوارع والمأذونيات</span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-stone-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>حصانة وتشفير محلي (Offline-First)</span>
          </div>
          <span className="text-stone-600">|</span>
          <span className="text-amber-400 font-medium">
            المطور: أ / حسام الدين الخولي
          </span>
        </div>
      </div>

      {/* ═══ متن الترويسة الرئيسي ═══ */}
      <div className="px-5 py-3.5 flex flex-wrap justify-between items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-emerald-800 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-950/40 border border-emerald-500/30">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white font-['Cairo']">
                منظومة التوثيق الرقمي للشوارع والمأذونيات
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                إصدار 3.0 — سبتمبر 2026
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              شوارع ومأذونيات بندر دمنهور — قاعدة البيانات المعتمدة
            </p>
          </div>
        </div>

        {/* ═══ إجراءات الترويسة المبسطة والوصول للوحة التحكم ═══ */}
        <div className="flex items-center gap-2.5">
          {/* اسم الموثق المسجل */}
          <div 
            onClick={onOpenSettings}
            className="hidden md:flex items-center gap-1.5 bg-stone-800/80 px-3 py-1.5 rounded-lg border border-stone-700/80 text-xs text-stone-300 cursor-pointer hover:border-emerald-500/50 transition"
            title="انقر لتعديل بيانات الموثق من لوحة الإعدادات"
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-stone-400">الموثق:</span>
            <span className="font-semibold text-emerald-300 truncate max-w-[160px]">{settings.operatorName}</span>
          </div>

          {/* زر الإحصائيات السريع */}
          <button
            onClick={onOpenStats}
            className="p-2 text-stone-300 hover:text-emerald-400 hover:bg-stone-800 rounded-lg transition border border-stone-700/60"
            title="عرض الإحصائيات والرسوم البيانية (Alt+S)"
          >
            <BarChart3 className="w-4 h-4" />
          </button>

          {/* زر دليل الاختصارات */}
          <button
            onClick={onOpenHelp}
            className="p-2 text-stone-300 hover:text-amber-400 hover:bg-stone-800 rounded-lg transition border border-stone-700/60"
            title="دليل الاختصارات والمساعدة (F1)"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* 🎛️ زر لوحة التحكم والإعدادات الشاملة الرئيسي */}
          <button
            onClick={onOpenSettings}
            className="px-4 py-2 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 active:scale-98 text-white rounded-lg text-xs font-bold transition flex items-center gap-2 shadow-md border border-emerald-500/30"
            title="فتح لوحة التحكم والإعدادات الشاملة"
          >
            <Settings className="w-4 h-4 text-emerald-200" />
            <span>الإعدادات</span>
          </button>
        </div>
      </div>

      {/* ═══ شريط الإحصائيات السريعة ═══ */}
      <div className="bg-stone-800/50 px-5 py-2 border-t border-stone-800 flex flex-wrap items-center justify-between text-xs text-stone-300">
        <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-stone-400">إجمالي السجلات:</span>
            <span className="font-bold text-white bg-stone-700 px-2 py-0.5 rounded">
              {totalRecordsCount.toLocaleString('ar-EG')}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-stone-400">المعروض بالتصفية:</span>
            <span className="font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
              {filteredCount.toLocaleString('ar-EG')}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-stone-400">شوارع مشتركة:</span>
            <span className="font-bold text-amber-300 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">
              {sharedCount.toLocaleString('ar-EG')}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-stone-400">
            لقطات التراجع: <strong className="text-emerald-400">{undoCount}</strong> / 15
          </span>
          <span className="text-stone-600 hidden sm:inline">|</span>
          <span className="text-stone-400 hidden sm:inline">
            اضغط <kbd className="px-1.5 py-0.5 bg-stone-700 rounded text-[10px] text-stone-200">F1</kbd> للاختصارات
          </span>
        </div>
      </div>
    </header>
  );
};
