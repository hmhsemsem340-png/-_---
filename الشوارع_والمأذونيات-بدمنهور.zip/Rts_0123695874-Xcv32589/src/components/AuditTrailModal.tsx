// ============================================================
// 📋 نافذة سجل التعديلات والتوثيق القانوني
// Audit Log & Legal Chain-of-Custody Modal with Certificate Printing
// ============================================================

import React, { useState, useMemo } from 'react';
import { AuditLogEntry, StreetRecord, UserSettings } from '../types';
import { ArabicUtils } from '../utils/arabicUtils';
import { 
  History, 
  X, 
  Printer, 
  Copy, 
  Check, 
  Filter, 
  FileText
} from 'lucide-react';

interface AuditTrailModalProps {
  isOpen: boolean;
  onClose: () => void;
  auditEntries: AuditLogEntry[];
  targetRecord?: StreetRecord | null;
  settings: UserSettings;
}

export const AuditTrailModal: React.FC<AuditTrailModalProps> = ({
  isOpen,
  onClose,
  auditEntries,
  targetRecord,
  settings
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedActionFilter, setSelectedActionFilter] = useState<string>('all');

  // تصفية السجلات حسب السجل المستهدف وحسب العملية
  const filteredEntries = useMemo(() => {
    let list = auditEntries;
    if (targetRecord) {
      list = list.filter((e) => e.recordId === targetRecord.id || e.recordName === targetRecord.streetName);
    }
    if (selectedActionFilter !== 'all') {
      list = list.filter((e) => e.action === selectedActionFilter);
    }
    return list;
  }, [auditEntries, targetRecord, selectedActionFilter]);

  if (!isOpen) return null;

  // توليد تقرير نصي ونسخه للحافظة
  const handleCopyReport = () => {
    const title = targetRecord
      ? `تقرير سجل التدقيق القانوني لشارع: ${targetRecord.streetName} (${targetRecord.notarization})`
      : 'تقرير سجل التعديلات الشامل لمنظومة الشوارع والمأذونيات بدمنهور';

    let text = `═══════════════════════════════════════════════════════════\n`;
    text += `  🏛️ ${title}\n`;
    text += `  محافظة البحيرة — بندر دمنهور — جمهورية مصر العربية\n`;
    text += `  تاريخ الاستخراج: ${ArabicUtils.formatDateArabic(new Date())}\n`;
    text += `  الموثق القائم بالحصر: ${settings.operatorName}\n`;
    text += `═══════════════════════════════════════════════════════════\n\n`;

    if (filteredEntries.length === 0) {
      text += `لا توجد تعديلات مسجلة حتى تاريخه.\n`;
    } else {
      filteredEntries.forEach((entry, idx) => {
        text += `[${idx + 1}] الإجراء: ${entry.action} | التاريخ: ${ArabicUtils.formatDateArabic(entry.timestamp)}\n`;
        text += `    الموثق: ${entry.operatorName} | الشارع: ${entry.recordName}\n`;
        if (entry.changes && entry.changes.length > 0) {
          text += `    التغييرات الموثقة:\n`;
          entry.changes.forEach((c) => {
            text += `      • ${c.fieldLabel}: [القيمة السابقة: ${c.oldValue}] ← [القيمة الجديدة: ${c.newValue}]\n`;
          });
        }
        if (entry.notes) {
          text += `    ملاحظات: ${entry.notes}\n`;
        }
        text += `───────────────────────────────────────────────────────────\n`;
      });
    }

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  // طباعة شهادة تدقيق رسمية جاهزة للاعتماد
  const handlePrintCertificate = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('يرجى السماح بفتح النوافذ المنبثقة لطباعة الشهادة.');
      return;
    }

    const title = targetRecord 
      ? `شهادة تدقيق رسمي وتتبع قانوني — ${targetRecord.streetName}` 
      : 'شهادة سجل التعديلات والتوثيق القانوني — بندر دمنهور';

    const nowArabic = ArabicUtils.formatDateArabic(new Date());

    let rowsHtml = '';
    filteredEntries.forEach((entry, i) => {
      const changesHtml = entry.changes && entry.changes.length > 0
        ? entry.changes.map((c) => `
            <div style="margin-bottom: 4px;">
              <strong>${c.fieldLabel}:</strong> 
              ${c.oldValue ? `<span style="text-decoration: line-through; color: #b91c1c; margin-left: 4px;">${c.oldValue}</span> ← ` : ''}
              <span style="font-weight: bold; color: #15803d;">${c.newValue}</span>
            </div>
          `).join('')
        : `<span style="color: #64748b;">${entry.notes || 'إجراء نظام'}</span>`;

      rowsHtml += `
        <tr>
          <td style="text-align: center; border: 1px solid #333; padding: 6px;">${i + 1}</td>
          <td style="border: 1px solid #333; padding: 6px; font-weight: bold;">${entry.recordName}</td>
          <td style="border: 1px solid #333; padding: 6px; text-align: center;">${entry.action}</td>
          <td style="border: 1px solid #333; padding: 6px; font-size: 11px;">${ArabicUtils.formatDateArabic(entry.timestamp)}</td>
          <td style="border: 1px solid #333; padding: 6px;">${entry.operatorName}</td>
          <td style="border: 1px solid #333; padding: 6px; font-size: 11px;">${changesHtml}</td>
        </tr>
      `;
    });

    const certHtml = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>${title}</title>
        <style>
          @page { size: A4 portrait; margin: 15mm; }
          body { font-family: 'Cairo', 'Amiri', 'Traditional Arabic', serif; direction: rtl; color: #111; line-height: 1.5; font-size: 12px; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 15px; }
          .header h1 { margin: 0 0 5px; font-size: 18px; color: #064e3b; }
          .header h2 { margin: 0 0 3px; font-size: 14px; color: #1f2937; }
          .header p { margin: 0; font-size: 11px; color: #4b5563; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; }
          th { background: #f3f4f6; border: 1px solid #333; padding: 8px; font-size: 11px; }
          .signatures { display: flex; justify-content: space-between; margin-top: 40px; page-break-inside: avoid; }
          .sig-box { width: 30%; text-align: center; font-size: 12px; }
          .sig-line { border-top: 1px dotted #333; margin-top: 50px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h2>جمهورية مصر العربية — محافظة البحيرة</h2>
          <h1>منظومة التوثيق الرقمي للشوارع والمأذونيات — بندر دمنهور</h1>
          <p>${title}</p>
          <p style="margin-top: 4px; font-weight: bold;">تاريخ الاستخراج: ${nowArabic} | الموثق المسؤول: ${settings.operatorName}</p>
        </div>

        ${targetRecord ? `
          <div style="background: #f8fafc; border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 4px; margin-bottom: 12px; font-size: 11px;">
            <strong>بيانات الشارع:</strong> ${targetRecord.streetName} | 
            <strong>جهة المأذونية:</strong> ${targetRecord.notarization} | 
            <strong>التصنيف:</strong> ${targetRecord.category} | 
            <strong>رقم الإصدار الحالي:</strong> ${targetRecord.version}
          </div>
        ` : ''}

        <table>
          <thead>
            <tr>
              <th style="width: 30px;">م</th>
              <th>اسم الشارع</th>
              <th style="width: 60px;">نوع الإجراء</th>
              <th style="width: 110px;">التاريخ والوقت</th>
              <th style="width: 90px;">الموثق</th>
              <th>المقارنة البصرية للتغييرات (سابق ← لاحق)</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml || '<tr><td colspan="6" style="text-align: center; padding: 20px;">لا توجد تعديلات مسجلة</td></tr>'}
          </tbody>
        </table>

        <div class="signatures">
          <div class="sig-box">
            <strong>القائم بالحصر والتدقيق</strong>
            <p style="margin: 4px 0 0; color: #475569;">${settings.operatorName}</p>
            <div class="sig-line">التوقيع</div>
          </div>
          <div class="sig-box">
            <strong>المراجع القضائي المختص</strong>
            <div class="sig-line">التوقيع والاعتماد</div>
          </div>
          <div class="sig-box">
            <strong>خاتم شعار المنظومة</strong>
            <div class="sig-line">بصمة الخاتم الرسمي</div>
          </div>
        </div>
      </body>
      </html>
    `;

    printWindow.document.write(certHtml);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-700 flex items-center justify-center text-white">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                {targetRecord 
                  ? `سجل التعديلات والتوثيق القانوني: ${targetRecord.streetName}` 
                  : 'سجل التعديلات العام للمنظومة (Audit Log)'}
              </h2>
              <p className="text-xs text-stone-400">
                إجمالي العمليات الموثقة: {filteredEntries.length} حركة تعديل
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ شريط أدوات التصفية والطباعة والنسخ ═══ */}
        <div className="bg-stone-100 px-5 py-2.5 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-stone-500" />
            <span className="font-semibold text-stone-700">تصفية بنوع الإجراء:</span>
            <select
              value={selectedActionFilter}
              onChange={(e) => setSelectedActionFilter(e.target.value)}
              className="bg-white border border-stone-300 rounded px-2 py-1 text-xs text-stone-800 focus:outline-none"
            >
              <option value="all">كافة الإجراءات</option>
              <option value="إنشاء">إنشاء</option>
              <option value="تعديل">تعديل</option>
              <option value="حذف">حذف</option>
              <option value="دمج">دمج</option>
              <option value="استيراد">استيراد</option>
              <option value="ترميم">ترميم</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyReport}
              className="px-3 py-1.5 bg-white hover:bg-stone-50 text-stone-700 border border-stone-300 rounded-md font-semibold transition flex items-center gap-1.5"
              title="نسخ التقرير التوثيقي كاملاً للحافظة"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-stone-500" />}
              <span>{copied ? 'تم النسخ للحافظة!' : 'نسخ التقرير'}</span>
            </button>

            <button
              onClick={handlePrintCertificate}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-bold transition flex items-center gap-1.5 shadow-xs"
              title="طباعة شهادة سجل التعديلات والتوثيق القانوني"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة شهادة التدقيق</span>
            </button>
          </div>
        </div>

        {/* ═══ قائمة حركات التعديل والمقارنة البصرية ═══ */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {filteredEntries.length === 0 ? (
            <div className="text-center py-12 text-stone-400">
              <FileText className="w-10 h-10 mx-auto text-stone-300 mb-2 stroke-[1.5]" />
              <p className="text-sm font-semibold text-stone-600">لا توجد حركات تعديل مسجلة</p>
            </div>
          ) : (
            filteredEntries.map((entry) => (
              <div
                key={entry.id}
                className="bg-white border border-stone-200 rounded-lg p-4 shadow-2xs space-y-2.5 text-xs transition hover:border-stone-300"
              >
                {/* رأس حركة التعديل */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        entry.action === 'إنشاء'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : entry.action === 'تعديل'
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : entry.action === 'حذف'
                          ? 'bg-rose-100 text-rose-900 border border-rose-300'
                          : entry.action === 'دمج'
                          ? 'bg-indigo-100 text-indigo-900 border border-indigo-300'
                          : 'bg-purple-100 text-purple-900 border border-purple-300'
                      }`}
                    >
                      {entry.action}
                    </span>
                    <span className="font-bold text-stone-900">{entry.recordName}</span>
                  </div>

                  <div className="flex items-center gap-3 text-stone-500 text-[11px]">
                    <span>الموثق: <strong className="text-stone-700">{entry.operatorName}</strong></span>
                    <span>•</span>
                    <span className="font-mono">{ArabicUtils.formatDateArabic(entry.timestamp)}</span>
                  </div>
                </div>

                {/* المقارنة البصرية بين القيم السابقة والجديدة */}
                {entry.changes && entry.changes.length > 0 && (
                  <div className="bg-stone-50/70 border border-stone-200/80 rounded p-2.5 space-y-2">
                    <p className="font-semibold text-stone-700 text-[11px]">
                      المقارنة البصرية للحقول المعدلة:
                    </p>
                    <div className="space-y-1.5">
                      {entry.changes.map((change, cIdx) => (
                        <div key={cIdx} className="flex items-start gap-2 flex-wrap text-xs">
                          <span className="font-bold text-stone-800 min-w-[110px]">
                            • {change.fieldLabel}:
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {change.oldValue && (
                              <span className="line-through text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded text-[11px]">
                                {change.oldValue}
                              </span>
                            )}
                            {change.oldValue && <span className="text-stone-400">←</span>}
                            <span className="font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[11px]">
                              {change.newValue}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ملاحظات التعديل */}
                {entry.notes && (
                  <p className="text-[11px] text-stone-600 bg-stone-50 px-2.5 py-1 rounded">
                    <strong>ملاحظة التوثيق:</strong> {entry.notes}
                  </p>
                )}
              </div>
            ))
          )}
        </div>

        {/* التذييل */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-md text-xs font-semibold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
