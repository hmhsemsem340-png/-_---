// ============================================================
// 🛠️ مركز فحص وترميم النصوص العربية التالفة (Mojibake)
// Mojibake Diagnostic & Text Reconstruction Center
// ============================================================

import React, { useState, useMemo } from 'react';
import { StreetRecord } from '../types';
import { MojibakeEngine } from '../utils/mojibakeEngine';
import { Wrench, X, CheckCircle2, AlertTriangle, Sparkles, RefreshCw, ArrowRight } from 'lucide-react';

interface MojibakeModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: StreetRecord[];
  onRepairAll: (repairedRecords: StreetRecord[]) => void;
}

interface CorruptedItem {
  record: StreetRecord;
  field: keyof StreetRecord;
  fieldLabel: string;
  corruptedText: string;
  restoredText: string;
}

export const MojibakeModal: React.FC<MojibakeModalProps> = ({
  isOpen,
  onClose,
  records,
  onRepairAll
}) => {
  const [customTestInput, setCustomTestInput] = useState('ÔÇÑÚ ÚÈÏ ÇáÓáÇã ÇáÔÇÐáí');
  const [repairedCount, setRepairedCount] = useState<number | null>(null);

  // فحص كافة السجلات في قاعدة البيانات لاكتشاف النصوص التالفة
  const corruptedItems = useMemo(() => {
    const list: CorruptedItem[] = [];

    records.forEach((r) => {
      // فحص اسم الشارع
      if (MojibakeEngine.isMojibake(r.streetName)) {
        list.push({
          record: r,
          field: 'streetName',
          fieldLabel: 'اسم الشارع',
          corruptedText: r.streetName,
          restoredText: MojibakeEngine.repairMojibake(r.streetName)
        });
      }

      // فحص الوصف
      if (r.description && MojibakeEngine.isMojibake(r.description)) {
        list.push({
          record: r,
          field: 'description',
          fieldLabel: 'الوصف والبيان',
          corruptedText: r.description,
          restoredText: MojibakeEngine.repairMojibake(r.description)
        });
      }

      // فحص المعالم
      if (r.landmarks && MojibakeEngine.isMojibake(r.landmarks)) {
        list.push({
          record: r,
          field: 'landmarks',
          fieldLabel: 'المعالم المميزة',
          corruptedText: r.landmarks,
          restoredText: MojibakeEngine.repairMojibake(r.landmarks)
        });
      }

      // فحص الحدود
      if (r.boundaries && MojibakeEngine.isMojibake(r.boundaries)) {
        list.push({
          record: r,
          field: 'boundaries',
          fieldLabel: 'الحدود الجغرافية',
          corruptedText: r.boundaries,
          restoredText: MojibakeEngine.repairMojibake(r.boundaries)
        });
      }
    });

    return list;
  }, [records]);

  if (!isOpen) return null;

  // تنفيذ الترميم الجماعي لكافة الحقول والسجلات التالفة
  const handleExecuteRepairAll = () => {
    const updated = records.map((r) => {
      let isChanged = false;
      let newStreetName = r.streetName;
      let newDescription = r.description;
      let newLandmarks = r.landmarks;
      let newBoundaries = r.boundaries;

      if (MojibakeEngine.isMojibake(r.streetName)) {
        newStreetName = MojibakeEngine.repairMojibake(r.streetName);
        isChanged = true;
      }
      if (r.description && MojibakeEngine.isMojibake(r.description)) {
        newDescription = MojibakeEngine.repairMojibake(r.description);
        isChanged = true;
      }
      if (r.landmarks && MojibakeEngine.isMojibake(r.landmarks)) {
        newLandmarks = MojibakeEngine.repairMojibake(r.landmarks);
        isChanged = true;
      }
      if (r.boundaries && MojibakeEngine.isMojibake(r.boundaries)) {
        newBoundaries = MojibakeEngine.repairMojibake(r.boundaries);
        isChanged = true;
      }

      if (isChanged) {
        return {
          ...r,
          streetName: newStreetName,
          description: newDescription,
          landmarks: newLandmarks,
          boundaries: newBoundaries,
          version: r.version + 1,
          updatedAt: new Date().toISOString()
        };
      }
      return r;
    });

    setRepairedCount(corruptedItems.length);
    onRepairAll(updated);
  };

  const restoredTestOutput = MojibakeEngine.repairMojibake(customTestInput);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white rounded-xl shadow-2xl border border-stone-300 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden text-right"
        dir="rtl"
      >
        {/* ═══ الترويسة ═══ */}
        <div className="bg-stone-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 flex items-center justify-center text-white">
              <Wrench className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-['Cairo'] text-white">
                مركز فحص وترميم النصوص المشوهة والتالفة (Mojibake)
              </h2>
              <p className="text-xs text-stone-400">
                إصلاح تلف ترميز Windows-1256 و UTF-8 الموروث من ملفات إكسيل القديمة
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-stone-400 hover:text-white p-1 rounded-md hover:bg-stone-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ═══ محتوى الفحص والترميم ═══ */}
        <div className="p-5 space-y-4 flex-1 overflow-y-auto">
          {/* حالة الفحص */}
          <div className="p-4 rounded-lg border flex items-center justify-between gap-3 bg-stone-50 border-stone-200">
            <div className="flex items-center gap-3">
              {corruptedItems.length > 0 ? (
                <div className="w-9 h-9 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700">
                  <AlertTriangle className="w-5 h-5" />
                </div>
              ) : (
                <div className="w-9 h-9 rounded-full bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              )}
              <div>
                <h3 className="text-xs font-bold text-stone-900">
                  {corruptedItems.length > 0
                    ? `تم رصد ${corruptedItems.length} حقلاً يحتوي على نصوص عربية تالفة التشفير`
                    : 'سجلات المنظومة سليمة 100% ولا توجد نصوص تالفة حالياً'}
                </h3>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  يعتمد المحرك على خريطة البايتات العكسية ومعجم دمنهور للترميم الحرفي الدقيق.
                </p>
              </div>
            </div>

            {corruptedItems.length > 0 && (
              <button
                onClick={handleExecuteRepairAll}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-md text-xs font-bold transition flex items-center gap-1.5 shadow-sm shrink-0"
              >
                <Sparkles className="w-4 h-4" />
                <span>ترميم كافة النصوص التالفة الآن</span>
              </button>
            )}
          </div>

          {repairedCount !== null && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3 rounded-lg text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>تم بنجاح ترميم {repairedCount} حقلاً نصياً وحفظها تلقائياً مع توثيق التراجع!</span>
            </div>
          )}

          {/* قائمة النصوص المكتشفة مع المعاينة قبل/بعد */}
          {corruptedItems.length > 0 && (
            <div className="border border-stone-200 rounded-lg overflow-hidden text-xs">
              <div className="bg-stone-100 px-3 py-2 font-bold text-stone-700 border-b border-stone-200">
                معاينة السجلات التالفة والترميم المقترح:
              </div>
              <div className="max-h-60 overflow-y-auto divide-y divide-stone-100">
                {corruptedItems.map((item, idx) => (
                  <div key={idx} className="p-3 bg-white hover:bg-stone-50 transition space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-stone-500">
                      <span className="font-bold text-stone-800">
                        {item.fieldLabel} — سجل #{item.record.id} ({item.record.notarization})
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                      <div className="bg-rose-50 border border-rose-200 p-2 rounded text-rose-900 font-mono">
                        <span className="text-[10px] text-rose-500 block">النص التالف الحالي:</span>
                        {item.corruptedText}
                      </div>
                      <div className="bg-emerald-50 border border-emerald-200 p-2 rounded text-emerald-900 font-bold">
                        <span className="text-[10px] text-emerald-600 block">النص بعد الترميم التلقائي:</span>
                        {item.restoredText}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ═══ معمل التجربة اليدوي (Scratchpad Tester) ═══ */}
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-3.5 space-y-2.5">
            <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
              <RefreshCw className="w-3.5 h-3.5 text-stone-600" />
              <span>معمل الاختبار الفوري لترميم النصوص:</span>
            </h4>
            <p className="text-[11px] text-stone-500">
              يمكنك لصق أي نص مشوه من ملف قديم لتجربة الترميم الفوري:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  أدخل النص المشوه:
                </label>
                <input
                  type="text"
                  value={customTestInput}
                  onChange={(e) => setCustomTestInput(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded text-xs text-stone-900 font-mono"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  النتيجة المرممة:
                </label>
                <div className="w-full px-2.5 py-1.5 bg-emerald-50 border border-emerald-300 rounded text-xs text-emerald-900 font-bold">
                  {restoredTestOutput || '—'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* التذييل */}
        <div className="bg-stone-100 border-t border-stone-200 px-5 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-md text-xs font-semibold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
