// ============================================================
// 🏛️ منظومة التوثيق الرقمي للشوارع والمأذونيات بدمنهور
// Application Root Component with Complete Offline-First Orchestration
// ============================================================

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  StreetRecord, 
  AuditLogEntry, 
  UserSettings, 
  FilterState, 
  DuplicateCheckResult,
  AdvancedExportOptions 
} from './types';
import { StorageEngine } from './utils/storageEngine';
import { CollationEngine } from './utils/collationEngine';
import { ArabicUtils } from './utils/arabicUtils';
import { SimilarityEngine } from './utils/similarityEngine';
import { DuplicateEngine } from './utils/duplicateEngine';
import { ExportEngine } from './utils/exportEngine';

// استيراد المكونات الفرعية
import { Header } from './components/Header';
import { Toolbar } from './components/Toolbar';
import { SearchBar } from './components/SearchBar';
import { NotarizationTags } from './components/NotarizationTags';
import { DataTable } from './components/DataTable';
import { RecordModal } from './components/RecordModal';
import { DuplicateModal } from './components/DuplicateModal';
import { AuditTrailModal } from './components/AuditTrailModal';
import { PrintModal } from './components/PrintModal';
import { MojibakeModal } from './components/MojibakeModal';
import { StatsModal } from './components/StatsModal';
import { HelpModal } from './components/HelpModal';
import { FloatingProductivityBar } from './components/FloatingProductivityBar';
import { ToastContainer, ToastMessage } from './components/ToastContainer';
import { AdvancedExportModal } from './components/AdvancedExportModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // ═══ الحالات الرئيسية ═══
  const [records, setRecords] = useState<StreetRecord[]>([]);
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>([]);
  const [settings, setSettings] = useState<UserSettings>(StorageEngine.loadSettings());
  const [undoCount, setUndoCount] = useState<number>(0);

  // منظومة التنبيهات المنبثقة
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info', title?: string) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { id, message, type, title };
    setToasts((prev) => [...prev, newToast]);

    // إخفاء تلقائي بعد 4 ثوانٍ
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // البحث والتصفية والفرز
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FilterState>({
    searchQuery: '',
    notarization: 'all',
    category: 'all',
    recordType: 'all',
    status: 'all',
    sharedStreetsOnly: false
  });
  const [sortField, setSortField] = useState<string>('streetName');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // التحديد المتعدد
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // النوافذ المنبثقة
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<StreetRecord | null>(null);
  const [sequentialIndex, setSequentialIndex] = useState<number | null>(null);

  // نافذة فض نزاع التكرار
  const [duplicateModalData, setDuplicateModalData] = useState<{
    isOpen: boolean;
    incomingRecord: Partial<StreetRecord> | null;
    duplicateResult: DuplicateCheckResult | null;
  }>({
    isOpen: false,
    incomingRecord: null,
    duplicateResult: null
  });

  // نوافذ التدقيق، الطباعة، الترميم، والإحصائيات والتصدير المتقدم ولوحة التحكم
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [auditTargetRecord, setAuditTargetRecord] = useState<StreetRecord | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isMojibakeModalOpen, setIsMojibakeModalOpen] = useState(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isAdvancedExportOpen, setIsAdvancedExportOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // ═══ تحميل البيانات عند الإقلاع ═══
  useEffect(() => {
    const loadedRecords = StorageEngine.loadRecords();
    const loadedAudit = StorageEngine.loadAuditLog();
    setRecords(loadedRecords);
    setAuditLog(loadedAudit);
    setUndoCount(StorageEngine.getUndoCount());
    showToast('مرحباً بك في منظومة التوثيق الرقمي للشوارع والمأذونيات بدمنهور 🏛️', 'success');
  }, [showToast]);

  // حفظ الإعدادات عند التغيير
  const handleSaveSettings = (newSettings: UserSettings) => {
    setSettings(newSettings);
    StorageEngine.saveSettings(newSettings);
    showToast('تم حفظ وتطبيق الإعدادات المخصصة بنجاح ⚙️', 'success');
  };

  const handleResetSettingsToDefault = () => {
    const defaultSettings = StorageEngine.loadSettings();
    setSettings(defaultSettings);
    StorageEngine.saveSettings(defaultSettings);
    showToast('تمت استعادة الإعدادات الافتراضية بنجاح 🔄', 'info');
  };

  // ═══ التصفية والفرز اللحظي فائق السرعة ═══
  const filteredRecords = useMemo(() => {
    let result = records;

    // 1. تصفية بالمأذونية
    if (filter.notarization !== 'all') {
      result = result.filter((r) => r.notarization === filter.notarization);
    }

    // 2. تصفية بالنوع الجغرافي
    if (filter.recordType !== 'all') {
      result = result.filter((r) => r.recordType === filter.recordType);
    }

    // 3. تصفية بالتصنيف القانوني
    if (filter.category !== 'all') {
      result = result.filter((r) => r.category === filter.category);
    }

    // 4. تصفية بالحالة
    if (filter.status !== 'all') {
      result = result.filter((r) => r.status === filter.status);
    }

    // 5. تصفية الشوارع المشتركة فقط
    if (filter.sharedStreetsOnly) {
      result = result.filter((r) => !!r.sharedNotarization || !!r.sharedNote);
    }

    // 6. البحث الشامل فائق السرعة مع التطبيع
    if (searchQuery.trim()) {
      const normalizedQuery = ArabicUtils.normalizeArabic(searchQuery);
      result = result.filter((r) => {
        const matchName = ArabicUtils.normalizeArabic(r.streetName).includes(normalizedQuery);
        const matchNotarization = ArabicUtils.normalizeArabic(r.notarization).includes(normalizedQuery);
        const matchDesc = r.description ? ArabicUtils.normalizeArabic(r.description).includes(normalizedQuery) : false;
        const matchLandmarks = r.landmarks ? ArabicUtils.normalizeArabic(r.landmarks).includes(normalizedQuery) : false;
        const matchBoundaries = r.boundaries ? ArabicUtils.normalizeArabic(r.boundaries).includes(normalizedQuery) : false;
        return matchName || matchNotarization || matchDesc || matchLandmarks || matchBoundaries;
      });
    }

    // 7. الفرز الأبجدي العربي الصارم
    result = CollationEngine.sortRecords(result, sortField as keyof StreetRecord, sortDirection);

    return result;
  }, [records, filter, searchQuery, sortField, sortDirection]);

  // إحصائيات المأذونيات للوسوم
  const notarizationCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    records.forEach((r) => {
      counts[r.notarization] = (counts[r.notarization] || 0) + 1;
    });
    return counts;
  }, [records]);

  // عدد الشوارع المشتركة
  const sharedCount = useMemo(() => {
    return records.filter((r) => !!r.sharedNotarization || !!r.sharedNote).length;
  }, [records]);

  // ═══ إجراءات التحديد ═══
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleToggleSelectAll = () => {
    if (selectedIds.size === filteredRecords.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredRecords.map((r) => r.id)));
    }
  };

  // ═══ إضافة وتعديل السجلات ═══
  const handleAddNew = () => {
    setEditingRecord(null);
    setSequentialIndex(null);
    setIsRecordModalOpen(true);
  };

  const handleEditRecord = (record: StreetRecord) => {
    const idx = filteredRecords.findIndex((r) => r.id === record.id);
    setEditingRecord(record);
    setSequentialIndex(idx !== -1 ? idx : null);
    setIsRecordModalOpen(true);
  };

  // حفظ السجل من النافذة
  const handleSaveRecord = (recordData: Partial<StreetRecord>, isSequentialNext: boolean = false) => {
    // فحص التكرار إذا كان سجلاً جديداً ولم يكن تعديلاً لنفس السجل
    if (!editingRecord && recordData.streetName) {
      const dup = DuplicateEngine.checkDuplicate(
        recordData.streetName,
        recordData.notarization || 'شبرا بحري',
        records
      );

      if (dup.isDuplicate && dup.similarityScore >= 0.85) {
        // فتح نافذة فض النزاع
        setDuplicateModalData({
          isOpen: true,
          incomingRecord: recordData,
          duplicateResult: dup
        });
        return;
      }
    }

    // التنفيذ الفعلي للحفظ
    executeSave(recordData, isSequentialNext);
  };

  const executeSave = (recordData: Partial<StreetRecord>, isSequentialNext: boolean = false) => {
    const isEdit = !!recordData.id;
    const updatedRecords = StorageEngine.saveRecord(recordData, settings.operatorName);
    setRecords(updatedRecords);
    setAuditLog(StorageEngine.loadAuditLog());
    setUndoCount(StorageEngine.getUndoCount());

    showToast(
      isEdit ? `تم تحديث بيانات شارع "${recordData.streetName}" بنجاح ✅` : `تم إضافة شارع "${recordData.streetName}" بنجاح ✅`,
      'success'
    );

    if (isSequentialNext && sequentialIndex !== null && sequentialIndex + 1 < filteredRecords.length) {
      // الانتقال للسجل التالي في وضع التدقيق المتتالي
      const nextRecord = filteredRecords[sequentialIndex + 1];
      setEditingRecord(nextRecord);
      setSequentialIndex(sequentialIndex + 1);
    } else {
      setIsRecordModalOpen(false);
      setEditingRecord(null);
      setSequentialIndex(null);
    }
  };

  // فض نزاع التكرار
  const handleResolveDuplicate = (action: 'merge' | 'replace' | 'separate') => {
    const { incomingRecord, duplicateResult } = duplicateModalData;
    if (!incomingRecord || !duplicateResult || duplicateResult.matchedRecords.length === 0) {
      setDuplicateModalData({ isOpen: false, incomingRecord: null, duplicateResult: null });
      return;
    }

    const target = duplicateResult.matchedRecords[0];

    if (action === 'merge') {
      const merged = DuplicateEngine.mergeDuplicate(target, incomingRecord);
      const updated = StorageEngine.saveRecord(merged, settings.operatorName);
      setRecords(updated);
      setAuditLog(StorageEngine.loadAuditLog());
      setUndoCount(StorageEngine.getUndoCount());
      showToast(`تم دمج المعالم والبيانات لشارع "${target.streetName}" بنجاح 🔀`, 'success');
    } else if (action === 'replace') {
      const updated = StorageEngine.saveRecord(
        { ...incomingRecord, id: target.id, version: target.version },
        settings.operatorName
      );
      setRecords(updated);
      setAuditLog(StorageEngine.loadAuditLog());
      setUndoCount(StorageEngine.getUndoCount());
      showToast(`تم تحديث السجل الأصلي لشارع "${target.streetName}" بنجاح ✏️`, 'success');
    } else if (action === 'separate') {
      // حفظ منفصل مع توليد معرّف جديد
      const updated = StorageEngine.saveRecord(
        { ...incomingRecord, id: undefined },
        settings.operatorName
      );
      setRecords(updated);
      setAuditLog(StorageEngine.loadAuditLog());
      setUndoCount(StorageEngine.getUndoCount());
      showToast(`تم حفظ الشارع كإدخال منفصل بنجاح ➕`, 'success');
    }

    setDuplicateModalData({ isOpen: false, incomingRecord: null, duplicateResult: null });
    setIsRecordModalOpen(false);
  };

  // حذف سجل فردي
  const handleDeleteRecord = (id: string) => {
    const rec = records.find((r) => r.id === id);
    if (!rec) return;

    if (settings.confirmDelete && !confirm(`هل أنت متأكد من حذف شارع "${rec.streetName}"؟ (يمكنك التراجع عبر Ctrl+Z)`)) {
      return;
    }

    const updated = StorageEngine.deleteRecord(id, settings.operatorName);
    setRecords(updated);
    setAuditLog(StorageEngine.loadAuditLog());
    setUndoCount(StorageEngine.getUndoCount());
    selectedIds.delete(id);
    setSelectedIds(new Set(selectedIds));
    showToast(`تم حذف شارع "${rec.streetName}" 🗑️`, 'info');
  };

  // حذف متعدد
  const handleBulkDelete = () => {
    if (selectedIds.size === 0) {
      showToast('لم يتم تحديد أي سجلات للحذف', 'warning');
      return;
    }
    if (
      settings.confirmDelete &&
      !confirm(
        `هل أنت متأكد من حذف ${selectedIds.size} سجلاً محدداً دفعة واحدة؟ (سيتم حفظ لقطة تراجع فورية)`
      )
    ) {
      return;
    }

    const count = selectedIds.size;
    let currentRecords = records;
    selectedIds.forEach((id) => {
      currentRecords = StorageEngine.deleteRecord(id, settings.operatorName);
    });
    setRecords(currentRecords);
    setAuditLog(StorageEngine.loadAuditLog());
    setUndoCount(StorageEngine.getUndoCount());
    setSelectedIds(new Set());
    showToast(`تم حذف ${count} سجل محدد 🗑️`, 'info');
  };

  // ═══ التراجع (Undo) ═══
  const handleUndo = useCallback(() => {
    const restored = StorageEngine.undo();
    if (restored) {
      setRecords(restored);
      setAuditLog(StorageEngine.loadAuditLog());
      setUndoCount(StorageEngine.getUndoCount());
      showToast('تم التراجع عن آخر عملية بنجاح ↩️', 'info');
    } else {
      showToast('لا توجد عمليات سابقة للتراجع عنها', 'warning');
    }
  }, [showToast]);

  // ═══ كشف وتوثيق الاشتراكات المكانية آلياً ═══
  const handleAutoAnnotateOverlaps = () => {
    const overlaps = SimilarityEngine.findSharedStreets(records);
    if (overlaps.length === 0) {
      showToast('لم يتم رصد اشتراكات مكانية غير مسجلة حالياً بين المأذونيات', 'info');
      return;
    }

    if (
      confirm(
        `تم اكتشاف ${overlaps.length} اشتراكاً مكانياً بين مأذونيات دمنهور. هل ترغب في توثيق وتضمين ملاحظات الاشتراك التلقائية؟`
      )
    ) {
      const updated = records.map((r) => {
        const found = overlaps.find((o) => o.record.id === r.id);
        if (found) {
          return {
            ...r,
            sharedNotarization: found.overlapWithNotarization,
            sharedNote: `[تنبيه اشتراك مكاني: هذا الشارع مشترك مكانياً مع مأذونية (${found.overlapWithNotarization})]`,
            version: r.version + 1,
            updatedAt: new Date().toISOString()
          };
        }
        return r;
      });

      StorageEngine.saveRecordsDirectly(updated, 'توثيق الاشتراكات المكانية', settings.operatorName);
      setRecords(updated);
      setAuditLog(StorageEngine.loadAuditLog());
      setUndoCount(StorageEngine.getUndoCount());
      showToast(`تم بنجاح توثيق ${overlaps.length} شارعاً مشتركاً مكانياً 🔗`, 'success');
    }
  };

  // ═══ ترميم النصوص التالفة (Mojibake) ═══
  const handleRepairAllMojibake = (repairedRecords: StreetRecord[]) => {
    StorageEngine.saveRecordsDirectly(
      repairedRecords,
      'ترميم نصوص تالفة التشفير (Mojibake)',
      settings.operatorName
    );
    setRecords(repairedRecords);
    setAuditLog(StorageEngine.loadAuditLog());
    setUndoCount(StorageEngine.getUndoCount());
    showToast('تم ترميم وحفظ النصوص التالفة بنجاح 🔧', 'success');
  };

  // ═══ التصدير السريع والتصدير المتقدم ═══
  const handleExecuteAdvancedExport = (options: AdvancedExportOptions) => {
    let targetRecords = filteredRecords;
    if (options.scope === 'all') {
      targetRecords = records;
    } else if (options.scope === 'selected') {
      targetRecords = records.filter((r) => selectedIds.has(r.id));
    }

    if (targetRecords.length === 0) {
      showToast('لا توجد سجلات مطابقة لنطاق التصدير المحدد', 'warning');
      return;
    }

    try {
      ExportEngine.exportAdvanced(targetRecords, options);
      showToast(`تم التصدير المتقدم بصيغة ${options.format.toUpperCase()} بنجاح ✅ (${targetRecords.length} سجل)`, 'success');
    } catch (err: any) {
      showToast(`خطأ أثناء التصدير المتقدم: ${err.message || err}`, 'error');
    }
  };

  const handleExportBackup = () => {
    ExportEngine.exportFullBackup(records, auditLog, settings);
    showToast('تم حفظ وتحميل النسخة الاحتياطية الشاملة بنجاح 💾', 'success');
  };

  const handleImportBackupFile = async (file: File) => {
    try {
      const result = await ExportEngine.importFile(file, settings.operatorName);
      if (result.records.length === 0) {
        showToast('لم يتم العثور على سجلات صالحة في الملف المستورد', 'error');
        return;
      }

      if (
        confirm(
          `تم قراءة ${result.records.length} سجلاً بنجاح من الملف.\nهل ترغب في دمجها وإضافتها لقاعدة البيانات الحالية؟ (سيتم حفظ لقطة تراجع)`
        )
      ) {
        // دمج السجلات
        const merged = [...records];
        result.records.forEach((newRec) => {
          if (!merged.some((m) => m.id === newRec.id)) {
            merged.push(newRec);
          }
        });

        StorageEngine.saveRecordsDirectly(
          merged,
          `استيراد ملف: ${file.name} (${result.records.length} سجل)`,
          settings.operatorName
        );
        setRecords(merged);
        setAuditLog(StorageEngine.loadAuditLog());
        setUndoCount(StorageEngine.getUndoCount());
        showToast(
          `تم استيراد ${result.records.length} سجل بنجاح${result.repairedCount ? ` (وترميم ${result.repairedCount} نص تالف)` : ''} 📥`,
          'success'
        );
      }
    } catch (err: any) {
      showToast(`خطأ أثناء قراءة الملف: ${err.message || err}`, 'error');
    }
  };

  // استعادة قاعدة البيانات الأولية
  const handleResetDatabase = () => {
    const resetRecords = StorageEngine.resetToInitial(settings.operatorName);
    setRecords(resetRecords);
    setAuditLog(StorageEngine.loadAuditLog());
    setUndoCount(StorageEngine.getUndoCount());
    showToast('تمت استعادة قاعدة البيانات المعتمدة الأصلية (2943 شارع ومأذونية) بنجاح 🏛️', 'success');
  };

  // ═══ اختصارات لوحة المفاتيح العالمية ═══
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!settings.shortcutsEnabled) return;

      const target = e.target as HTMLElement;
      const isInput = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.isContentEditable;

      // F1: دليل المساعدة
      if (e.key === 'F1') {
        e.preventDefault();
        setIsHelpModalOpen(true);
        return;
      }

      // Esc: إغلاق النوافذ
      if (e.key === 'Escape') {
        setIsRecordModalOpen(false);
        setIsAuditModalOpen(false);
        setIsPrintModalOpen(false);
        setIsMojibakeModalOpen(false);
        setIsStatsModalOpen(false);
        setIsHelpModalOpen(false);
        setIsAdvancedExportOpen(false);
        setIsSettingsModalOpen(false);
        setDuplicateModalData({ isOpen: false, incomingRecord: null, duplicateResult: null });
        return;
      }

      // Ctrl + Z / Cmd + Z: التراجع
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        if (!isInput) {
          e.preventDefault();
          handleUndo();
        }
        return;
      }

      // Ctrl + N: إضافة شارع
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        handleAddNew();
        return;
      }

      // Ctrl + F: التركيز على البحث
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        document.getElementById('omni-search-input')?.focus();
        return;
      }

      // Ctrl + P: طباعة تقرير
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        setIsPrintModalOpen(true);
        return;
      }

      // Ctrl + E: تصدير متقدم
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        setIsAdvancedExportOpen(true);
        return;
      }

      // Alt + S: الإحصائيات
      if (e.altKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        setIsStatsModalOpen(true);
        return;
      }

      // Delete: حذف المحدد عند عدم الكتابة في حقل إدخال
      if (e.key === 'Delete' && !isInput && selectedIds.size > 0) {
        e.preventDefault();
        handleBulkDelete();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, selectedIds, settings.shortcutsEnabled]);

  // تبديل فئة الثيم
  const themeClass =
    settings.theme === 'excel-green' ? 'theme-excel' :
    settings.theme === 'classic-blue' ? 'theme-blue' :
    settings.theme === 'dark-mode' ? 'theme-dark bg-stone-950 text-stone-100' :
    'theme-purple theme-dynamic';

  return (
    <div 
      className={`min-h-screen flex flex-col font-['Cairo',sans-serif] select-text transition-colors duration-200 ${themeClass}`} 
      style={{ fontSize: `${settings.fontSize}px` }}
      dir="rtl"
    >
      {/* ═══ منظومة التنبيهات المنبثقة ═══ */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* ═══ الترويسة الرسمية المبسطة ═══ */}
      {settings.viewMode !== 'clean' && (
        <Header
          settings={settings}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
          totalRecordsCount={records.length}
          filteredCount={filteredRecords.length}
          sharedCount={sharedCount}
          undoCount={undoCount}
          onOpenHelp={() => setIsHelpModalOpen(true)}
          onOpenStats={() => setIsStatsModalOpen(true)}
        />
      )}

      {/* ═══ شريط الأدوات المنظم والمبسط ═══ */}
      <Toolbar
        onAddNew={handleAddNew}
        onUndo={handleUndo}
        undoCount={undoCount}
        selectedCount={selectedIds.size}
        onBulkDelete={handleBulkDelete}
        onAutoAnnotateOverlaps={handleAutoAnnotateOverlaps}
        onOpenMojibakeScanner={() => setIsMojibakeModalOpen(true)}
        onOpenAdvancedExport={() => setIsAdvancedExportOpen(true)}
        onOpenPrint={() => setIsPrintModalOpen(true)}
        onOpenAuditLog={() => {
          setAuditTargetRecord(null);
          setIsAuditModalOpen(true);
        }}
      />

      {/* ═══ شريط البحث والتصفية المتعددة ═══ */}
      <SearchBar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        filter={filter}
        onFilterChange={(newF) => setFilter({ ...filter, ...newF })}
        sortField={sortField}
        sortDirection={sortDirection}
        onSortChange={(field) => {
          if (sortField === field) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
          } else {
            setSortField(field);
            setSortDirection('asc');
          }
        }}
      />

      {/* ═══ شريط وسوم المأذونيات الملونة والعدادات ═══ */}
      <NotarizationTags
        selectedNotarization={filter.notarization}
        onSelect={(not) => setFilter({ ...filter, notarization: not })}
        counts={notarizationCounts}
        totalCount={records.length}
      />

      {/* ═══ جدول البيانات الرئيسي ═══ */}
      <DataTable
        records={filteredRecords}
        selectedIds={selectedIds}
        onToggleSelect={handleToggleSelect}
        onToggleSelectAll={handleToggleSelectAll}
        onEdit={handleEditRecord}
        onDelete={handleDeleteRecord}
        onOpenAudit={(rec) => {
          setAuditTargetRecord(rec);
          setIsAuditModalOpen(true);
        }}
        density={settings.tableDensity}
        viewMode={settings.viewMode}
        showSharedBadge={settings.showSharedBadge}
        fontSize={settings.fontSize}
      />

      {/* ═══ شريط الإنتاجية العائم السريع ═══ */}
      <FloatingProductivityBar
        undoCount={undoCount}
        onUndo={handleUndo}
        onAddNew={handleAddNew}
        onOpenStats={() => setIsStatsModalOpen(true)}
        onOpenHelp={() => setIsHelpModalOpen(true)}
        selectedCount={selectedIds.size}
        onBulkDelete={handleBulkDelete}
        filteredCount={filteredRecords.length}
        totalCount={records.length}
      />

      {/* ═══ النوافذ المنبثقة ═══ */}
      {/* 1. نافذة الإضافة والتعديل */}
      <RecordModal
        isOpen={isRecordModalOpen}
        onClose={() => setIsRecordModalOpen(false)}
        recordToEdit={editingRecord}
        onSave={handleSaveRecord}
        allRecords={records}
        currentIndex={sequentialIndex !== null ? sequentialIndex : undefined}
        totalCount={filteredRecords.length}
        onNavigateNext={
          sequentialIndex !== null && sequentialIndex + 1 < filteredRecords.length
            ? () => {
                const nextRec = filteredRecords[sequentialIndex + 1];
                setEditingRecord(nextRec);
                setSequentialIndex(sequentialIndex + 1);
              }
            : undefined
        }
        onNavigatePrev={
          sequentialIndex !== null && sequentialIndex > 0
            ? () => {
                const prevRec = filteredRecords[sequentialIndex - 1];
                setEditingRecord(prevRec);
                setSequentialIndex(sequentialIndex - 1);
              }
            : undefined
        }
      />

      {/* 2. نافذة فض النزاع ومنع التكرار */}
      {duplicateModalData.incomingRecord && duplicateModalData.duplicateResult && (
        <DuplicateModal
          isOpen={duplicateModalData.isOpen}
          onClose={() =>
            setDuplicateModalData({ isOpen: false, incomingRecord: null, duplicateResult: null })
          }
          incomingRecord={duplicateModalData.incomingRecord}
          duplicateResult={duplicateModalData.duplicateResult}
          onResolve={handleResolveDuplicate}
        />
      )}

      {/* 3. نافذة سجل التعديلات والتوثيق القانوني */}
      <AuditTrailModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        auditEntries={auditLog}
        targetRecord={auditTargetRecord}
        settings={settings}
      />

      {/* 4. نافذة إعداد وطباعة التقارير */}
      <PrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        records={filteredRecords}
        settings={settings}
      />

      {/* 5. مركز ترميم النصوص التالفة (Mojibake) */}
      <MojibakeModal
        isOpen={isMojibakeModalOpen}
        onClose={() => setIsMojibakeModalOpen(false)}
        records={records}
        onRepairAll={handleRepairAllMojibake}
      />

      {/* 6. نافذة الإحصائيات الجغرافية */}
      <StatsModal
        isOpen={isStatsModalOpen}
        onClose={() => setIsStatsModalOpen(false)}
        records={records}
      />

      {/* 7. دليل الاختصارات والتشغيل */}
      <HelpModal isOpen={isHelpModalOpen} onClose={() => setIsHelpModalOpen(false)} />

      {/* 8. نافذة التصدير المتقدم ونظام الحماية الشامل */}
      <AdvancedExportModal
        isOpen={isAdvancedExportOpen}
        onClose={() => setIsAdvancedExportOpen(false)}
        filteredRecords={filteredRecords}
        allRecords={records}
        selectedCount={selectedIds.size}
        settings={settings}
        onExecuteExport={handleExecuteAdvancedExport}
      />

      {/* 9. 🎛️ لوحة التحكم والإعدادات الشاملة (7 تبويبات) */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        allRecords={records}
        auditLog={auditLog}
        onExportFullBackup={handleExportBackup}
        onImportBackupFile={handleImportBackupFile}
        onResetAllData={handleResetDatabase}
        onResetSettingsToDefault={handleResetSettingsToDefault}
      />
    </div>
  );
}
