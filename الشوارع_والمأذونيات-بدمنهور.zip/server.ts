import express from 'express';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';

const execFileAsync = promisify(execFile);

const SOFFICE_CANDIDATES = [
  '/usr/bin/soffice',
  '/usr/bin/libreoffice',
  '/usr/local/bin/soffice',
  '/opt/libreoffice/program/soffice',
];

function findSoffice(): string | null {
  for (const candidate of SOFFICE_CANDIDATES) {
    try {
      fs.accessSync(candidate, fs.constants.X_OK);
      return candidate;
    } catch {
      // try next
    }
  }
  return null;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '100mb' }));

  // API Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // 1. LibreOffice status endpoint
  app.get('/api/libreoffice/status', async (_req, res) => {
    const soffice = findSoffice();
    if (!soffice) {
      res.json({ installed: false, error: 'LibreOffice غير مثبت على خادم النظام' });
      return;
    }
    try {
      const { stdout } = await execFileAsync(soffice, ['--version'], { timeout: 10000 });
      res.json({ installed: true, version: stdout.trim(), path: soffice });
    } catch (err) {
      res.json({ installed: false, error: String(err) });
    }
  });

  // 2. Convert an uploaded file (base64 JSON body) to a target format
  app.post('/api/libreoffice/convert', async (req, res) => {
    const { filename, data, target } = req.body || {};
    if (!filename || !data || !target) {
      res.status(400).json({ error: 'filename, data (base64) and target are required' });
      return;
    }
    const soffice = findSoffice();
    if (!soffice) {
      res.status(500).json({ error: 'LibreOffice غير مثبت على خادم النظام' });
      return;
    }

    const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'street_lo_'));
    const srcPath = path.join(workDir, path.basename(filename));
    const outDir = path.join(workDir, 'out');
    fs.mkdirSync(outDir, { recursive: true });

    try {
      fs.writeFileSync(srcPath, Buffer.from(data, 'base64'));
      await execFileAsync(
        soffice,
        ['--headless', '--norestore', '--convert-to', target, '--outdir', outDir, srcPath],
        { timeout: 60000 }
      );
      const convertedFiles = fs.readdirSync(outDir);
      const converted = convertedFiles[0];
      if (!converted) {
        res.status(500).json({ error: 'فشل التحويل: لم يتم إنتاج ملف ناتج' });
        return;
      }
      const filePath = path.join(outDir, converted);
      res.download(filePath, converted, () => {
        fs.rmSync(workDir, { recursive: true, force: true });
      });
    } catch (err) {
      fs.rmSync(workDir, { recursive: true, force: true });
      res.status(500).json({ error: String(err) });
    }
  });

  // 3. Save a file and open it in LibreOffice GUI
  app.post('/api/libreoffice/open', async (req, res) => {
    const { filename, data } = req.body || {};
    if (!filename || !data) {
      res.status(400).json({ error: 'filename and data (base64) are required' });
      return;
    }
    const soffice = findSoffice();
    if (!soffice) {
      res.status(500).json({ error: 'LibreOffice غير مثبت على خادم النظام' });
      return;
    }

    const target = path.join(os.tmpdir(), `street_app_open_${Date.now()}_${path.basename(filename)}`);
    try {
      fs.writeFileSync(target, Buffer.from(data, 'base64'));
      execFile(soffice, [target], (err) => {
        if (err) console.error('soffice open error:', err.message);
      });
      res.json({ ok: true, message: 'تم فتح الملف في ليبرأوفيس' });
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });

  // 4. Download System Features Markdown documentation
  app.get('/api/features-md', (_req, res) => {
    const mdPath = path.join(process.cwd(), 'SYSTEM_FEATURES.md');
    if (fs.existsSync(mdPath)) {
      res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="SYSTEM_FEATURES.md"');
      res.sendFile(mdPath);
    } else {
      res.status(404).send('Not found');
    }
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
