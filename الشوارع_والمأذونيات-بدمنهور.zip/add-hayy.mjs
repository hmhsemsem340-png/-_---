import XLSX from 'xlsx';
import { writeFileSync } from 'fs';

function normalize(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ');
}

const wbBase = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const wsBase = wbBase.Sheets['البيانات المنظمة'];
const baseRows = XLSX.utils.sheet_to_json(wsBase, { header: 1 });

const baseRecords = [];
for (let i = 1; i < baseRows.length; i++) {
  const r = baseRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  baseRecords.push({
    id: String(i),
    name,
    permission: r[1] ? String(r[1]).trim() : '',
    metadata: r[2] ? String(r[2]).trim() : '',
    category: r[3] ? String(r[3]).trim() : 'شارع'
  });
}

const baseNorm = new Set(baseRecords.map(r => normalize(r.name)));

const wbNew = XLSX.readFile('/home/sam2/Videos/مواقع الشوارع في حي دمنهور.xls');
const wsNew = wbNew.Sheets[wbNew.SheetNames[0]];
const newRows = XLSX.utils.sheet_to_json(wsNew, { header: 1 });

const newOnly = [];
for (let i = 3; i < newRows.length; i++) {
  const r = newRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const norm = normalize(name);
  if (!baseNorm.has(norm)) {
    const area = r[1] ? String(r[1]).trim() : '';
    newOnly.push({ name, area, norm });
  }
}

console.log('New streets to add:', newOnly.length);
newOnly.forEach((r, idx) => {
  console.log(`  ${idx + 1}. [${r.name}] area=${r.area}`);
});

let nextId = baseRecords.length + 1;
const added = newOnly.map(r => {
  const rec = {
    id: String(nextId++),
    name: r.name,
    permission: r.area,
    metadata: '',
    category: 'حي'
  };
  return rec;
});

const allRecords = [...baseRecords, ...added];

const lines = allRecords.map(r => {
  const esc = (s) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  return `  { id: '${r.id}', name: '${esc(r.name)}', permission: '${esc(r.permission)}', metadata: '${esc(r.metadata)}', category: '${esc(r.category)}' },`;
});

const content = `import { RecordItem } from '../types';

export const INITIAL_RECORDS: RecordItem[] = [
${lines.join('\n')}
];
`;

writeFileSync('/home/sam2/Music/الشوارع_والمأذونيات/src/data/initialData.ts', content, 'utf-8');
console.log('\nWrote initialData.ts with', allRecords.length, 'records');
console.log('Added', added.length, 'new أحياء streets');