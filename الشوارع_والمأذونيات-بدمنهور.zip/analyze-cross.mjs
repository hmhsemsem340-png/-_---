import XLSX from 'xlsx';

const wb = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const ws = wb.Sheets['البيانات المنظمة'];
const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

const official = ['شبرا بحري', 'شبرا قبلي', 'طاموس', 'قرطسا بحري', 'قرطسا قبلي', 'سكنيدة', 'نقرها'];

const cross = {};
for (let i = 1; i < rows.length; i++) {
  const r = rows[i];
  if (!r || !r[0]) continue;
  const perm = (r[1] || '').trim() || '(فارغ)';
  const cat = (r[3] || '').trim() || '(فارغ)';
  const key = `${perm} | ${cat}`;
  cross[key] = (cross[key] || 0) + 1;
}

console.log('=== Cross-tab: permission × category ===');
Object.entries(cross).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => {
  console.log(`  ${v}x  ${k}`);
});

console.log('\n=== Official permissions with non-official category ===');
Object.entries(cross).filter(([k]) => {
  const perm = k.split(' | ')[0];
  return official.includes(perm) && !k.includes('مأذونية رسمية');
}).forEach(([k, v]) => console.log(`  ${v}x  ${k}`));

console.log('\n=== Non-official (أحياء) with category مأذونية رسمية ===');
Object.entries(cross).filter(([k]) => {
  const perm = k.split(' | ')[0];
  return !official.includes(perm) && perm !== '(فارغ)' && k.includes('مأذونية رسمية');
}).forEach(([k, v]) => console.log(`  ${v}x  ${k}`));