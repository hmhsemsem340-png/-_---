import XLSX from 'xlsx';

const wb = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');

for (const sheetName of ['البيانات المنظمة', 'البيانات المنظمة_2']) {
  const ws = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const names = new Set();
  let dupCount = 0;
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r || !r[0]) continue;
    const n = String(r[0]).trim();
    if (names.has(n)) dupCount++;
    names.add(n);
  }
  console.log(`Sheet [${sheetName}]: ${rows.length - 1} data rows, ${names.size} unique names, ${dupCount} duplicates`);
}

const ws1 = wb.Sheets['البيانات المنظمة'];
const ws2 = wb.Sheets['البيانات المنظمة_2'];
const rows1 = XLSX.utils.sheet_to_json(ws1, { header: 1 });
const rows2 = XLSX.utils.sheet_to_json(ws2, { header: 1 });

const names1 = new Set();
for (let i = 1; i < rows1.length; i++) {
  const r = rows1[i];
  if (r && r[0]) names1.add(String(r[0]).trim());
}
const names2 = new Set();
for (let i = 1; i < rows2.length; i++) {
  const r = rows2[i];
  if (r && r[0]) names2.add(String(r[0]).trim());
}

let overlap = 0;
for (const n of names1) {
  if (names2.has(n)) overlap++;
}
console.log(`Overlap between sheets: ${overlap}`);
console.log(`Sheet1 only: ${names1.size - overlap}, Sheet2 only: ${names2.size - overlap}`);