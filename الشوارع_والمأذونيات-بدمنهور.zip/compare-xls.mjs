import XLSX from 'xlsx';

function normalize(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ');
}

const wbBase = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const wsBase = wbBase.Sheets['البيانات المنظمة'];
const baseRows = XLSX.utils.sheet_to_json(wsBase, { header: 1 });

const baseRecords = [];
for (let i = 1; i < baseRows.length; i++) {
  const r = baseRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  baseRecords.push({
    name,
    permission: r[1] ? String(r[1]).trim() : '',
    metadata: r[2] ? String(r[2]).trim() : '',
    category: r[3] ? String(r[3]).trim() : 'شارع',
    norm: normalize(name)
  });
}

const wbNew = XLSX.readFile('/home/sam2/Videos/مواقع الشوارع في حي دمنهور.xls');
const wsNew = wbNew.Sheets[wbNew.SheetNames[0]];
const newRows = XLSX.utils.sheet_to_json(wsNew, { header: 1 });

const newRecords = [];
for (let i = 3; i < newRows.length; i++) {
  const r = newRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const area = r[1] ? String(r[1]).trim() : '';
  newRecords.push({
    name,
    area,
    norm: normalize(name)
  });
}

const baseNorm = new Map();
baseRecords.forEach(r => {
  if (!baseNorm.has(r.norm)) baseNorm.set(r.norm, []);
  baseNorm.get(r.norm).push(r);
});

const newNorm = new Map();
newRecords.forEach(r => {
  if (!newNorm.has(r.norm)) newNorm.set(r.norm, []);
  newNorm.get(r.norm).push(r);
});

let matched = 0;
let newOnly = 0;
let baseOnly = 0;
const matchedDetails = [];
const newOnlyDetails = [];

for (const r of newRecords) {
  if (baseNorm.has(r.norm)) {
    matched++;
    const base = baseNorm.get(r.norm)[0];
    matchedDetails.push({ newName: r.name, newArea: r.area, baseName: base.name, basePerm: base.permission, baseCat: base.category });
  } else {
    newOnly++;
    newOnlyDetails.push({ name: r.name, area: r.area });
  }
}

baseOnly = baseRecords.length - matched;

console.log('=== COMPARISON: أحياء file vs Base (القاعدة الأولى) ===');
console.log('Base records:', baseRecords.length);
console.log('New file records:', newRecords.length);
console.log('Matched (in both):', matched);
console.log('New only (in file, not in base):', newOnly);
console.log('Base only (in base, not in file):', baseOnly);

console.log('\n=== Matched samples (first 15) ===');
matchedDetails.slice(0, 15).forEach(d => {
  console.log(`  [${d.newName}] area=${d.newArea} | base: perm=${d.basePerm} cat=${d.baseCat}`);
});

console.log('\n=== New only samples (first 15) ===');
newOnlyDetails.slice(0, 15).forEach(d => {
  console.log(`  [${d.name}] area=${d.area}`);
});

console.log('\n=== New-only by area ===');
const newOnlyByArea = {};
newOnlyDetails.forEach(d => {
  const a = d.area || '(فارغ)';
  newOnlyByArea[a] = (newOnlyByArea[a] || 0) + 1;
});
Object.entries(newOnlyByArea).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log(`  ${v}x ${k}`));