import XLSX from 'xlsx';

const wb = XLSX.readFile('/home/sam2/Videos/مواقع الشوارع في حي دمنهور.xls');
const ws = wb.Sheets[wb.SheetNames[0]];
const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

const records = [];
for (let i = 3; i < rows.length; i++) {
  const r = rows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const area = r[1] ? String(r[1]).trim() : '';
  records.push({ name, area });
}

console.log('Total records:', records.length);

const areaCount = {};
records.forEach(r => {
  const a = r.area || '(فارغ)';
  areaCount[a] = (areaCount[a] || 0) + 1;
});
console.log('\n--- Area distribution ---');
Object.entries(areaCount).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => console.log(`  ${v}x ${k}`));

console.log('\n--- Sample records ---');
records.slice(0, 10).forEach(r => console.log(JSON.stringify(r)));

const emptyArea = records.filter(r => !r.area).length;
console.log('\nEmpty area:', emptyArea);

const uniqueNames = new Set(records.map(r => r.name));
console.log('Unique names:', uniqueNames.size);
console.log('Duplicates:', records.length - uniqueNames.size);