import * as XLSX from 'xlsx';
import { readFileSync, writeFileSync } from 'fs';
import { execSync } from 'child_process';

const dir = '/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/الملفات الرسمية هنا عنوان الحقيقة/';
const dataFile = './src/data/initialData.ts';

function norm(s) {
  return String(s).trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[^\u0600-\u06FF\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractOds(file) {
  const wb = XLSX.read(readFileSync(dir + file), { type: 'buffer' });
  const names = [];
  for (const sn of wb.SheetNames) {
    const ws = wb.Sheets[sn];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    for (const r of rows) {
      const cell = String(r[0] || '').trim();
      if (cell && !/^\d+$/.test(cell)) {
        names.push(cell);
      }
    }
  }
  return names;
}

function extractOdtStreets(file) {
  execSync(`unzip -o -q "${dir}${file}" content.xml -d /tmp/opencode/odt_x`);
  const content = readFileSync('/tmp/opencode/odt_x/content.xml', 'utf8');
  const texts = content.match(/<text:p[^>]*>(.*?)<\/text:p>/g) || [];
  const lines = [];
  for (const t of texts) {
    let s = t.replace(/<[^>]+>/g, '');
    s = s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    s = s.trim();
    if (s) lines.push(s);
  }
  const start = lines.findIndex(l => l.includes('الشوارع والطرق'));
  const end = lines.findIndex(l => l.includes('المعالم والمنشآت'));
  const section = lines.slice(start + 1, end);
  const names = [];
  let prevWasNumber = false;
  for (const l of section) {
    if (/^\d+$/.test(l)) {
      prevWasNumber = true;
      continue;
    }
    if (/^[أ-هـ]\./.test(l) || /^\d+\./.test(l)) {
      prevWasNumber = false;
      continue;
    }
    if (prevWasNumber) {
      names.push(l);
      prevWasNumber = false;
    }
  }
  return names;
}

const official = {
  'سكنيدة': extractOds('سكنيدة.ods'),
  'شبرا بحري': extractOds('شبرا بحري.ods'),
  'شبرا قبلي': extractOdtStreets('شبرا قبلي.odt'),
  'قرطسا بحري': extractOds('قرطسا بحري.ods'),
  'قرطسا قبلي': extractOds('قرطسا قبلي.ods'),
  'نقرها': extractOds('نقرها.ods'),
};

const officialNorm = {};
for (const [perm, names] of Object.entries(official)) {
  officialNorm[perm] = new Set(names.map(norm));
}

const overlapReport = {};
for (const [perm, set] of Object.entries(officialNorm)) {
  const overlaps = [];
  for (const [other, otherSet] of Object.entries(officialNorm)) {
    if (perm === other) continue;
    for (const n of set) {
      if (otherSet.has(n)) overlaps.push({ name: n, other });
    }
  }
  overlapReport[perm] = overlaps;
}

console.log('=== OVERLAPS BETWEEN OFFICIAL FILES ===');
for (const [perm, overlaps] of Object.entries(overlapReport)) {
  if (overlaps.length > 0) {
    console.log(`\n${perm}: ${overlaps.length} overlaps`);
    for (const o of overlaps) console.log(`  - ${o.name} (also in ${o.other})`);
  }
}

const src = readFileSync(dataFile, 'utf8');
const records = [];
const re = /\{\s*id:\s*'([^']+)'\s*,\s*name:\s*'([^']*)'\s*,\s*permission:\s*'([^']*)'\s*,\s*metadata:\s*'([^']*)'\s*,\s*category:\s*'([^']*)'\s*\}/g;
let m;
while ((m = re.exec(src)) !== null) {
  records.push({ id: m[1], name: m[2], permission: m[3], metadata: m[4], category: m[5] });
}
console.log(`\nBase records: ${records.length}`);

const summary = {};
for (const perm of Object.keys(official)) {
  const set = officialNorm[perm];
  const current = records.filter(r => r.permission === perm);
  const inOfficial = current.filter(r => set.has(norm(r.name)));
  const notInOfficial = current.filter(r => !set.has(norm(r.name)));
  const officialNames = [...set];
  const baseNames = new Set(records.map(r => norm(r.name)));
  const missing = officialNames.filter(n => !baseNames.has(n));
  const otherPermMatches = records.filter(r => r.permission !== perm && set.has(norm(r.name)));
  summary[perm] = { current: current.length, inOfficial: inOfficial.length, notInOfficial: notInOfficial.length, missing: missing.length, otherPermMatches: otherPermMatches.length };
  console.log(`\n=== ${perm} ===`);
  console.log(`  Current records: ${current.length}`);
  console.log(`  In official file: ${inOfficial.length}`);
  console.log(`  NOT in official file (→ غير رسمي): ${notInOfficial.length}`);
  console.log(`  Official names missing from base: ${missing.length}`);
  console.log(`  Other-permission records matching official: ${otherPermMatches.length}`);
  if (missing.length > 0) {
    console.log(`  Missing names: ${JSON.stringify(missing)}`);
  }
  if (otherPermMatches.length > 0) {
    console.log(`  Other-perm matches:`);
    for (const r of otherPermMatches) console.log(`    - ${r.name} (currently ${r.permission})`);
  }
}

console.log('\n=== SUMMARY ===');
console.log(JSON.stringify(summary, null, 2));