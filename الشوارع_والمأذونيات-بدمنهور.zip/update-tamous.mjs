import XLSX from 'xlsx';
import { writeFileSync } from 'fs';

function normalize(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .replace(/[إأآا]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ');
}

// 1. Read base from ODS
const wbBase = XLSX.readFile('/home/sam2/Videos/شوارع_دمنهور_النهائي.ods');
const wsBase = wbBase.Sheets['البيانات المنظمة'];
const baseRows = XLSX.utils.sheet_to_json(wsBase, { header: 1 });

const records = [];
for (let i = 1; i < baseRows.length; i++) {
  const r = baseRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  records.push({
    id: String(i),
    name,
    permission: r[1] ? String(r[1]).trim() : '',
    metadata: r[2] ? String(r[2]).trim() : '',
    category: r[3] ? String(r[3]).trim() : 'شارع'
  });
}

// 2. Add the 17 أحياء streets
const wbNew = XLSX.readFile('/home/sam2/Videos/مواقع الشوارع في حي دمنهور.xls');
const wsNew = wbNew.Sheets[wbNew.SheetNames[0]];
const newRows = XLSX.utils.sheet_to_json(wsNew, { header: 1 });

const baseNorm = new Set(records.map(r => normalize(r.name)));
let nextId = records.length + 1;
for (let i = 3; i < newRows.length; i++) {
  const r = newRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const norm = normalize(name);
  if (!baseNorm.has(norm)) {
    const area = r[1] ? String(r[1]).trim() : '';
    records.push({ id: String(nextId++), name, permission: area, metadata: '', category: 'حي' });
    baseNorm.add(norm);
  }
}

// 3. Read official طاموس file
const wbT = XLSX.readFile('/run/media/sam2/BackupPlus/شوارع دمنهور 2025 حسام الخولي حتى أول يونيه 06/شوارع دمنهور/طاموس.ods');
const wsT = wbT.Sheets[wbT.SheetNames[0]];
const tRows = XLSX.utils.sheet_to_json(wsT, { header: 1 });

const tamousNorm = new Set();
for (let i = 1; i < tRows.length; i++) {
  const r = tRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (name) tamousNorm.add(normalize(name));
}

// 4. Apply updates
let reclassified = 0;
let updatedToTamous = 0;
let addedNew = 0;

records.forEach(r => {
  const norm = normalize(r.name);
  if (r.permission === 'طاموس') {
    if (!tamousNorm.has(norm)) {
      r.permission = 'مأذونية غير رسمي';
      r.category = 'مأذونية غير رسمي';
      reclassified++;
    }
  } else if (tamousNorm.has(norm)) {
    r.permission = 'طاموس';
    r.category = 'مأذونية رسمية';
    updatedToTamous++;
  }
});

// 5. Add official طاموس streets not in base
for (let i = 1; i < tRows.length; i++) {
  const r = tRows[i];
  if (!r || !r[0]) continue;
  const name = String(r[0]).trim();
  if (!name) continue;
  const norm = normalize(name);
  if (!baseNorm.has(norm)) {
    records.push({ id: String(nextId++), name, permission: 'طاموس', metadata: '', category: 'مأذونية رسمية' });
    baseNorm.add(norm);
    addedNew++;
  }
}

// 6. Write initialData.ts
const lines = records.map(r => {
  const esc = (s) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  return `  { id: '${r.id}', name: '${esc(r.name)}', permission: '${esc(r.permission)}', metadata: '${esc(r.metadata)}', category: '${esc(r.category)}' },`;
});

const content = `import { RecordItem } from '../types';

export const INITIAL_RECORDS: RecordItem[] = [
${lines.join('\n')}
];
`;

writeFileSync('/home/sam2/Music/الشوارع_والمأذونيات/src/data/initialData.ts', content, 'utf-8');

console.log('=== UPDATE SUMMARY ===');
console.log('Total records:', records.length);
console.log('Reclassified طاموس → مأذونية غير رسمي:', reclassified);
console.log('Updated to طاموس (official):', updatedToTamous);
console.log('Added new طاموس streets:', addedNew);

const tamousCount = records.filter(r => r.permission === 'طاموس').length;
const unofficialCount = records.filter(r => r.permission === 'مأذونية غير رسمي').length;
console.log('\nFinal counts:');
console.log('  permission=طاموس:', tamousCount);
console.log('  permission=مأذونية غير رسمي:', unofficialCount);